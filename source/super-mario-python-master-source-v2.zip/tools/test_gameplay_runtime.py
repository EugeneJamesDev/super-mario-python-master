"""Exercise the game and map editor through their normal runtime objects."""

import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from types import SimpleNamespace

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

from classes.Dashboard import Dashboard
from classes.EntityCollider import EntityCollider
from classes.Level import Level
from classes.Menu import Menu
from classes.Sound import Sound
from entities.Goomba import Goomba
from entities.Mario import Mario
from tools.mapmaker import MapMaker


def check_gameplay(screen):
    # Force the silent path even on machines with a working SDL audio driver.
    pygame.mixer.quit()
    sound = Sound()
    dashboard = Dashboard("img/sheets/font.png", 8, screen)
    dashboard.save_high_score = lambda: None
    level = Level(screen, sound, dashboard)
    menu = Menu(screen, dashboard, level, sound)
    with TemporaryDirectory() as temp:
        settings = Path(temp) / "settings.json"
        settings.write_text("{")
        menu.loadSettings(settings)
        assert not menu.music and not menu.sfx
        menu.saveSettings(settings / "nested.json")
        dashboard.highScorePath = Path(temp) / "highscore.json"
        dashboard.highScorePath.write_text("[]")
        assert dashboard._load_high_score() == 0

    menu.chooseLevel()
    menu._move_picker_world(1)
    menu._move_picker_stage(-1)
    assert menu.currSelectedLevel == 2
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_TAB))
    menu.update()
    assert menu.selected_character == "luigi"

    for index, stage in enumerate((*Menu.SMB1_STAGES, "Infinity")):
        if stage == "Infinity":
            level.load_endless(seed=12)
        else:
            level.loadLevel(stage)
        player = Mario(0, 0, level, screen, dashboard, sound,
                       character=("mario", "luigi")[index % 2])
        assert level.player is player and player not in level.entityList
        for _ in range(90):
            level.drawLevel(player.camera)
            dashboard.update()
            player.update()
        assert not player.restart, f"{stage} killed the idle player at spawn"
        if stage in {"World1-2", "World1-4"}:
            assert level.level[0][0].sprite is level.get_theme_sprite("sky")

    # Near-zero-capability controllers must not be polled for missing controls.
    player.input.joystick = SimpleNamespace(
        get_numaxes=lambda: 0, get_numhats=lambda: 0, get_numbuttons=lambda: 0
    )
    player.input.checkForControllerInput()
    player.pauseObj.joystick = player.input.joystick
    player.pauseObj.checkControllerInput()

    player.rect.topleft = (24, 40)
    player.shootFire()
    assert player.fireballCount == player.maxFireballs
    player.powerup(1)
    player.shootFire()
    bolt = level.entityList[-1]
    assert abs(bolt.rect.x - player.rect.x) <= bolt.rect.width
    assert abs(bolt.rect.y - player.rect.y) <= player.rect.height
    bolt.rect.x = 10100
    bolt.update(player.camera)
    assert bolt.alive, "Infinity projectiles should survive past world x=10000"
    goomba = Goomba(screen, level.sprites.spriteCollection, 3, 1, level, sound)
    level.entityList.append(goomba)
    bolt.rect.topleft = goomba.rect.topleft
    bolt.update(player.camera)
    assert goomba.alive is False and bolt.alive is None

    level.addKoopa(5, 8)
    koopa = level.entityList[-1]
    player.killEntity(koopa)
    player.rect.midright = koopa.rect.center
    player.vel.y = 0
    player.checkEntityCollision()
    assert koopa.bouncing and not player.rect.colliderect(koopa.rect)

    player.rect.bottom = koopa.rect.bottom - 1
    player.rect.centerx = koopa.rect.centerx
    player.vel.y = 1
    assert not EntityCollider(player).check(koopa).isTop, "side contact counted as a stomp"

    player.rect.topleft = (16, -48)
    player.vel.y = -4
    player.collision.checkY()
    assert not player.restart and player.vel.y == -4, "jump above screen hit the floor"
    player.rect.top = len(level.level) * 32
    player.collision.checkY()
    assert player.dying and not player.restart
    for _ in range(24):
        player.update()
    assert player.restart, "falling out of the map should end the run"


def check_block_interactions(screen):
    sound = Sound()
    dashboard = Dashboard("img/sheets/font.png", 8, screen)
    level = Level(screen, sound, dashboard)
    level.loadLevel("World1-1")
    player = Mario(0, 0, level, screen, dashboard, sound)

    level.addCoinBox(2, 8)
    level.addCoinBrick(4, 8)
    level.addBrickBlock(6, 8, contents="FireFlower")
    for column in (2, 4, 6):
        block = level.level[8][column].block
        player.rect.midtop = (block.rect.centerx, block.rect.bottom + 4)
        player.vel.y = -10
        player.moveMario()
        assert block.triggered, f"{type(block).__name__} did not react to an upward hit"
    assert dashboard.coins == 2
    flower = level.entityList[-1]
    assert flower.item_name == "fire_flower"
    player.rect.topleft = flower.rect.topleft
    player.checkEntityCollision()
    assert player.powerUpState == 1 and dashboard.points == 500

    player.rect.x = 40 * 32
    player.camera.move()
    assert player.camera.x < 0
    player.rect.x = 0
    player.camera.move()
    assert player.camera.x == 0
    player.rect.bottom = 13 * 32
    player.vel.y = 0.3
    player.moveMario()
    assert player.onGround


def check_underwater_death(screen):
    pygame.mixer.quit()
    sound = Sound()
    dashboard = Dashboard("img/sheets/font.png", 8, screen)
    level = Level(screen, sound, dashboard)
    level.loadLevel("World2-2")
    player = Mario(16, 3, level, screen, dashboard, sound)

    player._sync_water_physics()
    assert player.inWater, "underwater death regression must run in the water"
    player._take_damage()
    assert player.dying and not player.restart
    player._take_damage()
    assert player._death_frame == 0, "repeated underwater damage restarted the death transition"

    for _ in range(24):
        player.update()
    assert player.restart, "underwater death should finish and restart the game"


def check_editor_round_trip():
    editor = MapMaker()
    assert editor._place_sprite("ground", 0, 13)
    assert editor._place_sprite("hardBlock", 3, 10)
    assert editor._place_pipe(8, 9)
    for sprite, x in (("coin", 12), ("mushroom", 14), ("super_star", 16),
                      ("fire_flower_item", 18), ("bowser_redeyes_1", 22)):
        assert editor._place_sprite(sprite, x, 10)
    editor._toggle_play()
    expected = {"Coin", "RedMushroom", "SuperStar", "FireFlowerCollectible", "Bowser"}
    assert {type(entity).__name__ for entity in editor.play_level.entityList} == expected
    assert editor.mario.camera.y == 0
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_F5))
    editor.draw()
    assert editor.mario.pause
    pygame.event.post(pygame.event.Event(pygame.KEYDOWN, key=pygame.K_RETURN))
    editor.draw()
    assert not editor.mario.pause
    editor._toggle_play()

    # Write the actual editor export and load it via the same path as the game.
    cwd = Path.cwd()
    with TemporaryDirectory() as temp:
        try:
            os.chdir(temp)
            path = editor._save_map()
            editor.level.loadLevel(Path(path).stem)
        finally:
            os.chdir(cwd)

    for x, y, name in ((0, 13, "ground"), (3, 10, "hardBlock"), (8, 9, "pipeL")):
        tile = editor.level.level[y][x]
        assert tile.sprite is editor.level.sprites.spriteCollection[name]
        assert tile.rect == pygame.Rect(x * 32, y * 32, 32, 32)
    assert {type(entity).__name__ for entity in editor.level.entityList} == expected
    bowser = next(entity for entity in editor.level.entityList if type(entity).__name__ == "Bowser")
    assert bowser.variant == "redeyes"

    # The original editor grid and preview use the same pipe depth.
    assert editor._remove_at_position(8, 13)
    assert not editor.placed_entities["objects"]["pipe"]
    assert all(editor.level.level[row][x].sprite not in editor.level.pipeSprites
               for row in range(9, 15) for x in (8, 9))


def main():
    pygame.init()
    try:
        screen = pygame.display.set_mode((640, 480), pygame.RESIZABLE | pygame.SCALED)
        check_gameplay(screen)
        check_block_interactions(screen)
        check_underwater_death(screen)
        check_editor_round_trip()
    finally:
        pygame.quit()
    print("PASS: gameplay, underwater death, 32 stages, seeded Infinity, controller bounds, and editor round trip")


if __name__ == "__main__":
    main()
