import random

from classes.Collider import Collider


class LeftRightWalkTrait:
    # NES enemy speeds in blocks, converted to pixels (1 block = 32 pixels)
    BLOCK_SIZE = 32  # pixels per block

    def __init__(self, entity, level, turn_at_ledges=True):
        self.direction = random.choice([-1, 1])
        self.entity = entity
        self.turn_at_ledges = turn_at_ledges
        self.collDetection = Collider(self.entity, level)
        # NES: Goomba, Koopa speed = 0.046875 blocks/f → 1.5 px/frame
        self.speed = 0.046875 * self.BLOCK_SIZE
        self.entity.vel.x = self.speed * self.direction

    def update(self):
        # Check if entity is about to walk off a platform (no ground ahead)
        # This helps enemies properly interact with blocks they walk on
        if self.entity.vel.x == 0:
            self.direction *= -1
        elif self.turn_at_ledges:
            # Check if there's ground ahead in the direction we're moving
            # This prevents enemies from walking off platforms
            pos = self.entity.getPosIndex()
            # Check one block ahead horizontally
            check_x = pos.x + (1 if self.direction > 0 else -1)
            # Check if enemy is on ground (has collision below current position)
            # We check one row below the entity's current position
            entity_bottom_row = pos.y + 1  # Entity is typically 1 block tall, so check row below

            # Make sure we're checking valid coordinates
            if 0 <= entity_bottom_row < len(self.collDetection.level):
                row = self.collDetection.level[entity_bottom_row]
                tile_current_below = row[pos.x] if 0 <= pos.x < len(row) else None
                tile_next_below = row[check_x] if 0 <= check_x < len(row) else None

                # If we're on ground (current position has ground below) but next position doesn't, reverse
                if (tile_current_below and tile_current_below.rect is not None and
                    (tile_next_below is None or tile_next_below.rect is None)):
                    # About to walk off platform - reverse direction
                    self.direction *= -1

        self.entity.vel.x = self.speed * self.direction
        self.moveEntity()

    def moveEntity(self):
        self.entity.rect.y += self.entity.vel.y
        self.collDetection.checkY()
        self.entity.rect.x += self.entity.vel.x
        self.collDetection.checkX()
