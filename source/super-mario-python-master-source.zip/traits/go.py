import random
import pygame

from classes.SurfaceCache import flip_surface


class GoTrait:
    # NES SMB1 speeds in blocks, converted to pixels (1 block = 32 pixels)
    # Block values from NES: Min walk 0.0375, Max walk 0.09375, Run 0.125 blocks/frame
    BLOCK_SIZE = 32  # pixels per block

    # Convert block values to pixels:
    MIN_WALK_SPEED = 0.0375 * BLOCK_SIZE  # 0.0375 blocks/f → 1.2 px/frame
    WALK_SPEED = 0.09375 * BLOCK_SIZE     # 0.09375 blocks/f → 3.0 px/frame
    RUN_SPEED = 0.125 * BLOCK_SIZE        # 0.125 blocks/f → 4.0 px/frame (SMB1 cap)
    P_SPEED = 0.125 * BLOCK_SIZE          # SMB1 doesn't have P-speed, cap at 0.125 blocks/f

    # Acceleration values adjusted to reach these speeds
    WALK_ACCEL = 0.15  # Adjusted to reach 3.0 max walk
    RUN_ACCEL = 0.20   # Adjusted to reach 4.0 max run
    P_ACCEL = 0.20     # Same as run (no P-speed in SMB1)

    # Deceleration in blocks, converted to pixels
    RELEASE_DECEL = 0.03125 * BLOCK_SIZE  # 0.03125 blocks²/frame → 1.0 px/frame²
    TURN_DECEL = 0.03125 * BLOCK_SIZE     # Same for skid
    SKID_THRESHOLD = 0.05 * BLOCK_SIZE    # 0.05 blocks/f → 1.6 px/frame

    P_BUILD_FRAMES = 30

    def __init__(self, animation, screen, camera, ent, sprite_invert=False, color_offset_randomize=False):
        self.animation = animation
        self.direction = 0
        self.heading = 1
        self.screen = screen
        self.boost = False
        self.camera = camera
        self.entity = ent
        self.speedTier = "walk"
        self.running_timer = 0
        self.current_max_speed = self.WALK_SPEED
        self.current_accel = self.WALK_ACCEL
        self.sprite_invert = sprite_invert
        self.color_offset_randomize = color_offset_randomize
        self.color_offset = [0, 0, 0]  # RGB offset
        if self.color_offset_randomize:
            self._randomize_color_offset()

    def update(self):
        self._update_speed_profile()
        if self.direction != 0:
            if getattr(self.entity, "inWater", False):
                self.heading = self.direction
                self._apply_water_acceleration()
            else:
                self._apply_turn_resistance()
                self._accelerate()
            if not self.entity.inAir or getattr(self.entity, "inWater", False):
                self.animation.update()
        else:
            if not self.entity.inAir:
                self._apply_idle_animation()
            elif getattr(self.entity, "inWater", False):
                self.animation.update()
            if self.entity.onGround and not getattr(self.entity, "inWater", False):
                self._apply_friction()
            elif getattr(self.entity, "inWater", False):
                self.entity.vel.x = self._approach_zero(self.entity.vel.x, 0.20)
        if self.entity.inAir and not getattr(self.entity, "inWater", False):
            self.animation.inAir()
        # Always draw entity unless invincibility frames are active (flicker effect)
        if (self.entity.invincibilityFrames // 2) % 2 == 0:
            self.drawEntity()

    def _update_speed_profile(self):
        if getattr(self.entity, "inWater", False):
            self.speedTier = "run" if self.boost and self.direction != 0 else "walk"
            # SMB1 horizontal limits are $18 (walk) / $28 (B-run), or
            # 1.5 / 2.5 NES pixels per frame. The game draws at 2x scale.
            self.current_max_speed = 5.0 if self.speedTier == "run" else 3.0
            self.current_accel = 0.30 if self.speedTier == "run" else 0.20
            self.animation.deltaTime = 6
            return
        # NES SMB1: No P-speed (that's SMB3), only walk and run
        if self.boost and self.direction != 0:
            if self.entity.onGround and (
                self.entity.vel.x == 0 or self.heading == self.direction
            ):
                self.running_timer = min(self.running_timer + 1, self.P_BUILD_FRAMES)
            # SMB1 caps at run speed (2.0), no p_speed tier
            self.speedTier = "run"
        else:
            self.running_timer = 0
            self.speedTier = "walk"

        if self.speedTier == "walk":
            self.current_max_speed = self.WALK_SPEED
            self.current_accel = self.WALK_ACCEL
            self.animation.deltaTime = 4
        else:  # run (SMB1 only has walk and run)
            self.current_max_speed = self.RUN_SPEED
            self.current_accel = self.RUN_ACCEL
            self.animation.deltaTime = 3

    def _apply_turn_resistance(self):
        desired_heading = self.direction
        if (
            self.entity.onGround
            and self.entity.vel.x != 0
            and self.entity.vel.x * desired_heading < 0
        ):
            # NES skid: if speed > 0.8 and direction changes, apply skid deceleration
            if abs(self.entity.vel.x) > self.SKID_THRESHOLD:
                skid = min(self.TURN_DECEL, abs(self.entity.vel.x))
                self.entity.vel.x -= skid * (1 if self.entity.vel.x > 0 else -1)
            else:
                # Below threshold, normal turn
                skid = min(self.TURN_DECEL, abs(self.entity.vel.x))
                self.entity.vel.x -= skid * (1 if self.entity.vel.x > 0 else -1)
        self.heading = desired_heading

    def _accelerate(self):
        # NES: Walk speed range is 0.6-1.5, Run is up to 2.0
        if self.speedTier == "walk":
            # Walk: accelerate from 0.6 to 1.5
            if abs(self.entity.vel.x) < self.MIN_WALK_SPEED:
                # Start at minimum walk speed
                self.entity.vel.x = self.MIN_WALK_SPEED * self.heading
            elif self.entity.vel.x * self.heading < self.current_max_speed:
                self.entity.vel.x += self.current_accel * self.heading
                if abs(self.entity.vel.x) > self.current_max_speed:
                    self.entity.vel.x = self.current_max_speed * self.heading
        else:
            # Run: accelerate to the selected run cap.
            if self.entity.vel.x * self.heading < self.current_max_speed:
                self.entity.vel.x += self.current_accel * self.heading
                if abs(self.entity.vel.x) > self.current_max_speed:
                    self.entity.vel.x = self.current_max_speed * self.heading

    def _apply_water_acceleration(self):
        """Accelerate and coast in water without ground friction or speed carry."""
        target_speed = self.current_max_speed * self.heading
        delta = self.current_accel * self.heading
        if self.entity.vel.x * self.heading < target_speed:
            self.entity.vel.x += delta
            if self.entity.vel.x * self.heading > self.current_max_speed:
                self.entity.vel.x = target_speed

    @staticmethod
    def _approach_zero(value, amount):
        if value > 0:
            return max(0, value - amount)
        if value < 0:
            return min(0, value + amount)
        return 0
    def _apply_idle_animation(self):
        if abs(self.entity.vel.x) <= 0.01:
            self.entity.vel.x = 0
            self.animation.idle()
        else:
            self.animation.update()

    def _apply_friction(self):
        if self.entity.vel.x > 0:
            self.entity.vel.x = max(0, self.entity.vel.x - self.RELEASE_DECEL)
        elif self.entity.vel.x < 0:
            self.entity.vel.x = min(0, self.entity.vel.x + self.RELEASE_DECEL)

    def updateAnimation(self, animation):
        self.animation = animation
        self.update()

    def _randomize_color_offset(self):
        """Generate random RGB color offset for sprite tinting"""
        self.color_offset = [
            random.randint(-50, 50),
            random.randint(-50, 50),
            random.randint(-50, 50)
        ]

    def _apply_sprite_effects(self, image):
        """Apply sprite inversion and color offset effects"""
        if image is None:
            return image

        # Create a copy to avoid modifying the original
        result = image.copy()

        # Convert to a format that supports per-pixel alpha if needed
        if not result.get_flags() & pygame.SRCALPHA:
            result = result.convert_alpha()

        # Apply color offset if enabled
        if self.color_offset_randomize and any(self.color_offset):
            # Use get_at and set_at for reliable pixel manipulation
            width, height = result.get_size()
            for y in range(height):
                for x in range(width):
                    try:
                        pixel = result.get_at((x, y))
                        if pixel.a > 0:  # Only modify non-transparent pixels
                            r = max(0, min(255, pixel.r + self.color_offset[0]))
                            g = max(0, min(255, pixel.g + self.color_offset[1]))
                            b = max(0, min(255, pixel.b + self.color_offset[2]))
                            result.set_at((x, y), (r, g, b, pixel.a))
                    except (IndexError, ValueError):
                        pass

        # Apply sprite inversion if enabled
        if self.sprite_invert:
            # Invert colors (255 - value for each channel)
            width, height = result.get_size()
            for y in range(height):
                for x in range(width):
                    try:
                        pixel = result.get_at((x, y))
                        if pixel.a > 0:  # Only modify non-transparent pixels
                            result.set_at((x, y), (255 - pixel.r, 255 - pixel.g, 255 - pixel.b, pixel.a))
                    except (IndexError, ValueError):
                        pass

        return result

    def drawEntity(self):
        if self.animation is None or self.animation.image is None:
            return
        pos = self.entity.getPos()
        image = self.animation.image

        # Apply sprite effects
        if self.sprite_invert or self.color_offset_randomize:
            image = self._apply_sprite_effects(image)

        if self.heading == 1:
            self.screen.blit(image, pos)
        elif self.heading == -1:
            self.screen.blit(flip_surface(image, True, False), pos)

    def get_speed_tier(self):
        return self.speedTier
