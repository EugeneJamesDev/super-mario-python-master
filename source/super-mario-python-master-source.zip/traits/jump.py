class JumpTrait:
    # NES SMB1 jump physics: 4-phase gravity system
    # Values in blocks, converted to pixels (1 block = 32 pixels)
    BLOCK_SIZE = 32  # pixels per block

    # Initial jump velocities (in blocks, converted to pixels):
    # Tuned for 6-block maximum jump height (192 pixels)
    STANDING_JUMP_SPEED = -0.3125 * BLOCK_SIZE  # -0.3125 blocks/f → -10 px/frame
    RUNNING_JUMP_SPEED = -0.328125 * BLOCK_SIZE     # -0.328125 blocks/f → -10.5 px/frame
    MAX_RUNNING_JUMP_SPEED = -0.328125 * BLOCK_SIZE # Max running jump → -10.5 px/frame

    # Gravity (in blocks, converted to pixels):
    # Tuned to achieve exactly 6-block max height (192 pixels)
    RISING_GRAVITY = 0.0125 * BLOCK_SIZE      # 0.0125 blocks/f² → 0.4 px/frame²
    FALLING_GRAVITY = 0.021875 * BLOCK_SIZE     # 0.021875 blocks/f² → 0.7 px/frame²

    MAX_HOLD_FRAMES = 12
    HOLD_IMPULSE = 0.23  # Tuned for 6-block maximum jump height (net: 0.4 - 0.23 = 0.17 px/frame²)

    def __init__(self, entity):
        self.entity = entity
        self.jump_active = False
        self.jump_button = False
        self.hold_frames = 0
        self.is_rising = False  # Track if Mario is rising or falling

    def jump(self, jumping):
        if getattr(self.entity, "inWater", False):
            # SMB1 water uses its own jump profile and a 32-frame stroke timer.
            # A stroke starts on a fresh press only once Mario is falling or
            # level; repeated held input cannot create an endless upward boost.
            if (
                jumping
                and not self.jump_button
                and self.entity.swim_timer == 0
                and self.entity.vel.y >= 0
            ):
                self.entity.vel.y = -3.0  # ($FE + $80 fraction) x 2 display scale
                self.entity.swim_timer = 32
                self.entity.inAir = True
                self.entity.onGround = False
                self.entity.inJump = False
                self.jump_active = False
                self.hold_frames = 0
                self.entity.sound.play_sfx(self.entity.sound.jump)
            self.jump_button = bool(jumping)
            return
        if jumping:
            if self.entity.onGround and not self.jump_active:
                self._start_jump()
            self.jump_button = True
        else:
            self.jump_button = False
            self.hold_frames = self.MAX_HOLD_FRAMES

    def _start_jump(self):
        self.entity.sound.play_sfx(self.entity.sound.jump)
        self.entity.vel.y = self._initial_jump_velocity()
        self.entity.inAir = True
        self.entity.onGround = False
        self.entity.inJump = True
        self.jump_active = True
        self.hold_frames = 0
        self.is_rising = True  # Start by rising

    def _initial_jump_velocity(self):
        go_trait = None
        if getattr(self.entity, "traits", None):
            go_trait = self.entity.traits.get("goTrait")
        if go_trait is not None:
            tier = getattr(go_trait, "get_speed_tier", lambda: "walk")()
        else:
            tier = "walk"
        if tier == "p_speed":
            return self.MAX_RUNNING_JUMP_SPEED
        if tier == "run":
            return self.RUNNING_JUMP_SPEED
        return self.STANDING_JUMP_SPEED

    def update(self):
        if not self.jump_active:
            return
        if self.entity.onGround and self.entity.vel.y >= 0:
            self._end_jump()
            return

        # NES 4-phase gravity: rising vs falling
        if self.entity.vel.y < 0:
            # Rising: use rising gravity (+0.15)
            self.is_rising = True
            # Apply rising gravity (velocity increases toward 0)
            self.entity.vel.y += self.RISING_GRAVITY
        else:
            # Falling: use falling gravity (+0.35)
            self.is_rising = False
            # Apply falling gravity (velocity increases toward terminal)
            self.entity.vel.y += self.FALLING_GRAVITY

        # Apply jump hold impulse if button held
        if self.jump_button and self.hold_frames < self.MAX_HOLD_FRAMES and self.is_rising:
            self.entity.vel.y -= self.HOLD_IMPULSE
            self.hold_frames += 1
        else:
            self.hold_frames = self.MAX_HOLD_FRAMES

        # End jump phase when velocity becomes positive (start falling)
        if self.entity.vel.y >= 0:
            self.jump_active = False
            self.entity.inJump = False

    def _end_jump(self):
        self.jump_active = False
        self.entity.inJump = False
        self.hold_frames = 0

    def reset(self):
        self.jump_active = False
        self.jump_button = False
        self.hold_frames = 0
        self.entity.inAir = False
        self.entity.inJump = False
