class Collider:
    def __init__(self, entity, level):
        self.entity = entity
        self.level = level.level
        self.levelObj = level

    def _overlapping_tiles(self, rect):
        # Clamp the grid lookup. Jumps can take an actor above the first row,
        # where negative Python indices would otherwise inspect the floor.
        first_row = max(0, rect.top // 32)
        last_row = (rect.bottom - 1) // 32 + 1
        first_column = max(0, rect.left // 32)
        last_column = (rect.right - 1) // 32 + 1
        for row in self.level[first_row:max(first_row, last_row)]:
            for tile in row[first_column:last_column]:
                if tile is not None and tile.rect is not None and rect.colliderect(tile.rect):
                    yield tile

    def checkX(self):
        rect = self.entity.rect
        if rect.left < 0:
            rect.left = 0
            self.entity.vel.x = 0
        if not self.levelObj.endless:
            right_edge = self.levelObj.levelLength * 32
            if rect.right > right_edge:
                rect.right = right_edge
                self.entity.vel.x = 0
        for tile in self._overlapping_tiles(rect):
            obstacle = tile.rect
            if self.entity.vel.x > 0:
                rect.right = obstacle.left
            elif self.entity.vel.x < 0:
                rect.left = obstacle.right
            else:
                break
            self.entity.vel.x = 0

    def checkY(self):
        self.entity.onGround = False
        rect = self.entity.rect
        # A pit only kills once the entire actor has left the bottom of the map.
        # Checking for a fixed number of following rows killed tall actors early.
        if rect.top >= len(self.level) * 32:
            if getattr(self.entity, "isMario", False):
                self.entity.gameOver()
            else:
                self.entity.alive = None
            return
        # Rect rounds subpixel gravity away. Probe one pixel below so a
        # stationary player stays grounded between normal gravity steps.
        probe = rect.move(0, 1) if 0 < self.entity.vel.y < 1 else rect
        for tile in self._overlapping_tiles(probe):
            obstacle = tile.rect
            if self.entity.vel.y > 0:
                self.entity.onGround = True
                rect.bottom = obstacle.top
                self.entity.vel.y = 0
                for name in ("jumpTrait", "bounceTrait"):
                    trait = (self.entity.traits or {}).get(name)
                    if trait is not None:
                        trait.reset()
            elif self.entity.vel.y < 0:
                rect.top = obstacle.bottom
                self.entity.vel.y = 0
                return tile
            break
