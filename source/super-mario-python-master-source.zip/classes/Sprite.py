class Sprite:
    def __init__(self, image, colliding, animation=None, redrawBackground=False):
        self.image = image
        self.colliding = colliding
        self.animation = animation
        self.redrawBackground = redrawBackground

    def drawSprite(self, x, y, screen):
        image = self.image
        if self.animation is not None:
            self.animation.update()
            image = self.animation.image
        if image is not None:
            screen.blit(image, (x * 32, y * 32))
