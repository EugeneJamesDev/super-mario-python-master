import json
import sys
from pathlib import Path
import pygame

from classes.Paths import DATA_DIR, PROJECT_ROOT, read_save_path
from classes.Spritesheet import Spritesheet


class Menu:
    SMB1_STAGES = tuple(
        f"World{world}-{stage}"
        for world in range(1, 9)
        for stage in range(1, 5)
    )
    STAGES_PER_WORLD = 4

    def __init__(self, screen, dashboard, level, sound, selected_character="mario"):
        self.screen = screen
        self.sound = sound
        self.start = False
        self.inSettings = False
        self.state = 0
        self.level = level
        self.music = True
        self.sfx = True
        self.currSelectedLevel = 1
        self.levelNames = []
        self.inChoosingLevel = False
        self.picker_page = "infinity"
        self.picker_focus = 0
        self.dashboard = dashboard
        self.levelCount = 0
        self.levelPickerNotice = ""
        self._menu_background_cache = {}
        self.characters = ["mario", "luigi"]
        try:
            self.character_index = self.characters.index(selected_character.lower())
        except ValueError:
            self.character_index = 0
        self.spritesheet = Spritesheet("./img/references/title_screen.png")
        self.menu_banner = self.spritesheet.image_at(
            0,
            60,
            2,
            colorkey=[255, 0, 220],
            ignoreTileSize=True,
            xTileSize=180,
            yTileSize=88,
        )
        self.menu_dot = self.spritesheet.image_at(
            0, 150, 2, colorkey=[255, 0, 220], ignoreTileSize=True
        )
        self.menu_dot2 = self.spritesheet.image_at(
            20, 150, 2, colorkey=[255, 0, 220], ignoreTileSize=True
        )
        self.settings_path = DATA_DIR / "settings.json"
        self.loadSettings(read_save_path(self.settings_path.name))

    def update(self):
        self.checkInput()
        if self.start:
            return
        if self.inChoosingLevel:
            self.drawLevelChooser()
            return

        self.drawMenuBackground()
        self._draw_centered_text("HI SCORE", self._menu_center_x(), 18, 10)
        self._draw_centered_text(
            self.dashboard.highScoreString(), self._menu_center_x(), 32, 12
        )

        if not self.inSettings:
            self.drawMenu()
        else:
            self.drawSettings()
        pygame.display.flip()

    def drawDot(self):
        positions = self._menu_option_positions()
        if not positions:
            return
        self.state = max(0, min(self.state, len(positions) - 1))
        panel_x = round(self._menu_center_x() - 178)
        for index, y in enumerate(positions):
            sprite = self.menu_dot if index == self.state else self.menu_dot2
            self.screen.blit(sprite, (panel_x + 10, y))

    def loadSettings(self, url):
        try:
            with open(url) as jsonData:
                data = json.load(jsonData)
                if not isinstance(data, dict):
                    data = {}
        except (OSError, ValueError):
            data = {}
        browser_defaults = sys.platform == "emscripten"
        self.music = data.get("sound", browser_defaults) is True
        self.sfx = data.get("sfx", browser_defaults) is True
        self.sound.allowSFX = self.sfx
        if self.music:
            self.sound.music_channel.play(self.sound.soundtrack, loops=-1)
        else:
            self.sound.music_channel.stop()

    def saveSettings(self, url):
        data = {"sound": self.music, "sfx": self.sfx}
        path = Path(url)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with path.open("w") as outfile:
                json.dump(data, outfile)
        except OSError:
            # Read-only installations can still change settings for this session.
            pass

    def drawMenu(self):
        panel_x = round(self._menu_center_x() - 178)
        pygame.draw.rect(self.screen, (0, 0, 96), (panel_x, 246, 356, 142))
        self.drawBorder(panel_x, 246, 356, 142, (252, 188, 60), 4)
        self.drawDot()
        self.dashboard.drawText("CHOOSE LEVEL", panel_x + 50, 264, 22)
        self.dashboard.drawText("SETTINGS", panel_x + 50, 310, 22)
        self.dashboard.drawText("EXIT", panel_x + 50, 356, 22)

    def _menu_center_x(self):
        """Horizontal center of the SMB title plate on the main menu."""
        return 150 + self.menu_banner.get_width() / 2

    def drawMenuBackground(self, withBanner=True):
        cache_key = bool(withBanner)
        background = self._menu_background_cache.get(cache_key)
        if background is None:
            background = pygame.Surface((640, 480))
            sky = self.level.sprites.spriteCollection.get("sky").image
            ground = self.level.sprites.spriteCollection.get("ground").image
            for y in range(0, 13):
                for x in range(20):
                    background.blit(sky, (x * 32, y * 32))
            for y in range(13, 15):
                for x in range(20):
                    background.blit(ground, (x * 32, y * 32))
            if withBanner:
                background.blit(self.menu_banner, (150, 68))
            for index, key in enumerate(("bush_1", "bush_2", "bush_2", "bush_2", "bush_3")):
                sprite = self.level.sprites.spriteCollection.get(key)
                if sprite and sprite.image:
                    background.blit(sprite.image, ((14 + index) * 32, 12 * 32))
            goomba = self.level.sprites.spriteCollection.get("goomba-1")
            if goomba and goomba.image:
                background.blit(goomba.image, (int(18.5 * 32), 12 * 32))
            self._menu_background_cache[cache_key] = background
        self.screen.blit(background, (0, 0))
        self._draw_selected_character()

    def _draw_selected_character(self):
        sprite_key = f"{self.selected_character}_idle"
        sprite = self.level.sprites.spriteCollection.get(sprite_key)
        if sprite is None:
            sprite = self.level.sprites.spriteCollection.get("mario_idle")
        if sprite is not None:
            self.screen.blit(sprite.image, (2 * 32, 12 * 32))

    def _menu_option_positions(self):
        if self.inSettings:
            return [273, 309, 345, 381, 417]
        return [273, 313, 353]

    def _max_state_index(self):
        positions = self._menu_option_positions()
        return len(positions) - 1 if positions else 0

    def _player_setting_index(self):
        return 2

    def _settings_font_size(self):
        base_size = 24
        reduced_scale = 0.8  # 20% smaller than the default menu text
        return max(12, int(round(base_size * reduced_scale)))

    def _draw_centered_text(self, text, center_x, y, size):
        """Center bitmap text using the dashboard font's half-width spaces."""
        width = sum(size if char != " " else size // 2 for char in text)
        self.dashboard.drawText(text, center_x - width // 2, y, size)

    def drawSettings(self):
        pygame.draw.rect(self.screen, (0, 0, 96), (142, 260, 356, 194))
        self.drawBorder(142, 260, 356, 194, (252, 188, 60), 4)
        self.drawDot()
        font_size = self._settings_font_size()
        value_x = 374
        base_y = 273
        row_step = 36
        self.dashboard.drawText("MUSIC", 180, base_y, font_size)
        music_text = "ON" if self.music else "OFF"
        self.dashboard.drawText(music_text, value_x, base_y, font_size)
        sfx_y = base_y + row_step
        self.dashboard.drawText("SFX", 180, sfx_y, font_size)
        sfx_text = "ON" if self.sfx else "OFF"
        self.dashboard.drawText(sfx_text, value_x, sfx_y, font_size)
        player_y = base_y + row_step * 2
        player_text = f"PLAYER: {self.selected_character.upper()}"
        self.dashboard.drawText(player_text, 180, player_y, max(14, font_size - 3))
        self.dashboard.drawText("TAB: CHANGE PLAYER", 180, player_y + 23, 7)
        reset_y = base_y + row_step * 3
        self.dashboard.drawText("RESET HIGH SCORE", 180, reset_y, font_size)
        back_y = base_y + row_step * 4
        self.dashboard.drawText("BACK", 180, back_y, font_size)

    def chooseLevel(self):
        self.inChoosingLevel = True
        self.levelNames = self.loadLevelNames()
        self.currSelectedLevel = 1
        self.picker_page = "infinity"
        self.picker_focus = 0
        self.levelPickerNotice = ""

    def drawBorder(self, x, y, width, height, color, thickness):
        pygame.draw.rect(self.screen, color, (x, y, width, thickness))
        pygame.draw.rect(self.screen, color, (x, y + height - thickness, width, thickness))
        pygame.draw.rect(self.screen, color, (x, y, thickness, height))
        pygame.draw.rect(self.screen, color, (x + width - thickness, y, thickness, height))

    def drawLevelChooser(self):
        if self.picker_page == "worlds":
            self._draw_world_picker()
        else:
            self._draw_infinity_picker()
        pygame.display.flip()

    def _draw_infinity_picker(self):
        # The SMB title screen remains the backdrop; Infinity is the main
        # destination, with the original remakes one keypress away.
        self.drawMenuBackground(withBanner=True)
        x, y, width, height = 98, 254, 464, 152
        panel = pygame.Rect(x, y, width, height)
        self._draw_picker_panel(panel, True)

        mario = self.level.sprites.spriteCollection.get("mario_idle")
        if mario and mario.image:
            self.screen.blit(mario.image, (x + 34, y + 38))
        self._draw_centered_text("INFINITY WORLD", 354, y + 13, 20)
        self._draw_centered_text("ENDLESS RANDOMIZED SMB COURSE", 354, y + 40, 9)
        pygame.draw.rect(self.screen, (252, 188, 60), (x + 28, y + 64, width - 56, 2))

        first_y = y + 78
        focus_y = first_y + self.picker_focus * 27
        self.screen.blit(self.menu_dot, (x + 42, focus_y + 2))
        self._draw_centered_text("START INFINITY", 354, first_y, 12)
        self._draw_centered_text("BROWSE SMB1 WORLDS", 354, first_y + 27, 10)
        self._draw_centered_text("RIGHT / Q / E: OPEN SMB1 WORLDS", 354, y + 132, 8)

    def _draw_world_picker(self):
        self._draw_picker_background()
        self._draw_centered_text("SUPER MARIO BROS. WORLDS", 320, 14, 17)
        back_rect = pygame.Rect(94, 45, 452, 35)
        self._draw_picker_panel(back_rect, False)
        self._draw_centered_text("HOME / ESC: BACK TO INFINITY", 320, 56, 9)
        self._draw_centered_text("CHOOSE A COURSE", 320, 91, 10)

        grid_x, header_y, grid_y = 22, 108, 126
        cell_width, cell_height, column_gap, row_gap = 70, 45, 4, 3
        for world in range(8):
            x = grid_x + world * (cell_width + column_gap)
            self._draw_centered_text(f"WORLD {world + 1}", x + cell_width // 2, header_y, 8)
            for stage in range(4):
                selection = 2 + world * 4 + stage
                y = grid_y + stage * (cell_height + row_gap)
                rect = pygame.Rect(x, y, cell_width, cell_height)
                selected = self.currSelectedLevel == selection
                self._draw_picker_panel(rect, selected)
                stage_name = f"{world + 1}-{stage + 1}"
                level_name = f"World{stage_name}"
                available = self._level_is_available(level_name)
                self._draw_centered_text(stage_name, rect.centerx, y + 13, 13)
                if not available:
                    self._draw_centered_text("MISSING", rect.centerx, y + 31, 6)

        footer = pygame.Rect(22, 342, 596, 69)
        pygame.draw.rect(self.screen, (0, 0, 96), footer)
        self.drawBorder(footer.x, footer.y, footer.width, footer.height, (252, 188, 60), 3)
        self._draw_centered_text("ARROWS: COURSE / WORLD    Q / E: WORLD", 320, footer.y + 8, 9)
        self._draw_centered_text("ENTER: PLAY    ESC / HOME: INFINITY", 320, footer.y + 27, 9)
        notice = self.levelPickerNotice or "COURSE DATA LOADED - MAPS NOT ALL VERIFIED 1:1"
        self._draw_centered_text(notice, 320, footer.y + 49, 7)

    def _draw_picker_background(self):
        sprites = self.level.sprites.spriteCollection
        sky = sprites.get("sky")
        ground = sprites.get("ground")
        if sky and sky.image:
            for y in range(14):
                for x in range(20):
                    self.screen.blit(sky.image, (x * 32, y * 32))
        else:
            self.screen.fill((92, 148, 252))
        clouds = [sprites.get(name) for name in ("cloud1_1", "cloud1_2", "cloud1_3")]
        if all(cloud and cloud.image for cloud in clouds):
            self.screen.blit(clouds[0].image, (44, 72))
            self.screen.blit(clouds[1].image, (76, 72))
            self.screen.blit(clouds[2].image, (108, 72))
            self.screen.blit(clouds[0].image, (500, 72))
            self.screen.blit(clouds[1].image, (532, 72))
            self.screen.blit(clouds[2].image, (564, 72))
        if ground and ground.image:
            for y in range(13, 15):
                for x in range(20):
                    self.screen.blit(ground.image, (x * 32, y * 32))

    def _draw_picker_panel(self, rect, selected):
        fill = (0, 0, 112) if selected else (0, 0, 80)
        border = (252, 188, 60) if selected else (188, 220, 252)
        pygame.draw.rect(self.screen, fill, rect)
        self.drawBorder(rect.x, rect.y, rect.width, rect.height, border, 3 if selected else 1)

    def _cycle_character(self, direction=1):
        if not self.characters:
            return
        self.character_index = (self.character_index + direction) % len(self.characters)

    def _move_picker_world(self, direction):
        if self.picker_page != "worlds":
            self.picker_focus = 1
            self.picker_page = "worlds"
            if self.currSelectedLevel == 1:
                self.currSelectedLevel = 2
            self.levelPickerNotice = ""
            return
        if self.currSelectedLevel == 1:
            self.currSelectedLevel = 2 if direction > 0 else self.levelCount
        else:
            world = (self.currSelectedLevel - 2) // self.STAGES_PER_WORLD
            stage = (self.currSelectedLevel - 2) % self.STAGES_PER_WORLD
            world = (world + direction) % 8
            self.currSelectedLevel = 2 + world * self.STAGES_PER_WORLD + stage
        self.levelPickerNotice = ""

    def _move_picker_stage(self, direction):
        if self.picker_page != "worlds":
            self.picker_focus = max(0, min(1, self.picker_focus + direction))
            return
        if self.currSelectedLevel == 1:
            if direction > 0:
                self.currSelectedLevel = 2
        else:
            world = (self.currSelectedLevel - 2) // self.STAGES_PER_WORLD
            stage = (self.currSelectedLevel - 2) % self.STAGES_PER_WORLD
            stage = max(0, min(self.STAGES_PER_WORLD - 1, stage + direction))
            self.currSelectedLevel = 2 + world * self.STAGES_PER_WORLD + stage
        self.levelPickerNotice = ""

    def loadLevelNames(self):
        # Always expose the canonical catalog. Missing maps are marked in the
        # picker and cannot be launched until their authored JSON is present.
        res = ["Infinity", *self.SMB1_STAGES]
        self.levelCount = len(res)
        return res

    @staticmethod
    def _level_is_available(level_name):
        if level_name == "Infinity":
            return True
        levels_dir = PROJECT_ROOT / "levels"
        return (levels_dir / f"{level_name}.json").is_file()

    @property
    def selected_character(self):
        return self.characters[self.character_index]

    def checkInput(self):
        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    if self.inChoosingLevel and self.picker_page == "worlds":
                        self.picker_page = "infinity"
                        self.currSelectedLevel = 1
                        self.picker_focus = 0
                        self.levelPickerNotice = ""
                    elif self.inChoosingLevel or self.inSettings:
                        self.inChoosingLevel = False
                        self.inSettings = False
                        self.__init__(
                            self.screen,
                            self.dashboard,
                            self.level,
                            self.sound,
                            selected_character=self.selected_character,
                        )
                    else:
                        pygame.quit()
                        sys.exit()
                elif event.key == pygame.K_UP or event.key == pygame.K_k:
                    if self.inChoosingLevel:
                        self._move_picker_stage(-1)
                    elif self.state > 0:
                        self.state -= 1
                elif event.key == pygame.K_DOWN or event.key == pygame.K_j:
                    if self.inChoosingLevel:
                        self._move_picker_stage(1)
                    elif self.state < self._max_state_index():
                        self.state += 1
                elif event.key == pygame.K_LEFT or event.key == pygame.K_h:
                    if self.inChoosingLevel:
                        self._move_picker_world(-1)
                    elif self.inSettings and self.state == self._player_setting_index():
                        self._cycle_character(-1)
                elif event.key == pygame.K_RIGHT or event.key == pygame.K_l:
                    if self.inChoosingLevel:
                        self._move_picker_world(1)
                elif event.key in (pygame.K_q, pygame.K_PAGEUP):
                    if self.inChoosingLevel:
                        self._move_picker_world(-1)
                elif event.key == pygame.K_HOME:
                    if self.inChoosingLevel:
                        self.picker_page = "infinity"
                        self.currSelectedLevel = 1
                        self.picker_focus = 0
                        self.levelPickerNotice = ""
                elif event.key in (pygame.K_e, pygame.K_PAGEDOWN):
                    if self.inChoosingLevel:
                        self._move_picker_world(1)
                    elif self.inSettings and self.state == self._player_setting_index():
                        self._cycle_character(1)
                elif event.key == pygame.K_TAB:
                    if self.inChoosingLevel or (self.inSettings and self.state == self._player_setting_index()):
                        self._cycle_character()
                elif event.key == pygame.K_RETURN:
                    if self.inChoosingLevel:
                        if self.picker_page != "worlds" and self.picker_focus == 1:
                            self.picker_page = "worlds"
                            self.currSelectedLevel = 2
                            self.levelPickerNotice = ""
                            continue
                        selected_level = (
                            "Infinity"
                            if self.picker_page != "worlds"
                            else self.levelNames[self.currSelectedLevel - 1]
                        )
                        if not self._level_is_available(selected_level):
                            self.levelPickerNotice = f"{selected_level} has not been rebuilt yet"
                            continue
                        self.inChoosingLevel = False
                        self.dashboard.state = "start"
                        self.dashboard.time = 0
                        self.dashboard.points = 0
                        self.dashboard.coins = 0
                        if selected_level.lower() in ("endless", "infinity"):
                            self.level.load_endless()
                            self.dashboard.levelName = "INFINITY"
                        else:
                            self.level.loadLevel(selected_level)
                            try:
                                self.dashboard.levelName = selected_level.split("Level")[1]
                            except IndexError:
                                self.dashboard.levelName = selected_level
                        self.start = True
                        return
                    if not self.inSettings:
                        if self.state == 0:
                            self.chooseLevel()
                        elif self.state == 1:
                            self.inSettings = True
                            self.state = 0
                        elif self.state == 2:
                            pygame.quit()
                            sys.exit()
                    else:
                        if self.state == 0:
                            if self.music:
                                self.sound.music_channel.stop()
                                self.music = False
                            else:
                                self.sound.music_channel.play(self.sound.soundtrack, loops=-1)
                                self.music = True
                            self.saveSettings(self.settings_path)
                        elif self.state == 1:
                            if self.sfx:
                                self.sound.allowSFX = False
                                self.sfx = False
                            else:
                                self.sound.allowSFX = True
                                self.sfx = True
                            self.saveSettings(self.settings_path)
                        elif self.state == 2:
                            self._cycle_character()
                        elif self.state == 3:
                            self.dashboard.reset_high_score()
                        elif self.state == 4:
                            self.inSettings = False
                            self.state = 0
