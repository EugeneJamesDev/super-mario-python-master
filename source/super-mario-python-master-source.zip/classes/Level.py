import json
import math
import random
import pygame

from classes.Sprites import Sprites
from classes.Tile import Tile
from entities.BrickBlock import BrickBlock
from entities.Coin import Coin
from entities.CoinBrick import CoinBrick
from entities.Goomba import Goomba
from entities.MovingPlatform import MovingPlatform
from entities.Mushroom import RedMushroom
from entities.Koopa import Koopa
from entities.KoopaParatroopa import KoopaParatroopa
from entities.Springboard import Springboard
from entities.FortressBridge import FortressBridge
from entities.PiranhaPlant import PiranhaPlant
from entities.FireBar import FireBar
from entities.CoinBox import CoinBox
from entities.RandomBox import RandomBox
from entities.BuzzyBeetle import BuzzyBeetle
from entities.Lakitu import Lakitu
from entities.Spiny import Spiny
from entities.CheepCheep import CheepCheep
from entities.Blooper import Blooper
from entities.HammerBro import HammerBro
from entities.BulletBill import BulletBill
from entities.BillBlaster import BillBlaster
from entities.Podoboo import Podoboo
from entities.OneUpMushroom import OneUpMushroom
from entities.Bowser import Bowser
from entities.Princess import Princess
from entities.Vine import Vine


class Level:
    DEMO_PATTERN_FILE = "./levels/demo_patterns.json"
    FALLBACK_PATTERN_FILE = "./levels/infinity_patterns.json"
    _DEMO_STRUCTURES = None
    _INFINITY_WORLD_MOTIFS = None
    PIPE_LIP_HEIGHT = 12
    INTRO_SAFE_COLUMNS = 6
    MAX_JUMP_HEIGHT = 6  # Mario's max jump in blocks (traits/jump.py)
    SCENERY_TYPE_MAP = {
        "SMB_Goal_Pole": "goal_pole",
        "goal_pole": "goal_pole",
        "LargeFortressSMB": "large_fortress",
        "large_fortress": "large_fortress",
    }
    SCENERY_QUEUE_TYPES = {"goal_pole"}
    DAYTIME_BIOMES = frozenset(
        {"normal", "canyon", "ice", "mushroom"}
    )
    DARK_BIOMES = frozenset({"underground", "underwater", "fortress", "firebar"})

    def __init__(self, screen, sound, dashboard):
        self.sprites = Sprites()
        # SMB1's water area uses the bright blue water palette. The project
        # sheet's old fill was a muted surface-water color, so keep this exact
        # NES map color as the solid procedural underwater background.
        underwater_fill = self.sprites.spriteCollection.get("underwater_fill")
        if underwater_fill is not None:
            water = pygame.Surface((32, 32))
            water.fill((32, 56, 236))
            underwater_fill.image = water
        self.dashboard = dashboard
        self.sound = sound
        self.screen = screen
        self.level = None
        self.levelLength = 0
        self.stageBiome = "normal"
        self.stageWaterline = None
        self.stageWaterRegions = None
        self.entityList = []
        # Mario updates separately after the level draws its entities.
        self.player = None
        self.endless = False
        self.generatedColumns = 0
        self.columnBiomes = []
        self.gapRemaining = 0
        self.randomizer = random.Random()
        self.endlessBuffer = 85
        self.distanceRewarded = 0
        self.pipeSprites = {
            self.sprites.spriteCollection.get("pipeL"),
            self.sprites.spriteCollection.get("pipeR"),
            self.sprites.spriteCollection.get("pipe2L"),
            self.sprites.spriteCollection.get("pipe2R"),
        }
        self.pipeTopSprites = {
            self.sprites.spriteCollection.get("pipeL"),
            self.sprites.spriteCollection.get("pipeR"),
        }
        self.bushColumns = set()
        self.overlaySprites = []
        self.foregroundSprites = []
        self._overlayBuckets = {}
        self._foregroundBuckets = {}
        self._maxOverlayWidth = 0
        self._maxForegroundWidth = 0
        self._reset_generation_state()
        self.demoStructures = self._load_demo_structures()

    def loadLevel(self, levelname):
        with open(f"./levels/{levelname}.json", encoding="utf-8") as source:
            data = json.load(source)
        self.load_authored(data, levelname)

    def load_authored(self, data, levelname=""):
        # Switch out of endless mode before layer/object helpers consult biome
        # state; otherwise a previously active endless biome can leak into a
        # canonical stage load.
        self.endless = False
        self.player = None
        self.columnBiomes = []
        self.coinTiles = set()
        level_data = data.get("level", {})
        stage_defaults = {
            "World1-1": "normal",
            "World1-2": "underground",
            "World1-3": "normal",
            "World1-4": "fortress",
            "World2-2": "underwater",
            "World7-2": "underwater",
        }
        self.stageBiome = level_data.get(
            "biome", data.get("biome", stage_defaults.get(levelname, "normal"))
        )
        self.stageWaterline = level_data.get("waterline")
        self.stageWaterRegions = level_data.get("water_regions")
        if self.stageBiome == "underwater" and self.stageWaterline is None:
            # Some stitched reference sheets include a surface entrance and
            # exit around a fully submerged room; the x ranges are explicit.
            self.stageWaterline = 0 if levelname in {"World2-2", "World7-2"} else None
        if self.stageBiome == "underwater" and self.stageWaterRegions is None:
            self.stageWaterRegions = [[0, data["length"]]]
        # Reset generation-owned queues before placing static map features;
        # resetting afterward erased map overlays and foreground pipes.
        self._reset_generation_state()
        self.entityList = []
        self.loadLayers(data)
        self.loadObjects(data)
        self.loadEntities(data)
        self.levelLength = data["length"]
        self.generatedColumns = len(self.level[0]) if self.level else 0
        self.distanceRewarded = 0
        self._rebuild_coin_tile_cache()
        self._rebuild_pipe_foreground()

    def load_endless(self, seed=None, initial_columns=70):
        """
        Initializes infinity/endless mode level generation.
        
        Infinity mode generates levels procedurally as the player progresses.
        The generation system ensures:
        - No soft-locks (always provides passable terrain)
        - Varied gameplay (structures, enemies, collectibles)
        - Proper blending of background elements (clouds)
        
        Args:
            seed: Random seed for reproducible generation (None = random)
            initial_columns: Number of columns to generate at start (default 70)
        """
        self.endless = True
        self.player = None
        self.stageBiome = "normal"
        self.stageWaterline = None
        self.stageWaterRegions = None
        self.columnBiomes = []
        self.levelLength = float("inf")  # Infinite level length
        self.entityList = []
        # Initialize level as 15 rows (vertical tiles)
        self.level = [[] for _ in range(15)]
        # Initialize randomizer with seed for reproducibility
        self.randomizer = random.Random(seed)
        self.generatedColumns = 0
        self.gapRemaining = 0
        self.distanceRewarded = 0
        # Reset all generation state variables
        self._reset_generation_state()
        # Generate initial columns (safe starting area)
        for _ in range(initial_columns):
            self._append_column()

    def loadEntities(self, data):
        entities = data["level"].get("entities", {})
        for entry in entities.get("CoinBox", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addCoinBox(x, y)
        for entry in entities.get("Goomba", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addGoomba(x, y)
        for entry in entities.get("Koopa", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addKoopa(
                    x,
                    y,
                    variant=self._extract_value(entry, 2, "variant", default="green"),
                )
        for entry in entities.get("KoopaParatroopa", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addParatroopa(
                    x,
                    y,
                    variant=self._extract_value(entry, 2, "variant", default="green"),
                )
        for entry in entities.get("Springboard", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addSpringboard(x, y)
        for entry in entities.get("FortressBridge", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                length = self._extract_value(entry, 2, "length", default=5)
                self.addFortressBridge(x, y, length)
        for entry in entities.get("coin", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addCoin(x, y)
        for key, spawn in (
            ("RedMushroom", self.addRedMushroom),
            ("Star", self.addSuperStar),
            ("FireFlower", self.addFireFlowerItem),
        ):
            for entry in entities.get(key, []):
                x, y = self._extract_xy(entry)
                if x is not None and y is not None:
                    spawn(x, y)
        for entry in entities.get("coinBrick", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addCoinBrick(x, y)
        for entry in entities.get("RandomBox", []):
            x, y = self._extract_xy(entry)
            item = self._extract_value(entry, 2, "item", default=None)
            if x is not None and y is not None:
                self.addRandomBox(x, y, item)
        for entry in entities.get("BrickBlock", []):
            self._add_brick_from_data(entry)
        for entry in entities.get("brick", []):
            self._add_brick_from_data(entry)
        for entry in entities.get("HardBlock", []):
            x, y = self._extract_xy(entry)
            if x is None or y is None:
                continue
            self.addHardBlock(x, y)
        for entry in entities.get("FireBar", []):
            x, y = self._extract_xy(entry)
            if x is None or y is None:
                continue
            segments = self._extract_value(entry, 2, "segments", default=4)
            self.addFireBar(x, y, segments=segments)
        for entry in entities.get("MovingPlatform", []):
            x, y = self._extract_xy(entry)
            if x is None or y is None:
                continue
            size = self._extract_value(entry, 2, "size", default="large")
            axis = self._extract_value(entry, 3, "axis", default="horizontal")
            travel_tiles = self._extract_value(entry, 4, "travel_tiles", default=3)
            self.addMovingPlatform(x, y, size=size, axis=axis, travel_tiles=travel_tiles)
        for entry in entities.get("PiranhaPlant", []):
            x, y = self._extract_xy(entry)
            if x is None or y is None:
                continue
            variant = self._extract_value(entry, 2, "variant", default="green")
            self.addPiranhaPlant(x, y, variant=variant)
        for entry in entities.get("BuzzyBeetle", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addBuzzyBeetle(x, y)
        for entry in entities.get("Lakitu", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addLakitu(x, y)
        for entry in entities.get("Spiny", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addSpiny(x, y)
        for entry in entities.get("CheepCheep", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                variant = self._extract_value(entry, 2, "variant", default="red")
                self.addCheepCheep(x, y, variant=variant)
        for entry in entities.get("Blooper", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addBlooper(x, y)
        for entry in entities.get("HammerBro", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addHammerBro(x, y)
        for entry in entities.get("BulletBill", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addBulletBill(x, y)
        for entry in entities.get("BillBlaster", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addBillBlaster(x, y)
        for entry in entities.get("Podoboo", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addPodoboo(x, y)
        for entry in entities.get("OneUpMushroom", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                self.addOneUpMushroom(x, y)
        for entry in entities.get("Bowser", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                variant = self._extract_value(entry, 2, "variant", default="green")
                self.addBowser(x, y, variant=variant)
        for entry in entities.get("Princess", []):
            x, y = self._extract_xy(entry)
            if x is not None and y is not None:
                as_npc = bool(self._extract_value(entry, 2, "as_npc", default=True))
                self.addPrincess(x, y, as_npc=as_npc)

    def loadLayers(self, data):
        layers = []
        sky_sprite = self.get_theme_sprite("sky")
        surface_sky_sprite = self.sprites.spriteCollection.get("sky")
        ground_sprite = self.get_theme_sprite("ground")
        layer_spec = data["level"]["layers"]
        sky_rows = range(*layer_spec["sky"]["y"])
        ground_rows = range(*layer_spec["ground"]["y"])
        for x in range(*layer_spec["sky"]["x"]):
            column_is_water = self._is_underwater_column(x)
            column_ground = ground_sprite
            if self._is_biome("underwater") and not column_is_water:
                column_ground = self.sprites.spriteCollection.get("ground")
            layers.append(
                (
                        [
                            Tile(
                                surface_sky_sprite if self.stageBiome == "underwater" and (
                                    not column_is_water
                                    or (self.stageWaterline is not None and y < self.stageWaterline)
                                ) else sky_sprite,
                                None,
                            )
                            for y in range(*data["level"]["layers"]["sky"]["y"])
                        ]
                        + [
                            Tile(
                                column_ground,
                                # Authored ground ranges use a legacy offset.
                                # The hitbox follows the stored (rendered) row.
                                pygame.Rect(x * 32, y * 32, 32, 32),
                            )
                            for y in range(len(sky_rows), len(sky_rows) + len(ground_rows))
                            if y < 15
                        ]
                )
            )
        self.level = list(map(list, zip(*layers)))
        if self._is_biome("underwater") and self.stageWaterline is not None:
            surface = self.sprites.spriteCollection.get("water")
            if surface is not None:
                surface_row = max(0, self.stageWaterline - 1)
                for x in range(len(self.level[0])):
                    if self._is_underwater_column(x):
                        self._register_overlay(surface, x, surface_row)

    def loadObjects(self, data):
        for x, y in data["level"]["objects"]["bush"]:
            self.addBushSprite(x, y)
        for x, y in data["level"]["objects"]["cloud"]:
            self.addCloudSprite(x, y)
        for pipe_data in data["level"]["objects"].get("pipe", []):
            if len(pipe_data) < 3:
                continue
            x, y, height = pipe_data[:3]
            # Canonical JSON maps are deterministic: plants must be authored
            # explicitly instead of being rolled randomly on every load.
            plant = pipe_data[3] if len(pipe_data) > 3 else False
            self.addPipeSprite(x, y, height, plant=plant)
        for x, y in data["level"]["objects"]["sky"]:
            if 0 <= y < len(self.level) and 0 <= x < len(self.level[y]):
                sky = self.get_theme_sprite("sky")
                if self._is_underwater_cell(x, y):
                    sky = self.get_theme_sprite("sky")
                elif self._is_underwater_column(x):
                    sky = self.sprites.spriteCollection.get("sky")
                self.level[y][x] = Tile(sky, None)
        for x, y in data["level"]["objects"]["ground"]:
            if 0 <= y < len(self.level) and 0 <= x < len(self.level[y]):
                self.level[y][x] = Tile(
                    self.get_theme_sprite("ground"),
                    pygame.Rect(x * 32, y * 32, 32, 32),
                )
        # Editor exports can paint any registered tile over the base layers.
        for x, y, name in data["level"].get("tiles", []):
            sprite = self.sprites.spriteCollection.get(name)
            if sprite is not None and 0 <= y < len(self.level) and 0 <= x < len(self.level[y]):
                hitbox = pygame.Rect(x * 32, y * 32, 32, 32) if sprite.colliding else None
                self.level[y][x] = Tile(sprite, hitbox)
        for x, y in data["level"]["objects"].get("coral", []):
            self.addCoralSprite(x, y)
        for entry in data["level"]["objects"].get("scenery", []):
            self._place_scenery_from_data(entry)

    def updateEntities(self, cam):
        self._prune_endless_entities_behind_camera(cam.x)
        camera_x = cam.x  # Camera offset is negative while scrolling right.
        update_distance = 1000  # Only update entities within 1000 pixels of camera
        
        dead_entities = []
        # Spawners append to the live list. New entities get their first update
        # on the next frame, regardless of where the spawner is in the list.
        for entity in self.entityList[:]:
            # Cull entities that are far off-screen
            entity_x = getattr(entity, 'rect', None)
            if entity_x is not None:
                entity_x = entity_x.x + camera_x
                if (
                    entity_x < -update_distance
                    or entity_x > self.screen.get_width() + update_distance
                ):
                    continue
            entity.update(cam)
            if entity.alive is None:
                dead_entities.append(entity)
        
        # Remove dead entities after iteration
        for entity in dead_entities:
            if entity in self.entityList:
                self.entityList.remove(entity)

    def _prune_endless_entities_behind_camera(self, camera_x):
        """Discard entities more than two screens behind in endless mode.

        Canonical stages retain their authored entities for the full stage.
        Endless entities can never become relevant again after falling this far
        behind the scrolling camera, so removing them bounds entity memory.
        ``camera_x`` is the pixel camera offset (negative while scrolling right).
        """
        if not self.endless or not self.entityList:
            return 0
        cutoff_screen_x = -2 * self.screen.get_width()
        before = len(self.entityList)
        self.entityList[:] = [
            entity
            for entity in self.entityList
            if getattr(entity, "rect", None) is None
            or entity.rect.x + camera_x >= cutoff_screen_x
        ]
        return before - len(self.entityList)

    def drawLevel(self, camera):
        # Start each frame from a clean logical canvas. Most SMB backgrounds
        # are opaque tiles, but entities with transparent/rotating frames can
        # leave visible trails anywhere a tile is missing or clipped at the
        # camera edge. Clearing here also makes every caller (gameplay,
        # captures, and level previews) use the same redraw contract.
        sky_column = max(0, int(-camera.pos.x))
        sky_sprite = self.get_theme_sprite("sky", column=sky_column)
        sky_image = getattr(sky_sprite, "image", None)
        if sky_image is not None and sky_image.get_width() and sky_image.get_height():
            color = sky_image.get_at((0, 0))
            if len(color) >= 4 and color.a < 255:
                color = (92, 148, 252)
            else:
                color = color[:3]
            self.screen.fill(color)
        else:
            self.screen.fill((92, 148, 252))
        if self.endless:
            self._ensure_endless_buffer(camera)

        self._draw_tile_layer(camera, foreground=False)
        self._draw_overlays(camera)
        self._draw_tile_layer(camera, foreground=True)
        self.updateEntities(camera)
        self._draw_foreground(camera)

    def _draw_tile_layer(self, camera, foreground):
        # Include neighboring columns so wide sprites can draw into the frame.
        start_x = max(0, -int(camera.pos.x + 1))
        end_x = 20 - int(camera.pos.x - 1)
        rows = self.level[:15] if self.level else ()
        for y, row in enumerate(rows):
            for x in range(start_x, min(end_x, len(row))):
                tile = row[x]
                if tile is None or tile.sprite is None:
                    continue
                sprite = tile.sprite
                if bool(sprite.redrawBackground) != foreground:
                    continue
                if foreground:
                    sky = self.get_theme_sprite("sky", column=x)
                    if sky is None:
                        sky = self.sprites.spriteCollection.get("sky")
                    if sky and sky.image is not None:
                        self.screen.blit(sky.image, ((x + camera.pos.x) * 32, y * 32))
                sprite.drawSprite(x + camera.pos.x, y, self.screen)

    def addCloudSprite(self, x, y):
        """
        Places an original SMB1 cloud sprite.
        
        The source sheet has three native cloud silhouettes. They are kept as
        pixel-based overlays so their transparent edges blend cleanly with the
        sky and adjacent clouds.
        """
        theme = self._smb1_scenery_theme()
        variants = [
            self.sprites.spriteCollection.get(f"smb1_{theme}_cloud_{size}")
            for size in ("small", "medium", "wide")
        ]
        variants = [sprite for sprite in variants if sprite and sprite.image]
        if variants:
            self.randomizer.shuffle(variants)
            sprite = next(
                (
                    candidate for candidate in variants
                    if self._cloud_candidate_clear(
                        x, y, candidate.image.get_width(), candidate.image.get_height()
                    )
                ),
                None,
            )
            if sprite is None:
                return False
            width = max(1, math.ceil(sprite.image.get_width() / 32))
            height = max(1, math.ceil(sprite.image.get_height() / 32))
            if not self._can_place_rectangle(x, y, width, height):
                return False
            self._register_overlay(sprite, x * 32, y * 32, pixel=True)
            world_x = x * 32
            bucket = int(world_x // 512)
            self._cloudBuckets.setdefault(bucket, []).append(
                (world_x, y * 32, sprite.image.get_width(), sprite.image.get_height())
            )
            return True

        # Keep the old tile-built clouds as a fallback if a cutout is missing.
        if not self._can_place_rectangle(x, y, 3, 2):
            return False
        # Place each cloud tile piece (clouds are 3x2 tiles)
        for yOff in range(0, 2):
            for xOff in range(0, 3):
                sprite_name = "cloud{}_{}".format(yOff + 1, xOff + 1)
                # Always register clouds as overlays for proper blending
                # This ensures clouds can overlap and blend with each other
                sprite = self.sprites.spriteCollection.get(sprite_name)
                if sprite is not None:
                    # Register as overlay so it draws on top and blends properly
                    self._register_overlay(sprite, x + xOff, y + yOff)
        return True

    def _smb1_scenery_theme(self):
        """Map procedural biomes to palettes from the original NES sheets."""
        if self._is_biome("ice"):
            return "snow"
        if self._is_biome("mushroom"):
            return "mushrooms"
        if self._is_biome("underwater"):
            return "underwater"
        if self._is_biome("underground"):
            return "underground"
        if self._is_biome("fortress") or self._is_biome("firebar"):
            return "castle"
        return "overworld"

    def _place_background_hill(self, column):
        """Place an authentic NES hill behind the ground and gameplay entities."""
        if self._is_dark_biome() or not self.level:
            return False
        theme = self._smb1_scenery_theme()
        sprites = [
            self.sprites.spriteCollection.get(f"smb1_{theme}_hill_{size}")
            for size in ("slope", "round", "low", "group")
        ]
        sprites = [sprite for sprite in sprites if sprite and sprite.image]
        if not sprites:
            return False
        sprite = self.randomizer.choice(sprites)
        span = self._scenery_span_tiles(sprite)
        if column < 0 or column + span > len(self.level[0]):
            return False

        surface_row = self._highest_solid_tile(column)
        if surface_row is None:
            return False
        if any(
            self._highest_solid_tile(x) != surface_row
            for x in range(column, column + span)
        ):
            return False
        self._register_overlay(
            sprite,
            column * 32,
            surface_row * 32 - sprite.image.get_height(),
            pixel=True,
        )
        return True

    def addPipeSprite(self, x, y, length=2, plant=None, plant_variant="green"):
        if not self._can_place_rectangle(x, y, 2, 1):
            return False
        columns = len(self.level[0]) if self.level else 0
        rows = len(self.level)
        if x < 0 or x + 1 >= columns or y < 0 or y >= rows:
            return False
        self.level[y][x] = Tile(
            self.sprites.spriteCollection.get("pipeL"),
            pygame.Rect(x * 32, y * 32, 32, 32),
        )
        self.level[y][x + 1] = Tile(
            self.sprites.spriteCollection.get("pipeR"),
            pygame.Rect((x + 1) * 32, y * 32, 32, 32),
        )
        self._register_pipe_sprite(self.level[y][x].sprite, x, y)
        self._register_pipe_sprite(self.level[y][x + 1].sprite, x + 1, y)
        self._register_pipe_lip_sprite(self.level[y][x].sprite, x, y)
        self._register_pipe_lip_sprite(self.level[y][x + 1].sprite, x + 1, y)
        max_depth = self.pipe_end_row(y, length)
        for i in range(y + 1, max_depth):
            self.level[i][x] = Tile(
                self.sprites.spriteCollection.get("pipe2L"),
                pygame.Rect(x * 32, i * 32, 32, 32),
            )
            self.level[i][x + 1] = Tile(
                self.sprites.spriteCollection.get("pipe2R"),
                pygame.Rect((x + 1) * 32, i * 32, 32, 32),
            )
            self._register_pipe_sprite(self.level[i][x].sprite, x, i)
            self._register_pipe_sprite(self.level[i][x + 1].sprite, x + 1, i)
        spawn_plant = False
        if plant is True:
            spawn_plant = True
        elif plant is None:
            spawn_plant = self.randomizer.random() < 0.2
        if spawn_plant and self._pipe_has_clearance_for_plant(x, y):
            emergence = self._calculate_plant_emergence(y)
            self.addPiranhaPlant(
                x, y, emergence=emergence, variant=plant_variant
            )
        return True

    def pipe_end_row(self, y, length):
        """Return the exclusive bottom row of the pipe's solid body."""
        return min(len(self.level), y + length + 20)

    def addBushSprite(self, x, y):
        if not self._can_place_rectangle(x, y, 3, 1):
            return False
        # Validate the full clump before placing any piece. Keep each clump in
        # the overlay layer so a later clump can overlap it without replacing
        # one of its left, middle, or right pieces.
        pieces = [
            self.sprites.spriteCollection.get(name)
            for name in ("bush_1", "bush_2", "bush_3")
        ]
        if any(piece is None or piece.image is None for piece in pieces):
            return False
        for offset, sprite in enumerate(pieces):
            self._register_overlay(sprite, x + offset, y)
        self._register_bush_columns(x)
        return True

    def addFenceSprite(self, x, y, length=3):
        if length < 3:
            length = 3
        if not self._can_place_rectangle(x, y, length, 1):
            return False
        segment_count = length - 2
        sprites = ["fence_left"] + ["fence_mid"] * max(0, segment_count) + ["fence_right"]
        for offset, sprite_name in enumerate(sprites):
            self._apply_decoration_sprite(x + offset, y, sprite_name)
        return True

    def addCoralSprite(self, x, y, tall=False):
        """Place an original SMB coral cutout as non-solid background art."""
        sprite_name = "coral_tall" if tall else "coral"
        sprite = self.sprites.spriteCollection.get(sprite_name)
        if not sprite or not sprite.image:
            return False
        height_tiles = max(1, math.ceil(sprite.image.get_height() / 32))
        if not self._can_place_rectangle(x, y, 1, height_tiles):
            return False
        for row in range(y, y + height_tiles):
            tile = self.level[row][x]
            if tile is not None and tile.rect is not None:
                return False
        self._register_overlay(sprite, x * 32, y * 32, pixel=True)
        return True

    def addUnderwaterPlantSprite(self, x, surface_row):
        """Place the tall source-sheet bulb plant with its stem rooted at seabed."""
        sprite = self.sprites.spriteCollection.get("smb1_underwater_tree_tall")
        if not sprite or not sprite.image or not self._can_place_rectangle(x, surface_row - 3, 1, 3):
            return False
        pixel_y = surface_row * 32 - sprite.image.get_height()
        first_row = max(0, pixel_y // 32)
        for row in range(first_row, surface_row):
            tile = self.level[row][x]
            if tile is not None and tile.rect is not None:
                return False
        self._register_overlay(sprite, x * 32, pixel_y, pixel=True)
        return True

    def _place_block(self, x, y, block):
        # Keep a fixed collision rectangle while the visible block bounces.
        self.level[y][x] = Tile(self.get_theme_sprite("sky"), block.rect.copy(), block)
        self.entityList.append(block)

    def addBrickBlock(self, x, y, contents=None, coin_total=0):
        if self.endless and self._biome_at_column(x) == "underwater":
            return False
        if not 0 <= y < len(self.level) or not 0 <= x < len(self.level[y]):
            return False
        brick = BrickBlock(
            self.screen,
            self.sprites.spriteCollection,
            x,
            y,
            self.sound,
            self.dashboard,
            self,
            contents=contents,
            coin_total=coin_total,
        )
        self._place_block(x, y, brick)
        return True

    def _add_brick_from_data(self, entry):
        if isinstance(entry, dict):
            x = entry.get("x")
            y = entry.get("y")
            contents = entry.get("contents")
            coins = entry.get("coins", entry.get("coin_total", 0))
        else:
            try:
                x, y = entry[0], entry[1]
            except (TypeError, IndexError):
                return False
            contents = entry[2] if len(entry) >= 3 else None
            coins = entry[3] if len(entry) >= 4 else 0
        if x is None or y is None:
            return False
        return self.addBrickBlock(x, y, contents, coins)

    def _extract_xy(self, entry):
        if isinstance(entry, dict):
            return entry.get("x"), entry.get("y")
        try:
            return entry[0], entry[1]
        except (TypeError, IndexError):
            return None, None

    def _extract_value(self, entry, index, key, default=None):
        if isinstance(entry, dict):
            return entry.get(key, default)
        try:
            if len(entry) > index:
                return entry[index]
        except TypeError:
            pass
        return default

    def clear_tile(self, x, y):
        if not self.level:
            return False
        if y < 0 or y >= len(self.level) or x < 0 or x >= len(self.level[0]):
            return False
        background = self.get_theme_sprite("sky")
        if self._is_biome("underwater") and not self._is_underwater_cell(x, y):
            background = self.sprites.spriteCollection.get("sky")
        self.level[y][x] = Tile(background, None)
        return True

    def addHardBlock(self, x, y):
        try:
            self.level[y][x] = Tile(
                self.get_theme_sprite("hardBlock"),
                pygame.Rect(x * 32, y * 32, 32, 32),
            )
        except IndexError:
            return

    def addCoinBox(self, x, y):
        if self.endless and self._biome_at_column(x) == "underwater":
            return False
        if not self._question_block_has_clearance(x, y):
            return False
        self._place_block(
            x, y,
            CoinBox(
                self.screen,
                self.sprites.spriteCollection,
                x,
                y,
                self.sound,
                self.dashboard,
                self,
            )
        )
        return True

    def addRandomBox(self, x, y, item):
        # Queued procedural segments can execute after a biome transition.
        # SMB1 underwater rooms contain coins and aquatic enemies, not
        # power-up blocks, so validate against the destination column here.
        if self.endless and self._biome_at_column(x) == "underwater":
            return False
        if not self._question_block_has_clearance(x, y):
            return False
        self._place_block(
            x, y,
            RandomBox(
                self.screen,
                self.sprites.spriteCollection,
                x,
                y,
                item,
                self.sound,
                self.dashboard,
                self,
            )
        )
        return True

    def addCoin(self, x, y):
        column = int(round(x))
        row = int(round(y))
        if not self._tile_is_empty(column, row):
            return False
        self._mark_coin_tile(column, row)
        self.entityList.append(
            Coin(self.screen, self.sprites.spriteCollection, column, row)
        )
        return True

    def addCoinBrick(self, x, y):
        if self.endless and self._biome_at_column(x) == "underwater":
            return False
        if not 0 <= y < len(self.level) or not 0 <= x < len(self.level[y]):
            return False
        self._place_block(
            x, y,
            CoinBrick(
                self.screen,
                self.sprites.spriteCollection,
                x,
                y,
                self.sound,
                self.dashboard,
                level=self,
            )
        )

    def addGoomba(self, x, y):
        if self.endless and self._biome_at_column(x) == "underwater":
            return False
        self.entityList.append(
            Goomba(self.screen, self.sprites.spriteCollection, x, y, self, self.sound)
        )

    def addKoopa(self, x, y, variant="green"):
        if self.endless and self._biome_at_column(x) == "underwater":
            return False
        self.entityList.append(
            Koopa(self.screen, self.sprites.spriteCollection, x, y, self, self.sound, variant=variant)
        )

    def addParatroopa(self, x, y, variant="green"):
        if self.endless and self._biome_at_column(x) == "underwater":
            return False
        enemy = KoopaParatroopa(
            self.screen,
            self.sprites.spriteCollection,
            x,
            y,
            self,
            self.sound,
            variant=variant,
        )
        self.entityList.append(enemy)
        return enemy

    def addSpringboard(self, x, ground_row):
        if self.endless and self._biome_at_column(x) == "underwater":
            return False
        springboard = Springboard(
            self.screen,
            self.sprites.spriteCollection,
            x,
            ground_row,
            self,
            self.sound,
        )
        self.entityList.append(springboard)
        return springboard

    def addFortressBridge(self, x, y, length=5):
        bridge = FortressBridge(
            self.screen,
            self.sprites.spriteCollection,
            x,
            y,
            length,
            self,
        )
        self.entityList.append(bridge)
        return bridge

    def addMovingPlatform(self, x, y, size="large", axis="horizontal", travel_tiles=3):
        platform = MovingPlatform(
            self.screen,
            x,
            y,
            size=size,
            axis=axis,
            travel_tiles=travel_tiles,
            speed=1.4 if axis == "horizontal" else 0.9,
            spriteCollection=self.sprites.spriteCollection,
        )
        self.entityList.append(platform)
        return platform

    def addVine(self, x, block_y):
        """Grow an SMB1 beanstalk from a triggered question block."""
        if self._biome_at_column(x) == "underwater":
            return False
        collection = self.sprites.spriteCollection
        if any(
            collection.get(name) is None or collection[name].image is None
            for name in ("smb1_vine_segment", "smb1_vine_tip")
        ):
            return False
        max_segments = max(1, min(9, int(block_y) - 1))
        vine = Vine(
            self.screen,
            int(x),
            int(block_y),
            self.sprites.spriteCollection,
            max_segments=max_segments,
        )
        self.entityList.append(vine)
        return vine

    def addPiranhaPlant(self, x, y, emergence=None, variant="green"):
        plant = PiranhaPlant(
            self.screen,
            x,
            y,
            emergence=emergence or 56,
            spriteCollection=self.sprites.spriteCollection,
            level=self,
            variant=variant,
        )
        self.entityList.append(plant)
        return plant

    def addFireBar(self, x, y, segments=4):
        if self.endless and self._biome_at_column(x) == "underwater":
            return False
        firebar = FireBar(
            self.screen,
            x,
            y,
            segments=segments,
            spriteCollection=self.sprites.spriteCollection,
            rng=self.randomizer,
        )
        firebar.levelObj = self
        self.entityList.append(firebar)
        return firebar

    def addBuzzyBeetle(self, x, y):
        self.entityList.append(
            BuzzyBeetle(self.screen, self.sprites.spriteCollection, x, y, self, self.sound)
        )

    def addLakitu(self, x, y):
        self.entityList.append(
            Lakitu(self.screen, self.sprites.spriteCollection, x, y, self, self.sound)
        )

    def addSpiny(self, x, y):
        self.entityList.append(
            Spiny(self.screen, self.sprites.spriteCollection, x, y, self, self.sound)
        )

    def addCheepCheep(self, x, y, variant="red"):
        self.entityList.append(
            CheepCheep(self.screen, self.sprites.spriteCollection, x, y, self, self.sound, variant=variant)
        )

    def addBlooper(self, x, y):
        self.entityList.append(
            Blooper(self.screen, self.sprites.spriteCollection, x, y, self, self.sound)
        )

    def addHammerBro(self, x, y, variant=None):
        if variant is None:
            variant = "underground" if self._biome_at_column(x) == "underground" else "normal"
        self.entityList.append(
            HammerBro(
                self.screen,
                self.sprites.spriteCollection,
                x,
                y,
                self,
                self.sound,
                variant=variant,
            )
        )

    def addBulletBill(self, x, y):
        self.entityList.append(
            BulletBill(self.screen, self.sprites.spriteCollection, x, y, -1, self)
        )

    def addBillBlaster(self, x, y):
        self.entityList.append(
            BillBlaster(self.screen, self.sprites.spriteCollection, x, y, self, self.sound)
        )

    def addPodoboo(self, x, y):
        self.entityList.append(
            Podoboo(self.screen, self.sprites.spriteCollection, x, y, self, self.sound)
        )

    def addOneUpMushroom(self, x, y):
        self.entityList.append(
            OneUpMushroom(self.screen, self.sprites.spriteCollection, x, y, self, self.sound)
        )

    def addBowser(self, x, y, variant="green"):
        """Place an SMB1 Bowser actor from level JSON coordinates."""
        bowser = Bowser(
            self.screen,
            self.sprites.spriteCollection,
            x,
            y,
            self,
            self.sound,
            variant=variant,
        )
        self.entityList.append(bowser)
        return bowser

    def addPrincess(self, x, y, as_npc=True):
        """Place the castle-rescue NPC (or a non-interactive decoration)."""
        princess = Princess(
            self.screen,
            self.sprites.spriteCollection,
            x,
            y,
            level=self,
            as_npc=as_npc,
        )
        self.entityList.append(princess)
        return princess

    def addSuperStar(self, x, y):
        from entities.SuperStar import SuperStar
        self.entityList.append(
            SuperStar(self.screen, self.sprites.spriteCollection, x, y, self)
        )

    def addFireFlowerItem(self, x, y):
        from entities.FireFlowerCollectible import FireFlowerCollectible
        self.entityList.append(
            FireFlowerCollectible(self.screen, self.sprites.spriteCollection, x, y)
        )

    def _append_column(self):
        """
        Main infinity generation function: creates a new column of the level.
        
        This is the core procedural generation loop that:
        1. Prepares biome transitions
        2. Adds sky tiles as base layer
        3. Manages ground generation with gap prevention
        4. Places features (structures, enemies, collectibles)
        5. Processes background decorations (clouds, bushes)
        
        Soft-lock prevention:
        - Always ensures ground exists after gaps
        - Maintains safe ground buffer after structures
        - Enforces minimum gap spacing
        - Guarantees ground in intro columns
        """
        x_index = self.generatedColumns
        
        # Prepare biome system (handles biome transitions and special rules)
        self._prepare_biome_for_column(x_index)
        # Generation runs ahead of the camera. Keep biome identity per column
        # so runtime physics and drawing use the player's biome, not the
        # generator frontier's biome.
        self.columnBiomes.append(self.activeBiome)
        
        # Initialize column with sky tiles (base layer for all rows)
        sky_sprite = self.get_theme_sprite("sky")
        for row in self.level:
            row.append(Tile(sky_sprite, None))
        
        # Decay all cooldown timers (structures, enemies, decorations, etc.)
        self._decay_cooldowns()
        
        # Handle safe ground buffer (prevents placing obstacles immediately after structures)
        if self.safeColumnsRemaining > 0:
            self.safeColumnsRemaining -= 1
        
        # Gap management: prevents soft-locks by ensuring ground after gaps
        if self.gapRemaining > 0:
            # Draw one native 32x64 NES lava column at the surface. Repeating
            # that tall image in every ground row stacked it into a mess.
            if self._is_biome("firebar") or self._is_biome("fortress"):
                self._draw_lava_gap_column(x_index)
            self.gapRemaining -= 1
            if self.gapRemaining == 0:
                # Gap ending: ensure safe ground after gap to prevent soft-locks
                self._start_gap_cooldown()
                # Reserve 5 columns of safe ground after gap (prevents player from falling)
                self._reserve_safe_ground(5)
                # CRITICAL: Ensure ground exists immediately after gap ends
                # This prevents soft-locks where player falls into void
                if x_index + 1 < len(self.level[0]) if self.level else True:
                    # Force ground in next column to guarantee landing spot
                    pass  # Ground will be built in next iteration
        else:
            # Normal ground generation
            # Adjust ground height based on terrain profiles and biomes
            self._maybe_change_ground_height()
            # Build the ground column (places solid tiles)
            self._build_ground_column(x_index)
            # Decay gap cooldown (prevents too many gaps too close together)
            self._decay_gap_cooldown()
            
            # Apply biome-specific gap rules (e.g., canyon biome has special gap patterns)
            handled_gap = self._apply_canyon_gap_rules(x_index)
            
            # Random gap generation (only if conditions are safe)
            if not handled_gap and (
                x_index > 10  # Don't create gaps too early
                and self.gapCooldown == 0  # Respect gap spacing
                and self.safeColumnsRemaining == 0  # Don't gap during safe buffer
                and getattr(self, "restColumnsRemaining", 0) <= 0  # No gaps during rest
            ):
                gap_chance = {"easy": 0.04, "medium": 0.06, "hard": 0.07}[self._get_difficulty_tier()]
                if self.randomizer.random() < gap_chance:
                    # Create a small gap (1-2 tiles, within Mario's jump distance)
                    self.gapRemaining = self.randomizer.randint(1, 2)
        
        # Process classic queue (pre-scheduled features from demo patterns)
        self._process_classic_queue(x_index)
        
        # Place features (structures, collectibles, enemies)
        self._maybe_place_features(x_index)
        
        # Process background queue (clouds, bushes scheduled earlier)
        self._process_background_queue(x_index)
        
        # Increment generation counter
        self.generatedColumns += 1

    def _reset_generation_state(self):
        self.groundHeight = 2
        self.terrainCountdown = 0
        self.decorationCooldown = 0
        self.enemyCooldown = 0
        self.structureCooldown = 0
        self.coinCooldown = 0
        self.gapCooldown = 0
        self.minGapSpacing = 3
        self.backgroundQueue = []
        self._cloudBuckets = {}
        self.bushColumns = set()
        self.coinTiles = set()
        self._clear_overlay_layers()
        self.classicQueue = []
        self.classicQueueEnd = -1
        self.safeColumnsRemaining = 0
        self.pendingGroundProfile = []
        self.initialFlatColumns = self.INTRO_SAFE_COLUMNS
        self.activeBiome = "normal"
        self.biomeColumnsRemaining = 0
        self.biomeData = {}
        self.restColumnsRemaining = 0
        self.recentStructureIds = []
        self.recentClassicSegmentNames = []
        self.vineNextColumn = 120
        self.springboardNextColumn = 150

    def _rebuild_coin_tile_cache(self):
        self.coinTiles = set()
        for entity in self.entityList:
            if isinstance(entity, Coin):
                column = entity.rect.x // 32
                row = entity.rect.y // 32
                self.coinTiles.add((column, row))

    def _rebuild_pipe_foreground(self):
        self.foregroundSprites = []
        self._foregroundBuckets = {}
        self._maxForegroundWidth = 0
        if not self.level:
            return
        for y, row in enumerate(self.level):
            for x, tile in enumerate(row):
                sprite = tile.sprite
                if sprite in self.pipeSprites:
                    self._register_pipe_sprite(sprite, x, y)
                    if sprite in self.pipeTopSprites:
                        self._register_pipe_lip_sprite(sprite, x, y)

    def _register_pipe_sprite(self, sprite, tile_x, tile_y):
        if sprite is None or sprite not in self.pipeSprites:
            return
        pixel_x = tile_x * 32
        pixel_y = tile_y * 32
        self._register_foreground(sprite, pixel_x, pixel_y, pixel=True)

    def _register_pipe_lip_sprite(self, sprite, tile_x, tile_y):
        if sprite is None or sprite not in self.pipeTopSprites:
            return
        clip = self._pipe_lip_clip(sprite)
        pixel_x = tile_x * 32
        pixel_y = tile_y * 32
        self._register_foreground(sprite, pixel_x, pixel_y, pixel=True, clip=clip)

    def _pipe_lip_clip(self, sprite):
        if sprite is None or sprite.image is None:
            return None
        lip_height = min(sprite.image.get_height(), self.PIPE_LIP_HEIGHT)
        return pygame.Rect(0, 0, sprite.image.get_width(), lip_height)

    def _surface_row(self):
        return max(0, 15 - self.groundHeight)

    def _is_reachable(self, column, row):
        """Check if (column, row) is within Mario's jump reach (6 blocks vertical)."""
        surface_row = self._surface_row()
        vertical_dist = surface_row - row
        return 0 <= vertical_dist <= self.MAX_JUMP_HEIGHT

    def _get_difficulty_tier(self):
        """Return 'easy', 'medium', or 'hard' based on distance progressed."""
        cols = getattr(self, "generatedColumns", 0)
        if cols < 100:
            return "easy"
        if cols < 300:
            return "medium"
        return "hard"

    def _build_ground_column(self, x_index):
        """
        Builds a column of ground tiles.
        
        Places solid ground tiles from bottom up based on groundHeight.
        This ensures the player always has a surface to land on.
        
        Soft-lock prevention:
        - Always places at least 2 tiles of ground (minimum safe height)
        - Ensures ground exists even if groundHeight is invalid
        """
        # Build ground from bottom up (row 14 is bottom, row 13 is above it, etc.)
        # groundHeight determines how many tiles to place (2-4 tiles)
        ground_height = (
            1 if self._biome_at_column(x_index) == "underwater" else self.groundHeight
        )
        for offset in range(ground_height):
            row_index = 14 - offset
            tile_y = row_index + 1
            self._add_ground_tile(x_index, row_index, tile_y)
        
        # The cold biome changes movement and pacing while keeping the
        # original SMB block art.
        # The ice biome keeps the original SMB ground tiles. Its obstacles are
        # placed as sparse hard-block ledges rather than tiled into the terrain.

    def _reinforce_ice_ground_column(self, x_index):
        if not self.level or not self._is_biome("ice"):
            return
        surface_row = self._surface_row()
        if surface_row <= 0:
            return
        crest_height = 0
        if self.randomizer.random() < 0.35:
            crest_height = self.randomizer.randint(1, 2)
        for offset in range(crest_height):
            row = surface_row - 1 - offset
            if row < 0 or not self._tile_is_empty(x_index, row):
                break
            self._assign_solid_tile(x_index, row, "hardBlock")
        if self.randomizer.random() >= 0.2:
            return
        direction = self.randomizer.choice([-1, 1])
        span = self.randomizer.randint(1, 2)
        target_row = max(0, surface_row - 1)
        for step in range(1, span + 1):
            column = x_index + direction * step
            if column < 0 or column >= len(self.level[0]):
                break
            if not self._tile_is_empty(column, target_row):
                break
            self._assign_solid_tile(column, target_row, "hardBlock")
            self._ensure_ground_column(column, target_row + 1)

    def _maybe_change_ground_height(self):
        """
        Manages ground height variation for terrain diversity.
        
        Ground height determines how many solid tiles are placed vertically.
        Height 2 = 2 tiles (standard), 3 = 3 tiles (higher), 4 = 4 tiles (tallest).
        
        Soft-lock prevention:
        - Always maintains ground in intro columns
        - Never creates impossible jumps
        - Respects biome-specific height rules
        """
        # Intro safety: keep ground flat and safe in first columns
        if self.generatedColumns < getattr(self, "initialFlatColumns", self.INTRO_SAFE_COLUMNS):
            self.groundHeight = 2  # Standard height for safety
            self.terrainCountdown = 0
            return
        
        # Biome-specific height adjustments (e.g., canyon biome varies height)
        if self._biome_adjusts_ground_height():
            return
        
        # Advance through pre-planned ground profile sequence
        if self._advance_ground_profile():
            return
        
        # Wait for terrain countdown before changing height
        if self.terrainCountdown > 0:
            self.terrainCountdown -= 1
            return
        
        # Start a new ground profile sequence (hills, valleys, etc.)
        if self._maybe_begin_ground_profile():
            self._advance_ground_profile()
            return
        
        # Random height variation (18% chance)
        if self.randomizer.random() < 0.18:
            # Weighted towards standard height (2) for playability
            self.groundHeight = self.randomizer.choice([2, 2, 3, 3, 4])
            # Maintain height for 4-12 columns for consistency
            self.terrainCountdown = self.randomizer.randint(4, 12)

    def _advance_ground_profile(self):
        if not getattr(self, "pendingGroundProfile", None):
            return False
        if not self.pendingGroundProfile:
            return False
        self.groundHeight = self.pendingGroundProfile.pop(0)
        return True

    def _maybe_begin_ground_profile(self):
        if not self.endless or not hasattr(self, "pendingGroundProfile"):
            return False
        if self.pendingGroundProfile:
            return False
        if self.randomizer.random() >= 0.22:
            return False
        profile = self._build_ground_profile_sequence()
        if not profile:
            return False
        self.pendingGroundProfile = profile
        return True

    def _build_ground_profile_sequence(self):
        templates = self._ground_profile_templates()
        if not templates:
            return []
        template = self.randomizer.choice(templates)
        if not template:
            return []
        current = self.groundHeight
        sequence = []
        for delta in template:
            current += delta
            current = max(2, min(4, current))
            sequence.append(current)
        return sequence

    def _ground_profile_templates(self):
        return [
            [0, 1, 1, 0, -1, -1],
            [0, 0, 1, 2, 1, 0, -1],
            [0, -1, -1, 0, 1, 1, 0],
            [0, 1, 0, 1, 0, -1, 0],
            [0, 0, 0, -1, -1, 0, 1, 1],
            [0, 1, 2, 2, 1, 0, -1, -2],
            [0, 0, -1, -2, -1, 0, 1, 2, 1],
        ]

    def _add_ground_tile(self, x_index, row_index, tile_y):
        if row_index >= len(self.level):
            return
        sprite_name = self._biome_sprite("ground")
        sprite = self.sprites.spriteCollection.get(sprite_name)
        self.level[row_index][-1] = Tile(
            sprite,
            pygame.Rect(x_index * 32, (tile_y - 1) * 32, 32, 32),
        )

    def _maybe_place_features(self, x_index):
        """
        Main feature placement function for infinity generation.
        
        Places background decorations, structures, collectibles, and enemies.
        Respects intro safety zone and biome-specific rules.
        
        Soft-lock prevention:
        - Skips feature placement in intro columns
        - Respects safe ground buffer
        - Biome features handle their own safety rules
        """
        # Skip feature placement in intro columns (keep it safe for player start)
        if x_index < getattr(self, "initialFlatColumns", self.INTRO_SAFE_COLUMNS):
            return

        if self._maybe_spawn_springboard(x_index):
            return
        
        # Apply biome-specific features (firebar biome, canyon biome, etc.)
        if self._apply_biome_features(x_index):
            return
        
        # Standard feature placement
        self._maybe_place_background(x_index)  # Clouds, bushes, fences
        if getattr(self, "restColumnsRemaining", 0) <= 0:
            self._maybe_spawn_structures(x_index)  # Pipes, blocks, platforms
        self._maybe_spawn_collectibles(x_index)  # Coins, coin arcs
        self._maybe_spawn_items(x_index)  # Power-up items
        self._maybe_spawn_enemies(x_index)  # Enemies

    def _decay_cooldowns(self):
        rest = getattr(self, "restColumnsRemaining", 0)
        if rest > 0:
            self.restColumnsRemaining = rest - 1
        for attr in [
            "decorationCooldown",
            "enemyCooldown",
            "structureCooldown",
            "coinCooldown",
        ]:
            current = getattr(self, attr, 0)
            if current > 0:
                setattr(self, attr, current - 1)

    def _maybe_place_background(self, x_index):
        """
        Places background decorations: clouds, bushes, fences.
        
        Background decorations are placed as overlays so they can blend
        properly. Clouds especially benefit from overlay rendering for blending.
        
        Priority order:
        1. Fences (if conditions met)
        2. Bushes (if conditions met)
        3. Background patterns (clouds + bushes combinations)
        4. Single clouds (fallback)
        """
        if self._is_dark_biome():
            return
        # Keep sky detail appearing during scenery cooldown; cloud spacing is
        # checked independently so repeated decoration cannot stack up.
        if self.decorationCooldown > 0:
            self._maybe_schedule_extra_cloud(x_index, allow_cooldown=False)
            return
        
        # Need at least 2 columns for placement
        if x_index < 2:
            return
        
        # Try to place fence (highest priority decoration)
        if self._maybe_place_fence(x_index):
            self.decorationCooldown = self.randomizer.randint(3, 6)
            # Sometimes add extra cloud near fence for variety
            if self.randomizer.random() < 0.35:
                self._maybe_schedule_extra_cloud(x_index)
            return
        
        # Try to place bush (requires ground support, no gaps)
        if (
            self.gapRemaining == 0  # Don't place bushes over gaps
            and self.randomizer.random() < 0.10  # 10% chance
            and self._place_supported_bush(x_index - 2)  # Place 2 columns back
        ):
            self.decorationCooldown = self.randomizer.randint(4, 8)
            # Sometimes schedule background pattern (clouds + bushes)
            if self.randomizer.random() < 0.45:
                self._schedule_background_pattern(x_index)
            return

        # Grounded scenery: trees, flowers, circle bushes
        if self.gapRemaining == 0:
            if self.randomizer.random() < 0.025:
                if self._schedule_scenery_feature("hill", x_index):
                    self.decorationCooldown = self.randomizer.randint(5, 9)
                    return
            if self._maybe_schedule_tree(x_index):
                self.decorationCooldown = self.randomizer.randint(5, 10)
                return
            if self.randomizer.random() < 0.06 and self._maybe_place_ground_flower(x_index):
                self.decorationCooldown = self.randomizer.randint(3, 6)
                return
            if self.randomizer.random() < 0.05 and self._maybe_place_circle_bush(x_index - 1):
                self.decorationCooldown = self.randomizer.randint(4, 7)
                return
        
        # Try to schedule background pattern (clouds + bushes combinations)
        if self.randomizer.random() < 0.08:  # 8% chance
            if self._schedule_background_pattern(x_index):
                self.decorationCooldown = self.randomizer.randint(6, 14)
                return
        
        # Fallback: schedule single cloud
        self._maybe_schedule_extra_cloud(x_index)

    def _highest_solid_tile(self, column_index):
        if not self.level or column_index < 0 or column_index >= len(self.level[0]):
            return None
        # When searching for support tiles we care about the visually highest
        # (closest to the sky) solid block.  The previous implementation scanned
        # from the bottom of the map which effectively returned the lowest solid
        # tile, causing bushes and other decorations to think there was no space
        # above the ground in endless mode.  Scanning from the top ensures we
        # detect the first available surface the moment we encounter it.
        for row_index in range(len(self.level)):
            tile = self.level[row_index][column_index]
            if tile is not None and tile.rect is not None:
                return row_index
        return None

    def _coin_can_spawn(self, x_index, coin_y, max_horizontal=3, max_vertical=5):
        for offset in range(-max_horizontal, max_horizontal + 1):
            column = x_index + offset
            support_row = self._highest_solid_tile(column)
            if support_row is None:
                continue
            vertical_gap = coin_y - support_row
            if 1 <= vertical_gap <= max_vertical:
                return True
        return False

    def _attempt_coin_spawn(self, column, row):
        if not self._tile_is_empty(column, row):
            return False
        if not self._coin_can_spawn(column, row):
            return False
        return self.addCoin(column, row)

    def _maybe_spawn_structures(self, x_index):
        """
        Attempts to spawn various structures in infinity mode.
        
        Structure types (in priority order):
        1. Demo structures (from demo_patterns.json - authentic NES patterns)
        2. Classic segments (pre-designed feature combinations)
        3. Bonus trios (three question blocks with rewards)
        4. Brick shelves (horizontal brick platforms)
        5. Coin brick clusters (groups of coin bricks)
        6. Hard block stairs (staircase patterns)
        7. Mushroom platforms (floating platforms with mushrooms)
        8. Ice ledges (ice biome specific)
        9. Firebar features (rotating fire obstacles)
        10. Moving platforms (horizontal/vertical moving platforms)
        11. Pipes (with optional piranha plants)
        12. Coin boxes (question blocks)
        13. Random boxes (power-up blocks)
        
        Soft-lock prevention:
        - Respects structure cooldown (prevents overcrowding)
        - Skips during gaps (ensures safe landing)
        - Respects safe ground buffer (guarantees landing after structures)
        - Each structure reserves safe ground after placement
        """
        # Skip structure placement if conditions aren't safe
        if (
            self.structureCooldown > 0  # Wait for cooldown
            or self.gapRemaining > 0  # Don't place during gaps
            or self.safeColumnsRemaining > 0  # Respect safe ground buffer
        ):
            return

        # A rare vine block gives the player a vertical SMB-style detour
        # without changing the endless world/camera coordinate system.
        if self._maybe_spawn_vine_block(x_index):
            self.structureCooldown = self.randomizer.randint(4, 7)
            self._reserve_safe_ground(4)
            return
        
        # Priority 1: Demo structures (authentic NES patterns from demo_patterns.json)
        if self._maybe_spawn_demo_structure(x_index):
            return
        
        # Priority 2: Classic segments (pre-designed feature combinations)
        classic_length = self._maybe_schedule_classic_segment(x_index)
        if classic_length:
            self.structureCooldown = max(self.structureCooldown, classic_length)
            # Reserve safe ground proportional to segment length
            self._reserve_safe_ground(max(6, classic_length // 2))
            self.restColumnsRemaining = max(
                getattr(self, "restColumnsRemaining", 0),
                self.randomizer.randint(8, 12),
            )
            return
        
        # Priority 3: Bonus trios (three question blocks in a row)
        if self._maybe_spawn_bonus_trio(x_index):
            self.structureCooldown = self.randomizer.randint(4, 8)
            self._reserve_safe_ground(5)
            return
        
        # Priority 4: Brick shelves (horizontal brick platforms)
        if self._maybe_spawn_brick_shelf(x_index):
            self.structureCooldown = self.randomizer.randint(6, 12)
            self._reserve_safe_ground(6)
            return
        
        # Priority 5: Coin brick clusters (groups of coin bricks)
        if self._maybe_spawn_coin_brick_cluster(x_index):
            self.structureCooldown = self.randomizer.randint(6, 12)
            self._reserve_safe_ground(5)
            return
        
        # Priority 6: Hard block stairs (staircase patterns)
        if self._maybe_spawn_hard_block_stairs(x_index):
            self.structureCooldown = self.randomizer.randint(5, 10)
            self._reserve_safe_ground(6)
            return
        
        # Priority 7: Mushroom platforms (floating platforms)
        if not self._is_dark_biome() and self._maybe_spawn_mushroom_platform(x_index):
            self.structureCooldown = self.randomizer.randint(6, 12)
            self._reserve_safe_ground(6)
            return
        
        # Priority 8: Ice ledges (ice biome specific structures)
        if self._maybe_spawn_ice_ledge(x_index):
            self.structureCooldown = self.randomizer.randint(5, 9)
            self._reserve_safe_ground(5)
            return
        
        # Priority 9: Firebar features (rotating fire obstacles)
        if self._maybe_spawn_firebar_feature(x_index):
            return
        
        # Priority 10: Moving platforms (horizontal/vertical movement)
        if self._maybe_spawn_moving_platform(x_index):
            self.structureCooldown = self.randomizer.randint(7, 14)
            self._reserve_safe_ground(7)  # Extra safe ground for moving platforms
            return
        
        # Priority 11: Pipes (with optional piranha plants)
        if x_index >= 1 and self.randomizer.random() < 0.10:  # 10% chance
            pipe_columns = [x_index - 1, x_index]
            if not self._columns_blocked_by_bush(pipe_columns):
                # Place pipe at variable height above ground
                pipe_y = max(6, self._surface_row() - self.randomizer.randint(1, 3))
                pipe_length = self.randomizer.randint(2, 4)
                tier = self._get_difficulty_tier()
                plant_chance = {"easy": 0.5, "medium": 0.7, "hard": 0.85}[tier]
                force_plant = self.randomizer.random() < plant_chance
                placed = self.addPipeSprite(
                    x_index - 1, pipe_y, pipe_length, plant=force_plant
                )
                if not placed:
                    return
                self.structureCooldown = self.randomizer.randint(5, 10)
                self._reserve_safe_ground(5)
                return
        
        # Priority 12: Coin boxes (question blocks with coins)
        if self.randomizer.random() < 0.08 and not self._columns_blocked_by_bush([x_index]):
            target_row = self.randomizer.choice([8, 9, 10])
            if self.addCoinBox(x_index, target_row):
                self.structureCooldown = self.randomizer.randint(3, 6)
                self._reserve_safe_ground(4)
                return

        # Priority 13: Random boxes (power-up blocks)
        tier = self._get_difficulty_tier()
        powerup_chance = {"easy": 0.06, "medium": 0.055, "hard": 0.05}[tier]
        if self.randomizer.random() < powerup_chance and not self._columns_blocked_by_bush([x_index]):
            item = self._select_random_box_item()
            target_row = self.randomizer.randint(6, 9)
            if self.addRandomBox(x_index, target_row, item):
                self.structureCooldown = self.randomizer.randint(4, 8)
                self._reserve_safe_ground(4)
                return

    def _maybe_spawn_vine_block(self, x_index):
        collection = self.sprites.spriteCollection
        if any(
            collection.get(name) is None or collection[name].image is None
            for name in ("smb1_vine_segment", "smb1_vine_tip")
        ):
            return False
        if x_index < getattr(self, "vineNextColumn", 120):
            return False
        if not (self._is_biome("normal") or self._is_biome("underground")):
            self.vineNextColumn = x_index + 24
            return False

        self.vineNextColumn = x_index + self.randomizer.randint(220, 360)
        if self.randomizer.random() >= 0.45:
            return False

        surface = self._surface_row()
        block_row = max(3, surface - 4)
        # The plant needs a clear vertical shaft from the question block to
        # the top portion of the screen. Don't overwrite other structures.
        if any(not self._tile_is_empty(x_index, row) for row in range(1, block_row)):
            return False
        if self._columns_blocked_by_bush([x_index]):
            return False
        return self.addRandomBox(x_index, block_row, "Vine")

    def _maybe_spawn_springboard(self, x_index):
        """Add a rare, grounded springboard in traversable land biomes."""
        biome = self._biome_at_column(x_index)
        if biome not in {"normal", "canyon", "mushroom"}:
            return False
        if x_index < self.springboardNextColumn:
            return False
        self.springboardNextColumn = x_index + self.randomizer.randint(180, 300)
        if (
            self.gapRemaining > 0
            or self.safeColumnsRemaining > 0
            or self.structureCooldown > 0
            or getattr(self, "restColumnsRemaining", 0) > 0
            or self._columns_blocked_by_bush([x_index])
            or self.randomizer.random() >= 0.35
        ):
            return False

        ground_row = self._surface_row()
        if not all(self._tile_is_empty(x_index, row) for row in range(max(0, ground_row - 3), ground_row)):
            return False
        springboard = self.addSpringboard(x_index, ground_row)
        if springboard:
            self._reserve_safe_ground(2)
            return True
        return False

    def _maybe_spawn_demo_structure(self, x_index):
        if not self.demoStructures or self.randomizer.random() >= 0.22:
            return False
        attempts = 0
        recent = getattr(self, "recentStructureIds", [])
        while attempts < 5:
            available = [
                (index, structure)
                for index, structure in enumerate(self.demoStructures)
                if index not in recent[-12:]
            ]
            if not available:
                available = list(enumerate(self.demoStructures))
            index, structure = self.randomizer.choice(available)
            width = max(1, structure.get("width", 1))
            if self._structure_columns_blocked(x_index, width):
                attempts += 1
                continue
            if self._stamp_structure(structure, x_index):
                recent.append(index)
                self.recentStructureIds = recent[-20:]
                self.structureCooldown = max(self.structureCooldown, width + 2)
                self._reserve_safe_ground(width + 3)
                return True
            attempts += 1
        return False

    def _maybe_spawn_collectibles(self, x_index):
        """
        Spawns collectibles (coins) in infinity mode.
        
        Collectible types:
        - Single coins (random placement)
        - Coin arcs (arch patterns)
        - Coin stairs (staircase patterns)
        - Flat coin rows (horizontal lines)
        
        Soft-lock prevention:
        - Ensures coins have proper support (can't float in air)
        - Respects coin cooldown (prevents overcrowding)
        - Skips in intro columns (keeps start area clear)
        """
        # Single coin spawn (14% chance)
        if self.randomizer.random() < 0.14:
            ceiling = max(4, self._surface_row() - 2)
            coin_y = self.randomizer.randint(4, ceiling)
            self._attempt_coin_spawn(x_index, coin_y)
        
        # Skip coin patterns if cooldown active or too early
        if self.coinCooldown > 0 or x_index < 4:
            return
        
        # Coin pattern spawn (10% chance)
        if self.randomizer.random() < 0.10:
            length = self.randomizer.randint(3, 6)  # Pattern length
            start = x_index - length + 1
            if start >= 0:
                surface_row = self._surface_row()
                min_height = max(5, surface_row - self.MAX_JUMP_HEIGHT)
                max_height = surface_row - 2
                base_height = self.randomizer.randint(min_height, max_height) if max_height >= min_height else min_height
                pattern = self.randomizer.choice(["flat", "arch", "stair"])
                
                # Generate pattern
                for offset in range(length):
                    if pattern == "arch":
                        # Arch pattern: highest in middle, lower on sides
                        mid = length // 2
                        height = base_height - abs(offset - mid)
                    elif pattern == "stair":
                        # Stair pattern: descending from left to right
                        height = base_height - offset
                    else:  # "flat"
                        # Flat pattern: all coins at same height
                        height = base_height
                    
                    coin_y = max(2, height)  # Ensure minimum height
                    self._attempt_coin_spawn(start + offset, coin_y)
                
                # Set cooldown based on pattern length
                self.coinCooldown = length + 2

    def _maybe_spawn_items(self, x_index):
        """Place an occasional item block; power-ups must emerge from blocks."""
        # The original underwater stages use coins and aquatic enemies, not
        # floating mushroom/star/flower pickups or question-block power-ups.
        if self._biome_at_column(x_index) == "underwater":
            return
        if getattr(self, "restColumnsRemaining", 0) > 0:
            return
        if self.gapRemaining > 0:
            return
        if getattr(self, "safeColumnsRemaining", 0) > 0:
            return
        if self.coinCooldown > 0:
            return
        intro = getattr(self, "initialFlatColumns", self.INTRO_SAFE_COLUMNS)
        if x_index < intro + 10:
            return

        item_interval = 70 + (x_index // 250) * 15
        if x_index <= 0 or x_index % item_interval >= 3 or self.randomizer.random() >= 0.45:
            return

        surface = self._surface_row()
        block_y = max(2, surface - 4)
        if not self._tile_is_empty(x_index, block_y):
            return
        item = self._select_random_box_item()
        if x_index > 200 and self.randomizer.random() < 0.035:
            item = "OneUpMushroom"
        item = self._sanitize_powerup_item(item)
        if self.addRandomBox(x_index, block_y, item):
            self.coinCooldown = max(self.coinCooldown, 5)

    def _maybe_spawn_enemies(self, x_index):
        """
        Spawns enemies per biome with full enemy pool.

        Each biome gets a distinct enemy composition:
        - normal: BuzzyBeetle, HammerBro, Goomba, Koopa
        - firebar: HammerBro, BuzzyBeetle, Koopa, Goomba
        - canyon: HammerBro, BuzzyBeetle, Koopa, Goomba
        - ice: BuzzyBeetle, Goomba, Koopa
        - mushroom: BuzzyBeetle, Goomba, Koopa
        - underground: Goomba, Koopa, BuzzyBeetle
        - underwater: CheepCheep, Blooper, BuzzyBeetle, Goomba

        Harder enemies (HammerBro, BuzzyBeetle) are gated by difficulty tier.
        Lakitu appears as a flying enemy in later columns.
        """
        if self.enemyCooldown > 0 or self.gapRemaining > 0:
            return
        if getattr(self, "restColumnsRemaining", 0) > 0:
            return
        # Don't spawn enemies right after a gap (landing zone safety)
        if getattr(self, "safeColumnsRemaining", 0) > 2:
            return

        tier = self._get_difficulty_tier()
        enemy_chance = {"easy": 0.12, "medium": 0.18, "hard": 0.22}[tier]
        if self.randomizer.random() >= enemy_chance:
            return

        spawn_y = max(2, self._surface_row() - 1)
        if self._is_biome("underwater"):
            surface = self._surface_row()
            free_rows = [
                row for row in range(2, max(3, surface - 1))
                if self._tile_is_empty(x_index, row)
            ]
            if not free_rows:
                return
            spawn_y = self.randomizer.choice(free_rows)
        roll = self.randomizer.random()

        if (
            not self._is_biome("underwater")
            and x_index > 45
            and tier != "easy"
            and self.randomizer.random() < 0.12
        ):
            variant = self.randomizer.choice(("green", "red"))
            self.addParatroopa(x_index, spawn_y, variant=variant)

        elif self._is_biome("firebar"):
            if roll < 0.30 and tier != "easy":
                self.addHammerBro(x_index, spawn_y)
            elif roll < 0.55:
                self.addBuzzyBeetle(x_index, spawn_y)
            elif roll < 0.75:
                self._spawn_endless_koopa(x_index, spawn_y)
            else:
                self.addGoomba(x_index, spawn_y)

        elif self._is_biome("canyon"):
            if roll < 0.25 and tier != "easy":
                self.addHammerBro(x_index, spawn_y)
            elif roll < 0.50:
                self.addBuzzyBeetle(x_index, spawn_y)
            elif roll < 0.75:
                self._spawn_endless_koopa(x_index, spawn_y)
            else:
                self.addGoomba(x_index, spawn_y)

        elif self._is_biome("ice"):
            if roll < 0.40:
                self.addBuzzyBeetle(x_index, spawn_y)
            elif roll < 0.70:
                self.addGoomba(x_index, spawn_y)
            else:
                self._spawn_endless_koopa(x_index, spawn_y)

        elif self._is_biome("mushroom"):
            if roll < 0.35:
                self.addBuzzyBeetle(x_index, spawn_y)
            elif roll < 0.65:
                self.addGoomba(x_index, spawn_y)
            else:
                self._spawn_endless_koopa(x_index, spawn_y)

        elif self._is_biome("underground"):
            if roll < 0.40:
                self.addGoomba(x_index, spawn_y)
            elif roll < 0.65:
                self._spawn_endless_koopa(x_index, spawn_y)
            elif roll < 0.85 and tier != "easy":
                self.addBuzzyBeetle(x_index, spawn_y)
            else:
                self.addGoomba(x_index, spawn_y)

        elif self._is_biome("underwater"):
            if roll < 0.65:
                fish_variant = "gray" if self.randomizer.random() < 0.5 else "red"
                self.addCheepCheep(x_index, spawn_y, variant=fish_variant)
            else:
                self.addBlooper(x_index, spawn_y)

        else:  # normal biome
            if roll < 0.30 and tier != "easy":
                self.addBuzzyBeetle(x_index, spawn_y)
            elif roll < 0.45 and tier != "easy":
                self.addHammerBro(x_index, spawn_y)
            elif roll < 0.70:
                self.addGoomba(x_index, spawn_y)
            else:
                self.addKoopa(x_index, spawn_y)

        self.enemyCooldown = self.randomizer.randint(4, 8)

        # Lakitu - flying enemy in later columns (drops Spiny eggs)
        if (
            x_index > 30
            and tier != "easy"
            and not self._is_biome("underwater")
            and self.randomizer.random() < 0.025
        ):
            sky_y = self.randomizer.randint(1, 4)
            self.addLakitu(x_index, sky_y)

    def _spawn_endless_koopa(self, x, y):
        """Keep both SMB1 shell colors in the endless enemy pool."""
        variant = self.randomizer.choice(("green", "green", "red"))
        return self.addKoopa(x, y, variant=variant)

    def _prepare_biome_for_column(self, x_index):
        if not self.endless:
            return
        intro = getattr(self, "initialFlatColumns", self.INTRO_SAFE_COLUMNS)
        if x_index < intro:
            return
        if self.biomeColumnsRemaining <= 0:
            if self.gapRemaining > 0:
                # Keep an opened pit within its biome. A transition in the
                # middle of a gap can mix terrain, palettes, and water rules.
                return
            self._start_new_biome()
        if self.biomeColumnsRemaining > 0:
            self.biomeColumnsRemaining -= 1

    def _start_new_biome(self):
        previous_biome = getattr(self, "activeBiome", "normal")
        if previous_biome in (
            "firebar", "fortress", "mushroom", "underground", "ice", "canyon"
        ):
            self.restColumnsRemaining = max(
                getattr(self, "restColumnsRemaining", 0),
                self.randomizer.randint(8, 12),
            )
        biome = self._select_next_biome()
        self.activeBiome = biome
        if biome == "underwater":
            self.groundHeight = 1
            self.terrainCountdown = 0
            self.pendingGroundProfile = []
        elif previous_biome == "underwater":
            self.groundHeight = 2
            self.terrainCountdown = 0
            self.pendingGroundProfile = []
        self.biomeColumnsRemaining = self.randomizer.randint(60, 150)
        self.biomeData = {}
        if biome == "underwater":
            self._trim_incompatible_underwater_lookahead(self.generatedColumns)
        if biome == "firebar":
            self.biomeData["firebars_remaining"] = self.randomizer.randint(5, 10)
            self.biomeData["next_spawn_column"] = (
                self.generatedColumns + self.randomizer.randint(6, 10)
            )
        elif biome == "canyon":
            self.biomeData["ground_columns"] = 3
            self.biomeData["height_timer"] = 0
        elif biome == "mushroom":
            self.biomeData["next_spawn_column"] = (
                self.generatedColumns + self.randomizer.randint(8, 12)
            )
            self.biomeData["intro_pending"] = True
        elif biome == "underground":
            self.biomeData["next_spawn_column"] = (
                self.generatedColumns + self.randomizer.randint(5, 9)
            )
            self.biomeData["shelves_remaining"] = self.randomizer.randint(3, 6)
        elif biome == "underwater":
            self.biomeData["coral_next_column"] = (
                self.generatedColumns + self.randomizer.randint(4, 7)
            )
        elif biome == "fortress":
            self.biomeData.update(
                {
                    "blasters_remaining": self.randomizer.randint(2, 4),
                    "next_spawn_column": self.generatedColumns + self.randomizer.randint(7, 11),
                    "podo_remaining": self.randomizer.randint(1, 3),
                    "lava_pits": self.randomizer.randint(2, 4),
                    "lava_next_column": self.generatedColumns + self.randomizer.randint(12, 20),
                }
            )

    def _draw_lava_gap_column(self, column):
        """Render a non-colliding lava column across a ground gap."""
        if not self.level or not 0 <= column < len(self.level[0]):
            return
        surface_row = self._surface_row()
        sky = self.get_theme_sprite("sky", column=column)
        for row in range(surface_row, len(self.level)):
            self.level[row][column] = Tile(sky, None)
        lava = self.get_theme_sprite("lava", column=column)
        if lava is not None and lava.image is not None:
            self._register_overlay(
                lava, column * 32, surface_row * 32, pixel=True
            )

    def _trim_incompatible_underwater_lookahead(self, first_water_column):
        """Remove queued lookahead features that crossed into a water biome."""
        aquatic = {"CheepCheep", "Blooper", "Coin"}
        block_types = {"BrickBlock", "CoinBox", "CoinBrick", "RandomBox"}
        kept = []
        for entity in self.entityList:
            rect = getattr(entity, "rect", None)
            if rect is None or rect.right <= first_water_column * 32:
                kept.append(entity)
                continue
            kind = type(entity).__name__
            if kind in aquatic:
                kept.append(entity)
                continue
            if kind in block_types:
                column = int(rect.centerx // 32)
                row = int((rect.top + 1) // 32)
                if 0 <= column < len(self.level[0]) and 0 <= row < len(self.level):
                    self.level[row][column] = Tile(self.get_theme_sprite("sky"), None)
            # These entities were placed by queued features from the previous
            # biome, but their destination lies inside the new water section.
        self.entityList = kept
        self.classicQueue = [
            feature for feature in self.classicQueue
            if feature.get("x", -1) < first_water_column
        ]
        if not self.classicQueue:
            self.classicQueueEnd = -1
        self.backgroundQueue = [
            feature for feature in self.backgroundQueue
            if feature.get("x", -1) < first_water_column
        ]

        # Clouds and land scenery can be queued by the preceding biome with
        # art that extends over the transition. Rebuild both decoration
        # indexes after removing anything that reaches the water columns.
        for name, foreground in (("overlaySprites", False), ("foregroundSprites", True)):
            decorations = getattr(self, name)
            kept_decorations = []
            for decoration in decorations:
                world_x = decoration["x"] if decoration["pixel"] else decoration["x"] * 32
                if world_x + decoration.get("width", 32) <= first_water_column * 32:
                    kept_decorations.append(decoration)
            setattr(self, name, [])
            buckets = {}
            max_width = 0
            for decoration in kept_decorations:
                replacement = dict(decoration, order=len(getattr(self, name)))
                getattr(self, name).append(replacement)
                self._index_decoration(replacement, buckets, foreground)
                max_width = max(max_width, replacement["width"])
            if foreground:
                self._foregroundBuckets = buckets
                self._maxForegroundWidth = max_width
            else:
                self._overlayBuckets = buckets
                self._maxOverlayWidth = max_width

    def _select_next_biome(self):
        options = [
            "normal",
            "normal",
            "normal",
            "underground",
            "underground",
            "firebar",
            "fortress",
            "canyon",
            "ice",
            "mushroom",
            "underwater",
        ]
        biome = self.randomizer.choice(options)
        if biome == self.activeBiome and biome != "normal":
            remaining = [opt for opt in options if opt != biome]
            biome = self.randomizer.choice(remaining)
        return biome

    def _is_dark_biome(self):
        return self._active_theme_biome() in self.DARK_BIOMES

    def _is_daytime_biome(self):
        return (
            self.endless
            and getattr(self, "activeBiome", "normal") in self.DAYTIME_BIOMES
        )

    def _is_biome(self, name):
        if self.endless:
            return getattr(self, "activeBiome", "normal") == name
        return getattr(self, "stageBiome", "normal") == name

    def is_underwater_at(self, rect):
        """Return whether this player rectangle is submerged in the stage."""
        if self.endless:
            return self._biome_at_column(rect.centerx // 32) == "underwater"
        if not self._is_biome("underwater"):
            return False
        if not self._is_underwater_column(rect.centerx // 32):
            return False
        if self.stageWaterline is None:
            return True
        return rect.bottom > int(self.stageWaterline * 32)

    def _is_underwater_column(self, x):
        if self._biome_at_column(x) != "underwater":
            return False
        if self.endless or self.stageWaterRegions is None:
            return True
        return any(start <= x < end for start, end in self.stageWaterRegions)

    def _is_underwater_cell(self, x, y):
        if not self._is_underwater_column(x):
            return False
        if self.endless or self.stageWaterline is None:
            return True
        return y >= self.stageWaterline

    _BIOME_THEME_MAP = {
        "normal": {
            "sky": "sky",
            "ground": "ground",
            "bricks": "bricks",
            "hardBlock": "hardBlock",
            "empty": "empty",
            "question": "CoinBox",
        },
        "fortress": {
            "sky": "sky_fortress",
            "ground": "castle_brick",
            "bricks": "castle_brick",
            "hardBlock": "castle_brick",
            "empty": "empty_block",
            "question": "castle_question",
        },
        "underwater": {
            "sky": "underwater_fill",
            "ground": "ground_underwater",
            "bricks": "bricks",
            "hardBlock": "ground_underwater",
            "empty": "empty_block",
            "question": "CoinBox",
        },
        "underground": {
            "sky": "sky_underground",
            "ground": "ground_underground",
            "bricks": "bricks_underground",
            "hardBlock": "hardBlock_underground",
            "empty": "empty_block",
            "question": "CoinBox",
        },
        "ice": {
            "sky": "sky",
            "ground": "ground",
            "bricks": "bricks",
            "hardBlock": "hardBlock",
            "empty": "empty",
            "question": "CoinBox",
        },
        "firebar": {
            "sky": "sky_fortress",
            "ground": "castle_brick",
            "bricks": "castle_brick",
            "hardBlock": "castle_brick",
            "empty": "empty_block",
            "question": "castle_question",
            "lava": "lava",
        },
        "canyon": {
            "sky": "sky",
            "ground": "ground",
            "bricks": "bricks",
            "hardBlock": "hardBlock",
            "empty": "empty",
            "question": "CoinBox",
        },
        "mushroom": {
            "sky": "sky",
            "ground": "ground",
            "bricks": "bricks",
            "hardBlock": "hardBlock",
            "empty": "empty",
            "question": "CoinBox",
        },
    }

    def _active_theme_biome(self):
        if not self.endless:
            return getattr(self, "stageBiome", "normal")
        return getattr(self, "activeBiome", "normal")

    def _biome_at_column(self, column):
        if self.endless:
            column = int(column)
            if 0 <= column < len(self.columnBiomes):
                return self.columnBiomes[column]
            return getattr(self, "activeBiome", "normal")
        return getattr(self, "stageBiome", "normal")

    def _span_matches_biome(self, start_column, end_column, biome=None):
        """Reject multi-column features that would spill across a biome seam."""
        if not self.endless:
            return True
        biome = biome or self.activeBiome
        start_column, end_column = int(start_column), int(end_column)
        if start_column < 0 or end_column < start_column:
            return False
        known_end = min(end_column, len(self.columnBiomes))
        if any(
            self.columnBiomes[column] != biome
            for column in range(start_column, known_end)
        ):
            return False
        future_columns = max(0, end_column - len(self.columnBiomes))
        return (
            self.activeBiome == biome
            and future_columns <= self.biomeColumnsRemaining
        )

    def _biome_sprite(self, logical_name, biome=None):
        biome = biome or self._active_theme_biome()
        theme = self._BIOME_THEME_MAP.get(biome, self._BIOME_THEME_MAP["normal"])
        if logical_name == "ground":
            return theme.get("ground", self._ground_sprite_for_biome())
        return theme.get(logical_name, logical_name)

    def get_theme_sprite(self, logical_name, column=None):
        biome = self._biome_at_column(column) if column is not None else None
        sprite_name = self._biome_sprite(logical_name, biome)
        return self.sprites.spriteCollection.get(sprite_name)

    def get_theme_sprite_name(self, logical_name):
        return self._biome_sprite(logical_name)

    def _ground_sprite_for_biome(self):
        if self._is_biome("fortress"):
            return "castle_brick"
        if self._is_biome("underwater"):
            return "ground_underwater"
        if self._is_biome("underground"):
            return "ground_underground"
        return "ground"

    def _biome_adjusts_ground_height(self):
        if self._is_biome("underwater"):
            self.groundHeight = 1
            self.terrainCountdown = 0
            self.pendingGroundProfile = []
            return True
        if not self._is_biome("canyon"):
            return False
        timer = self.biomeData.get("height_timer", 0)
        if timer <= 0:
            delta = self.randomizer.choice([-1, 0, 1])
            self.groundHeight = max(2, min(4, self.groundHeight + delta))
            self.biomeData["height_timer"] = self.randomizer.randint(2, 4)
        else:
            self.biomeData["height_timer"] = timer - 1
        return True

    def _apply_canyon_gap_rules(self, x_index):
        if not self._is_biome("canyon"):
            return False
        intro = getattr(self, "initialFlatColumns", self.INTRO_SAFE_COLUMNS)
        if x_index < intro + 2:
            return True
        if self.gapRemaining > 0:
            return True
        ground_columns = self.biomeData.get("ground_columns", 0)
        if ground_columns > 0:
            self.biomeData["ground_columns"] = ground_columns - 1
            return True
        gap_width = self.randomizer.randint(1, 2)
        self.gapRemaining = gap_width
        self.biomeData["ground_columns"] = self.randomizer.randint(3, 6)
        return True

    def _apply_biome_features(self, x_index):
        if self._is_biome("firebar"):
            self._biome_firebar_features(x_index)
            return True
        if self._is_biome("fortress"):
            self._biome_fortress_features(x_index)
            return True
        if self._is_biome("canyon"):
            self._biome_canyon_features(x_index)
            return True
        if self._is_biome("mushroom"):
            self._biome_mushroom_features(x_index)
            return True
        if self._is_biome("underground"):
            self._biome_underground_features(x_index)
            return True
        if self._is_biome("underwater"):
            self._biome_underwater_features(x_index)
            return True
        if self._is_biome("ice"):
            self._biome_ice_features(x_index)
            return True
        return False

    def _biome_firebar_features(self, x_index):
        self._maybe_place_background(x_index)
        data = self.biomeData
        firebars_remaining = data.get("firebars_remaining", 0)
        next_spawn = data.get("next_spawn_column", x_index)
        if (
            firebars_remaining > 0
            and self.structureCooldown == 0
            and self.gapRemaining == 0
            and x_index >= next_spawn
        ):
            if self._spawn_firebar_course_segment(x_index):
                data["firebars_remaining"] = firebars_remaining - 1
                data["next_spawn_column"] = x_index + self.randomizer.randint(7, 12)
                self.structureCooldown = self.randomizer.randint(4, 7)
                self._reserve_safe_ground(6)
        self._maybe_spawn_collectibles(x_index)
        self._maybe_spawn_items(x_index)
        self._maybe_spawn_enemies(x_index)

    def _spawn_firebar_course_segment(self, x_index):
        surface_row = self._surface_row()
        pedestal_row = max(2, surface_row - 1)
        width = self.randomizer.randint(2, 3)
        radius_tiles = self.randomizer.randint(3, 4)
        # Leave room to the right of the hazard for the generator's clearance
        # scan. The old center sat at the generation frontier, so its right
        # half always fell outside the level array and every check failed.
        center_column = x_index - radius_tiles - 2
        start_column = center_column - width // 2
        if start_column < 2:
            return False
        if not self._span_matches_biome(
            start_column, center_column + radius_tiles + 1, "firebar"
        ):
            return False
        columns = range(start_column, start_column + width)
        if self._columns_blocked_by_bush(columns):
            return False
        for column in columns:
            if not self._tile_is_empty(column, pedestal_row):
                return False
        center_row = max(3, pedestal_row - self.randomizer.randint(2, 3))
        if not self._firebar_clearance_ok(center_column, center_row, radius_tiles, surface_row):
            return False
        # Validate first: previously a failed clearance check left floating
        # pedestals behind with no firebar, cluttering the level.
        for column in columns:
            self.addHardBlock(column, pedestal_row)
        segments = radius_tiles + 2
        self.addFireBar(center_column, center_row, segments=segments)
        return True

    def _biome_canyon_features(self, x_index):
        self._maybe_place_background(x_index)
        self._maybe_spawn_collectibles(x_index)
        self._maybe_spawn_items(x_index)
        self._maybe_spawn_enemies(x_index)

    def _biome_ice_features(self, x_index):
        self._maybe_place_background(x_index)
        self._maybe_spawn_ice_ground_cluster(x_index)
        self._maybe_spawn_ice_ledge(x_index)
        self._maybe_spawn_collectibles(x_index)
        self._maybe_spawn_items(x_index)
        self._maybe_spawn_enemies(x_index)

    def _biome_underground_features(self, x_index):
        self._maybe_place_underground_background(x_index)
        data = self.biomeData
        next_spawn = data.get("next_spawn_column", x_index)
        shelves_remaining = data.get("shelves_remaining", 0)
        if (
            shelves_remaining > 0
            and self.structureCooldown == 0
            and self.gapRemaining == 0
            and x_index >= next_spawn
            and self.randomizer.random() < 0.35
        ):
            if self._maybe_spawn_brick_shelf(x_index):
                data["shelves_remaining"] = shelves_remaining - 1
                data["next_spawn_column"] = x_index + self.randomizer.randint(6, 10)
                self.structureCooldown = self.randomizer.randint(4, 8)
                self._reserve_safe_ground(5)
        if (
            self.structureCooldown == 0
            and self.gapRemaining == 0
            and x_index >= 3
            and self.randomizer.random() < 0.08
        ):
            pipe_columns = [x_index - 1, x_index]
            if not self._columns_blocked_by_bush(pipe_columns):
                pipe_y = max(6, self._surface_row() - self.randomizer.randint(1, 2))
                pipe_length = self.randomizer.randint(2, 3)
                if self.addPipeSprite(
                    x_index - 1,
                    pipe_y,
                    pipe_length,
                    plant=True,
                    plant_variant="underground",
                ):
                    self.structureCooldown = self.randomizer.randint(5, 9)
                    self._reserve_safe_ground(5)
        if getattr(self, "restColumnsRemaining", 0) <= 0:
            self._maybe_spawn_structures(x_index)
        self._maybe_spawn_collectibles(x_index)
        self._maybe_spawn_items(x_index)
        self._maybe_spawn_enemies(x_index)

    def _biome_fortress_features(self, x_index):
        self._maybe_place_background(x_index)
        data = self.biomeData

        # Place ceiling blocks for indoor fortress feel (rows 1-2)
        if x_index > 0 and self.generatedColumns % 3 == 0:
            ceiling_row = 1
            if self._tile_is_empty(x_index, ceiling_row):
                self.addHardBlock(x_index, ceiling_row)

        # BillBlaster placement
        blasters_remaining = data.get("blasters_remaining", 0)
        next_spawn = data.get("next_spawn_column", x_index)
        if (
            blasters_remaining > 0
            and self.structureCooldown == 0
            and self.gapRemaining == 0
            and self.safeColumnsRemaining == 0
            and getattr(self, "restColumnsRemaining", 0) == 0
            and x_index >= next_spawn
        ):
            surface_row = self._surface_row()
            # The 32x64 blaster is anchored at the ground surface and extends
            # two tile rows upward. The previous check included x_index + 1
            # and a frontier bound, so it could never spawn at the live edge.
            blaster_row = max(3, surface_row - 1)
            if all(
                self._tile_is_empty(x_index, row)
                for row in (blaster_row - 1, blaster_row)
            ):
                self.addBillBlaster(x_index, blaster_row)
                data["blasters_remaining"] = blasters_remaining - 1
                data["next_spawn_column"] = x_index + self.randomizer.randint(10, 16)
                self.structureCooldown = self.randomizer.randint(5, 9)
                self._reserve_safe_ground(6)

        # Lava pits are capped at three columns and only start after a clear
        # run-up. The first column is carved now; the ordinary gap countdown
        # carries the pit through the next one or two generated columns.
        lava_pits = data.get("lava_pits", 0)
        lava_next = data.get("lava_next_column", 0)
        if (
            lava_pits > 0
            and x_index >= lava_next
            and self.gapRemaining == 0
            and self.structureCooldown == 0
            and self.safeColumnsRemaining == 0
            and getattr(self, "restColumnsRemaining", 0) == 0
        ):
            surface_row = self._surface_row()
            pit_width = self.randomizer.randint(2, 3)
            if (
                surface_row > 3
                and self.randomizer.random() < 0.25
                and self._span_matches_biome(
                    x_index, x_index + pit_width, "fortress"
                )
            ):
                self._draw_lava_gap_column(x_index)
                self.gapRemaining = pit_width - 1
                bridge_spawned = (
                    self.randomizer.random() < 0.18
                    and self.addFortressBridge(x_index, surface_row, pit_width + 1)
                )
                podo_remaining = data.get("podo_remaining", 0)
                if not bridge_spawned and podo_remaining > 0 and self.randomizer.random() < 0.8:
                    self.addPodoboo(
                        x_index + pit_width // 2,
                        surface_row,
                    )
                    data["podo_remaining"] = podo_remaining - 1
                data["lava_pits"] = lava_pits - 1
                data["lava_next_column"] = (
                    x_index + pit_width + self.randomizer.randint(10, 18)
                )
                return
        if self.gapRemaining > 0 or self.safeColumnsRemaining > 0:
            return
        self._maybe_spawn_collectibles(x_index)
        self._maybe_spawn_items(x_index)
        self._maybe_spawn_enemies(x_index)

    def _biome_underwater_features(self, x_index):
        """
        Underwater biome features:
        - Full-screen NES blue water, with no exposed waterline
        - Original coral cutouts on the seabed and block formations
        - CheepCheep and Blooper enemies
        - Coins only; SMB1 underwater stages do not drop free power-ups
        """
        data = self.biomeData
        next_spawn = data.get("next_spawn_column", x_index)

        surface = self._surface_row()

        coral_next = data.get("coral_next_column", x_index)
        if x_index >= coral_next:
            flora_roll = self.randomizer.random()
            if flora_roll < 0.4:
                self.addUnderwaterPlantSprite(x_index, surface)
            elif flora_roll < 0.8:
                coral_row = max(2, surface - 3)
                self.addCoralSprite(x_index, coral_row, tall=True)
            else:
                coral_row = max(2, surface - 1)
                self.addCoralSprite(x_index, coral_row)
            data["coral_next_column"] = x_index + self.randomizer.randint(9, 15)

        # Spawn underwater structure platforms occasionally
        if (
            self.structureCooldown == 0
            and self.gapRemaining == 0
            and x_index >= next_spawn
            and self.randomizer.random() < 0.5
        ):
            layout = self.randomizer.choice(("pillar", "ledge", "arch"))
            plan = []
            if layout == "pillar":
                width = self.randomizer.randint(2, 3)
                height = self.randomizer.randint(2, 4)
                start = x_index - width + 1
                plan = [
                    (column, row)
                    for column in range(start, x_index + 1)
                    for row in range(surface - height, surface)
                ]
            elif layout == "ledge":
                width = self.randomizer.randint(3, 5)
                start = x_index - width + 1
                row = max(4, surface - self.randomizer.randint(3, 5))
                plan = [(column, row) for column in range(start, x_index + 1)]
            else:
                width = self.randomizer.randint(5, 6)
                start = x_index - width + 1
                top = max(4, surface - 4)
                plan = [(column, top) for column in range(start, x_index + 1)]
                for column in (start, x_index):
                    for row in range(top + 1, surface):
                        plan.append((column, row))

            same_biome = self._span_matches_biome(start, x_index + 1, "underwater")
            clear = same_biome and all(
                0 <= column < len(self.level[0])
                and 0 <= row < len(self.level)
                and self._tile_is_empty(column, row)
                for column, row in plan
            )
            if clear:
                for column, row in plan:
                    self.addHardBlock(column, row)
                if layout == "ledge" and self.randomizer.random() < 0.45:
                    for offset in range(width):
                        self._attempt_coin_spawn(start + offset, max(2, row - 1))
                data["next_spawn_column"] = x_index + self.randomizer.randint(6, 10)
                self.structureCooldown = self.randomizer.randint(4, 7)
                self._reserve_safe_ground(2)

        self._maybe_spawn_collectibles(x_index)
        self._maybe_spawn_enemies(x_index)

    def _biome_mushroom_features(self, x_index):
        self._maybe_place_background(x_index)
        data = self.biomeData
        next_spawn = data.get("next_spawn_column", x_index)
        if data.get("intro_pending"):
            if self._spawn_mushroom_intro(x_index):
                data["intro_pending"] = False
                data["next_spawn_column"] = x_index + self.randomizer.randint(9, 14)
                self.structureCooldown = self.randomizer.randint(6, 10)
                self._reserve_safe_ground(6)
            return
        if (
            self.structureCooldown == 0
            and self.gapRemaining == 0
            and x_index >= next_spawn
            and self._spawn_mushroom_course(x_index)
        ):
            data["next_spawn_column"] = x_index + self.randomizer.randint(10, 16)
            self.structureCooldown = self.randomizer.randint(6, 11)
            self._reserve_safe_ground(6)
        self._maybe_spawn_collectibles(x_index)
        self._maybe_spawn_items(x_index)
        self._maybe_spawn_enemies(x_index)

    def _spawn_mushroom_course(self, x_index):
        mushroom_count = self.randomizer.randint(3, 4)
        widths = []
        gaps = []
        total_span = 0
        for index in range(mushroom_count):
            width = self.randomizer.randint(3, 5)
            if width % 2 == 0:
                width -= 1
            width = max(3, width)
            widths.append(width)
            total_span += width
            if index < mushroom_count - 1:
                gap = self.randomizer.randint(2, 3)
                gaps.append(gap)
                total_span += gap
        surface_row = self._surface_row()
        if surface_row <= 1:
            return False
        base_drop = self.randomizer.randint(2, 4)
        cap_rows = []
        current_row = max(2, surface_row - base_drop)
        cap_rows.append(current_row)
        for _ in range(1, mushroom_count):
            delta = self.randomizer.choice([-1, 0, 1])
            current_row = max(2, min(surface_row - 3, current_row + delta))
            cap_rows.append(current_row)
        stair_width = self.randomizer.randint(2, 4)
        approach_gap = self.randomizer.randint(1, 2)
        total_span += stair_width + approach_gap
        start_column = x_index - total_span + 1
        if start_column < 1:
            return False
        if not self._span_matches_biome(start_column, start_column + total_span):
            return False
        columns = range(start_column, start_column + total_span)
        if self._columns_blocked_by_bush(columns):
            return False
        if not self._build_approach_stair(start_column, stair_width, cap_rows[0], surface_row):
            return False
        gap_start = start_column + stair_width
        if not self._gap_is_clear(gap_start, approach_gap, max(1, cap_rows[0] - 1), surface_row - 1):
            return False
        column = gap_start + approach_gap
        for idx, width in enumerate(widths):
            cap_row = cap_rows[idx]
            if not self._area_is_clear(column, width, cap_row):
                return False
            color = self.randomizer.choice(["red", "green"])
            if not self._build_mushroom_cap(column, width, cap_row, color):
                return False
            stem_col = column + width // 2
            stem_height = surface_row - cap_row
            self._build_mushroom_stem(stem_col, cap_row + 1, stem_height)
            coin_row = max(1, cap_row - 2)
            for offset in range(width):
                if self.randomizer.random() < 0.5:
                    self._attempt_coin_spawn(column + offset, coin_row)
            if idx < len(gaps):
                gap_width = min(3, max(2, gaps[idx]))
                top_row = max(1, cap_row - 1)
                if not self._gap_is_clear(column + width, gap_width, top_row, surface_row - 1):
                    return False
                column += width + gap_width
            else:
                column += width
        return True

    def _spawn_mushroom_intro(self, x_index):
        cap_width = 5
        stair_width = self.randomizer.randint(2, 4)
        approach_gap = self.randomizer.randint(1, 2)
        total_span = stair_width + approach_gap + cap_width
        start_column = x_index - total_span + 1
        if start_column < 1:
            return False
        if not self._span_matches_biome(start_column, start_column + total_span):
            return False
        columns = range(start_column, start_column + total_span)
        if self._columns_blocked_by_bush(columns):
            return False
        surface_row = self._surface_row()
        if surface_row <= 1:
            return False
        cap_row = max(2, surface_row - self.randomizer.randint(2, 4))
        if not self._build_approach_stair(start_column, stair_width, cap_row, surface_row):
            return False
        gap_start = start_column + stair_width
        if not self._gap_is_clear(gap_start, approach_gap, max(1, cap_row - 1), surface_row - 1):
            return False
        mushroom_start = gap_start + approach_gap
        if not self._area_is_clear(mushroom_start, cap_width, cap_row):
            return False
        color = self.randomizer.choice(["red", "green"])
        if not self._build_mushroom_cap(mushroom_start, cap_width, cap_row, color):
            return False
        stem_col = mushroom_start + cap_width // 2
        stem_height = surface_row - cap_row
        self._build_mushroom_stem(stem_col, cap_row + 1, stem_height)
        coin_row = max(1, cap_row - 2)
        for offset in range(cap_width):
            if self.randomizer.random() < 0.5:
                self._attempt_coin_spawn(mushroom_start + offset, coin_row)
        return True

    def _build_mushroom_stairs(
        self, start_column, span, step_count, base_row, target_top_row
    ):
        if span <= 0 or step_count <= 0:
            return True
        span = max(span, step_count)
        end_column = start_column + span - 1
        columns = [start_column]
        remaining_columns = span - 1
        steps_left = max(0, step_count - 1)
        while steps_left > 0:
            steps_after = steps_left - 1
            max_step = min(3, remaining_columns - steps_after)
            min_step = max(1, remaining_columns - steps_after * 3)
            if max_step < min_step:
                min_step = max_step
            step = self.randomizer.randint(min_step, max_step)
            columns.append(columns[-1] + step)
            remaining_columns -= step
            steps_left -= 1
        if columns[-1] != end_column:
            if end_column - columns[-1] > 3:
                return False
            columns[-1] = end_column
        placements = []
        total_transitions = len(columns) - 1
        current_top = base_row
        placements.append((columns[0], current_top))
        for idx in range(1, len(columns)):
            diff_to_target = current_top - target_top_row
            remaining_transitions = total_transitions - idx
            if diff_to_target > 0:
                min_drop = max(0, diff_to_target - remaining_transitions * 2)
                max_drop = min(2, diff_to_target)
                if max_drop < min_drop:
                    min_drop = max_drop
                drop = self.randomizer.randint(min_drop, max_drop)
                current_top -= drop
            else:
                if remaining_transitions > 0 and self.randomizer.random() < 0.35:
                    descent = min(2, base_row - current_top)
                    descent = min(descent, remaining_transitions * 2)
                    if descent > 0:
                        current_top += self.randomizer.randint(1, descent)
            placements.append((columns[idx], current_top))
        if placements[-1][1] != target_top_row:
            if len(placements) >= 2 and abs(placements[-2][1] - target_top_row) > 2:
                return False
            placements[-1] = (placements[-1][0], target_top_row)
        placement_map = {column: top_row for column, top_row in placements}
        current_top = placement_map.get(start_column, base_row)
        column_heights = {}
        for column in range(start_column, end_column + 1):
            if column in placement_map:
                current_top = placement_map[column]
            column_heights[column] = current_top
        for column, top_row in column_heights.items():
            for row in range(top_row, base_row + 1):
                if row < 0 or not self._tile_is_empty(column, row):
                    return False
        prev_row = None
        chain_length = 0
        for column in range(start_column, end_column + 1):
            top_row = column_heights[column]
            for row in range(top_row, base_row + 1):
                self.addHardBlock(column, row)
            if prev_row is not None and top_row == prev_row:
                chain_length += 1
            else:
                chain_length = 1
            prev_row = top_row
            if chain_length >= 2:
                question_row = max(0, top_row - 1)
                if self._tile_is_empty(column, question_row) and self.randomizer.random() < 0.35:
                    self.addRandomBox(
                        column, question_row, self._select_random_box_item()
                    )
        return True

    def _ensure_endless_buffer(self, camera):
        target_column = int(camera.entity.getPosIndexAsFloat().x) + self.endlessBuffer
        while self.generatedColumns <= target_column:
            self._append_column()

    def addRedMushroom(self, x, y):
        self.entityList.append(
            RedMushroom(self.screen, self.sprites.spriteCollection, x, y, self, self.sound)
        )

    def _bush_support_row(self, start_column, width=3):
        if width <= 0:
            return None
        columns = [start_column + offset for offset in range(width)]
        if start_column < 0 or not self.level or columns[-1] >= len(self.level[0]):
            return None
        support_rows = []
        for column in columns:
            ground_row = self._highest_solid_tile(column)
            if ground_row is None:
                return None
            tile = self.level[ground_row][column]
            if tile.sprite in self.pipeSprites:
                return None
            support_rows.append(ground_row)
        if max(support_rows) != min(support_rows):
            return None
        return support_rows[0]

    def _place_supported_bush(self, start_column):
        support_row = self._bush_support_row(start_column)
        if support_row is None:
            return False
        bush_row = max(0, support_row - 1)
        if not self._bush_has_clearance(start_column, bush_row):
            return False
        return self.addBushSprite(start_column, bush_row)

    def _maybe_schedule_tree(self, x_index):
        if not self._is_daytime_biome() or self.gapRemaining > 0:
            return False
        if x_index < 8 or self.randomizer.random() >= 0.05:
            return False
        tree_type = self.randomizer.choice(["tree_small", "tree_big"])
        column = max(0, x_index - self.randomizer.randint(1, 3))
        return self._schedule_scenery_feature(tree_type, column)

    def _place_small_tree(self, column):
        variant = self.randomizer.choice(("round", "oval"))
        return self._place_complete_tree(column, variant)

    def _place_big_tree(self, column):
        return self._place_complete_tree(column, "tall")

    def _place_complete_tree(self, column, variant):
        """Place one complete, palette-matched tree cutout rooted on ground."""
        if column < 0 or not self.level or column >= len(self.level[0]):
            return False
        theme = self._smb1_scenery_theme()
        sprite = self.sprites.spriteCollection.get(
            f"smb1_{theme}_tree_{variant}"
        )
        if sprite is None or sprite.image is None:
            return False
        width = self._scenery_span_tiles(sprite)
        support_row = self._scenery_support_row(column, width)
        if support_row is None:
            return False
        columns = range(column, column + width)
        if any(
            self.level[support_row][col].sprite in self.pipeSprites
            for col in columns
        ):
            return False
        pixel_y = support_row * 32 - sprite.image.get_height()
        if pixel_y < 0:
            return False
        first_row = pixel_y // 32
        for col in columns:
            if any(
                self.level[row][col].rect is not None
                for row in range(first_row, support_row)
            ):
                return False
        tile_width = width * 32
        pixel_x = column * 32 + max(0, (tile_width - sprite.image.get_width()) // 2)
        self._register_overlay(sprite, pixel_x, pixel_y, pixel=True)
        return True

    def _maybe_place_ground_flower(self, x_index):
        if self._is_dark_biome() or self.gapRemaining > 0 or x_index < 2:
            return False
        surface = self._surface_row()
        if surface >= len(self.level) - 1:
            return False
        sprite_name = "decorative_flower_normal"
        self._apply_decoration_sprite(x_index, surface, sprite_name)
        return True

    def _maybe_place_circle_bush(self, start_column):
        if start_column < 1:
            return False
        support_row = self._bush_support_row(start_column)
        if support_row is None:
            return False
        bush_row = max(0, support_row - 1)
        if not self._bush_has_clearance(start_column, bush_row):
            return False
        self._apply_decoration_sprite(start_column, bush_row, "circle_bush")
        return True

    def _maybe_place_underground_background(self, x_index):
        """Underground uses dark palette only — no flowers or trees."""
        return

    def _place_fence_run(self, start_column, length):
        if length < 3:
            return False
        support_row = self._bush_support_row(start_column, width=length)
        if support_row is None:
            return False
        fence_row = max(0, support_row - 1)
        return self.addFenceSprite(start_column, fence_row, length=length)

    def _place_scenery_from_data(self, entry):
        if isinstance(entry, dict):
            name = entry.get("type")
            column = entry.get("x")
        else:
            try:
                name, column = entry[0], entry[1]
            except (IndexError, TypeError):
                return False
        if name is None or column is None:
            return False
        normalized = self.SCENERY_TYPE_MAP.get(name)
        if not normalized:
            return False
        column = int(round(column))
        if normalized == "large_fortress":
            return False
        if normalized in self.SCENERY_QUEUE_TYPES:
            return self._place_grounded_sprite(
                normalized, column, require_ground_sprite=True
            )
        return False

    def _place_grounded_sprite(
        self, sprite_name, column, align="left", require_ground_sprite=False
    ):
        sprite = self.sprites.spriteCollection.get(sprite_name)
        if sprite is None or sprite.image is None:
            return False
        span_tiles = self._scenery_span_tiles(sprite)
        total_columns = len(self.level[0]) if self.level else 0
        if total_columns and column >= total_columns:
            column = total_columns - span_tiles
        if total_columns and column < 0:
            column = 0
        if total_columns and column + span_tiles > total_columns:
            return False
        support_row = self._scenery_support_row(
            column, span_tiles, require_ground_sprite=require_ground_sprite
        )
        if support_row is None:
            if require_ground_sprite:
                return False
            support_row = max(0, self._surface_row())
        pixel_base = support_row * 32
        pixel_y = pixel_base - sprite.image.get_height()
        tile_width = span_tiles * 32
        pixel_x = column * 32
        if align == "center":
            pixel_x += max(0, (tile_width - sprite.image.get_width()) // 2)
        elif align == "right":
            pixel_x += max(0, tile_width - sprite.image.get_width())
        self._register_overlay(sprite, pixel_x, pixel_y, pixel=True)
        return True

    def _scenery_support_row(
        self, start_column, span_tiles, require_ground_sprite=False
    ):
        if not self.level or span_tiles <= 0:
            return None
        columns = [start_column + offset for offset in range(span_tiles)]
        support_rows = []
        ground_sprite = None
        if require_ground_sprite:
            ground_sprite = self.sprites.spriteCollection.get("ground")
        for column in columns:
            row = self._highest_solid_tile(column)
            if row is None:
                return None
            if require_ground_sprite:
                tile = self.level[row][column]
                if tile.sprite != ground_sprite:
                    return None
            support_rows.append(row)
        if not support_rows:
            return None
        if max(support_rows) != min(support_rows):
            return None
        return support_rows[0]

    def _scenery_span_tiles(self, sprite):
        if sprite is None or sprite.image is None:
            return 1
        return max(1, int(math.ceil(sprite.image.get_width() / 32.0)))

    def _feature_width(self, feature_type):
        if feature_type == "cloud":
            theme = self._smb1_scenery_theme()
            variants = [
                self.sprites.spriteCollection.get(
                    f"smb1_{theme}_cloud_{size}"
                )
                for size in ("small", "medium", "wide")
            ]
            widths = [
                self._scenery_span_tiles(sprite)
                for sprite in variants
                if sprite and sprite.image
            ]
            return max(widths, default=3)
        if feature_type == "hill":
            theme = self._smb1_scenery_theme()
            widths = [
                self._scenery_span_tiles(
                    self.sprites.spriteCollection.get(
                        f"smb1_{theme}_hill_{size}"
                    )
                )
                for size in ("slope", "round", "low", "group")
                if self.sprites.spriteCollection.get(
                    f"smb1_{theme}_hill_{size}"
                )
            ]
            return max(widths, default=1)
        if feature_type == "bush":
            return 3
        if feature_type in self.SCENERY_QUEUE_TYPES:
            sprite = self.sprites.spriteCollection.get(feature_type)
            return self._scenery_span_tiles(sprite)
        return 1

    def _apply_decoration_sprite(self, x, y, sprite_name):
        sprite = self.sprites.spriteCollection.get(sprite_name)
        if sprite is None:
            return
        sky = self.sprites.spriteCollection.get("sky")
        tile = self.level[y][x]
        if tile.sprite is None or tile.sprite == sky:
            self.level[y][x] = Tile(sprite, None)
        else:
            self._register_overlay(sprite, x, y)

    def _assign_solid_tile(self, column, row, sprite_name):
        if not self.level:
            return False
        if (
            row < 0
            or row >= len(self.level)
            or column < 0
            or column >= len(self.level[0])
        ):
            return False
        sprite = self.sprites.spriteCollection.get(sprite_name)
        if sprite is None:
            return False
        rect = pygame.Rect(column * 32, row * 32, 32, 32)
        self.level[row][column] = Tile(sprite, rect)
        return True

    def _overlay_tile_sprite(self, sprite_name, column, row):
        sprite = self.sprites.spriteCollection.get(sprite_name)
        if sprite is None:
            return
        pixel_x = column * 32
        pixel_y = row * 32
        self._register_overlay(sprite, pixel_x, pixel_y, pixel=True)

    def _register_overlay(self, sprite, x, y, pixel=False, clip=None):
        overlay = {
            "sprite": sprite,
            "x": x,
            "y": y,
            "pixel": pixel,
            "clip": clip,
            "order": len(self.overlaySprites),
        }
        self.overlaySprites.append(overlay)
        self._index_decoration(overlay, self._overlayBuckets, foreground=False)

    def _draw_overlays(self, camera):
        """
        Draws overlay sprites (clouds, decorations that go behind entities).
        
        Overlays are drawn after background tiles but before entities,
        allowing proper layering. Clouds use this system to blend with
        each other when overlapping.
        
        The overlay system enables:
        - Cloud blending (overlapping clouds render correctly)
        - Proper depth sorting
        - Decorative elements that don't block gameplay
        """
        if not self.overlaySprites:
            return
        
        for overlay in self._visible_decorations(
            self._overlayBuckets, self._maxOverlayWidth, camera
        ):
            if overlay.get("pixel"):
                # Pixel-based positioning (for precise placement)
                image = self._overlay_image(overlay["sprite"])
                if image is None:
                    continue
                pixel_x = overlay["x"] + camera.pos.x * 32
                clip = overlay.get("clip")
                dest = (pixel_x, overlay["y"])
                if clip is not None:
                    self.screen.blit(image, dest, clip)
                else:
                    # Full sprite blit (enables cloud blending)
                    self.screen.blit(image, dest)
            else:
                # Tile-based positioning
                overlay["sprite"].drawSprite(
                    overlay["x"] + camera.pos.x, overlay["y"], self.screen
                )

    def _register_foreground(self, sprite, x, y, pixel=False, clip=None):
        if sprite is None:
            return
        overlay = {
            "sprite": sprite,
            "x": x,
            "y": y,
            "pixel": pixel,
            "clip": clip,
            "order": len(self.foregroundSprites),
        }
        self.foregroundSprites.append(overlay)
        self._index_decoration(overlay, self._foregroundBuckets, foreground=True)

    def _draw_foreground(self, camera):
        if not self.foregroundSprites:
            return
        for overlay in self._visible_decorations(
            self._foregroundBuckets, self._maxForegroundWidth, camera
        ):
            if overlay.get("pixel"):
                image = self._overlay_image(overlay["sprite"])
                if image is None:
                    continue
                pixel_x = overlay["x"] + camera.pos.x * 32
                clip = overlay.get("clip")
                dest = (pixel_x, overlay["y"])
                if clip is not None:
                    self.screen.blit(image, dest, clip)
                else:
                    self.screen.blit(image, dest)
            else:
                overlay["sprite"].drawSprite(
                    overlay["x"] + camera.pos.x, overlay["y"], self.screen
                )

    def _overlay_image(self, sprite):
        if sprite is None:
            return None
        if sprite.animation is not None:
            sprite.animation.update()
            return sprite.animation.image
        return sprite.image

    def _index_decoration(self, overlay, buckets, foreground):
        """Index a world decoration by horizontal world-space bucket."""
        world_x = overlay["x"] if overlay["pixel"] else overlay["x"] * 32
        bucket = int(world_x // 512)
        buckets.setdefault(bucket, []).append(overlay)
        sprite = overlay["sprite"]
        image = getattr(sprite, "image", None)
        animation = getattr(sprite, "animation", None)
        if animation is not None and getattr(animation, "images", None):
            width = max(frame.get_width() for frame in animation.images)
        else:
            width = image.get_width() if image is not None else 32
        if overlay.get("clip") is not None:
            width = overlay["clip"].width
        overlay["width"] = width
        if foreground:
            self._maxForegroundWidth = max(self._maxForegroundWidth, width)
        else:
            self._maxOverlayWidth = max(self._maxOverlayWidth, width)

    def _visible_decorations(self, buckets, max_width, camera):
        """Yield only decorations that can touch the current viewport.

        Endless maps retain their generated scenery, so a full-list draw pass
        scales linearly with distance. Decorations are append-indexed into
        fixed 512px horizontal buckets; this keeps rendering work proportional
        to the visible area without changing draw order within a bucket.
        """
        world_left = max(0, int(-camera.pos.x * 32))
        world_right = world_left + self.screen.get_width()
        first_bucket = max(0, int((world_left - max_width) // 512))
        last_bucket = int(world_right // 512)
        visible = []
        for bucket in range(first_bucket, last_bucket + 1):
            for decoration in buckets.get(bucket, ()):
                world_x = decoration["x"] if decoration["pixel"] else decoration["x"] * 32
                if world_x + decoration["width"] > world_left and world_x < world_right:
                    visible.append(decoration)
        visible.sort(key=lambda decoration: decoration["order"])
        yield from visible

    def _clear_overlay_layers(self):
        self.overlaySprites = []
        self.foregroundSprites = []
        self._overlayBuckets = {}
        self._foregroundBuckets = {}
        self._maxOverlayWidth = 0
        self._maxForegroundWidth = 0

    def _can_place_rectangle(self, x, y, width, height):
        if not self.level:
            return False
        if width <= 0 or height <= 0:
            return False
        columns = len(self.level[0])
        rows = len(self.level)
        return 0 <= x and 0 <= y and x + width <= columns and y + height <= rows

    def _process_background_queue(self, x_index):
        """
        Processes scheduled background features from the queue.
        
        Features are scheduled ahead of time to allow proper placement
        and blending. Clouds are processed here to ensure they overlay
        correctly when multiple clouds are placed.
        
        The queue system allows:
        - Clouds to blend when overlapping
        - Proper spacing of decorations
        - Coordinated placement of feature groups
        """
        if not getattr(self, "backgroundQueue", None):
            return
        
        # Separate ready features (can be placed now) from pending ones
        ready, pending = [], []
        for feature in self.backgroundQueue:
            width = self._feature_width(feature["type"])
            # Feature is ready if its end position has been reached
            if feature["x"] + width - 1 <= x_index:
                ready.append(feature)
            else:
                pending.append(feature)
        
        # Update queue with only pending features
        self.backgroundQueue = pending
        
        # Place ready features
        for feature in ready:
            if feature["type"] == "bush":
                self._place_supported_bush(feature["x"])
            elif feature["type"] == "cloud":
                # Clouds are placed as overlays for proper blending
                self.addCloudSprite(feature["x"], feature["y"])
            elif feature["type"] == "hill":
                self._place_background_hill(feature["x"])
            elif feature["type"] == "large_fortress":
                continue
            elif feature["type"] == "tree_small":
                if self._is_daytime_biome():
                    self._place_small_tree(feature["x"])
            elif feature["type"] == "tree_big":
                if self._is_daytime_biome():
                    self._place_big_tree(feature["x"])
            elif feature["type"] in self.SCENERY_QUEUE_TYPES:
                self._place_grounded_sprite(
                    feature["type"], feature["x"], require_ground_sprite=True
                )
            elif feature["type"] == "circle_bush":
                if not self._is_dark_biome():
                    self._maybe_place_circle_bush(feature["x"])
            elif feature["type"] == "flower":
                if not self._is_dark_biome():
                    flower_sprite = feature.get(
                        "sprite", "decorative_flower_normal"
                    )
                    self._apply_decoration_sprite(
                        feature["x"], self._surface_row(), flower_sprite
                    )
            else:
                self._place_scenery_from_data(feature)

    def _process_classic_queue(self, x_index):
        if not getattr(self, "classicQueue", None):
            return
        remaining = []
        for feature in self.classicQueue:
            if feature["x"] == x_index:
                if feature.get("deferred"):
                    prepared = self._prepare_classic_feature(
                        feature["feature"],
                        feature["x"],
                        self._surface_row(),
                    )
                    for item in prepared:
                        self._execute_classic_feature(item)
                else:
                    self._execute_classic_feature(feature)
            elif feature["x"] > x_index:
                remaining.append(feature)
        self.classicQueue = remaining
        if not remaining:
            self.classicQueueEnd = -1

    def _maybe_schedule_classic_segment(self, x_index):
        if self.gapRemaining > 0:
            return 0
        if getattr(self, "classicQueue", None) is None:
            self.classicQueue = []
        if self.classicQueue and self.classicQueueEnd >= x_index:
            return 0
        if self.randomizer.random() >= 0.22:
            return 0
        segments = self._classic_segments()
        if not segments:
            return 0
        recent = getattr(self, "recentClassicSegmentNames", [])
        available = [segment for segment in segments if segment.get("name") not in recent[-5:]]
        if not available:
            available = segments
        reference_segments = [
            segment for segment in available
            if segment.get("source_stages")
            or segment.get("name", "").startswith("smb_")
        ]
        # Keep the reference-driven motifs visible in play even though the
        # legacy library contains many more extracted block-only patterns.
        if reference_segments and self.randomizer.random() < 0.45:
            pattern = self.randomizer.choice(reference_segments)
        else:
            pattern = self.randomizer.choice(available)
        start_offset = self.randomizer.randint(2, 5)
        start_column = max(0, x_index + start_offset)
        if not self._span_matches_biome(
            start_column, start_column + pattern["length"], self.activeBiome
        ):
            return 0
        self._schedule_classic_segment(start_column, pattern)
        self.classicQueueEnd = start_column + pattern["length"]
        recent.append(pattern.get("name"))
        self.recentClassicSegmentNames = recent[-8:]
        return pattern["length"]

    def _schedule_classic_segment(self, start_column, pattern):
        for feature in pattern.get("features", []):
            column = start_column + feature.get("offset", 0)
            self.classicQueue.append(
                {
                    "deferred": True,
                    "feature": feature,
                    "x": column,
                }
            )

    def _prepare_classic_feature(self, feature, column, surface_row):
        feature_type = feature.get("type")
        if feature_type == "pipe":
            height = max(1, feature.get("height", 2))
            top_row = max(1, surface_row - height)
            depth = feature.get("depth", height + 1)
            return [
                {
                    "type": "pipe",
                    "x": column,
                    "y": top_row,
                    "length": depth,
                    "plant": feature.get("plant", False),
                }
            ]
        if feature_type == "brick_row":
            row_offset = feature.get("row_offset", 5)
            row = max(1, surface_row - row_offset)
            prepared = []
            for index, entry in enumerate(feature.get("pattern", [])):
                normalized = self._normalize_pattern_entry(entry)
                data = {
                    "x": column + index,
                    "row": row,
                    "contents": normalized.get("contents"),
                    "coin_total": normalized.get("coin_total", 0),
                }
                kind = normalized.get("kind")
                if kind == "question":
                    data["type"] = "coin_box"
                    data["item"] = normalized.get("item")
                elif kind == "random_box":
                    data["type"] = "coin_box"
                    data["item"] = normalized.get("item", self._select_random_box_item())
                else:
                    data["type"] = "brick"
                prepared.append(data)
            return prepared
        if feature_type == "coin_run":
            row_offset = feature.get("row_offset", 6)
            return self._schedule_coin_run(column, feature.get("length", 4), surface_row, row_offset)
        if feature_type == "coin_arc":
            row_offset = feature.get("row_offset", 6)
            return self._schedule_coin_arc_features(column, feature.get("length", 5), surface_row, row_offset)
        if feature_type == "enemy_group":
            spawn_row = max(2, surface_row - feature.get("row_offset", 1))
            prepared = []
            for index, enemy in enumerate(feature.get("enemies", [])):
                prepared.append({"type": "enemy", "enemy": enemy, "x": column + index, "row": spawn_row})
            return prepared
        if feature_type == "stair":
            height = max(2, feature.get("height", 3))
            block_type = feature.get("block", "hard")
            return self._schedule_stair_blocks(column, surface_row, height, block_type)
        if feature_type == "layout":
            return self._prepare_layout_feature(feature, column, surface_row)
        return []

    def _normalize_pattern_entry(self, entry):
        if isinstance(entry, str):
            return {"kind": entry}
        return {
            "kind": entry.get("kind", "brick"),
            "contents": entry.get("contents"),
            "coin_total": entry.get("coin_total", 0),
            "item": entry.get("item"),
        }

    def _execute_classic_feature(self, feature):
        ftype = feature.get("type")
        if self.endless and self._biome_at_column(feature.get("x", -1)) == "underwater":
            enemy = feature.get("enemy", "goomba")
            if ftype == "enemy" and enemy in {
                "cheep", "cheep_cheep", "CheepCheep", "blooper", "Blooper"
            }:
                pass
            elif ftype in {"coin", "coin_arc"}:
                pass
            else:
                return
        if ftype == "pipe":
            force_plant = True if feature.get("plant") else None
            self.addPipeSprite(
                feature["x"], feature["y"], feature.get("length", 3), plant=force_plant
            )
            return
        if ftype == "brick":
            self.addBrickBlock(
                feature["x"],
                feature["row"],
                contents=feature.get("contents"),
                coin_total=feature.get("coin_total", 0),
            )
            return
        if ftype == "coin_box":
            item = self._sanitize_powerup_item(feature.get("item"))
            if item and item not in {"coin", "coins"}:
                self.addRandomBox(feature["x"], feature["row"], item)
            else:
                self.addCoinBox(feature["x"], feature["row"])
            return
        if ftype == "coin":
            self.addCoin(feature["x"], feature["row"])
            return
        if ftype == "enemy":
            enemy = feature.get("enemy", "goomba")
            x_pos = feature["x"]
            row = feature["row"]
            if enemy == "koopa":
                self.addKoopa(x_pos, row)
            elif enemy in {"buzzy", "buzzy_beetle", "BuzzyBeetle"}:
                self.addBuzzyBeetle(x_pos, row)
            elif enemy in {"hammer_bro", "hammerbro", "HammerBro"}:
                self.addHammerBro(x_pos, row)
            elif enemy in {"cheep", "cheep_cheep", "CheepCheep"}:
                self.addCheepCheep(x_pos, row)
            elif enemy in {"blooper", "Blooper"}:
                self.addBlooper(x_pos, row)
            else:
                self.addGoomba(x_pos, row)
            return
        if ftype == "hardblock":
            self.addHardBlock(feature["x"], feature["row"])

    def _classic_segments(self):
        base_segments = [
            {
                "name": "pipe_pair",
                "length": 8,
                "features": [
                    {"type": "pipe", "offset": 0, "height": 2, "depth": 3, "plant": True},
                    {"type": "pipe", "offset": 4, "height": 3, "depth": 4, "plant": True},
                    {"type": "coin_arc", "offset": 1, "length": 5, "row_offset": 6},
                ],
            },
            {
                "name": "question_trio",
                "length": 7,
                "features": [
                    {
                        "type": "brick_row",
                        "offset": 0,
                        "row_offset": 5,
                        "pattern": [
                            {"kind": "brick", "contents": "coin", "coin_total": 1},
                            {"kind": "question", "item": "RedMushroom"},
                            {"kind": "brick"},
                            {"kind": "brick", "contents": "multi-coin", "coin_total": 4},
                        ],
                    },
                    {"type": "coin_run", "offset": 0, "length": 4, "row_offset": 7},
                    {"type": "enemy_group", "offset": 3, "enemies": ["goomba", "goomba"]},
                ],
            },
            {
                "name": "staircase",
                "length": 9,
                "features": [
                    {"type": "stair", "offset": 0, "height": 4, "block": "hard"},
                    {"type": "coin_arc", "offset": 4, "length": 4, "row_offset": 7},
                    {"type": "enemy_group", "offset": 5, "enemies": ["koopa"]},
                ],
            },
            {
                "name": "bonus_stack",
                "length": 8,
                "features": [
                    {
                        "type": "brick_row",
                        "offset": 1,
                        "row_offset": 6,
                        "pattern": [
                            {"kind": "brick", "contents": "coin", "coin_total": 1},
                            {"kind": "brick", "contents": "FireFlower"},
                            {"kind": "brick", "contents": "coin", "coin_total": 1},
                        ],
                    },
                    {"type": "coin_run", "offset": 2, "length": 3, "row_offset": 8},
                    {"type": "enemy_group", "offset": 0, "enemies": ["goomba", "koopa"]},
                ],
            },
            {
                "name": "groundarea6_intro",
                "length": 13,
                "features": [
                    {
                        "type": "layout",
                        "offset": 0,
                        "tiles": [
                            {"dx": 1, "row_offset": 5, "kind": "brick"},
                            {"dx": 2, "row_offset": 5, "kind": "question", "item": "RedMushroom"},
                            {"dx": 3, "row_offset": 5, "kind": "brick"},
                            {"dx": 5, "row_offset": 7, "kind": "coin"},
                            {"dx": 6, "row_offset": 7, "kind": "coin"},
                        ],
                    },
                    {"type": "pipe", "offset": 7, "height": 2, "depth": 3, "plant": False},
                    {"type": "enemy_group", "offset": 0, "enemies": ["goomba", "goomba"]},
                ],
            },
            {
                "name": "groundarea1_balcony",
                "length": 14,
                "features": [
                    {
                        "type": "layout",
                        "offset": 1,
                        "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "brick"},
                            {"dx": 1, "row_offset": 6, "kind": "brick", "contents": "coin", "coin_total": 1},
                            {"dx": 2, "row_offset": 6, "kind": "question", "item": "FireFlower"},
                            {"dx": 3, "row_offset": 6, "kind": "brick"},
                            {"dx": 5, "row_offset": 8, "kind": "coin"},
                            {"dx": 6, "row_offset": 9, "kind": "coin"},
                            {"dx": 7, "row_offset": 8, "kind": "coin"},
                        ],
                    },
                    {"type": "coin_arc", "offset": 6, "length": 5, "row_offset": 8},
                    {"type": "enemy_group", "offset": 4, "enemies": ["koopa"]},
                ],
            },
            {
                "name": "groundarea17_pipes",
                "length": 16,
                "features": [
                    {"type": "pipe", "offset": 1, "height": 2, "depth": 3, "plant": True},
                    {"type": "pipe", "offset": 6, "height": 3, "depth": 4, "plant": False},
                    {
                        "type": "layout",
                        "offset": 0,
                        "tiles": [
                            {"dx": 4, "row_offset": 6, "kind": "brick"},
                            {"dx": 5, "row_offset": 6, "kind": "question", "item": "Star"},
                            {"dx": 10, "row_offset": 5, "kind": "brick"},
                            {"dx": 11, "row_offset": 5, "kind": "brick"},
                            {"dx": 12, "row_offset": 6, "kind": "question"},
                        ],
                    },
                    {"type": "coin_run", "offset": 8, "length": 4, "row_offset": 7},
                    {"type": "enemy_group", "offset": 11, "enemies": ["goomba", "goomba"]},
                ],
            },
            {
                "name": "groundarea18_stairs",
                "length": 18,
                "features": [
                    {
                        "type": "stair",
                        "offset": 0,
                        "height": 3,
                        "block": "hard",
                    },
                    {
                        "type": "layout",
                        "offset": 4,
                        "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "brick"},
                            {"dx": 1, "row_offset": 6, "kind": "brick"},
                            {"dx": 2, "row_offset": 6, "kind": "question", "item": "RedMushroom"},
                            {"dx": 4, "row_offset": 8, "kind": "coin"},
                            {"dx": 5, "row_offset": 9, "kind": "coin"},
                            {"dx": 6, "row_offset": 10, "kind": "coin"},
                        ],
                    },
                    {"type": "enemy_group", "offset": 3, "enemies": ["koopa", "goomba"]},
                    {"type": "coin_arc", "offset": 9, "length": 5, "row_offset": 8},
                    {
                        "type": "layout",
                        "offset": 12,
                        "tiles": [
                            {"dx": 0, "row_offset": 5, "kind": "hardblock"},
                            {"dx": 1, "row_offset": 6, "kind": "hardblock"},
                            {"dx": 2, "row_offset": 7, "kind": "hardblock"},
                        ],
                    },
                ],
            },
        ]
        biome = self._active_theme_biome()
        tailored = self._infinity_reference_segments(biome)
        return base_segments + self._extended_segment_library() + tailored

    @classmethod
    def _infinity_reference_segments(cls, biome):
        """Small, named motifs adapted from the SMB1 stage diagrams.

        These are section recipes, not copied stages: a recipe contributes a
        short sequence of familiar objects while the endless route continues
        to be built by the regular generator.
        """
        if cls._INFINITY_WORLD_MOTIFS is None:
            try:
                with open("./levels/infinity_world_motifs.json", encoding="utf-8") as handle:
                    cls._INFINITY_WORLD_MOTIFS = json.load(handle).get("recipes", [])
            except (OSError, ValueError):
                cls._INFINITY_WORLD_MOTIFS = []
        world_recipes = [
            dict(recipe, name=recipe.get("id", "world_motif"))
            for recipe in cls._INFINITY_WORLD_MOTIFS
            if biome in recipe.get("biomes", [])
        ]
        if world_recipes:
            return world_recipes

        shared = {
            "normal": [
                {
                    "name": "smb_overworld_pipe_and_coin_row",
                    "length": 12,
                    "features": [
                        {"type": "pipe", "offset": 1, "height": 2, "depth": 3, "plant": True},
                        {"type": "brick_row", "offset": 5, "row_offset": 5, "pattern": [
                            {"kind": "brick", "contents": "coin", "coin_total": 1},
                            {"kind": "question", "item": "RedMushroom"},
                            {"kind": "brick"},
                            {"kind": "brick", "contents": "multi-coin", "coin_total": 4},
                        ]},
                        {"type": "coin_arc", "offset": 5, "length": 4, "row_offset": 7},
                        {"type": "enemy_group", "offset": 9, "enemies": ["goomba", "goomba"]},
                    ],
                },
                {
                    "name": "smb_overworld_stair_and_enemy_lane",
                    "length": 11,
                    "features": [
                        {"type": "stair", "offset": 0, "height": 4, "block": "hard"},
                        {"type": "coin_arc", "offset": 4, "length": 4, "row_offset": 7},
                        {"type": "enemy_group", "offset": 7, "enemies": ["koopa"]},
                    ],
                },
            ],
            "underground": [
                {
                    "name": "smb_underground_ceiling_and_coin_lane",
                    "length": 10,
                    "features": [
                        {"type": "brick_row", "offset": 1, "row_offset": 8, "pattern": [
                            {"kind": "brick"}, {"kind": "brick", "contents": "coin", "coin_total": 1},
                            {"kind": "question", "item": "FireFlower"}, {"kind": "brick"},
                        ]},
                        {"type": "coin_run", "offset": 3, "length": 3, "row_offset": 6},
                        {"type": "enemy_group", "offset": 7, "enemies": ["goomba", "goomba"]},
                    ],
                },
                {
                    "name": "smb_underground_stairwell",
                    "length": 9,
                    "features": [
                        {"type": "stair", "offset": 1, "height": 3, "block": "brick"},
                        {"type": "coin_arc", "offset": 4, "length": 3, "row_offset": 7},
                        {"type": "enemy_group", "offset": 6, "enemies": ["buzzy"]},
                    ],
                },
            ],
            "underwater": [
                {
                    "name": "smb_water_coin_arc_and_cheeps",
                    "length": 10,
                    "features": [
                        {"type": "coin_arc", "offset": 1, "length": 5, "row_offset": 5},
                        {"type": "enemy_group", "offset": 5, "row_offset": 6, "enemies": ["cheep", "blooper"]},
                        {"type": "coin_run", "offset": 7, "length": 3, "row_offset": 8},
                    ],
                },
                {
                    "name": "smb_water_open_swim_channel",
                    "length": 9,
                    "features": [
                        {"type": "coin_arc", "offset": 0, "length": 4, "row_offset": 7},
                        {"type": "enemy_group", "offset": 4, "row_offset": 7, "enemies": ["cheep", "cheep"]},
                        {"type": "coin_arc", "offset": 5, "length": 4, "row_offset": 6},
                    ],
                },
            ],
            "mushroom": [
                {
                    "name": "smb_athletic_platform_approach",
                    "length": 11,
                    "features": [
                        {"type": "layout", "offset": 1, "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "brick"},
                            {"dx": 1, "row_offset": 6, "kind": "question", "item": "RedMushroom"},
                            {"dx": 2, "row_offset": 7, "kind": "brick"},
                            {"dx": 3, "row_offset": 7, "kind": "brick"},
                        ]},
                        {"type": "coin_arc", "offset": 5, "length": 4, "row_offset": 8},
                        {"type": "enemy_group", "offset": 8, "enemies": ["goomba"]},
                    ],
                },
            ],
            "ice": [
                {
                    "name": "smb_athletic_stair_coin_run",
                    "length": 10,
                    "features": [
                        {"type": "stair", "offset": 0, "height": 3, "block": "hard"},
                        {"type": "coin_run", "offset": 3, "length": 4, "row_offset": 6},
                        {"type": "enemy_group", "offset": 7, "enemies": ["koopa"]},
                    ],
                },
            ],
            "canyon": [
                {
                    "name": "smb_bridge_approach_coin_arc",
                    "length": 10,
                    "features": [
                        {"type": "layout", "offset": 1, "tiles": [
                            {"dx": 0, "row_offset": 5, "kind": "brick"},
                            {"dx": 1, "row_offset": 5, "kind": "question", "item": "RedMushroom"},
                        ]},
                        {"type": "coin_arc", "offset": 4, "length": 5, "row_offset": 7},
                        {"type": "enemy_group", "offset": 7, "enemies": ["goomba", "koopa"]},
                    ],
                },
            ],
            "firebar": [
                {
                    "name": "smb_castle_hazard_approach",
                    "length": 10,
                    "features": [
                        {"type": "brick_row", "offset": 1, "row_offset": 6, "pattern": [
                            {"kind": "hardblock"}, {"kind": "hardblock"}, {"kind": "hardblock"},
                        ]},
                        {"type": "coin_arc", "offset": 4, "length": 3, "row_offset": 7},
                        {"type": "enemy_group", "offset": 7, "enemies": ["hammer_bro"]},
                    ],
                },
            ],
            "fortress": [
                {
                    "name": "smb_fortress_safe_lane_and_blocks",
                    "length": 9,
                    "features": [
                        {"type": "coin_run", "offset": 1, "length": 3, "row_offset": 6},
                        {"type": "layout", "offset": 5, "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "hardblock"},
                            {"dx": 1, "row_offset": 7, "kind": "hardblock"},
                            {"dx": 2, "row_offset": 6, "kind": "hardblock"},
                        ]},
                    ],
                },
            ],
        }
        return shared.get(biome, [])

    def _extended_segment_library(self):
        return [
            {
                "name": "pipe_gauntlet_a",
                "length": 13,
                "features": [
                    {"type": "pipe", "offset": 1, "height": 2, "depth": 3, "plant": True},
                    {"type": "pipe", "offset": 6, "height": 3, "depth": 4, "plant": False},
                    {"type": "coin_arc", "offset": 2, "length": 6, "row_offset": 7},
                    {
                        "type": "enemy_group",
                        "offset": 9,
                        "enemies": ["goomba", "goomba", "koopa"],
                    },
                ],
            },
            {
                "name": "pipe_gauntlet_b",
                "length": 15,
                "features": [
                    {"type": "pipe", "offset": 0, "height": 2, "depth": 3, "plant": False},
                    {"type": "pipe", "offset": 5, "height": 3, "depth": 4, "plant": True},
                    {"type": "pipe", "offset": 10, "height": 2, "depth": 3, "plant": False},
                    {"type": "coin_run", "offset": 2, "length": 4, "row_offset": 7},
                    {
                        "type": "layout",
                        "offset": 8,
                        "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "question", "item": "FireFlower"},
                            {"dx": 1, "row_offset": 6, "kind": "brick"},
                            {
                                "dx": 2,
                                "row_offset": 6,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                        ],
                    },
                ],
            },
            {
                "name": "pipe_gauntlet_c",
                "length": 11,
                "features": [
                    {"type": "pipe", "offset": 2, "height": 3, "depth": 4, "plant": True},
                    {"type": "stair", "offset": 6, "height": 4, "block": "hard"},
                    {"type": "coin_run", "offset": 0, "length": 3, "row_offset": 6},
                    {"type": "enemy_group", "offset": 7, "enemies": ["koopa"]},
                ],
            },
            {
                "name": "pipe_balcony_bridge",
                "length": 14,
                "features": [
                    {"type": "pipe", "offset": 1, "height": 2, "depth": 3, "plant": False},
                    {
                        "type": "layout",
                        "offset": 4,
                        "tiles": [
                            {"dx": 0, "row_offset": 5, "kind": "brick"},
                            {"dx": 1, "row_offset": 5, "kind": "question", "item": "RedMushroom"},
                            {"dx": 2, "row_offset": 5, "kind": "brick"},
                            {"dx": 4, "row_offset": 7, "kind": "coin"},
                            {"dx": 5, "row_offset": 8, "kind": "coin"},
                            {"dx": 6, "row_offset": 7, "kind": "coin"},
                        ],
                    },
                    {"type": "pipe", "offset": 9, "height": 3, "depth": 4, "plant": True},
                    {"type": "enemy_group", "offset": 11, "enemies": ["goomba", "goomba"]},
                ],
            },
            {
                "name": "pipe_coin_island",
                "length": 12,
                "features": [
                    {"type": "pipe", "offset": 0, "height": 2, "depth": 3, "plant": False},
                    {"type": "coin_arc", "offset": 3, "length": 5, "row_offset": 6},
                    {
                        "type": "layout",
                        "offset": 8,
                        "tiles": [
                            {
                                "dx": 0,
                                "row_offset": 6,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                            {"dx": 1, "row_offset": 6, "kind": "question", "item": "Star"},
                            {
                                "dx": 2,
                                "row_offset": 6,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                        ],
                    },
                    {"type": "enemy_group", "offset": 6, "enemies": ["koopa"]},
                ],
            },
            {
                "name": "balcony_coin_highway",
                "length": 12,
                "features": [
                    {
                        "type": "layout",
                        "offset": 1,
                        "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "brick"},
                            {"dx": 1, "row_offset": 6, "kind": "brick"},
                            {"dx": 2, "row_offset": 6, "kind": "question", "item": "RedMushroom"},
                            {"dx": 4, "row_offset": 8, "kind": "coin"},
                            {"dx": 5, "row_offset": 9, "kind": "coin"},
                            {"dx": 6, "row_offset": 8, "kind": "coin"},
                            {"dx": 8, "row_offset": 7, "kind": "brick"},
                            {"dx": 9, "row_offset": 7, "kind": "brick"},
                        ],
                    },
                    {"type": "coin_run", "offset": 3, "length": 4, "row_offset": 8},
                    {"type": "enemy_group", "offset": 7, "enemies": ["goomba", "goomba"]},
                ],
            },
            {
                "name": "balcony_question_lift",
                "length": 13,
                "features": [
                    {
                        "type": "layout",
                        "offset": 2,
                        "tiles": [
                            {"dx": 0, "row_offset": 5, "kind": "question", "item": "RedMushroom"},
                            {"dx": 1, "row_offset": 5, "kind": "brick"},
                            {"dx": 2, "row_offset": 5, "kind": "brick"},
                            {"dx": 4, "row_offset": 7, "kind": "question", "item": "Star"},
                            {"dx": 5, "row_offset": 7, "kind": "brick"},
                            {"dx": 6, "row_offset": 7, "kind": "brick"},
                        ],
                    },
                    {"type": "coin_arc", "offset": 5, "length": 5, "row_offset": 8},
                    {"type": "enemy_group", "offset": 9, "enemies": ["koopa", "goomba"]},
                ],
            },
            {
                "name": "balcony_star_corridor",
                "length": 14,
                "features": [
                    {
                        "type": "layout",
                        "offset": 1,
                        "tiles": [
                            {
                                "dx": 0,
                                "row_offset": 5,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                            {"dx": 1, "row_offset": 5, "kind": "brick"},
                            {"dx": 2, "row_offset": 5, "kind": "question", "item": "Star"},
                            {"dx": 3, "row_offset": 5, "kind": "brick"},
                            {"dx": 5, "row_offset": 7, "kind": "brick"},
                            {"dx": 6, "row_offset": 7, "kind": "question", "item": "FireFlower"},
                            {"dx": 7, "row_offset": 7, "kind": "brick"},
                        ],
                    },
                    {"type": "coin_run", "offset": 7, "length": 4, "row_offset": 8},
                    {
                        "type": "enemy_group",
                        "offset": 10,
                        "enemies": ["goomba", "goomba", "koopa"],
                    },
                ],
            },
            {
                "name": "balcony_zigzag",
                "length": 12,
                "features": [
                    {
                        "type": "layout",
                        "offset": 0,
                        "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "brick"},
                            {
                                "dx": 1,
                                "row_offset": 6,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                            {"dx": 2, "row_offset": 6, "kind": "brick"},
                            {"dx": 4, "row_offset": 8, "kind": "brick"},
                            {"dx": 5, "row_offset": 8, "kind": "question", "item": "RedMushroom"},
                            {"dx": 6, "row_offset": 8, "kind": "brick"},
                            {"dx": 8, "row_offset": 5, "kind": "coin"},
                            {"dx": 9, "row_offset": 6, "kind": "coin"},
                            {"dx": 10, "row_offset": 5, "kind": "coin"},
                        ],
                    },
                    {"type": "coin_arc", "offset": 2, "length": 6, "row_offset": 7},
                ],
            },
            {
                "name": "balcony_double_stack",
                "length": 13,
                "features": [
                    {
                        "type": "layout",
                        "offset": 2,
                        "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "brick"},
                            {"dx": 1, "row_offset": 6, "kind": "brick"},
                            {"dx": 2, "row_offset": 6, "kind": "question", "item": "RedMushroom"},
                            {"dx": 0, "row_offset": 4, "kind": "brick"},
                            {
                                "dx": 1,
                                "row_offset": 4,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                            {"dx": 2, "row_offset": 4, "kind": "question", "item": "FireFlower"},
                        ],
                    },
                    {"type": "coin_run", "offset": 6, "length": 4, "row_offset": 8},
                    {"type": "enemy_group", "offset": 9, "enemies": ["goomba", "koopa"]},
                ],
            },
            {
                "name": "balcony_low_ceiling",
                "length": 11,
                "features": [
                    {
                        "type": "layout",
                        "offset": 1,
                        "tiles": [
                            {"dx": 0, "row_offset": 5, "kind": "brick"},
                            {
                                "dx": 1,
                                "row_offset": 5,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                            {"dx": 2, "row_offset": 5, "kind": "question", "item": "FireFlower"},
                            {"dx": 4, "row_offset": 6, "kind": "brick"},
                            {"dx": 5, "row_offset": 6, "kind": "brick"},
                            {"dx": 6, "row_offset": 6, "kind": "question", "item": "RedMushroom"},
                        ],
                    },
                    {"type": "coin_arc", "offset": 4, "length": 4, "row_offset": 7},
                    {"type": "enemy_group", "offset": 7, "enemies": ["goomba", "goomba"]},
                ],
            },
            {
                "name": "balcony_guarded_mushroom",
                "length": 12,
                "features": [
                    {
                        "type": "layout",
                        "offset": 3,
                        "tiles": [
                            {"dx": 0, "row_offset": 5, "kind": "question", "item": "RedMushroom"},
                            {"dx": 1, "row_offset": 5, "kind": "brick"},
                            {"dx": 2, "row_offset": 5, "kind": "brick"},
                            {"dx": 4, "row_offset": 7, "kind": "brick"},
                            {"dx": 5, "row_offset": 7, "kind": "question", "item": "Star"},
                        ],
                    },
                    {"type": "coin_run", "offset": 0, "length": 3, "row_offset": 7},
                    {"type": "enemy_group", "offset": 6, "enemies": ["koopa"]},
                ],
            },
            {
                "name": "balcony_crossroad",
                "length": 14,
                "features": [
                    {
                        "type": "layout",
                        "offset": 0,
                        "tiles": [
                            {"dx": 1, "row_offset": 5, "kind": "brick"},
                            {"dx": 2, "row_offset": 5, "kind": "brick"},
                            {"dx": 3, "row_offset": 5, "kind": "question", "item": "FireFlower"},
                            {"dx": 5, "row_offset": 7, "kind": "brick"},
                            {"dx": 6, "row_offset": 7, "kind": "brick"},
                            {"dx": 7, "row_offset": 7, "kind": "question", "item": "RedMushroom"},
                            {"dx": 9, "row_offset": 6, "kind": "coin"},
                            {"dx": 10, "row_offset": 6, "kind": "coin"},
                        ],
                    },
                    {"type": "coin_arc", "offset": 8, "length": 5, "row_offset": 8},
                    {
                        "type": "enemy_group",
                        "offset": 11,
                        "enemies": ["goomba", "koopa", "goomba"],
                    },
                ],
            },
            {
                "name": "stair_runner_low",
                "length": 12,
                "features": [
                    {"type": "stair", "offset": 0, "height": 3, "block": "hard"},
                    {"type": "coin_run", "offset": 5, "length": 4, "row_offset": 7},
                    {"type": "enemy_group", "offset": 7, "enemies": ["goomba", "goomba"]},
                ],
            },
            {
                "name": "stair_runner_high",
                "length": 13,
                "features": [
                    {"type": "stair", "offset": 2, "height": 4, "block": "hard"},
                    {"type": "coin_arc", "offset": 6, "length": 5, "row_offset": 7},
                    {"type": "enemy_group", "offset": 8, "enemies": ["koopa"]},
                ],
            },
            {
                "name": "stair_runner_spiral",
                "length": 14,
                "features": [
                    {"type": "stair", "offset": 0, "height": 4, "block": "hard"},
                    {"type": "stair", "offset": 6, "height": 3, "block": "hard"},
                    {"type": "coin_run", "offset": 3, "length": 4, "row_offset": 8},
                    {
                        "type": "enemy_group",
                        "offset": 10,
                        "enemies": ["goomba", "goomba", "koopa"],
                    },
                ],
            },
            {
                "name": "stair_bridge_combo",
                "length": 15,
                "features": [
                    {"type": "stair", "offset": 1, "height": 3, "block": "hard"},
                    {
                        "type": "layout",
                        "offset": 6,
                        "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "brick"},
                            {"dx": 1, "row_offset": 6, "kind": "question", "item": "Star"},
                            {"dx": 2, "row_offset": 6, "kind": "brick"},
                            {"dx": 4, "row_offset": 8, "kind": "brick"},
                            {"dx": 5, "row_offset": 8, "kind": "question", "item": "FireFlower"},
                        ],
                    },
                    {"type": "coin_arc", "offset": 9, "length": 5, "row_offset": 8},
                ],
            },
            {
                "name": "stair_coin_drop",
                "length": 11,
                "features": [
                    {"type": "stair", "offset": 0, "height": 4, "block": "hard"},
                    {"type": "coin_run", "offset": 5, "length": 3, "row_offset": 6},
                    {"type": "enemy_group", "offset": 7, "enemies": ["goomba", "koopa"]},
                ],
            },
            {
                "name": "stair_enemy_gauntlet",
                "length": 16,
                "features": [
                    {"type": "stair", "offset": 0, "height": 4, "block": "hard"},
                    {"type": "stair", "offset": 8, "height": 4, "block": "hard"},
                    {"type": "coin_arc", "offset": 4, "length": 6, "row_offset": 8},
                    {
                        "type": "enemy_group",
                        "offset": 10,
                        "enemies": ["goomba", "goomba", "koopa", "goomba"],
                    },
                ],
            },
            {
                "name": "enemy_coin_lane_a",
                "length": 12,
                "features": [
                    {"type": "coin_run", "offset": 1, "length": 5, "row_offset": 6},
                    {
                        "type": "layout",
                        "offset": 7,
                        "tiles": [
                            {"dx": 0, "row_offset": 5, "kind": "question", "item": "RedMushroom"},
                            {"dx": 1, "row_offset": 5, "kind": "brick"},
                        ],
                    },
                    {
                        "type": "enemy_group",
                        "offset": 5,
                        "enemies": ["goomba", "goomba", "koopa"],
                    },
                ],
            },
            {
                "name": "enemy_coin_lane_b",
                "length": 13,
                "features": [
                    {"type": "coin_arc", "offset": 2, "length": 6, "row_offset": 7},
                    {
                        "type": "layout",
                        "offset": 8,
                        "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "brick"},
                            {"dx": 1, "row_offset": 6, "kind": "question", "item": "FireFlower"},
                            {"dx": 2, "row_offset": 6, "kind": "brick"},
                        ],
                    },
                    {"type": "enemy_group", "offset": 9, "enemies": ["koopa", "goomba"]},
                ],
            },
            {
                "name": "enemy_coin_lane_c",
                "length": 11,
                "features": [
                    {"type": "coin_run", "offset": 0, "length": 4, "row_offset": 7},
                    {
                        "type": "layout",
                        "offset": 5,
                        "tiles": [
                            {
                                "dx": 0,
                                "row_offset": 5,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                            {"dx": 1, "row_offset": 5, "kind": "question", "item": "RedMushroom"},
                            {"dx": 2, "row_offset": 5, "kind": "brick"},
                        ],
                    },
                    {"type": "enemy_group", "offset": 7, "enemies": ["goomba", "goomba"]},
                ],
            },
            {
                "name": "enemy_coin_lane_d",
                "length": 14,
                "features": [
                    {"type": "coin_arc", "offset": 4, "length": 5, "row_offset": 8},
                    {
                        "type": "layout",
                        "offset": 0,
                        "tiles": [
                            {"dx": 1, "row_offset": 6, "kind": "brick"},
                            {"dx": 2, "row_offset": 6, "kind": "brick"},
                            {"dx": 3, "row_offset": 6, "kind": "question", "item": "Star"},
                        ],
                    },
                    {"type": "enemy_group", "offset": 9, "enemies": ["koopa", "koopa"]},
                ],
            },
            {
                "name": "enemy_coin_lane_e",
                "length": 15,
                "features": [
                    {"type": "coin_run", "offset": 2, "length": 6, "row_offset": 7},
                    {
                        "type": "layout",
                        "offset": 9,
                        "tiles": [
                            {"dx": 0, "row_offset": 5, "kind": "question", "item": "FireFlower"},
                            {"dx": 1, "row_offset": 5, "kind": "brick"},
                            {
                                "dx": 2,
                                "row_offset": 5,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                        ],
                    },
                    {
                        "type": "enemy_group",
                        "offset": 6,
                        "enemies": ["goomba", "goomba", "goomba", "koopa"],
                    },
                ],
            },
            {
                "name": "enemy_coin_lane_f",
                "length": 12,
                "features": [
                    {"type": "coin_arc", "offset": 1, "length": 6, "row_offset": 7},
                    {
                        "type": "layout",
                        "offset": 7,
                        "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "brick"},
                            {"dx": 1, "row_offset": 6, "kind": "brick"},
                            {"dx": 2, "row_offset": 6, "kind": "question", "item": "RedMushroom"},
                        ],
                    },
                    {
                        "type": "enemy_group",
                        "offset": 8,
                        "enemies": ["koopa", "goomba", "goomba"],
                    },
                ],
            },
            {
                "name": "mixed_overhang_a",
                "length": 16,
                "features": [
                    {"type": "pipe", "offset": 2, "height": 2, "depth": 3, "plant": False},
                    {
                        "type": "layout",
                        "offset": 6,
                        "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "brick"},
                            {"dx": 1, "row_offset": 6, "kind": "question", "item": "RedMushroom"},
                            {"dx": 2, "row_offset": 6, "kind": "brick"},
                            {"dx": 4, "row_offset": 8, "kind": "coin"},
                            {"dx": 5, "row_offset": 8, "kind": "coin"},
                        ],
                    },
                    {"type": "coin_arc", "offset": 9, "length": 5, "row_offset": 7},
                    {"type": "enemy_group", "offset": 12, "enemies": ["goomba", "koopa"]},
                ],
            },
            {
                "name": "mixed_overhang_b",
                "length": 14,
                "features": [
                    {"type": "pipe", "offset": 0, "height": 3, "depth": 4, "plant": True},
                    {
                        "type": "layout",
                        "offset": 4,
                        "tiles": [
                            {"dx": 0, "row_offset": 5, "kind": "brick"},
                            {"dx": 1, "row_offset": 5, "kind": "question", "item": "FireFlower"},
                            {"dx": 2, "row_offset": 5, "kind": "brick"},
                            {"dx": 4, "row_offset": 7, "kind": "question", "item": "Star"},
                        ],
                    },
                    {"type": "coin_run", "offset": 7, "length": 4, "row_offset": 8},
                    {
                        "type": "enemy_group",
                        "offset": 10,
                        "enemies": ["goomba", "goomba", "koopa"],
                    },
                ],
            },
            {
                "name": "mixed_overhang_c",
                "length": 15,
                "features": [
                    {
                        "type": "layout",
                        "offset": 1,
                        "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "brick"},
                            {"dx": 1, "row_offset": 6, "kind": "brick"},
                            {"dx": 2, "row_offset": 6, "kind": "question", "item": "RedMushroom"},
                            {"dx": 4, "row_offset": 8, "kind": "brick"},
                            {
                                "dx": 5,
                                "row_offset": 8,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                            {"dx": 6, "row_offset": 8, "kind": "question", "item": "FireFlower"},
                        ],
                    },
                    {"type": "pipe", "offset": 9, "height": 2, "depth": 3, "plant": True},
                    {"type": "coin_arc", "offset": 10, "length": 4, "row_offset": 7},
                    {"type": "enemy_group", "offset": 6, "enemies": ["goomba", "koopa"]},
                ],
            },
            {
                "name": "mixed_overhang_d",
                "length": 13,
                "features": [
                    {
                        "type": "layout",
                        "offset": 0,
                        "tiles": [
                            {"dx": 1, "row_offset": 5, "kind": "brick"},
                            {"dx": 2, "row_offset": 5, "kind": "question", "item": "RedMushroom"},
                            {"dx": 3, "row_offset": 5, "kind": "brick"},
                            {"dx": 5, "row_offset": 7, "kind": "brick"},
                            {"dx": 6, "row_offset": 7, "kind": "question", "item": "Star"},
                        ],
                    },
                    {"type": "coin_run", "offset": 6, "length": 4, "row_offset": 8},
                    {
                        "type": "enemy_group",
                        "offset": 9,
                        "enemies": ["koopa", "goomba", "goomba"],
                    },
                ],
            },
            {
                "name": "mixed_overhang_e",
                "length": 16,
                "features": [
                    {"type": "pipe", "offset": 3, "height": 2, "depth": 3, "plant": True},
                    {
                        "type": "layout",
                        "offset": 7,
                        "tiles": [
                            {
                                "dx": 0,
                                "row_offset": 6,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                            {"dx": 1, "row_offset": 6, "kind": "brick"},
                            {"dx": 2, "row_offset": 6, "kind": "question", "item": "FireFlower"},
                            {"dx": 4, "row_offset": 8, "kind": "brick"},
                            {"dx": 5, "row_offset": 8, "kind": "question", "item": "RedMushroom"},
                        ],
                    },
                    {"type": "coin_arc", "offset": 9, "length": 6, "row_offset": 8},
                    {
                        "type": "enemy_group",
                        "offset": 12,
                        "enemies": ["goomba", "goomba", "koopa"],
                    },
                ],
            },
            {
                "name": "mixed_overhang_f",
                "length": 12,
                "features": [
                    {
                        "type": "layout",
                        "offset": 2,
                        "tiles": [
                            {
                                "dx": 0,
                                "row_offset": 5,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                            {"dx": 1, "row_offset": 5, "kind": "question", "item": "RedMushroom"},
                            {"dx": 2, "row_offset": 5, "kind": "brick"},
                            {"dx": 4, "row_offset": 7, "kind": "brick"},
                            {"dx": 5, "row_offset": 7, "kind": "question", "item": "Star"},
                        ],
                    },
                    {"type": "coin_arc", "offset": 5, "length": 4, "row_offset": 7},
                    {"type": "enemy_group", "offset": 8, "enemies": ["goomba", "koopa"]},
                ],
            },
            {
                "name": "mixed_overhang_g",
                "length": 17,
                "features": [
                    {"type": "pipe", "offset": 0, "height": 2, "depth": 3, "plant": False},
                    {
                        "type": "layout",
                        "offset": 4,
                        "tiles": [
                            {"dx": 0, "row_offset": 5, "kind": "brick"},
                            {"dx": 1, "row_offset": 5, "kind": "brick"},
                            {"dx": 2, "row_offset": 5, "kind": "question", "item": "FireFlower"},
                            {"dx": 4, "row_offset": 7, "kind": "brick"},
                            {"dx": 5, "row_offset": 7, "kind": "brick"},
                            {"dx": 6, "row_offset": 7, "kind": "question", "item": "RedMushroom"},
                        ],
                    },
                    {"type": "coin_run", "offset": 9, "length": 5, "row_offset": 8},
                    {
                        "type": "enemy_group",
                        "offset": 12,
                        "enemies": ["koopa", "goomba", "goomba"],
                    },
                ],
            },
            {
                "name": "mixed_overhang_h",
                "length": 15,
                "features": [
                    {"type": "pipe", "offset": 5, "height": 3, "depth": 4, "plant": True},
                    {
                        "type": "layout",
                        "offset": 0,
                        "tiles": [
                            {"dx": 1, "row_offset": 6, "kind": "brick"},
                            {
                                "dx": 2,
                                "row_offset": 6,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                            {"dx": 3, "row_offset": 6, "kind": "question", "item": "RedMushroom"},
                        ],
                    },
                    {"type": "coin_arc", "offset": 8, "length": 5, "row_offset": 7},
                    {
                        "type": "enemy_group",
                        "offset": 10,
                        "enemies": ["goomba", "goomba", "koopa"],
                    },
                ],
            },
            {
                "name": "mixed_overhang_i",
                "length": 14,
                "features": [
                    {
                        "type": "layout",
                        "offset": 1,
                        "tiles": [
                            {"dx": 0, "row_offset": 6, "kind": "brick"},
                            {"dx": 1, "row_offset": 6, "kind": "question", "item": "Star"},
                            {"dx": 2, "row_offset": 6, "kind": "brick"},
                            {"dx": 4, "row_offset": 8, "kind": "brick"},
                            {"dx": 5, "row_offset": 8, "kind": "question", "item": "FireFlower"},
                        ],
                    },
                    {"type": "coin_run", "offset": 6, "length": 4, "row_offset": 7},
                    {"type": "enemy_group", "offset": 9, "enemies": ["koopa", "koopa"]},
                    {"type": "pipe", "offset": 10, "height": 2, "depth": 3, "plant": False},
                ],
            },
            {
                "name": "mixed_overhang_j",
                "length": 16,
                "features": [
                    {
                        "type": "layout",
                        "offset": 2,
                        "tiles": [
                            {"dx": 0, "row_offset": 5, "kind": "brick"},
                            {"dx": 1, "row_offset": 5, "kind": "brick"},
                            {"dx": 2, "row_offset": 5, "kind": "question", "item": "FireFlower"},
                            {"dx": 3, "row_offset": 5, "kind": "brick"},
                            {"dx": 5, "row_offset": 7, "kind": "brick"},
                            {
                                "dx": 6,
                                "row_offset": 7,
                                "kind": "brick",
                                "contents": "coin",
                                "coin_total": 1,
                            },
                            {"dx": 7, "row_offset": 7, "kind": "question", "item": "RedMushroom"},
                        ],
                    },
                    {"type": "coin_arc", "offset": 6, "length": 6, "row_offset": 8},
                    {
                        "type": "enemy_group",
                        "offset": 11,
                        "enemies": ["goomba", "goomba", "koopa", "goomba"],
                    },
                ],
            },
        ]
    def _prepare_layout_feature(self, feature, column, surface_row):
        tiles = feature.get("tiles", [])
        if not tiles:
            return []
        prepared = []
        for tile in tiles:
            dx = tile.get("dx", 0)
            if "row" in tile:
                row = max(0, tile["row"])
            else:
                row_offset = tile.get("row_offset", 5)
                row = max(1, surface_row - row_offset)
            entry = {"x": column + dx, "row": row}
            kind = tile.get("kind", "brick")
            if kind == "brick":
                entry["type"] = "brick"
                entry["contents"] = tile.get("contents")
                entry["coin_total"] = tile.get("coin_total", 0)
            elif kind == "question":
                entry["type"] = "coin_box"
                entry["item"] = tile.get("item")
            elif kind == "random_box":
                entry["type"] = "coin_box"
                entry["item"] = tile.get("item", self._select_random_box_item())
            elif kind == "hardblock":
                entry["type"] = "hardblock"
            elif kind == "coin":
                entry["type"] = "coin"
            else:
                continue
            prepared.append(entry)
        return prepared

    def _schedule_coin_run(self, start_column, length, surface_row, row_offset):
        if length <= 0:
            return []
        target_row = max(2, surface_row - row_offset)
        return [
            {"type": "coin", "x": start_column + offset, "row": target_row}
            for offset in range(length)
        ]

    def _schedule_coin_arc_features(self, start_column, length, surface_row, row_offset):
        if length <= 0:
            return []
        prepared = []
        peak_row = max(2, surface_row - row_offset)
        midpoint = (length - 1) / 2.0
        for offset in range(length):
            distance = abs(offset - midpoint)
            row = min(surface_row - 2, peak_row + int(round(distance)))
            prepared.append({"type": "coin", "x": start_column + offset, "row": row})
        return prepared

    def _schedule_stair_blocks(self, start_column, surface_row, height, block_type):
        prepared = []
        for step in range(height):
            column = start_column + step
            for stack in range(step + 1):
                row = surface_row - 1 - stack
                if row < 1:
                    continue
                entry = {"x": column, "row": row}
                entry["type"] = "hardblock" if block_type == "hard" else "brick"
                prepared.append(entry)
        return prepared

    def _schedule_background_pattern(self, x_index):
        patterns = self._background_patterns()
        if not patterns:
            return False
        pattern = self.randomizer.choice(patterns)
        anchor_offset = self.randomizer.randint(-2, 4)
        anchor = max(0, x_index + anchor_offset)
        scheduled = False
        for feature in pattern:
            start_x = anchor + feature.get("offset", 0)
            if start_x < 0:
                continue
            entry = {"type": feature["type"], "x": start_x}
            if feature["type"] == "cloud":
                min_y, max_y = feature.get("height_range", (0, 4))
                entry["y"] = self.randomizer.randint(min_y, max_y)
                if not self._cloud_candidate_clear(start_x, entry["y"], 128, 48):
                    continue
            elif feature["type"] == "flower":
                entry["sprite"] = feature.get(
                    "sprite", "decorative_flower_normal"
                )
            self.backgroundQueue.append(entry)
            scheduled = True
        return scheduled

    def _schedule_single_cloud(self, x_index, min_offset=1, max_offset=4, height_range=(0, 4)):
        target_x = x_index + self.randomizer.randint(min_offset, max_offset)
        if target_x < 0:
            return False
        entry = {
            "type": "cloud",
            "x": target_x,
            "y": self.randomizer.randint(*height_range),
        }
        if not self._cloud_candidate_clear(target_x, entry["y"], 128, 48):
            return False
        self.backgroundQueue.append(entry)
        return True

    def _cloud_candidate_clear(self, x, y, width, height, margin=16):
        """Keep cloud silhouettes separated while preserving their pixel art."""
        if not self.endless:
            return True
        candidate = pygame.Rect(x * 32, y * 32, width, height).inflate(
            margin * 2, margin * 2
        )
        first_bucket = max(0, int((candidate.left - 128) // 512))
        last_bucket = int(candidate.right // 512)
        for bucket in range(first_bucket, last_bucket + 1):
            for old_x, old_y, old_width, old_height in self._cloudBuckets.get(bucket, ()):
                old = pygame.Rect(old_x, old_y, old_width, old_height)
                if candidate.colliderect(old):
                    return False
        # Reserve the widest cutout for queued clouds, before their art variant
        # is selected during placement.
        for feature in getattr(self, "backgroundQueue", ()):
            if feature.get("type") != "cloud":
                continue
            old = pygame.Rect(feature["x"] * 32, feature["y"] * 32, 128, 48)
            if candidate.colliderect(old):
                return False
        return True

    def _maybe_schedule_extra_cloud(self, x_index, allow_cooldown=True):
        """
        Schedules a single cloud for placement.
        
        Clouds are scheduled ahead so their silhouette bounds can be checked
        against already placed and pending clouds before rendering.
        
        Args:
            x_index: Current column index
            allow_cooldown: If False, skip adding a spacing cooldown after placement
        """
        # 18% chance to schedule a cloud
        if self.randomizer.random() < 0.18:
            if self._schedule_single_cloud(x_index):
                # Apply cooldown unless blending is desired
                if allow_cooldown:
                    cooldown = self.randomizer.randint(2, 5)
                    self.decorationCooldown = max(self.decorationCooldown, cooldown)
                return True
        return False

    def _maybe_place_fence(self, x_index):
        if x_index < 5 or self.gapRemaining > 0:
            return False
        if self.randomizer.random() >= 0.12:
            return False
        max_length = min(8, x_index - 1)
        if max_length < 3:
            return False
        preferred_min = 5 if max_length >= 5 else 3
        if max_length >= preferred_min and self.randomizer.random() < 0.5:
            length = self.randomizer.randint(preferred_min, max_length)
        else:
            length = self.randomizer.randint(3, max_length)
        start_column = x_index - length
        if start_column < 0:
            return False
        columns = range(start_column, start_column + length)
        if self._columns_blocked_by_bush(columns):
            return False
        return self._place_fence_run(start_column, length)

    def _schedule_scenery_feature(self, feature_type, column):
        if column < 0:
            return False
        if getattr(self, "backgroundQueue", None) is None:
            self.backgroundQueue = []
        self.backgroundQueue.append({"type": feature_type, "x": column})
        return True

    def _background_patterns(self):
        flower_sprite = "decorative_flower_normal"
        return [
            [{"type": "bush", "offset": 0}],
            [{"type": "bush", "offset": 0}, {"type": "bush", "offset": 5}],
            [
                {"type": "bush", "offset": 0},
                {"type": "cloud", "offset": 4, "height_range": (0, 4)},
            ],
            [
                {"type": "cloud", "offset": 0, "height_range": (0, 3)},
                {"type": "cloud", "offset": 6, "height_range": (1, 4)},
            ],
            [
                {"type": "bush", "offset": 0},
                {"type": "cloud", "offset": 3, "height_range": (1, 4)},
                {"type": "bush", "offset": 8},
            ],
            [
                {"type": "cloud", "offset": 1, "height_range": (0, 4)},
                {"type": "bush", "offset": 6},
            ],
            [
                {"type": "cloud", "offset": 0, "height_range": (0, 3)},
                {"type": "cloud", "offset": 4, "height_range": (1, 4)},
                {"type": "cloud", "offset": 8, "height_range": (2, 4)},
            ],
            [
                {"type": "tree_small", "offset": 0},
                {"type": "bush", "offset": 5},
            ],
            [
                {"type": "tree_big", "offset": 0},
                {"type": "cloud", "offset": 4, "height_range": (0, 3)},
            ],
            [
                {"type": "circle_bush", "offset": 0},
                {"type": "flower", "offset": 3, "sprite": flower_sprite},
            ],
            [
                {"type": "bush", "offset": 0},
                {"type": "flower", "offset": 4, "sprite": flower_sprite},
                {"type": "cloud", "offset": 7, "height_range": (1, 4)},
            ],
        ]

    def _register_bush_columns(self, start_column):
        if getattr(self, "bushColumns", None) is None:
            self.bushColumns = set()
        for offset in range(3):
            self.bushColumns.add(start_column + offset)

    def _columns_blocked_by_bush(self, columns):
        if not getattr(self, "bushColumns", None):
            return False
        return any(column in self.bushColumns for column in columns)

    def _structure_columns_blocked(self, start_column, width):
        if not self.level:
            return True
        end_column = start_column + width
        if start_column < 0 or end_column >= len(self.level[0]):
            return True
        return self._columns_blocked_by_bush(range(start_column, end_column))

    def _column_has_block_above(self, column, bush_row):
        for row in range(bush_row):
            tile = self.level[row][column]
            if tile is not None and tile.rect is not None:
                return True
        return False

    @classmethod
    def _structure_signature(cls, structure):
        blocks = structure.get("blocks", [])
        ordered = sorted(
            blocks,
            key=lambda block: (
                block.get("type"),
                block.get("dx"),
                block.get("height_offset"),
                block.get("contents"),
                block.get("item"),
                block.get("coins"),
            ),
        )
        return json.dumps(ordered, sort_keys=True)

    @classmethod
    def _load_demo_structures(cls):
        if cls._DEMO_STRUCTURES is not None:
            return cls._DEMO_STRUCTURES
        merged = []
        seen = set()
        for path in (cls.DEMO_PATTERN_FILE, cls.FALLBACK_PATTERN_FILE):
            try:
                with open(path) as handle:
                    data = json.load(handle)
            except (IOError, ValueError):
                continue
            for structure in data.get("structures", []):
                signature = cls._structure_signature(structure)
                if signature in seen:
                    continue
                seen.add(signature)
                merged.append(structure)
        cls._DEMO_STRUCTURES = merged
        return cls._DEMO_STRUCTURES

    def _stamp_structure(self, structure, start_column):
        base_row = self._surface_row()
        placements = []
        for block in structure.get("blocks", []):
            dx = int(block.get("dx", 0))
            target_column = start_column + dx
            height_offset = block.get("height_offset", 0)
            if height_offset > self.MAX_JUMP_HEIGHT:
                return False
            target_row = base_row - int(height_offset)
            if not self._is_reachable(target_column, target_row):
                return False
            block_type = block.get("type")
            if block_type != "coin" and not self._tile_is_empty(target_column, target_row):
                return False
            placements.append((block_type, target_column, target_row, block))
        if not placements:
            return False
        for block_type, column, row, block in placements:
            if block_type == "brick":
                self.addBrickBlock(column, row, block.get("contents"), block.get("coins", 0))
            elif block_type == "question":
                item = self._sanitize_powerup_item(block.get("item", "RedMushroom"))
                self.addRandomBox(column, row, item)
            elif block_type == "coin_box":
                self.addCoinBox(column, row)
            elif block_type == "hard":
                self.addHardBlock(column, row)
            elif block_type == "coin":
                self.addCoin(column, row)
        return True

    def _tile_is_empty(self, column, row):
        if not self.level:
            return False
        if (
            row < 0
            or row >= len(self.level)
            or column < 0
            or column >= len(self.level[0])
        ):
            return False
        tile_empty = self.level[row][column].rect is None
        return tile_empty and not self._tile_has_coin(column, row)

    def _tile_has_coin(self, column, row):
        return (column, row) in getattr(self, "coinTiles", set())

    def _mark_coin_tile(self, column, row):
        if getattr(self, "coinTiles", None) is None:
            self.coinTiles = set()
        self.coinTiles.add((int(column), int(row)))

    def _area_is_clear(self, start_column, length, row):
        return all(self._tile_is_empty(start_column + offset, row) for offset in range(length))

    def _gap_is_clear(self, start_column, width, top_row, bottom_row):
        if width <= 0:
            return True
        if not self.level:
            return False
        top_row = max(0, top_row)
        bottom_row = min(len(self.level) - 1, bottom_row)
        if bottom_row < top_row:
            return True
        for offset in range(width):
            column = start_column + offset
            if column < 0 or column >= len(self.level[0]):
                return False
            for row in range(top_row, bottom_row + 1):
                if not self._tile_is_empty(column, row):
                    return False
        return True

    def _question_block_has_clearance(self, column, row):
        if not self._tile_is_empty(column, row):
            return False
        below = row + 1
        if not self.level or below >= len(self.level):
            return False
        tile_below = self.level[below][column]
        return tile_below.rect is None

    def _maybe_spawn_bonus_trio(self, x_index):
        if x_index < 6 or self.randomizer.random() >= 0.04:
            return False
        width = 3
        start_column = x_index - width + 1
        if start_column < 0:
            return False
        row = max(4, self._surface_row() - self.randomizer.randint(4, 6))
        columns = [start_column + offset for offset in range(width)]
        if self._columns_blocked_by_bush(columns):
            return False
        if not self._area_is_clear(start_column, width, row):
            return False
        self.addBrickBlock(start_column, row, contents="coin", coin_total=1)
        self.addRandomBox(start_column + 1, row, self._select_random_box_item())
        self.addBrickBlock(start_column + 2, row, contents="coin", coin_total=1)
        if self.randomizer.random() < 0.3:
            bonus_row = max(2, row - 2)
            for offset in range(width):
                self._attempt_coin_spawn(start_column + offset, bonus_row)
        return True

    def _maybe_spawn_brick_shelf(self, x_index):
        if x_index < 8 or self.randomizer.random() >= 0.05:
            return False
        width = self.randomizer.randint(2, 5)
        start_column = x_index - width + 1
        if start_column < 0:
            return False
        surface_row = self._surface_row()
        row = max(3, surface_row - self.randomizer.randint(4, min(6, surface_row - 3)))
        if not self._area_is_clear(start_column, width, row):
            return False
        columns = [start_column + offset for offset in range(width)]
        if self._columns_blocked_by_bush(columns):
            return False
        patterns = [
            ["coin", "plain"],
            ["plain", "powerup"],
            ["coin", "powerup", "coin"],
            ["multi", "plain", "coin"],
            ["plain", "plain", "powerup", "star"],
        ]
        pattern = self.randomizer.choice(patterns)
        for offset, column in enumerate(columns):
            role = pattern[offset % len(pattern)]
            if role == "coin":
                self.addBrickBlock(column, row, contents="coin", coin_total=1)
            elif role == "powerup":
                self.addBrickBlock(column, row, contents=self._select_random_box_item())
            elif role == "multi":
                self.addBrickBlock(
                    column,
                    row,
                    contents="multi-coin",
                    coin_total=self.randomizer.randint(3, 6),
                )
            elif role == "star":
                self.addBrickBlock(column, row, contents="Star")
            else:
                self.addBrickBlock(column, row)
        if self.randomizer.random() < 0.35:
            coin_row = max(2, row - 2)
            for column in columns:
                self._attempt_coin_spawn(column, coin_row)
        return True

    def _maybe_spawn_coin_brick_cluster(self, x_index):
        if x_index < 6 or self.randomizer.random() >= 0.05:
            return False
        cluster_length = self.randomizer.randint(2, 5)
        start_column = x_index - cluster_length + 1
        preview_row = max(1, self._surface_row() - 3)
        if start_column < 0 or not self._area_is_clear(start_column, cluster_length, preview_row):
            return False
        base_row = max(4, self._surface_row() - self.randomizer.randint(3, 6))
        if not self._area_is_clear(start_column, cluster_length, base_row):
            return False
        for offset in range(cluster_length):
            self.addCoinBrick(start_column + offset, base_row)
        if self.randomizer.random() < 0.35:
            bonus_column = start_column + self.randomizer.randint(0, cluster_length - 1)
            bonus_row = max(3, base_row - 1)
            if self._tile_is_empty(bonus_column, bonus_row):
                self.addCoinBox(bonus_column, bonus_row)
        return True

    def _maybe_spawn_hard_block_stairs(self, x_index):
        if x_index < 6 or self.randomizer.random() >= 0.05:
            return False
        max_height = self.randomizer.randint(3, 4)
        width = max_height
        start_column = x_index - width + 1
        if start_column < 0:
            return False
        columns = [start_column + offset for offset in range(width)]
        if self._columns_blocked_by_bush(columns):
            return False
        if any(not self._column_has_ground(column) for column in columns):
            return False
        surface_row = self._surface_row()
        support_rows = [self._highest_solid_tile(column) for column in columns]
        if any(row is None or row != surface_row for row in support_rows):
            return False
        base_row = max(1, surface_row - 1)
        if base_row <= 0:
            return False
        for offset in range(width):
            column = start_column + offset
            column_height = min(max_height, offset + 1)
            for block_index in range(column_height):
                row = base_row - block_index
                if row < 0 or not self._tile_is_empty(column, row):
                    return False
        for offset in range(width):
            column = start_column + offset
            column_height = min(max_height, offset + 1)
            for block_index in range(column_height):
                row = base_row - block_index
                self.addHardBlock(column, row)
            top_row = base_row - column_height + 1
            coin_row = max(2, top_row - 1)
            self._attempt_coin_spawn(column, coin_row)
        return True

    def _maybe_spawn_mushroom_platform(self, x_index):
        if self._is_dark_biome():
            return False
        chance = 0.12 if self._is_biome("mushroom") else 0.055
        if x_index < 8 or self.randomizer.random() >= chance:
            return False
        mushroom_count = self.randomizer.choice([2, 3])
        widths = []
        gaps = []
        total_span = 0
        for index in range(mushroom_count):
            width = self.randomizer.randint(3, 5)
            if width % 2 == 0:
                width -= 1
            width = max(3, width)
            widths.append(width)
            total_span += width
            if index < mushroom_count - 1:
                gap = self.randomizer.randint(2, 3)
                gaps.append(gap)
                total_span += gap
        stair_width = self.randomizer.randint(2, 3)
        approach_gap = self.randomizer.randint(1, 2)
        total_span += stair_width + approach_gap
        start_column = x_index - total_span + 1
        if start_column < 1:
            return False
        if not self._span_matches_biome(start_column, start_column + total_span):
            return False
        columns = range(start_column, start_column + total_span)
        if self._columns_blocked_by_bush(columns):
            return False
        surface_row = self._surface_row()
        if surface_row <= 1:
            return False
        base_drop = self.randomizer.randint(2, 4)
        base_cap_row = max(2, surface_row - base_drop)
        cap_rows = [base_cap_row]
        for index in range(1, mushroom_count):
            delta = self.randomizer.choice([-1, 0, 1])
            next_row = max(2, min(surface_row - 3, cap_rows[-1] + delta))
            cap_rows.append(next_row)
        if not self._build_approach_stair(start_column, stair_width, cap_rows[0], surface_row):
            return False
        gap_start = start_column + stair_width
        if not self._gap_is_clear(gap_start, approach_gap, max(1, cap_rows[0] - 1), surface_row - 1):
            return False
        column = gap_start + approach_gap
        built_any = False
        for idx, width in enumerate(widths):
            cap_row = cap_rows[idx]
            if not self._area_is_clear(column, width, cap_row):
                return False
            color = self.randomizer.choice(["red", "green"])
            if not self._build_mushroom_cap(column, width, cap_row, color):
                return False
            stem_col = column + width // 2
            stem_height = surface_row - cap_row
            self._build_mushroom_stem(stem_col, cap_row + 1, stem_height)
            if self.randomizer.random() < 0.4:
                coin_row = max(1, cap_row - 2)
                for offset in range(width):
                    self._attempt_coin_spawn(column + offset, coin_row)
            built_any = True
            if idx < len(gaps):
                gap_width = gaps[idx]
                next_cap_row = cap_rows[idx + 1]
                gap_top = max(1, min(cap_row, next_cap_row) - 1)
                if not self._gap_is_clear(column + width, gap_width, gap_top, surface_row - 1):
                    return False
                column += width + gap_width
            else:
                column += width
        return built_any

    def _maybe_spawn_ice_ground_cluster(self, x_index):
        if not self._is_biome("ice") or x_index < 5:
            return False
        if self.randomizer.random() >= 0.015:
            return False
        width = self.randomizer.randint(2, 3)
        start_column = x_index - width + 1
        if start_column < 0:
            return False
        columns = [start_column + offset for offset in range(width)]
        plan = {}
        for column in columns:
            surface_row = self._highest_solid_tile(column)
            if surface_row is None or surface_row <= 0:
                return False
            crest_height = 1
            crest_height = min(surface_row, crest_height)
            for step in range(crest_height):
                row = surface_row - 1 - step
                if row < 0 or not self._tile_is_empty(column, row):
                    return False
            plan[column] = (surface_row, crest_height)
        for column, (surface_row, crest_height) in plan.items():
            for step in range(crest_height):
                row = surface_row - 1 - step
                self._assign_solid_tile(column, row, "hardBlock")
        if self.randomizer.random() < 0.4:
            coin_row = min(value[0] for value in plan.values()) - 2
            coin_row = max(1, coin_row)
            for column in columns:
                self._attempt_coin_spawn(column, coin_row)
        return True

    def _maybe_spawn_ice_ledge(self, x_index):
        if not self._is_biome("ice") or x_index < 6 or self.randomizer.random() >= 0.02:
            return False
        width = self.randomizer.randint(3, 5)
        start_column = x_index - width + 1
        if start_column < 0:
            return False
        surface_row = self._surface_row()
        platform_row = max(3, surface_row - self.randomizer.randint(2, 4))
        if not self._area_is_clear(start_column, width, platform_row):
            return False
        columns = range(start_column, start_column + width)
        if self._columns_blocked_by_bush(columns):
            return False
        for offset in range(width):
            column = start_column + offset
            if not self._assign_solid_tile(column, platform_row, "hardBlock"):
                return False
            below_row = platform_row + 1
            if (
                below_row < len(self.level)
                and self.randomizer.random() < 0.65
                and self._tile_is_empty(column, below_row)
            ):
                self._assign_solid_tile(column, below_row, "hardBlock")
        if self.randomizer.random() < 0.4:
            coin_row = max(1, platform_row - 2)
            for offset in range(width):
                self._attempt_coin_spawn(start_column + offset, coin_row)
        return True

    def _build_approach_stair(self, start_column, stair_width, cap_row, surface_row):
        if stair_width < 2 or cap_row >= surface_row:
            return False
        max_width = min(stair_width, surface_row - cap_row + 1)
        for i in range(max_width):
            step_height = i + 1
            top_row = surface_row - step_height
            col = start_column + i
            for row in range(top_row, surface_row):
                if row < 0 or not self._tile_is_empty(col, row):
                    return False
        for i in range(max_width):
            step_height = i + 1
            top_row = surface_row - step_height
            col = start_column + i
            for row in range(top_row, surface_row):
                self.addHardBlock(col, row)
        return True

    def _build_mushroom_cap(self, start_column, width, row, color):
        if width < 3:
            return False
        if not self._area_is_clear(start_column, width, row):
            return False
        for offset in range(width):
            column = start_column + offset
            if offset == 0:
                sprite_name = f"{color}MushroomCap_left"
            elif offset == width - 1:
                sprite_name = f"{color}MushroomCap_right"
            else:
                sprite_name = f"{color}MushroomCap_mid"
            if not self._assign_solid_tile(column, row, sprite_name):
                return False
        return True

    def _build_mushroom_stem(self, column, start_row, max_height):
        if max_height <= 0:
            return False
        placed = False
        last_row = None
        for offset in range(max_height):
            row = start_row + offset
            if row >= len(self.level):
                break
            if not self._tile_is_empty(column, row):
                if offset == 0:
                    return False
                break
            sprite_name = "mushroomStem_top" if offset == 0 else "mushroomStem_base"
            if not self._assign_solid_tile(column, row, sprite_name):
                return False
            placed = True
            last_row = row
        if placed:
            attach_row = last_row + 1 if last_row is not None else start_row
            self._ensure_ground_column(column, attach_row)
        return placed

    def _ensure_ground_column(self, column, top_row):
        if not self.level:
            return False
        sprite_name = self._ground_sprite_for_biome()
        bottom_row = len(self.level) - 1
        top_row = max(0, min(top_row, bottom_row))
        placed_any = False
        if column < 0 or column >= len(self.level[0]):
            return False
        for row in range(bottom_row, top_row - 1, -1):
            tile = self.level[row][column]
            if tile is None or tile.rect is None:
                if not self._assign_solid_tile(column, row, sprite_name):
                    return placed_any
                placed_any = True
        return placed_any

    def _maybe_spawn_moving_platform(self, x_index):
        if (
            not self.endless
            or self._biome_at_column(x_index) == "underwater"
            or x_index < 8
            or self.randomizer.random() >= 0.02
        ):
            return False
        size = self.randomizer.choice(["small", "medium", "large"])
        # Sprite crops are 24/32/48 source pixels wide and are doubled by the
        # sprite loader, so reserve enough tile columns for their display size.
        width_px = {"small": 48, "medium": 64, "large": 96}[size]
        width_tiles = max(1, math.ceil(width_px / 32))
        start_column = x_index - width_tiles + 1
        if start_column < 0:
            return False
        if not self._span_matches_biome(start_column, start_column + width_tiles):
            return False
        row = max(3, self._surface_row() - self.randomizer.randint(4, 6))
        travel_tiles = self.randomizer.randint(2, 4)
        axis = self.randomizer.choice(("horizontal", "vertical"))
        clear = (
            self._platform_clearance_ok(start_column, width_tiles, row, travel_tiles)
            if axis == "horizontal"
            else self._vertical_platform_clearance_ok(
                start_column, width_tiles, row, travel_tiles
            )
        )
        if not clear:
            return False
        self.addMovingPlatform(
            start_column, row, size=size, axis=axis, travel_tiles=travel_tiles
        )
        return True

    def _platform_clearance_ok(self, start_column, width_tiles, row, travel_tiles):
        if row <= 0 or row >= len(self.level) - 1:
            return False
        total_width = width_tiles + travel_tiles
        # The generator places a platform several columns ahead of the
        # current append frontier. Validate terrain that exists now and treat
        # the unbuilt movement corridor as reserved: structure/rest cooldowns
        # keep new blockers out while those columns are authored.
        existing_end = min(start_column + total_width, len(self.level[0]))
        for column in range(start_column, existing_end):
            if column < 0:
                return False
            if not self._tile_is_empty(column, row):
                return False
            if not self._tile_is_empty(column, row + 1):
                return False
        return True

    def _vertical_platform_clearance_ok(self, start_column, width_tiles, row, travel_tiles):
        """Keep a vertical platform's full route clear above the base floor."""
        if row <= 0 or row + travel_tiles + 1 >= len(self.level):
            return False
        # Ground can still rise later in the generation buffer. Keep the
        # entire platform route above the highest supported base floor (four
        # ground tiles from the bottom).
        highest_floor_row = len(self.level) - 1 - 4
        if row + travel_tiles + 1 >= highest_floor_row:
            return False
        end_column = start_column + width_tiles
        if start_column < 0 or end_column > len(self.level[0]):
            return False
        for column in range(start_column, end_column):
            for path_row in range(row, row + travel_tiles + 1):
                if not self._tile_is_empty(column, path_row):
                    return False
                if not self._tile_is_empty(column, path_row + 1):
                    return False
        return True

    def _maybe_spawn_firebar_feature(self, x_index):
        if self._maybe_spawn_firebar_pedestal(x_index):
            self.structureCooldown = self.randomizer.randint(7, 13)
            self._reserve_safe_ground(7)
            return True
        if self._maybe_spawn_firebar(x_index):
            self.structureCooldown = self.randomizer.randint(6, 12)
            self._reserve_safe_ground(6)
            return True
        return False

    def _maybe_spawn_firebar(self, x_index):
        if not self.endless:
            return False
        if x_index < 8 or self.randomizer.random() >= 0.12:
            return False
        center_column = x_index - 1
        radius_tiles = self.randomizer.randint(2, 4)
        surface_row = self._surface_row()
        center_row = max(3, surface_row - self.randomizer.randint(5, 8))
        if not self._firebar_clearance_ok(
            center_column, center_row, radius_tiles, surface_row
        ):
            return False
        segments = radius_tiles + 2
        self.addFireBar(center_column, center_row, segments=segments)
        return True

    def _maybe_spawn_firebar_pedestal(self, x_index):
        if not self.endless or x_index < 6 or self.randomizer.random() >= 0.04:
            return False
        surface_row = self._surface_row()
        pedestal_row = max(2, surface_row - 1)
        width = self.randomizer.randint(2, 3)
        start_column = x_index - self.randomizer.randint(2, 4)
        if start_column < 1:
            return False
        columns = [start_column + offset for offset in range(width)]
        if self._columns_blocked_by_bush(columns):
            return False
        for column in columns:
            if not self._tile_is_empty(column, pedestal_row):
                return False
        for column in columns:
            self.addHardBlock(column, pedestal_row)
        center_column = columns[width // 2]
        center_row = max(2, pedestal_row - self.randomizer.randint(2, 3))
        segments = self.randomizer.randint(4, 6)
        self.addFireBar(center_column, center_row, segments=segments)
        return True

    def _firebar_clearance_ok(self, center_column, center_row, radius_tiles, surface_row):
        if not self.level:
            return False
        radius = radius_tiles + 1
        total_rows = len(self.level)
        total_columns = len(self.level[0]) if self.level else 0
        for column in range(center_column - radius, center_column + radius + 1):
            if column < 0 or column >= total_columns:
                return False
            for row in range(center_row - radius, center_row + radius + 1):
                if row < 0 or row >= total_rows:
                    return False
                # The top ground row and everything below it are the floor
                # clearance boundary, rather than overhead obstructions.
                if row >= surface_row - 1:
                    continue
                if not self._tile_is_empty(column, row):
                    return False
        return True

    def _pipe_has_clearance_for_plant(self, x, y):
        for row in range(max(0, y - 3), y):
            for column in (x, x + 1):
                if not self._tile_is_empty(column, row):
                    return False
        return True

    def _calculate_plant_emergence(self, pipe_top_row):
        surface_row = self._surface_row()
        exposed_rows = max(1, surface_row - pipe_top_row + 1)
        base_extension = 32
        per_row = 8
        return min(80, base_extension + exposed_rows * per_row)

    def _bush_has_clearance(self, start_column, bush_row):
        if not self.level:
            return False
        width = 3
        total_columns = len(self.level[0])
        for offset in range(width):
            column = start_column + offset
            if column < 0 or column >= total_columns:
                return False
            if self._column_has_block_above(column, bush_row):
                return False
            tile = self.level[bush_row][column]
            if tile is not None and tile.rect is not None:
                return False
        return True

    def _sanitize_powerup_item(self, item):
        if not item or item in {"coin", "coins"}:
            return item
        mushroom_items = {"RedMushroom", "OneUpMushroom", "mushroom"}
        if self._is_dark_biome() and item in mushroom_items:
            return "FireFlower" if self.randomizer.random() < 0.5 else "Star"
        return item

    def _select_random_box_item(self):
        if self._is_dark_biome():
            return "FireFlower" if self.randomizer.random() < 0.5 else "Star"
        roll = self.randomizer.random()
        if roll < 0.55:
            return "RedMushroom"
        if roll < 0.8:
            return "Star"
        return "FireFlower"

    def _reserve_safe_ground(self, columns):
        """
        Reserves columns of safe ground after structures/gaps.
        
        This prevents soft-locks by ensuring the player has safe ground
        to land on after jumping over obstacles or gaps.
        
        Args:
            columns: Number of columns to reserve (will not place obstacles)
        """
        if columns <= 0:
            return
        current = getattr(self, "safeColumnsRemaining", 0)
        # Take maximum to extend existing reservations
        self.safeColumnsRemaining = max(current, int(math.ceil(columns)))

    def _start_gap_cooldown(self):
        self.gapCooldown = max(self.gapCooldown, self.minGapSpacing)

    def _decay_gap_cooldown(self):
        if self.gapCooldown > 0:
            self.gapCooldown -= 1

    def _column_has_ground(self, column):
        if not self.level or column < 0 or column >= len(self.level[0]):
            return False
        bottom_row = len(self.level) - 1
        tile = self.level[bottom_row][column]
        return tile is not None and tile.rect is not None
