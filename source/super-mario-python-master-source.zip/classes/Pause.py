import pygame
import sys

from classes.Spritesheet import Spritesheet


def _blur_background(surface):
    """Soften the frozen pause frame using Pygame's portable scaler."""
    width, height = surface.get_size()
    reduced = pygame.transform.smoothscale(surface, (max(1, width // 12), max(1, height // 12)))
    return pygame.transform.smoothscale(reduced, (width, height))


class Pause:
    def __init__(self, screen, entity, dashboard, joystick=None):
        self.screen = screen
        self.entity = entity
        self.dashboard = dashboard
        self.joystick = joystick
        self.state = 0
        self.spritesheet = Spritesheet("./img/references/title_screen.png")
        self.pause_srfc = _blur_background(self.screen)
        self.dot = self.spritesheet.image_at(
            0, 150, 2, colorkey=[255, 0, 220], ignoreTileSize=True
        )
        self.gray_dot = self.spritesheet.image_at(
            20, 150, 2, colorkey=[255, 0, 220], ignoreTileSize=True
        )
        # Track button states to prevent repeated presses
        self.last_up_state = False
        self.last_down_state = False
        self.last_confirm_state = False

    def update(self):
        self.screen.blit(self.pause_srfc, (0, 0))
        self.dashboard.drawText("PAUSED", 120, 160, 68)
        self.dashboard.drawText("CONTINUE", 150, 280, 32)
        self.dashboard.drawText("BACK TO MENU", 150, 320, 32)
        self.drawDot()
        self.checkInput()

    def drawDot(self):
        if self.state == 0:
            self.screen.blit(self.dot, (100, 275))
            self.screen.blit(self.gray_dot, (100, 315))
        elif self.state == 1:
            self.screen.blit(self.dot, (100, 315))
            self.screen.blit(self.gray_dot, (100, 275))

    def checkInput(self):
        events = pygame.event.get()
        self.entity.input.update_joystick(events)

        # Check controller input if available
        if self.joystick:
            self.checkControllerInput()

        # Check keyboard input
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key in (pygame.K_ESCAPE, pygame.K_F5):
                    self.entity.pause = False
                elif event.key == pygame.K_RETURN:
                    if self.state == 0:
                        self.entity.pause = False
                    elif self.state == 1:
                        self.entity.restart = True
                elif event.key == pygame.K_UP:
                    if self.state > 0:
                        self.state -= 1
                elif event.key == pygame.K_DOWN:
                    if self.state < 1:
                        self.state += 1

    def checkControllerInput(self):
        """Handle controller input for pause menu"""
        if not self.joystick:
            return

        # Check for D-pad as hat (some controllers)
        hat = (0, 0)
        if self.joystick.get_numhats() > 0:
            hat = self.joystick.get_hat(0)

        # Check for D-pad as buttons (PS5 controller on macOS typically uses buttons 11-14)
        num_buttons = self.joystick.get_numbuttons()
        dpad_up_pressed = False
        dpad_down_pressed = False

        # Try common D-pad button mappings (11-12 for PS5, but check alternatives)
        if num_buttons > 11:
            dpad_up_pressed = self.joystick.get_button(11)
        if num_buttons > 12:
            dpad_down_pressed = self.joystick.get_button(12)

        # Also check alternative mappings
        if num_buttons > 4:
            dpad_up_pressed = dpad_up_pressed or self.joystick.get_button(4)
        if num_buttons > 5:
            dpad_down_pressed = dpad_down_pressed or self.joystick.get_button(5)

        # Combine hat and button inputs for D-pad
        up_pressed = hat[1] > 0 or dpad_up_pressed
        down_pressed = hat[1] < 0 or dpad_down_pressed

        # Handle D-pad up/down with debouncing
        if up_pressed and not self.last_up_state:
            if self.state > 0:
                self.state -= 1
        if down_pressed and not self.last_down_state:
            if self.state < 1:
                self.state += 1

        self.last_up_state = up_pressed
        self.last_down_state = down_pressed

        # Confirm/Select: X button (Cross, button 0)
        confirm_pressed = num_buttons > 0 and self.joystick.get_button(0)
        if confirm_pressed and not self.last_confirm_state:
            if self.state == 0:
                self.entity.pause = False
            elif self.state == 1:
                self.entity.restart = True
        self.last_confirm_state = confirm_pressed

        # Also allow Options button to unpause (if on Continue)
        options_pressed = num_buttons > 9 and self.joystick.get_button(9)
        # The same held press that opened pause must not close it.
        if options_pressed and not self.entity.input.last_controller_pause_state and self.state == 0:
            self.entity.pause = False
        self.entity.input.last_controller_pause_state = options_pressed

    def createBackgroundBlur(self):
        self.pause_srfc = _blur_background(self.screen)
