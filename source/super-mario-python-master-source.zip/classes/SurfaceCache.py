"""Small bounded caches for repeated runtime sprite transforms."""

from functools import lru_cache

import pygame


@lru_cache(maxsize=512)
def flip_surface(image, flip_x=True, flip_y=False):
    """Return a cached mirrored surface for an immutable sprite frame."""
    return pygame.transform.flip(image, flip_x, flip_y)


@lru_cache(maxsize=256)
def scale_surface(image, size):
    """Return a cached scaled surface keyed by source frame and output size."""
    return pygame.transform.scale(image, size)
