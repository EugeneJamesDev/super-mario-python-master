import json
import pygame

from classes.Font import Font
from classes.Paths import DATA_DIR, read_save_path


class Dashboard(Font):
    def __init__(self, filePath, size, screen):
        Font.__init__(self, filePath, size)
        self.state = "menu"
        self.screen = screen
        self.levelName = ""
        self.points = 0
        self.highScorePath = DATA_DIR / "highscore.json"
        self.highScore = self._load_high_score(read_save_path(self.highScorePath.name))
        self.coins = 0
        self.ticks = 0
        self.time = 0
        self._glyphScaleCache = {}

    def _load_high_score(self, path=None):
        try:
            data = json.loads((path or self.highScorePath).read_text())
            return int(data.get("highScore", 0)) if isinstance(data, dict) else 0
        except (OSError, ValueError, TypeError, OverflowError):
            return 0

    def save_high_score(self):
        try:
            self.highScorePath.parent.mkdir(parents=True, exist_ok=True)
            self.highScorePath.write_text(json.dumps({"highScore": int(self.highScore)}))
        except OSError:
            pass

    def update_high_score(self, score):
        if score > self.highScore:
            self.highScore = score
            self.save_high_score()

    def reset_high_score(self):
        self.highScore = 0
        self.save_high_score()

    def update(self):
        self.drawText("MARIO", 50, 20, 15)
        self.drawText(self.pointString(), 50, 37, 15)

        self.drawText("HI-SCORE", 225, 20, 15)
        self.drawText(self.highScoreString(), 225, 37, 15)

        self.drawText("@x{}".format(self.coinString()), 50, 60, 15)

        self.drawText("WORLD", 380, 20, 15)
        self.drawText(str(self.levelName), 395, 37, 15)

        self.drawText("TIME", 520, 20, 15)
        if self.state != "menu":
            self.drawText(self.timeString(), 535, 37, 15)

        # update Time
        self.ticks += 1
        if self.ticks == 60:
            self.ticks = 0
            self.time += 1

    def drawText(self, text, x, y, size):
        for char in text:
            cache_key = (char, size)
            charSprite = self._glyphScaleCache.get(cache_key)
            if charSprite is None:
                charSprite = pygame.transform.scale(
                    self.charSprites[char], (size, size)
                )
                self._glyphScaleCache[cache_key] = charSprite
            self.screen.blit(charSprite, (x, y))
            if char == " ":
                x += size//2
            else:
                x += size

    def coinString(self):
        return "{:02d}".format(self.coins)

    def pointString(self):
        return "{:06d}".format(self.points)

    def timeString(self):
        return "{:03d}".format(self.time)

    def highScoreString(self):
        return "{:06d}".format(self.highScore)
