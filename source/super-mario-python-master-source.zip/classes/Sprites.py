import json
from pathlib import Path

from classes.Animation import Animation
from classes.Paths import PROJECT_ROOT
from classes.Sprite import Sprite
from classes.Spritesheet import Spritesheet


class Sprites:
    ASSET_ROOT = PROJECT_ROOT
    SPRITE_MANIFESTS = (
        "Mario.json",
        "SwimSprites.json",
        "Goomba.json",
        "Koopa.json",
        "Animations.json",
        "BackgroundSprites.json",
        "SceneryExtras.json",
        "ItemAnimations.json",
        "RedMushroom.json",
        "Luigi.json",
        "Bowser.json",
        "BowserRedEyes.json",
        "FireBolt.json",
        "Princess.json",
        "MushroomVariants.json",
        "FlowerVariants.json",
        "FireEffects.json",
        "NewEnemies.json",
        "NewItems.json",
        "NewTiles.json",
        "FireBarSprites.json",
        "SMB1Scenery.json",
        "SMB1ObjectVariants.json",
        "ParatroopaFrames.json",
        "SMB1WikiFrames.json",
    )

    def __init__(self):
        self.spriteCollection = self.loadSprites(
            [self.ASSET_ROOT / "sprites" / name for name in self.SPRITE_MANIFESTS]
        )

    def loadSprites(self, urlList):
        resDict = {}
        sheet_cache = {}

        def get_sheet(path):
            if not path:
                return None
            path = Path(path)
            if not path.is_absolute():
                path = self.ASSET_ROOT / path
            path = path.resolve()
            if path not in sheet_cache:
                try:
                    sheet_cache[path] = Spritesheet(path)
                except Exception as e:
                    print(f"Warning: Failed to load spritesheet {path}: {e}")
                    # Cache failures so each sprite in the same sheet does not
                    # repeat the same disk access and warning.
                    sheet_cache[path] = None
                    return None
            return sheet_cache[path]

        for url in urlList:
            url = Path(url)
            if not url.is_absolute():
                url = self.ASSET_ROOT / url
            try:
                with url.open(encoding="utf-8") as jsonData:
                    data = json.load(jsonData)
                    # Individual sprites or frames can supply their own sheet.
                    default_sheet_path = data.get("spriteSheetURL")

                    dic = {}
                    if data["type"] == "background":
                        for sprite in data["sprites"]:
                            try:
                                sprite_name = sprite.get("name")
                                if not sprite_name:
                                    continue

                                sheet_path = sprite.get("spriteSheetURL", default_sheet_path)
                                active_sheet = get_sheet(sheet_path)
                                if active_sheet is None:
                                    continue

                                colorkey = sprite.get("colorKey")
                                ignore_tile_size = sprite.get("ignoreTileSize", False)
                                xSize = sprite.get("xsize")
                                ySize = sprite.get("ysize")
                                if xSize is not None or ySize is not None:
                                    ignore_tile_size = True
                                xSize = xSize if xSize is not None else sprite.get("tileWidth", 16)
                                ySize = ySize if ySize is not None else sprite.get("tileHeight", 16)

                                try:
                                    if ignore_tile_size:
                                        image = active_sheet.image_at(
                                            sprite["x"],
                                            sprite["y"],
                                            sprite.get("scalefactor", 2),
                                            colorkey,
                                            ignoreTileSize=True,
                                            xTileSize=xSize,
                                            yTileSize=ySize,
                                        )
                                    else:
                                        image = active_sheet.image_at(
                                            sprite["x"],
                                            sprite["y"],
                                            sprite.get("scalefactor", 2),
                                            colorkey,
                                        )

                                    if image is not None:
                                        dic[sprite_name] = Sprite(
                                            image,
                                            sprite.get("collision", False),
                                            None,
                                            sprite.get("redrawBg", False),
                                        )
                                except (KeyError, TypeError, AttributeError, ValueError) as e:
                                    print(f"Warning: Failed to load sprite '{sprite_name}' from {url}: {e}")
                                    continue
                            except (KeyError, TypeError) as e:
                                print(f"Warning: Error processing sprite in {url}: {e}")
                                continue
                        resDict.update(dic)
                        continue
                    elif data["type"] == "animation":
                        default_tile = data.get("size", (16, 16))
                        for sprite in data["sprites"]:
                            try:
                                sprite_name = sprite.get("name")
                                if not sprite_name:
                                    continue

                                images = []
                                # For animation type, spriteSheetURL can be in sprite or image level
                                sprite_sheet = sprite.get("spriteSheetURL") or default_sheet_path
                                for image_data in sprite.get("images", []):
                                    try:
                                        # Get spriteSheetURL from image, sprite, or top level (in that order)
                                        image_sheet = image_data.get("spriteSheetURL") or sprite_sheet
                                        if not image_sheet:
                                            # Skip this image if no spriteSheetURL found anywhere
                                            continue
                                        active_sheet = get_sheet(image_sheet)
                                        if active_sheet is None:
                                            continue

                                        color_key = image_data.get("colorKey", sprite.get("colorKey"))
                                        ignore_tile = image_data.get(
                                            "ignoreTileSize", sprite.get("ignoreTileSize", False)
                                        )
                                        x_size = image_data.get(
                                            "xsize", sprite.get("xsize", default_tile[0])
                                        )
                                        y_size = image_data.get(
                                            "ysize", sprite.get("ysize", default_tile[1])
                                        )
                                        if image_data.get("xsize") is not None or image_data.get("ysize") is not None:
                                            ignore_tile = True
                                        scale = image_data.get("scale", sprite.get("scale", 1))

                                        img = active_sheet.image_at(
                                            image_data["x"],
                                            image_data["y"],
                                            scale,
                                            colorkey=color_key,
                                            ignoreTileSize=ignore_tile,
                                            xTileSize=x_size,
                                            yTileSize=y_size,
                                        )
                                        if img is not None:
                                            images.append(img)
                                    except (KeyError, TypeError, AttributeError, ValueError) as e:
                                        print(f"Warning: Failed to load animation frame for '{sprite_name}': {e}")
                                        continue

                                if images:
                                    dic[sprite_name] = Sprite(
                                        None,
                                        None,
                                        animation=Animation(images, deltaTime=sprite.get("deltaTime", 4)),
                                    )
                            except (KeyError, TypeError) as e:
                                print(f"Warning: Error processing animation sprite in {url}: {e}")
                                continue
                        resDict.update(dic)
                        continue
                    elif data["type"] == "character" or data["type"] == "item":
                        for sprite in data["sprites"]:
                            try:
                                sprite_name = sprite.get("name")
                                if not sprite_name:
                                    continue

                                # Support per-sprite spriteSheetURL override (like background sprites)
                                sheet_path = sprite.get("spriteSheetURL", default_sheet_path)
                                active_sheet = get_sheet(sheet_path)
                                if active_sheet is None:
                                    continue

                                colorkey = sprite.get("colorKey", None)
                                try:
                                    xSize = sprite.get('xsize')
                                    ySize = sprite.get('ysize')
                                except KeyError:
                                    xSize, ySize = data.get('size', (16, 16))

                                img = active_sheet.image_at(
                                    sprite["x"],
                                    sprite["y"],
                                    sprite.get("scalefactor", 2),
                                    colorkey,
                                    True,
                                    xTileSize=xSize,
                                    yTileSize=ySize,
                                )
                                if img is not None:
                                    dic[sprite_name] = Sprite(
                                        img,
                                        sprite.get("collision", False),
                                    )
                            except (KeyError, TypeError, AttributeError, ValueError) as e:
                                print(f"Warning: Failed to load sprite '{sprite.get('name', 'unknown')}' from {url}: {e}")
                                continue
                        resDict.update(dic)
                        continue
            except (FileNotFoundError, json.JSONDecodeError, KeyError) as e:
                print(f"Warning: Failed to load sprite file {url}: {e}")
                continue
        return resDict
