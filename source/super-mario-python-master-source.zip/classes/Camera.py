from classes.Maths import Vec2D


class Camera:
    def __init__(self, pos, entity, auto_scroll_speed=0.03, min_screen_buffer=1.5):
        self.pos = Vec2D(pos.x, pos.y)
        self.entity = entity
        self.x = self.pos.x * 32
        self.y = self.pos.y * 32
        self._min_scroll = self.pos.x
        self.auto_scroll_speed = auto_scroll_speed
        self.min_screen_buffer = min_screen_buffer

    def move(self):
        xPosFloat = self.entity.getPosIndexAsFloat().x
        target = min(0.0, 10 - xPosFloat)
        if self._auto_scroll_enabled():
            self._min_scroll -= self.auto_scroll_speed
            limit = min(0.0, self.min_screen_buffer - xPosFloat)
            self._min_scroll = min(max(self._min_scroll, limit), target)
        else:
            self._min_scroll = target
        self.pos.x = self._min_scroll
        self.x = self.pos.x * 32
        self.y = self.pos.y * 32

    def _auto_scroll_enabled(self):
        level = getattr(self.entity, "levelObj", None)
        return getattr(level, "endless", False)
