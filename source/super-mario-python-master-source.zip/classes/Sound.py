from pygame import mixer


class SilentChannel:
    """Keep sound calls safe when SDL cannot open an audio device."""

    def play(self, sound, loops=0):
        pass

    def stop(self):
        pass

    def get_busy(self):
        return False


class Sound:
    ASSET_FILES = {
        "soundtrack": "sfx/main_theme.ogg",
        "coin": "sfx/coin.ogg",
        "bump": "sfx/bump.ogg",
        "stomp": "sfx/stomp.ogg",
        "jump": "sfx/small_jump.ogg",
        "death": "sfx/death.ogg",
        "kick": "sfx/kick.ogg",
        "brick_bump": "sfx/brick-bump.ogg",
        "powerup": "sfx/powerup.ogg",
        "powerup_appear": "sfx/powerup_appears.ogg",
        "pipe": "sfx/pipe.ogg",
    }

    def __init__(self):
        self.allowSFX = True
        enabled = mixer.get_init() is not None
        if enabled:
            self.music_channel = mixer.Channel(0)
            self.music_channel.set_volume(0.2)
            self.sfx_channel = mixer.Channel(1)
            self.sfx_channel.set_volume(0.2)
        else:
            self.music_channel = self.sfx_channel = SilentChannel()
        for name, path in self.ASSET_FILES.items():
            setattr(self, name, mixer.Sound(path) if enabled else None)

    def play_sfx(self, sfx):
        if self.allowSFX:
            self.sfx_channel.play(sfx)
