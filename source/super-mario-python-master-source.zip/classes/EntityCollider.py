class EntityCollider:
    def __init__(self, entity):
        self.entity = entity

    def check(self, target):
        actor = self.entity.rect
        obstacle = target.rect
        if not actor.colliderect(obstacle):
            return CollisionState(False, False)

        platform_motion = getattr(target, "velocity", None)
        fall_speed = self.entity.vel.y
        if platform_motion is not None:
            fall_speed -= platform_motion.y
        # A top contact crosses the target's top edge this frame. Allow one
        # pixel for Rect's integer rounding when movement uses fractional speed.
        is_top = fall_speed > 0 and actor.bottom - fall_speed <= obstacle.top + 1
        return CollisionState(True, is_top)


class CollisionState:
    def __init__(self, _isColliding, _isTop):
        self.isColliding = _isColliding
        self.isTop = _isTop
