class Tile:
    def __init__(self, sprite, rect, block=None):
        self.sprite = sprite
        self.rect = rect
        self.block = block
