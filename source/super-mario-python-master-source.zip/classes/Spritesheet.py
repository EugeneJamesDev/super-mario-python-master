from pathlib import Path

import pygame


class Spritesheet(object):
    def __init__(self, filename):
        try:
            loaded = pygame.image.load(str(filename))
            self.sheet_uses_alpha = bool(
                loaded.get_flags() & pygame.SRCALPHA or loaded.get_colorkey() is not None
            )

            # Convert only when a display exists. This also keeps sprite tooling
            # usable in headless mode and avoids scanning every sheet pixel.
            if pygame.display.get_surface() is not None:
                if self.sheet_uses_alpha:
                    loaded = loaded.convert_alpha()
                else:
                    loaded = loaded.convert()
            self.sheet = loaded
        except (pygame.error, OSError) as error:
            raise RuntimeError(
                "Unable to load spritesheet {}: {}".format(Path(filename), error)
            ) from error

    def image_at(
        self,
        x,
        y,
        scalingfactor,
        colorkey=None,
        ignoreTileSize=False,
        xTileSize=16,
        yTileSize=16,
    ):
        if ignoreTileSize:
            rect = pygame.Rect((x, y, xTileSize, yTileSize))
        else:
            rect = pygame.Rect((x * xTileSize, y * yTileSize, xTileSize, yTileSize))

        outside_sheet = (
            rect.left < 0
            or rect.top < 0
            or rect.right > self.sheet.get_width()
            or rect.bottom > self.sheet.get_height()
        )
        if outside_sheet:
            raise ValueError(
                "Sprite crop {} is outside sheet bounds {}".format(
                    rect, self.sheet.get_size()
                )
            )

        if self.sheet_uses_alpha:
            image = pygame.Surface(rect.size, pygame.SRCALPHA)
        else:
            image = pygame.Surface(rect.size)

        image.blit(self.sheet, (0, 0), rect)

        crop_has_alpha_cutout = False
        if image.get_flags() & pygame.SRCALPHA:
            crop_has_alpha_cutout = any(
                image.get_at((pixel_x, pixel_y)).a < 255
                for pixel_y in range(image.get_height())
                for pixel_x in range(image.get_width())
            )

        if colorkey is False:
            # Explicitly preserve opaque pixels, including black tile details.
            pass
        elif colorkey is not None and not crop_has_alpha_cutout:
            if colorkey == -1:
                colorkey = image.get_at((0, 0))
            key_rgb = tuple(colorkey[:3])
            if image.get_flags() & pygame.SRCALPHA:
                # A per-pixel-alpha surface does not reliably apply SDL's
                # color-key flag during blits. Convert the keyed matte to
                # transparent pixels before scaling instead.
                for pixel_y in range(image.get_height()):
                    for pixel_x in range(image.get_width()):
                        pixel = image.get_at((pixel_x, pixel_y))
                        if pixel.a and tuple(pixel[:3]) == key_rgb:
                            image.set_at((pixel_x, pixel_y), (*key_rgb, 0))
            else:
                image.set_colorkey(colorkey, pygame.RLEACCEL)
        elif not self.sheet_uses_alpha:
            # Legacy sheets without alpha use black as their transparent matte.
            image.set_colorkey((0, 0, 0), pygame.RLEACCEL)

        scaled = pygame.transform.scale(
            image, (xTileSize * scalingfactor, yTileSize * scalingfactor)
        )
        if image.get_colorkey() is not None:
            # pygame.transform.scale does not consistently retain surface
            # color keys across pygame versions.
            scaled.set_colorkey(image.get_colorkey(), pygame.RLEACCEL)
        return scaled
