import pygame
import sys


class Input:
    def __init__(self, entity, joystick=None):
        self.entity = entity
        self.joystick = joystick
        # Track button states to prevent repeated presses
        self.last_controller_pause_state = False
        self.last_fire_state = False
        self.last_jetpack_state = False

    def checkForInput(self):
        events = pygame.event.get()
        self.update_joystick(events)
        # Check controller first if available, then fall back to keyboard
        if self.joystick:
            self.checkForControllerInput()
        else:
            self.checkForKeyboardInput()
        self.checkForMouseInput(events)
        self.checkForQuitAndRestartInputEvents(events)

    def update_joystick(self, events):
        for event in events:
            if event.type == pygame.JOYDEVICEREMOVED and self.joystick is not None:
                if event.instance_id == self.joystick.get_instance_id():
                    self.joystick = None
            if event.type == pygame.JOYDEVICEADDED and self.joystick is None:
                try:
                    self.joystick = pygame.joystick.Joystick(event.device_index)
                except pygame.error:
                    # The device can unplug before SDL delivers the add event.
                    continue
        self.entity.pauseObj.joystick = self.joystick

    @staticmethod
    def first_joystick():
        if pygame.joystick.get_init() and pygame.joystick.get_count():
            try:
                return pygame.joystick.Joystick(0)
            except pygame.error:
                pass
        return None

    def checkForControllerInput(self):
        """Handle PS5 controller input"""
        if not self.joystick:
            return

        # Deadzone for analog stick to prevent drift
        deadzone = 0.3

        # Movement: Left stick horizontal axis (axis 0) or D-pad
        num_axes = self.joystick.get_numaxes()
        num_buttons = self.joystick.get_numbuttons()
        left_stick_x = self.joystick.get_axis(0) if num_axes else 0.0
        left_stick_y = self.joystick.get_axis(1) if num_axes > 1 else 0.0
        hat = self.joystick.get_hat(0) if self.joystick.get_numhats() > 0 else (0, 0)

        # Use D-pad if pressed, otherwise use stick
        direction = 0
        if hat[0] != 0:
            direction = -1 if hat[0] < 0 else 1
        elif abs(left_stick_x) > deadzone:
            direction = -1 if left_stick_x < -deadzone else (1 if left_stick_x > deadzone else 0)

        self.entity.traits["goTrait"].direction = direction
        if self.entity.climbing_vine and direction:
            self.entity.detach_vine()

        climb_axis = 0
        if hat[1] != 0:
            climb_axis = -1 if hat[1] > 0 else 1
        elif abs(left_stick_y) > deadzone:
            climb_axis = -1 if left_stick_y < -deadzone else 1
        self.entity.climb_input_y = climb_axis
        if climb_axis < 0 and not self.entity.climbing_vine:
            self.entity.try_attach_vine()

        # Jump: X button (Cross, button 0)
        isJumping = num_buttons > 0 and self.joystick.get_button(0)
        if self.entity.climbing_vine and isJumping:
            self.entity.detach_vine(jump=True)
            isJumping = False
        elif self.entity.climbing_vine:
            isJumping = False
        self.entity.traits['jumpTrait'].jump(isJumping)

        # Boost/Run: Square button (button 2)
        self.entity.traits['goTrait'].boost = num_buttons > 2 and self.joystick.get_button(2)

        # Fire: L2 trigger (left trigger) - check both button 6 and axis 3
        l2_button = False
        if num_buttons > 6:
            l2_button = self.joystick.get_button(6)
        # Also check axis 3 for L2 (PS5 controllers use analog triggers as axes)
        l2_axis = False
        if num_axes > 3:
            l2_axis_value = self.joystick.get_axis(3)
            l2_axis = l2_axis_value > 0.5  # Trigger pressed if axis > 0.5

        fire_pressed = l2_button or l2_axis
        if fire_pressed and not self.last_fire_state:
            if hasattr(self.entity, 'shootFire'):
                self.entity.shootFire()
        self.last_fire_state = fire_pressed

        # Jetpack: R2 trigger (right trigger) - check both button 7 and axis 4
        r2_button = False
        if num_buttons > 7:
            r2_button = self.joystick.get_button(7)
        # Also check axis 4 for R2 (PS5 controllers use analog triggers as axes)
        r2_axis = False
        if num_axes > 4:
            r2_axis_value = self.joystick.get_axis(4)
            r2_axis = r2_axis_value > 0.5  # Trigger pressed if axis > 0.5

        jetpack_pressed = r2_button or r2_axis
        if jetpack_pressed and not self.last_jetpack_state:
            if hasattr(self.entity, 'try_jetpack'):
                self.entity.try_jetpack()
        self.last_jetpack_state = jetpack_pressed

        # Pause: Options button (button 9)
        options_pressed = num_buttons > 9 and self.joystick.get_button(9)
        if options_pressed and not self.last_controller_pause_state:
            self.entity.pause = True
            self.entity.pauseObj.createBackgroundBlur()
        self.last_controller_pause_state = options_pressed

    def checkForKeyboardInput(self):
        pressedKeys = pygame.key.get_pressed()

        if (pressedKeys[pygame.K_LEFT] or pressedKeys[pygame.K_h]) and not (pressedKeys[pygame.K_RIGHT] or pressedKeys[pygame.K_l]):
            self.entity.traits["goTrait"].direction = -1
        elif (pressedKeys[pygame.K_RIGHT] or pressedKeys[pygame.K_l]) and not (pressedKeys[pygame.K_LEFT] or pressedKeys[pygame.K_h]):
            self.entity.traits["goTrait"].direction = 1
        else:
            self.entity.traits['goTrait'].direction = 0

        if self.entity.climbing_vine and self.entity.traits["goTrait"].direction:
            self.entity.detach_vine()

        climb_up = pressedKeys[pygame.K_UP]
        climb_down = pressedKeys[pygame.K_DOWN]
        self.entity.climb_input_y = -1 if climb_up else (1 if climb_down else 0)
        if climb_up and not self.entity.climbing_vine:
            self.entity.try_attach_vine()

        jump_button = pressedKeys[pygame.K_SPACE] or pressedKeys[pygame.K_k]
        if self.entity.climbing_vine:
            if jump_button:
                self.entity.detach_vine(jump=True)
            isJumping = False
        else:
            isJumping = jump_button or (climb_up and not self.entity.climbing_vine)
        self.entity.traits['jumpTrait'].jump(isJumping)

        self.entity.traits['goTrait'].boost = pressedKeys[pygame.K_LSHIFT]

        # Fire: 'a' key
        fire_pressed = pressedKeys[pygame.K_a]
        if fire_pressed and not self.last_fire_state:
            if hasattr(self.entity, 'shootFire'):
                self.entity.shootFire()
        self.last_fire_state = fire_pressed

        # Jetpack: 's' key (single-press, not held) - available to both Mario and Luigi
        jet_pressed = pressedKeys[pygame.K_s]
        if jet_pressed and not self.last_jetpack_state:
            if hasattr(self.entity, 'try_jetpack'):
                self.entity.try_jetpack()
        self.last_jetpack_state = jet_pressed

    def checkForMouseInput(self, events):
        mouseX, mouseY = pygame.mouse.get_pos()
        column = mouseX / 32 - self.entity.camera.pos.x
        row = mouseY / 32
        if self.isRightMouseButtonPressed(events):
            self.entity.levelObj.addKoopa(column, row)
            self.entity.levelObj.addGoomba(column, row)
            self.entity.levelObj.addRedMushroom(column, row)
        if self.isLeftMouseButtonPressed(events):
            self.entity.levelObj.addCoin(column, row)

    def checkForQuitAndRestartInputEvents(self, events):
        for event in events:
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN and \
                (event.key == pygame.K_ESCAPE or event.key == pygame.K_F5):
                self.entity.pause = True
                self.entity.pauseObj.createBackgroundBlur()

    def isLeftMouseButtonPressed(self, events):
        return self.checkMouse(events, 1)

    def isRightMouseButtonPressed(self, events):
        return self.checkMouse(events, 3)

    def checkMouse(self, events, button):
        for e in events:
            if e.type == pygame.MOUSEBUTTONUP and e.button == button:
                return True
        return False
