"""Locations shared by the source launcher and the packaged executable."""

from pathlib import Path
import sys


if sys.platform != "emscripten" and getattr(sys, "frozen", False):
    PROJECT_ROOT = Path(sys.executable).resolve().parent
else:
    PROJECT_ROOT = Path(__file__).resolve().parents[1]

DATA_DIR = PROJECT_ROOT / "data"


def read_save_path(filename):
    # Older checkouts may still have saves beside the launcher.
    current = DATA_DIR / filename
    legacy = PROJECT_ROOT / filename
    return legacy if not current.exists() and legacy.is_file() else current
