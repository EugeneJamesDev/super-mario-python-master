import pygame

from classes.SurfaceCache import flip_surface, scale_surface
from classes.Animation import Animation
from classes.Collider import Collider
from classes.EntityCollider import EntityCollider
from entities.EntityBase import EntityBase
from entities.FireBolt import FireBolt
from traits.leftrightwalk import LeftRightWalkTrait


class Bowser(EntityBase):
    def __init__(self, screen, spriteColl, x, y, level, sound, variant="green"):
        # x is the column; y is the row. Raise the large sprite one tile so
        # its feet align with the platform at the supplied row.
        super(Bowser, self).__init__(x, y - 1, 1.25)
        self.spriteCollection = spriteColl
        self.variant = variant  # "green" or "redeyes"
        self.screen = screen
        self.levelObj = level
        self.sound = sound
        self.type = "Mob"
        self.dashboard = level.dashboard
        self.collision = Collider(self, level)
        self.EntityCollider = EntityCollider(self)
        
        # Load animation frames based on variant
        prefix = "bowser_green" if variant == "green" else "bowser_redeyes"
        frames = []
        for i in range(1, 6):
            sprite_name = f"{prefix}_{i}"
            sprite = self.spriteCollection.get(sprite_name)
            if sprite is None or not sprite.image:
                # Create fallback if sprite missing (use proper colors, not pink)
                fallback = pygame.Surface((32, 32), pygame.SRCALPHA)
                if variant == "redeyes":
                    fallback.fill((200, 0, 0, 255))  # Dark red
                else:
                    fallback.fill((0, 150, 0, 255))  # Dark green
                frames.append(fallback)
            else:
                # Use the sprite image directly - exact SMB pixel size (32x32)
                frames.append(sprite.image)
        
        if not frames:
            # Ultimate fallback (use proper colors, not pink)
            fallback = pygame.Surface((32, 32), pygame.SRCALPHA)
            if variant == "redeyes":
                fallback.fill((200, 0, 0, 255))  # Dark red
            else:
                fallback.fill((0, 150, 0, 255))  # Dark green
            frames = [fallback]
        
        # Animation with slower frame rate (deltaTime=10 means change frame every 10 updates)
        # This makes the walking animation look more natural
        self.animation = Animation(frames, deltaTime=10)
        
        # Bowser walks slower than regular enemies
        self.leftrightTrait = LeftRightWalkTrait(self, level)
        # Use slower speed - about half of normal enemy speed
        # Normal enemies: 0.046875 * 32 = 1.5 px/frame
        # Bowser: 0.0234375 * 32 = 0.75 px/frame (half speed)
        self.leftrightTrait.speed = 0.0234375 * 32
        
        # Fire shooting
        self.fireCooldown = 0
        self.fireInterval = 180  # Frames between fire shots (3 seconds at 60fps)
        self.direction = -1  # Start facing left
        
        # Death animation state
        self.deathTimer = 0
        self.deathUpwardVelocity = -4.0  # Pixels per frame upward
        self.deathUpwardFrames = 8  # Frames to move up before falling
        self.deathFallSpeed = 0.5  # Faster gravity for death fall
        
        # Bowser sprite is 32x32 but should be displayed as 64x64 (2x2 blocks)
        # Update collision rect to match visual size (2x2 blocks = 64x64 pixels)
        self.rect = pygame.Rect(self.rect.x, self.rect.y, 64, 64)

    def update(self, camera):
        if not self.alive:
            self.onDead(camera)
            return
        if self.active:
            self.updateAlive(camera)
            self.checkEntityCollision()
            self.shootFire()
        # If not active, don't update (but keep alive)

    def updateAlive(self, camera):
        self.applyGravity()
        self.drawBowser(camera)
        self.animation.update()
        self.leftrightTrait.update()
        
        # Update fire cooldown
        if self.fireCooldown > 0:
            self.fireCooldown -= 1

    def onDead(self, camera):
        """Handle Bowser's death animation: freeze, move up, then fall"""
        # Stop horizontal movement
        self.vel.x = 0
        
        # Freeze animation and movement
        if self.deathTimer < self.deathUpwardFrames:
            # Move up a few pixels
            self.rect.y += self.deathUpwardVelocity
            self.deathTimer += 1
        else:
            # Reset upward velocity on first frame of falling
            if self.deathTimer == self.deathUpwardFrames:
                self.vel.y = 0  # Reset velocity before falling
            
            # Fall down with faster gravity for death
            self.vel.y += self.gravity * self.deathFallSpeed
            # Cap fall speed
            if self.vel.y > 8.0:  # Terminal velocity
                self.vel.y = 8.0
            
            # Update position based on velocity (fall straight down)
            self.rect.y += self.vel.y
            
            # Remove when off screen
            if self.rect.y > 600:  # Below screen
                self.alive = None  # Remove from entity list
            
            self.deathTimer += 1
        
        # Draw frozen sprite (last frame)
        self.drawBowser(camera, frozen=True)
    
    def drawBowser(self, camera, frozen=False):
        # Ensure animation exists and has an image
        if not hasattr(self, 'animation') or not self.animation or not self.animation.image:
            return
        
        draw_x = self.rect.x + camera.x
        # Bowser sprite is 32x32 but should be displayed as 64x64 (2x2 blocks)
        # Draw at rect position, but scale up 2x
        draw_y = self.rect.y
        
        # Make sure we're drawing on screen
        if draw_x < -100 or draw_x > 800 or draw_y < -200 or draw_y > 600:
            return
        
        # Get sprite image (frozen uses current frame, no animation update)
        sprite_image = self.animation.image
        
        # Flip based on direction
        if self.leftrightTrait.direction == 1:
            sprite_image = flip_surface(sprite_image, True, False)
        
        # Scale to 64x64 (2x2 blocks)
        scaled_sprite = scale_surface(sprite_image, (64, 64))
        self.screen.blit(scaled_sprite, (draw_x, draw_y))

    def shootFire(self):
        """Shoot a fire bolt if cooldown is ready"""
        if self.fireCooldown <= 0 and self.levelObj:
            # Shoot fire in the direction Bowser is facing
            fire_direction = self.leftrightTrait.direction
            
            # Spawn fire bolt from top left of Bowser when facing left (normal orientation)
            # Bowser is 64x64 (2x2 blocks), fire bolt is 2x1 blocks (64x32)
            # Fire should start attached to Bowser's mouth area (top left when facing left)
            if fire_direction == -1:  # Facing left (normal orientation - frame 1)
                # Start at Bowser's top left mouth area, fire extends leftward
                fire_x = self.rect.x - 64  # Fire starts attached, extends 64px left (2 blocks wide)
                fire_y = self.rect.y + 8  # Slightly below top, aligned with mouth area
            else:  # Facing right
                # Start at Bowser's top right mouth area, fire extends rightward
                fire_x = self.rect.x + 64  # Fire starts attached, extends 64px right
                fire_y = self.rect.y + 8  # Slightly below top, aligned with mouth area
            
            firebolt = FireBolt(
                self.screen,
                self.spriteCollection,
                fire_x,  # Pass pixel coordinates directly
                fire_y,
                fire_direction,
                self.levelObj
            )
            
            # Add to level's entity list
            self.levelObj.entityList.append(firebolt)
            
            # Reset cooldown
            self.fireCooldown = self.fireInterval

    def checkEntityCollision(self):
        for ent in self.levelObj.entityList:
            if ent is not self and hasattr(ent, 'type'):
                collisionState = self.EntityCollider.check(ent)
                if collisionState.isColliding:
                    if ent.type == "Mob" and hasattr(ent, 'bouncing') and ent.bouncing:
                        # Hit by a shell
                        self.alive = False
                        if self.sound:
                            self.sound.play_sfx(self.sound.brick_bump)
