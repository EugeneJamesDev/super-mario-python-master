"""A small SMB-style springboard platform for endless and authored courses."""

import pygame

from entities.EntityBase import EntityBase


class Springboard(EntityBase):
    """Compress beneath Mario and launch him with a tall, controlled bounce.

    ``ground_row`` is the first solid tile row under the springboard. The art
    is bottom-aligned to that row while collision is restricted to its top
    plate, so the spring coil itself never behaves like a wall.
    """

    COMPRESS_FRAMES = 10
    LAUNCH_VELOCITY = -13.0
    SPRITE_KEYS = {
        "up": ("springboard_up", "springboard"),
        "compressed": ("springboard_compressed", "springboard"),
    }

    def __init__(self, screen, sprite_collection, x, ground_row, level, sound=None):
        super().__init__(x, ground_row, gravity=0)
        self.screen = screen
        self.sprite_collection = sprite_collection
        self.level = level
        self.sound = sound
        self.type = "Platform"
        self.state = "up"
        self.compress_timer = 0
        self.ground_y = ground_row * 32
        self.sprite = self._get_sprite("up")
        self._art_rect = self.sprite.get_rect()
        self._art_rect.midbottom = (x * 32 + 16, self.ground_y)
        # Only the narrow top plate is solid; the long spring body is artwork.
        self.rect = pygame.Rect(self._art_rect.left, self._art_rect.top, 32, 12)
        self.velocity = pygame.Vector2(0, 0)
        self._previous_mario_bottom = None

    def _get_sprite(self, state):
        for key in self.SPRITE_KEYS[state]:
            sprite = self.sprite_collection.get(key)
            if sprite is not None and sprite.image is not None:
                return sprite.image
        return pygame.Surface((32, 62), pygame.SRCALPHA)

    def carry_offset(self):
        return self.velocity

    def update(self, camera):
        mario = self.level.player
        if mario is not None:
            self._check_landing(mario)

        if self.state == "compressed":
            self.compress_timer -= 1
            if self.compress_timer <= 0:
                if mario is not None and self._mario_still_on_plate(mario):
                    self._launch(mario)
                else:
                    self.state = "up"
                    self.compress_timer = 0

        key_state = "compressed" if self.state == "compressed" else "up"
        self.sprite = self._get_sprite(key_state)
        self._art_rect = self.sprite.get_rect()
        self._art_rect.midbottom = (self.rect.centerx, self.ground_y)
        self.screen.blit(self.sprite, (self._art_rect.x + camera.x, self._art_rect.y))

    def _check_landing(self, mario):
        current_bottom = mario.rect.bottom
        previous_bottom = self._previous_mario_bottom
        crossed_plate = (
            previous_bottom is not None
            and previous_bottom <= self.rect.top
            and current_bottom >= self.rect.top
            and mario.vel.y >= 0
            and mario.onGround
            and mario.rect.right > self.rect.left
            and mario.rect.left < self.rect.right
        )
        if crossed_plate and self.state == "up":
            self.state = "compressed"
            self.compress_timer = self.COMPRESS_FRAMES
        self._previous_mario_bottom = current_bottom

    def _mario_still_on_plate(self, mario):
        return (
            mario.onGround
            and abs(mario.rect.bottom - self.rect.top) <= 2
            and mario.rect.right > self.rect.left
            and mario.rect.left < self.rect.right
        )

    def _launch(self, mario):
        mario.rect.bottom = self.rect.top
        mario.vel.y = self.LAUNCH_VELOCITY
        mario.onGround = False
        mario.inAir = True
        mario.inJump = True
        jump_trait = getattr(mario, "traits", {}).get("jumpTrait")
        if jump_trait is not None:
            jump_trait.jump_active = False
            jump_trait.jump_button = False
            jump_trait.hold_frames = jump_trait.MAX_HOLD_FRAMES
        self.state = "up"
        self.compress_timer = 0
