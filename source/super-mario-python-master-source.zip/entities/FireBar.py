import math
import random
import pygame
from pygame.math import Vector2

from entities.EntityBase import EntityBase


class FireBar(EntityBase):
    """Rotating chain of fireballs that behaves as a hazard."""

    def __init__(self, screen, x, y, segments=4, angular_speed=0.04, spriteCollection=None, rng=None):
        super(FireBar, self).__init__(x, y, gravity=0)
        self.screen = screen
        self.type = "Hazard"
        self.spriteCollection = spriteCollection
        self.randomizer = rng or random.Random()
        self.segment_image = self._load_segment_image(spriteCollection)
        self.center_image = self._load_center_image(spriteCollection)
        self.segment_spacing = self.segment_image.get_width()
        self.center = Vector2(x * 32 + 16, y * 32 + 16)
        extent = self.segment_spacing * (segments + 1)
        self.rect = pygame.Rect(
            self.center.x - extent,
            self.center.y - extent,
            extent * 2,
            extent * 2,
        )
        self.segments = max(2, segments)
        # NES: Short bars 4° per frame, Long bars 8° per frame
        # Convert degrees to radians: 4° = 4 * π/180 ≈ 0.07, 8° ≈ 0.14
        if angular_speed == 0.04:  # Default, use segment count to determine
            if segments <= 4:
                self.angular_speed = math.radians(4)  # Short bar: 4°/frame
            else:
                self.angular_speed = math.radians(8)  # Long bar: 8°/frame
        else:
            self.angular_speed = angular_speed
        self.angle = self.randomizer.random() * math.pi * 2
        self.hitboxes = []
        # Fire burst effects - limit to prevent performance issues
        self.burst_timer = 0
        self.burst_interval = 60  # Spawn burst effect every 60 frames (reduced frequency)
        self.burst_effects = []
        self.max_burst_effects = 3  # Maximum concurrent burst effects
        self.levelObj = None  # Will be set by Level.addFireBar()

    @classmethod
    def _load_segment_image(cls, spriteCollection):
        if spriteCollection:
            sprite = spriteCollection.get("firebar_segment")
            if sprite and sprite.image:
                return sprite.image
        return pygame.Surface((32, 32), pygame.SRCALPHA)

    @classmethod
    def _load_center_image(cls, spriteCollection):
        if spriteCollection:
            sprite = spriteCollection.get("firebar_center")
            if sprite and sprite.image:
                return sprite.image
        return pygame.Surface((32, 32), pygame.SRCALPHA)

    def update(self, camera):
        self._advance_rotation()
        self._draw_segments(camera)
        self._update_burst_effects(camera)

    def _advance_rotation(self):
        self.angle += self.angular_speed
        two_pi = math.pi * 2
        if self.angle > two_pi:
            self.angle -= two_pi
        self.hitboxes = []
        for index in range(1, self.segments + 1):
            distance = index * self.segment_spacing
            offset = Vector2(distance, 0).rotate_rad(self.angle)
            rect = self.segment_image.get_rect()
            rect.center = (self.center.x + offset.x, self.center.y + offset.y)
            self.hitboxes.append(rect)

    def _draw_segments(self, camera):
        for rect in self.hitboxes:
            self.screen.blit(
                self.segment_image,
                (rect.x + camera.x, rect.y),
            )
        center_rect = self.center_image.get_rect()
        center_rect.center = (self.center.x, self.center.y)
        self.screen.blit(
            self.center_image,
            (center_rect.x + camera.x, center_rect.y),
        )

    def _update_burst_effects(self, camera):
        """Update and draw fire burst effects."""
        if not self.spriteCollection:
            return

        # Clean up expired bursts first
        self.burst_effects = [b for b in self.burst_effects if b.alive is not None]

        # Spawn new burst effects periodically, but limit total count
        self.burst_timer += 1
        if self.burst_timer >= self.burst_interval and len(self.burst_effects) < self.max_burst_effects:
            self.burst_timer = 0
            # Spawn burst at a random segment position
            if self.hitboxes:
                random_segment = self.randomizer.choice(self.hitboxes)
                burst = self._create_burst_effect(
                    random_segment.centerx,
                    random_segment.centery
                )
                if burst:
                    self.burst_effects.append(burst)
                    # Add to level's entity list if available
                    if self.levelObj and hasattr(self.levelObj, 'entityList'):
                        self.levelObj.entityList.append(burst)

        # Note: Bursts are now managed by level's entityList, so we don't update them here

    def _create_burst_effect(self, x, y):
        """Create a fire burst effect at the given position."""
        if not self.spriteCollection:
            return None

        from entities.FireBurst import FireBurst
        return FireBurst(self.screen, self.spriteCollection, x, y, "down", lifetime=20)

    def collides_with(self, other_rect):
        return any(rect.colliderect(other_rect) for rect in self.hitboxes)
