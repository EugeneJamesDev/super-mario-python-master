from classes.Animation import Animation
from classes.Collider import Collider
from entities.EntityBase import EntityBase


class SuperStar(EntityBase):
    def __init__(self, screen, spriteColl, x, y, level):
        super(SuperStar, self).__init__(x, y, 0.5)
        self.spriteCollection = spriteColl
        star = self.spriteCollection.get("super_star")
        if star and star.image:
            self.animation = Animation([star.image])
        else:
            self.animation = None
        self.screen = screen
        self.type = "Item"
        self.item_name = "star"
        self.collision = Collider(self, level)
        self.vel.y = -3

    def update(self, camera):
        if not self.alive:
            return
        self.applyGravity()
        self.rect.y += self.vel.y
        self.collision.checkY()
        if self.onGround:
            self.vel.y = -3
        if self.animation and self.alive:
            self.screen.blit(self.animation.image, (self.rect.x + camera.x, self.rect.y))
