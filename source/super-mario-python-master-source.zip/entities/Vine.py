"""Climbable, growing beanstalk used by SMB1 vine blocks in Infinity mode."""

from __future__ import annotations

import pygame

from entities.EntityBase import EntityBase


class Vine(EntityBase):
    GROW_EVERY_FRAMES = 5
    CLIMB_SPEED = 2.0  # 1 NES pixel per frame at the game's 2x render scale.

    def __init__(self, screen, x, block_y, sprite_collection, max_segments=7):
        super().__init__(x, block_y, 0)
        self.type = "ClimbableVine"
        self.obeyGravity = False
        self.screen = screen
        self.spriteCollection = sprite_collection
        self.block_x = int(x)
        self.block_y = int(block_y)
        self.max_segments = max(1, int(max_segments))
        self.grown_segments = 0
        self._growth_timer = 0
        self.segment_sprite = sprite_collection.get("smb1_vine_segment")
        self.tip_sprite = sprite_collection.get("smb1_vine_tip")
        self._sync_rect()

    @property
    def grown(self):
        return self.grown_segments > 0

    @property
    def top_y(self):
        return self.block_y * 32 - self.grown_segments * 32

    @property
    def base_y(self):
        return self.block_y * 32

    def _sync_rect(self):
        height = max(1, self.grown_segments * 32)
        self.rect = pygame.Rect(self.block_x * 32, self.base_y - height, 32, height)

    def update(self, camera):
        if self.grown_segments < self.max_segments:
            self._growth_timer += 1
            if self._growth_timer >= self.GROW_EVERY_FRAMES:
                self._growth_timer = 0
                self.grown_segments += 1
                self._sync_rect()
        self._draw(camera)

    def _draw(self, camera):
        if self.grown_segments <= 0:
            return
        x = self.block_x * 32 + camera.x
        segment = self.segment_sprite.image if self.segment_sprite else None
        tip = self.tip_sprite.image if self.tip_sprite else None
        if segment is None and tip is None:
            return

        # The vine is made of repeated native 16px source segments. Manifests
        # render those at 2x, so one segment aligns with the game's 32px tiles.
        segment_h = segment.get_height() if segment is not None else 32
        segment_h = max(1, segment_h)
        y = self.base_y - segment_h
        while y > self.top_y:
            if segment is not None:
                self.screen_blit(camera, segment, x, y)
            y -= segment_h
        if tip is not None:
            self.screen_blit(camera, tip, x, self.top_y - tip.get_height() + segment_h)

    def screen_blit(self, camera, image, x, y):
        # EntityBase deliberately has no display ownership; the actual screen
        # is attached by Level.addVine so the class stays easy to headless-test.
        if self.screen is not None:
            self.screen.blit(image, (x, y))
