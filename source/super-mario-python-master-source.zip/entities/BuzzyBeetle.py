from classes.SurfaceCache import flip_surface

from classes.Animation import Animation
from classes.Collider import Collider
from classes.EntityCollider import EntityCollider
from entities.EntityBase import EntityBase
from traits.leftrightwalk import LeftRightWalkTrait


class BuzzyBeetle(EntityBase):
    def __init__(self, screen, spriteColl, x, y, level, sound):
        super(BuzzyBeetle, self).__init__(x, y, 1.25)
        self.spriteCollection = spriteColl
        self.animation = Animation(
            [
                self.spriteCollection.get("buzzy_beetle-1").image,
                self.spriteCollection.get("buzzy_beetle-2").image,
            ]
        )
        if self.animation.image:
            sprite_height = self.animation.image.get_height()
            self.rect.height = sprite_height
            self.rect.y = self.rect.y - (sprite_height - 32)
        self.screen = screen
        self.leftrightTrait = LeftRightWalkTrait(self, level)
        self.timer = 0
        self.timeAfterDeath = 35
        self.type = "Mob"
        self.dashboard = level.dashboard
        self.collision = Collider(self, level)
        self.EntityCollider = EntityCollider(self)
        self.levelObj = level
        self.sound = sound
        self.fireResistant = True

    def update(self, camera):
        if self.alive and self.active:
            self.updateAlive(camera)
            self.checkEntityCollision()
        elif self.alive and not self.active and not self.bouncing:
            self.sleepingInShell(camera)
            self.checkEntityCollision()
        elif self.bouncing:
            self.shellBouncing(camera)
            self.checkEntityCollision()

    def drawBuzzyBeetle(self, camera):
        if self.leftrightTrait.direction == -1:
            self.screen.blit(
                self.animation.image, (self.rect.x + camera.x, self.rect.y)
            )
        else:
            self.screen.blit(
                flip_surface(self.animation.image, True, False),
                (self.rect.x + camera.x, self.rect.y),
            )

    def shellBouncing(self, camera):
        BLOCK_SIZE = 32
        self.leftrightTrait.speed = 0.1875 * BLOCK_SIZE
        self.applyGravity()
        shell_sprite = self.spriteCollection.get("buzzy_shell")
        if shell_sprite and shell_sprite.image:
            shell_height = shell_sprite.image.get_height()
            old_bottom = self.rect.bottom
            self.rect.height = shell_height
            self.rect.bottom = old_bottom
            self.animation.image = shell_sprite.image
        self.drawBuzzyBeetle(camera)
        self.leftrightTrait.update()

    def sleepingInShell(self, camera):
        if self.timer < self.timeAfterDeath:
            shell_sprite = self.spriteCollection.get("buzzy_shell")
            if shell_sprite and shell_sprite.image:
                shell_height = shell_sprite.image.get_height()
                old_bottom = self.rect.bottom
                self.rect.height = shell_height
                self.rect.bottom = old_bottom
                self.screen.blit(
                    shell_sprite.image,
                    (self.rect.x + camera.x, self.rect.y),
                )
        else:
            self.alive = True
            self.active = True
            self.bouncing = False
            self.timer = 0
            if self.animation.image:
                sprite_height = self.animation.image.get_height()
                old_bottom = self.rect.bottom
                self.rect.height = sprite_height
                self.rect.bottom = old_bottom
        self.timer += 0.1

    def updateAlive(self, camera):
        self.applyGravity()
        self.drawBuzzyBeetle(camera)
        self.animation.update()
        self.leftrightTrait.update()

    def checkEntityCollision(self):
        for ent in self.levelObj.entityList:
            if ent is not self:
                collisionState = self.EntityCollider.check(ent)
                if collisionState.isColliding:
                    if ent.type == "Mob":
                        self._onCollisionWithMob(ent, collisionState)

    def _onCollisionWithMob(self, mob, collisionState):
        if collisionState.isColliding and self.bouncing:
            mob.alive = False
            self.sound.play_sfx(self.sound.brick_bump)
        elif collisionState.isColliding and mob.bouncing:
            self.alive = False
            self.sound.play_sfx(self.sound.brick_bump)
