import pygame
from pygame.math import Vector2

from entities.EntityBase import EntityBase


class MovingPlatform(EntityBase):
    """Simple oscillating platforms used by the endless generator."""

    SPRITE_KEYS = {
        "large": "moving_platform_large",
        "medium": "moving_platform_medium",
        "small": "moving_platform_small",
        "mushroom": "smb1_mushroom_platform",
    }

    def __init__(
        self,
        screen,
        x,
        y,
        size="large",
        axis="horizontal",
        travel_tiles=3,
        speed=1.25,
        spriteCollection=None,
    ):
        super(MovingPlatform, self).__init__(x, y, gravity=0)
        self.screen = screen
        self.axis = axis
        self.size = str(size).lower()
        self.travel_distance = max(32, travel_tiles * 32)
        self.speed = max(0.5, speed)
        self.type = "Platform"
        self.sprite = self._load_sprite(size, spriteCollection)
        # Mushroom artwork includes a 32px stem below the cap. Keep collision
        # on the cap's top 16px so Mario lands on the visible platform surface.
        platform_height = 16 if self.size == "mushroom" else self.sprite.get_height()
        self.rect = pygame.Rect(
            x * 32,
            y * 32,
            self.sprite.get_width(),
            platform_height,
        )
        self.origin = Vector2(self.rect.topleft)
        self._path_position = 0.0
        self._direction = 1.0
        self.velocity = Vector2(0, 0)

    @classmethod
    def _load_sprite(cls, size, spriteCollection):
        key = size.lower()
        sprite_name = cls.SPRITE_KEYS.get(key, cls.SPRITE_KEYS["large"])
        if spriteCollection:
            sprite = spriteCollection.get(sprite_name)
            if sprite and sprite.image:
                return sprite.image
        width = {"large": 96, "medium": 64, "small": 48}.get(key, 96)
        surface = pygame.Surface((width, 16), pygame.SRCALPHA)
        surface.fill((180, 60, 60, 255))
        return surface

    def update(self, camera):
        self._advance_motion()
        self.screen.blit(
            self.sprite,
            (self.rect.x + camera.x, self.rect.y),
        )

    def _advance_motion(self):
        previous = Vector2(self.rect.topleft)
        step = self.speed * self._direction
        self._path_position += step
        if self._path_position >= self.travel_distance:
            self._path_position = self.travel_distance
            self._direction = -1.0
        elif self._path_position <= 0:
            self._path_position = 0.0
            self._direction = 1.0
        target = self.origin.copy()
        if self.axis == "horizontal":
            target.x = self.origin.x + self._path_position
            target.y = self.origin.y
        else:
            target.y = self.origin.y + self._path_position
            target.x = self.origin.x
        self.rect.topleft = (round(target.x), round(target.y))
        self.velocity = Vector2(self.rect.topleft) - previous

    def carry_offset(self):
        """Return the per-frame displacement to apply to riders."""
        return self.velocity
