from classes.Animation import Animation
from classes.Collider import Collider
from classes.EntityCollider import EntityCollider
from classes.Maths import Vec2D
from entities.EntityBase import EntityBase


class Spiny(EntityBase):
    def __init__(self, screen, spriteColl, x, y, level, sound=None, isEgg=False):
        super(Spiny, self).__init__(x, y, 0.5)
        self.spriteCollection = spriteColl
        if isEgg:
            self.animation = Animation(
                [self.spriteCollection.get("spiny_egg").image]
            )
        else:
            self.animation = Animation(
                [self.spriteCollection.get("spiny").image]
            )
        if self.animation.image:
            sprite_height = self.animation.image.get_height()
            self.rect.height = sprite_height
            self.rect.y = self.rect.y - (sprite_height - 32)
        self.screen = screen
        self.type = "Mob"
        self.dashboard = level.dashboard
        self.collision = Collider(self, level)
        self.EntityCollider = EntityCollider(self)
        self.levelObj = level
        self.sound = sound
        self.isEgg = isEgg
        self.cannotStomp = True
        self.landed = False
        self.landedTimer = 0

    def update(self, camera):
        if self.alive:
            if self.isEgg and not self.landed:
                self.updateEgg(camera)
            else:
                self.updateSpiny(camera)
            self.checkEntityCollision()
        else:
            self.onDead(camera)

    def updateEgg(self, camera):
        self.applyGravity()
        self.drawSpiny(camera)
        if self.onGround:
            self.landed = True
            self.isEgg = False
            self.animation = Animation(
                [self.spriteCollection.get("spiny").image]
            )

    def updateSpiny(self, camera):
        self.applyGravity()
        self.drawSpiny(camera)
        if self.onGround:
            self.vel.x = 1.5

    def drawSpiny(self, camera):
        draw_x = self.rect.x + camera.x
        if draw_x < -100 or draw_x > 800:
            return
        self.screen.blit(
            self.animation.image,
            (self.rect.x + camera.x, self.rect.y),
        )
        self.animation.update()

    def onDead(self, camera):
        if self.timer == 0:
            self.setPointsTextStartPosition(self.rect.x + 3, self.rect.y)
        if self.timer < self.timeAfterDeath:
            self.movePointsTextUpAndDraw(camera)
        else:
            self.alive = None
        self.timer += 0.1

    def setPointsTextStartPosition(self, x, y):
        self.textPos = Vec2D(x, y)

    def movePointsTextUpAndDraw(self, camera):
        self.textPos.y += -0.5
        self.dashboard.drawText("100", self.textPos.x + camera.x, self.textPos.y, 8)

    def checkEntityCollision(self):
        for ent in self.levelObj.entityList:
            if ent is not self and hasattr(ent, 'type'):
                collisionState = self.EntityCollider.check(ent)
                if collisionState.isColliding:
                    if ent.type == "Mob" and hasattr(ent, 'bouncing') and ent.bouncing:
                        self.alive = False
                        self.sound.play_sfx(self.sound.brick_bump)
