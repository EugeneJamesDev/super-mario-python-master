from entities.EntityBase import EntityBase
from entities.Item import Item


class CoinBrick(EntityBase):
    def __init__(self, screen, spriteCollection, x, y, sound, dashboard, gravity=0, level=None):
        super(CoinBrick, self).__init__(x, y, gravity)
        self.screen = screen
        self.spriteCollection = spriteCollection
        self.level = level
        bricks_sprite = None
        if level and hasattr(level, "get_theme_sprite"):
            bricks_sprite = level.get_theme_sprite("bricks")
        if bricks_sprite is None:
            bricks_sprite = spriteCollection.get("bricks")
        self.image = bricks_sprite.image if bricks_sprite else None
        self.type = "Block"
        self.triggered = False
        self.sound = sound
        self.dashboard = dashboard
        self.item = Item(spriteCollection, screen, self.rect.x, self.rect.y)

    def bump(self, _mario):
        if not self.triggered:
            self.triggered = True
            self.dashboard.coins += 1
            self.sound.play_sfx(self.sound.bump)

    def update(self, cam):
        if not self.alive or self.triggered:
            empty_sprite = None
            if self.level and hasattr(self.level, "get_theme_sprite"):
                empty_sprite = self.level.get_theme_sprite("empty")
            if empty_sprite is None:
                empty_sprite = self.spriteCollection.get("empty")
            if empty_sprite and empty_sprite.image:
                self.image = empty_sprite.image
            if self.item:
                self.item.spawnCoin(cam, self.sound, self.dashboard)
        # Sky is already drawn as background, so just draw the brick sprite
        if self.image is not None:
            try:
                self.screen.blit(self.image, (self.rect.x + cam.x, self.rect.y - 1))
            except (AttributeError, TypeError):
                pass
