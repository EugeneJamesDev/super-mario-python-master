from classes.Animation import Animation
from entities.EntityBase import EntityBase


class FireFlowerCollectible(EntityBase):
    def __init__(self, screen, spriteColl, x, y):
        super(FireFlowerCollectible, self).__init__(x, y, 0)
        self.spriteCollection = spriteColl
        flower = self.spriteCollection.get("fire_flower_item")
        if flower and flower.image:
            self.animation = Animation([flower.image])
        else:
            self.animation = None
        self.screen = screen
        self.type = "Item"
        self.item_name = "fire_flower"
        self.alive = True

    def update(self, camera):
        if self.alive and self.animation and self.animation.image:
            self.screen.blit(
                self.animation.image,
                (self.rect.x + camera.x, self.rect.y),
            )
