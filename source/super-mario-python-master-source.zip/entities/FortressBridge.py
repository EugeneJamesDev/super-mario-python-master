"""Optional SMB1-style bridge and axe set piece for Infinity's fortress biome."""

import pygame

from entities.EntityBase import EntityBase


class FortressBridge(EntityBase):
    """A solid tile bridge that collapses behind Mario when he touches its axe.

    This is a reusable endless-mode obstacle, not a course-ending trigger.
    The single wide platform hitbox keeps the bridge surface continuous while
    the original 16x16 bridge tile is repeated at native 2x scale for drawing.
    """

    COLLAPSE_FRAMES = 40
    FALL_DELAY_PER_TILE = 2
    FALL_SPEED = 2.0

    def __init__(self, screen, sprite_collection, x, y, length, level):
        super().__init__(x, y, gravity=0)
        self.screen = screen
        self.sprite_collection = sprite_collection
        self.level = level
        self.type = "Platform"
        self.length = max(3, int(length))
        self.bridge_sprite = self._image("bridge_tile", (32, 32))
        self.axe_sprite = self._image("axe", (32, 32))
        self.axe_frames = [
            sprite.image
            for index in range(1, 6)
            if (sprite := sprite_collection.get(f"axe-{index}")) and sprite.image
        ]
        if len(self.axe_frames) != 5:
            self.axe_frames = [self.axe_sprite]
            self.axe_frame_durations = (1,)
        else:
            # SMB Axe.gif timings at 60 Hz: 150 ms for the first four poses,
            # then 300 ms for its final pose before the cycle repeats.
            self.axe_frame_durations = (9, 9, 9, 9, 18)
        self.axe_frame_index = 0
        self.axe_frame_timer = 0
        self.rect = pygame.Rect(x * 32, y * 32, self.length * 32, 32)
        self.velocity = pygame.Vector2(0, 0)
        self.axe_rect = pygame.Rect(
            self.rect.right - 32,
            self.rect.top - self.axe_sprite.get_height(),
            self.axe_sprite.get_width(),
            self.axe_sprite.get_height(),
        )
        self.axe_triggered = False
        self.collapse_timer = 0
        self.segment_fall = [0.0] * self.length

    def _image(self, key, fallback_size):
        sprite = self.sprite_collection.get(key)
        if sprite is not None and sprite.image is not None:
            return sprite.image
        return pygame.Surface(fallback_size, pygame.SRCALPHA)

    def carry_offset(self):
        return self.velocity

    def update(self, camera):
        mario = self.level.player

        if not self.axe_triggered:
            if mario is not None and self.axe_rect.colliderect(mario.rect):
                self._trigger_axe()
            else:
                self._draw_intact(camera)
                return

        self._draw_collapsing(camera)

    def _trigger_axe(self):
        """Start a one-way collapse; the bridge stops supporting Mario now."""
        self.axe_triggered = True
        self.collapse_timer = 0
        self.alive = False

    def _draw_intact(self, camera):
        for index in range(self.length):
            self.screen.blit(
                self.bridge_sprite,
                (self.rect.x + index * 32 + camera.x, self.rect.y),
            )
        self.screen.blit(
            self.axe_frames[self.axe_frame_index],
            (self.axe_rect.x + camera.x, self.axe_rect.y),
        )
        self.axe_frame_timer += 1
        if self.axe_frame_timer >= self.axe_frame_durations[self.axe_frame_index]:
            self.axe_frame_timer = 0
            self.axe_frame_index = (self.axe_frame_index + 1) % len(self.axe_frames)

    def _draw_collapsing(self, camera):
        self.collapse_timer += 1
        for index in range(self.length):
            # Collapse travels from the axe end back across the span.
            delay = (self.length - 1 - index) * self.FALL_DELAY_PER_TILE
            elapsed = max(0, self.collapse_timer - delay)
            self.segment_fall[index] += min(self.FALL_SPEED, elapsed * 0.08)
            self.screen.blit(
                self.bridge_sprite,
                (
                    self.rect.x + index * 32 + camera.x,
                    self.rect.y + round(self.segment_fall[index]),
                ),
            )
        if self.collapse_timer >= self.COLLAPSE_FRAMES:
            self.alive = None

