from classes.Animation import Animation
from entities.BulletBill import BulletBill
from entities.EntityBase import EntityBase


class BillBlaster(EntityBase):
    def __init__(self, screen, spriteColl, x, y, level, sound=None):
        super(BillBlaster, self).__init__(x, y, 0)
        self.spriteCollection = spriteColl
        self.animation = Animation(
            [
                self.spriteCollection.get("bill_blaster").image,
            ]
        )
        if self.animation.image:
            sprite_height = self.animation.image.get_height()
            self.rect.height = sprite_height
            self.rect.y = self.rect.y - (sprite_height - 32)
        self.screen = screen
        self.type = "Hazard"
        self.levelObj = level
        self.sound = sound
        self.obeyGravity = False
        self.activeRange = 256
        self.spawnTimer = 0
        self.spawnInterval = 120

    def update(self, camera):
        if not self.alive:
            return
        mario = self._findMario()
        if mario:
            dist = abs(mario.rect.x - self.rect.x)
            if dist < self.activeRange:
                self.spawnTimer -= 1
                if self.spawnTimer <= 0:
                    self._spawnBulletBill()
                    self.spawnTimer = self.spawnInterval
        self.drawBillBlaster(camera)

    def drawBillBlaster(self, camera):
        self.screen.blit(
            self.animation.image,
            (self.rect.x + camera.x, self.rect.y),
        )
        self.animation.update()

    def _findMario(self):
        return self.levelObj.player

    def _spawnBulletBill(self):
        bullet = BulletBill(
            self.screen,
            self.spriteCollection,
            self.rect.x // 32,
            self.rect.y // 32,
            -1,
            self.levelObj,
        )
        self.levelObj.entityList.append(bullet)
