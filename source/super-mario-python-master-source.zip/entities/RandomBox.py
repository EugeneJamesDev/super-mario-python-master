from copy import copy

from classes.Animation import Animation
from entities.EntityBase import EntityBase


class RandomBox(EntityBase):
    def __init__(self, screen, spriteCollection, x, y, item, sound, dashboard, level, gravity=0):
        super(RandomBox, self).__init__(x, y, gravity)
        self.screen = screen
        self.spriteCollection = spriteCollection
        question_name = "CoinBox"
        if level and hasattr(level, "get_theme_sprite_name"):
            question_name = level.get_theme_sprite_name("question")
        question_sprite = spriteCollection.get(question_name)
        if question_sprite and question_sprite.animation:
            self.animation = copy(question_sprite.animation)
        else:
            self.animation = copy(spriteCollection.get("CoinBox").animation)
        if item == "Vine":
            vine_block = spriteCollection.get("smb1_vine_block")
            if vine_block and vine_block.image:
                self.animation = Animation([vine_block.image], idleSprite=vine_block.image)
        self.type = "Block"
        self.triggered = False
        self.time = 0
        # NES: Question block bump = 0.5 blocks total over 8 frames
        # Per frame: 0.5 blocks / 8 frames = 0.0625 blocks/frame → 2 px/frame
        BLOCK_SIZE = 32  # pixels per block
        self.maxTime = 8  # Frame count unchanged
        self.sound = sound
        self.dashboard = dashboard
        self.vel = (0.5 / 8) * BLOCK_SIZE  # 0.0625 blocks/frame → 2 px/frame bump
        self.item = item
        self.level = level
        self.grid_position = (int(x), int(y))

    def bump(self, _mario):
        if self.triggered:
            return
        self.triggered = True
        self.sound.play_sfx(self.sound.bump)

    def update(self, cam):
        if self.alive and not self.triggered:
            if self.animation:
                self.animation.update()
        else:
            empty_sprite = None
            if self.level and hasattr(self.level, "get_theme_sprite"):
                empty_sprite = self.level.get_theme_sprite("empty")
            if empty_sprite is None:
                empty_sprite = self.spriteCollection.get("empty")
            if empty_sprite and empty_sprite.image and self.animation:
                self.animation.image = empty_sprite.image
            if self.item:
                self._spawn_item()
            if self.time < self.maxTime:
                self.time += 1
                self.rect.y -= self.vel
            else:
                if self.time < self.maxTime * 2:
                    self.time += 1
                    self.rect.y += self.vel
        # Sky is already drawn as background, so just draw the box sprite
        if self.animation and self.animation.image is not None:
            try:
                self.screen.blit(self.animation.image, (self.rect.x + cam.x, self.rect.y - 1))
            except (AttributeError, TypeError):
                pass

    def _spawn_item(self):
        block_x, block_y = self.grid_position
        spawn_row = max(0, block_y - 1)
        if self.item == "Vine":
            self.level.addVine(block_x, block_y)
            self.sound.play_sfx(self.sound.powerup_appear)
        elif self.item == 'RedMushroom':
            self.level.addRedMushroom(block_x, spawn_row)
            self.sound.play_sfx(self.sound.powerup_appear)
        elif self.item == 'GreenMushroom':
            self.level.addOneUpMushroom(block_x, spawn_row)
            self.sound.play_sfx(self.sound.powerup_appear)
        elif self.item in {'BlueMushroom', 'DarkMushroom'}:
            # Older level data can still contain variant names; render the
            # original SMB power-up instead of introducing non-game variants.
            self.level.addRedMushroom(block_x, spawn_row)
            self.sound.play_sfx(self.sound.powerup_appear)
        elif self.item == 'Star':
            self.level.addSuperStar(block_x, spawn_row)
            self.sound.play_sfx(self.sound.powerup_appear)
        elif self.item in {'FireFlower', 'Flower'}:
            self.level.addFireFlowerItem(block_x, spawn_row)
            self.sound.play_sfx(self.sound.powerup_appear)
        elif self.item in {'NormalFlower', 'BlueFlower', 'RedFlower', 'WhiteFlower'}:
            # Preserve compatibility with old level files while keeping the
            # canonical SMB fire flower art and behavior.
            self.level.addFireFlowerItem(block_x, spawn_row)
            self.sound.play_sfx(self.sound.powerup_appear)
        self.item = None
