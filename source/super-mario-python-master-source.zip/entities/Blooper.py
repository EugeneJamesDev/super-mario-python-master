import math


from classes.SurfaceCache import flip_surface

from classes.Animation import Animation
from classes.Collider import Collider
from classes.EntityCollider import EntityCollider
from classes.Maths import Vec2D
from entities.EntityBase import EntityBase


class Blooper(EntityBase):
    def __init__(self, screen, spriteColl, x, y, level, sound=None):
        super(Blooper, self).__init__(x, y, 0.3)
        self.spriteCollection = spriteColl
        frames = [
            sprite.image
            for key in ("blooper-1", "blooper-2")
            if (sprite := self.spriteCollection.get(key)) and sprite.image
        ]
        if not frames:
            fallback = self.spriteCollection.get("blooper")
            if fallback and fallback.image:
                frames = [fallback.image]
        self.animation = Animation(
            frames,
            deltaTime=8,
        )
        if self.animation.image:
            sprite_height = self.animation.image.get_height()
            self.rect.height = sprite_height
            self.rect.y = self.rect.y - (sprite_height - 32)
        self.screen = screen
        self.type = "Mob"
        self.dashboard = level.dashboard
        self.collision = Collider(self, level)
        self.EntityCollider = EntityCollider(self)
        self.levelObj = level
        self.sound = sound
        self.baseY = self.rect.y
        self.pulsePhase = 0
        self.vel.x = -1.5

    def update(self, camera):
        if self.alive:
            self.updateBlooper(camera)
            self.checkEntityCollision()
        else:
            self.onDead(camera)

    def updateBlooper(self, camera):
        mario = self._findMario()
        self.pulsePhase += 0.04
        self.rect.y = self.baseY + math.sin(self.pulsePhase) * 15
        self.rect.x += self.vel.x
        if mario:
            target_y = mario.rect.y
            diff = target_y - self.rect.y
            self.baseY += diff * 0.01
        self.drawBlooper(camera)
        self.animation.update()

    def drawBlooper(self, camera):
        draw_x = self.rect.x + camera.x
        if draw_x < -100 or draw_x > 800:
            return
        if self.vel.x < 0:
            self.screen.blit(
                self.animation.image,
                (self.rect.x + camera.x, self.rect.y),
            )
        else:
            self.screen.blit(
                flip_surface(self.animation.image, True, False),
                (self.rect.x + camera.x, self.rect.y),
            )

    def _findMario(self):
        return self.levelObj.player

    def onDead(self, camera):
        if self.timer == 0:
            self.setPointsTextStartPosition(self.rect.x + 3, self.rect.y)
        if self.timer < self.timeAfterDeath:
            self.movePointsTextUpAndDraw(camera)
        else:
            self.alive = None
        self.timer += 0.1

    def setPointsTextStartPosition(self, x, y):
        self.textPos = Vec2D(x, y)

    def movePointsTextUpAndDraw(self, camera):
        self.textPos.y += -0.5
        self.dashboard.drawText("100", self.textPos.x + camera.x, self.textPos.y, 8)

    def checkEntityCollision(self):
        for ent in self.levelObj.entityList:
            if ent is not self and hasattr(ent, 'type'):
                collisionState = self.EntityCollider.check(ent)
                if collisionState.isColliding:
                    if ent.type == "Mob" and hasattr(ent, 'bouncing') and ent.bouncing:
                        self.alive = False
                        self.sound.play_sfx(self.sound.brick_bump)
