from classes.Animation import Animation
from entities.EntityBase import EntityBase


class Princess(EntityBase):
    """Princess character entity - can be used as NPC or decoration."""
    
    def __init__(self, screen, spriteCollection, x, y, level=None, as_npc=False):
        # x, y are grid coordinates
        super(Princess, self).__init__(x, y, 0)  # No gravity for now
        self.screen = screen
        self.spriteCollection = spriteCollection
        self.as_npc = as_npc
        self.type = "NPC" if as_npc else "Decoration"
        
        # Get princess sprite
        princess_sprite = self.spriteCollection.get("princess")
        if princess_sprite and princess_sprite.image:
            self.animation = Animation([princess_sprite.image])
        else:
            self.animation = None
        
        # Princess is 2 blocks tall (16x32 pixels = 32x64 when scaled)
        if self.animation and self.animation.image:
            self.rect.height = self.animation.image.get_height()
            self.rect.width = self.animation.image.get_width()
        else:
            self.rect.height = 64  # 2 blocks
            self.rect.width = 32   # 1 block
        
        self.level = level
        self.alive = True
    
    def update(self, camera):
        if not self.alive or self.alive is None:
            return
        
        if self.animation and self.animation.image:
            self.screen.blit(
                self.animation.image,
                (self.rect.x + camera.x, self.rect.y)
            )
            self.animation.update()

