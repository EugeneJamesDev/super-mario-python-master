from classes.SurfaceCache import flip_surface

from classes.Animation import Animation
from classes.Collider import Collider
from classes.EntityCollider import EntityCollider
from entities.EntityBase import EntityBase


class BulletBill(EntityBase):
    def __init__(self, screen, spriteColl, x, y, direction, level):
        super(BulletBill, self).__init__(x, y, 0)
        self.spriteCollection = spriteColl
        self.animation = Animation(
            [
                self.spriteCollection.get("bullet_bill").image,
            ]
        )
        if self.animation.image:
            sprite_height = self.animation.image.get_height()
            self.rect.height = sprite_height
            self.rect.y = self.rect.y - (sprite_height - 32)
        self.screen = screen
        self.direction = direction
        self.speed = 3.0
        self.type = "Hazard"
        self.levelObj = level
        self.obeyGravity = False
        self.collision = Collider(self, level)
        self.EntityCollider = EntityCollider(self)
        self.sound = None

    def update(self, camera):
        if self.alive is None or self.alive is False:
            return
        self.rect.x += self.speed * self.direction
        draw_x = self.rect.x + camera.x
        if draw_x < -200 or draw_x > 1000:
            self.alive = None
            return
        if self.rect.y < -200 or self.rect.y > 1200:
            self.alive = None
            return
        if self.levelObj:
            self.vel.x = self.speed * self.direction
            pos_before = self.rect.x
            self.collision.checkX()
            self.collision.checkY()
            if self.rect.x != pos_before or self.vel.x == 0:
                self.alive = None
                return
        self.animation.update()
        if self.direction == -1:
            self.screen.blit(
                self.animation.image,
                (self.rect.x + camera.x, self.rect.y),
            )
        else:
            self.screen.blit(
                flip_surface(self.animation.image, True, False),
                (self.rect.x + camera.x, self.rect.y),
            )
