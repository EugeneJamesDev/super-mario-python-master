from entities.EntityBase import EntityBase
from entities.Item import Item


class BrickBlock(EntityBase):
    """Interactive bricks inspired by the NES level layout."""

    STATE_RESTING = "resting"
    STATE_USED = "used"
    STATE_BROKEN = "broken"

    POWERUP_PAYLOADS = {
        "RedMushroom", "Star", "FireFlower",
        "BlueMushroom", "GreenMushroom", "DarkMushroom",
        "NormalFlower", "BlueFlower", "RedFlower", "WhiteFlower"
    }

    def __init__(
        self,
        screen,
        sprite_collection,
        x,
        y,
        sound,
        dashboard,
        level,
        contents=None,
        coin_total=0,
    ):
        super(BrickBlock, self).__init__(x, y, 0)
        self.screen = screen
        self.spriteCollection = sprite_collection
        self.sound = sound
        self.dashboard = dashboard
        self.level = level
        self.type = "Block"
        self.contents = contents
        self.coin_total = self._normalize_coin_payload(contents, coin_total)
        self.state = self.STATE_RESTING
        self.grid_position = (x, y)
        self.base_y = self.rect.y
        # NES: Question block bump = 0.5 blocks total over 8 frames
        # Per frame: 0.5 blocks / 8 frames = 0.0625 blocks/frame → 2 px/frame
        BLOCK_SIZE = 32  # pixels per block
        self.maxTime = 8  # Frame count unchanged
        self.vel = (0.5 / 8) * BLOCK_SIZE  # 0.0625 blocks/frame → 2 px/frame bump
        self._bump_timer = 0
        self.triggered = False
        self.coin_items = []
        # NES: Coin block can produce up to 10 coins, 16 frames per coin
        self.coin_interval = 16  # 16 frames per coin

    def bump(self, mario):
        if self.state != self.STATE_RESTING or self._bump_timer > 0:
            return
        if self.coin_total > 0:
            self._release_coin()
        elif self.contents in self.POWERUP_PAYLOADS:
            self._spawn_powerup(self.contents)
            self.contents = None
            self.state = self.STATE_USED
        elif self._is_breakable() and mario.powerUpState > 0:
            self._break_block()
            return
        else:
            # Plain bricks still animate when hit even if Mario is small.
            self.sound.play_sfx(self.sound.brick_bump)
        self._start_bump()

    def update(self, cam):
        if self.state == self.STATE_BROKEN:
            return
        self._update_bump_animation()
        # Continue releasing coins if we have more to release
        if hasattr(self, '_coin_release_timer') and self._coin_release_timer >= 0 and self.coin_total > 0:
            self._coin_release_timer += 1
            if self._coin_release_timer >= self.coin_interval:
                coin = Item(self.spriteCollection, self.screen, self.rect.x, self.base_y)
                self.coin_items.append(coin)
                self.dashboard.coins += 1
                self.coin_total -= 1
                self._coin_release_timer = 0
                if self.coin_total <= 0:
                    self.contents = None
                    self.state = self.STATE_USED
                    self._coin_release_timer = -1
        self._update_coin_items(cam)
        sprite = self._current_sprite()
        # Sky is already drawn as background, so just draw the block sprite
        if sprite is not None:
            try:
                self.screen.blit(sprite, (self.rect.x + cam.x, self.rect.y - 1))
            except (AttributeError, TypeError):
                pass

    def _current_sprite(self):
        if self.state == self.STATE_USED and self.coin_total == 0 and not self.contents:
            empty_sprite = None
            if self.level and hasattr(self.level, "get_theme_sprite"):
                empty_sprite = self.level.get_theme_sprite("empty")
            if empty_sprite is None:
                empty_sprite = self.spriteCollection.get("empty")
            if empty_sprite and empty_sprite.image:
                return empty_sprite.image
        bricks_sprite = None
        if self.level and hasattr(self.level, "get_theme_sprite"):
            bricks_sprite = self.level.get_theme_sprite("bricks")
        if bricks_sprite is None:
            bricks_sprite = self.spriteCollection.get("bricks")
        if bricks_sprite and bricks_sprite.image:
            return bricks_sprite.image
        return None

    def _start_bump(self):
        self._bump_timer = self.maxTime * 2
        self.triggered = True
        self.sound.play_sfx(self.sound.brick_bump)

    def _update_bump_animation(self):
        # Always start from the base y position to avoid drifting.
        self.rect.y = self.base_y
        if self._bump_timer <= 0:
            if self.triggered and self.state == self.STATE_RESTING and self.coin_total == 0 and not self.contents:
                self.triggered = False
            return
        if self._bump_timer > self.maxTime:
            self.rect.y -= self.vel
        else:
            self.rect.y += self.vel
        self._bump_timer -= 1
        if self._bump_timer == 0:
            self.rect.y = self.base_y

    def _update_coin_items(self, cam):
        if not self.coin_items:
            return
        for coin in list(self.coin_items):
            coin.spawnCoin(cam, self.sound, self.dashboard)
            if coin.coin_animation.timer >= 80:
                self.coin_items.remove(coin)

    def _release_coin(self):
        # NES: Release first coin immediately, then subsequent coins every 16 frames
        # This is called once per bump, so we need to track coin releases over time
        if not hasattr(self, '_coin_release_timer'):
            self._coin_release_timer = 0
            # Release first coin immediately
            coin = Item(self.spriteCollection, self.screen, self.rect.x, self.base_y)
            self.coin_items.append(coin)
            self.dashboard.coins += 1
            self.coin_total -= 1
            if self.coin_total <= 0:
                self.contents = None
                self.state = self.STATE_USED
                self._coin_release_timer = -1  # Done releasing coins
        elif self._coin_release_timer >= 0:
            # Continue releasing coins every 16 frames
            self._coin_release_timer += 1
            if self._coin_release_timer >= self.coin_interval and self.coin_total > 0:
                coin = Item(self.spriteCollection, self.screen, self.rect.x, self.base_y)
                self.coin_items.append(coin)
                self.dashboard.coins += 1
                self.coin_total -= 1
                self._coin_release_timer = 0  # Reset for next coin
                if self.coin_total <= 0:
                    self.contents = None
                    self.state = self.STATE_USED
                    self._coin_release_timer = -1  # Done

    def _spawn_powerup(self, payload):
        row = max(0, self.grid_position[1] - 1)
        column = self.grid_position[0]
        if payload == "RedMushroom":
            self.level.addRedMushroom(column, row)
        elif payload == "GreenMushroom":
            self.level.addOneUpMushroom(column, row)
        elif payload in {"BlueMushroom", "DarkMushroom"}:
            self.level.addRedMushroom(column, row)
        elif payload == "Star":
            self.level.addSuperStar(column, row)
        elif payload == "FireFlower":
            self.level.addFireFlowerItem(column, row)
        elif payload in {"NormalFlower", "BlueFlower", "RedFlower", "WhiteFlower"}:
            self.level.addFireFlowerItem(column, row)
        self.sound.play_sfx(self.sound.powerup_appear)

    def _break_block(self):
        self.level.clear_tile(*self.grid_position)
        self.dashboard.points += 50
        self.state = self.STATE_BROKEN
        self.alive = None

    def _normalize_coin_payload(self, contents, coin_total):
        if contents == "multi-coin" and coin_total <= 0:
            # NES: Coin block can produce up to 10 coins
            return 10
        if contents == "coin" and coin_total <= 0:
            return 1
        # Cap at 10 coins max
        return min(10, max(0, coin_total))

    def _is_breakable(self):
        return self.coin_total == 0 and not self.contents and self.state != self.STATE_BROKEN
