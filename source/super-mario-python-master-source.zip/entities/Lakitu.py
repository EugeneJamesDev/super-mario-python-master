from classes.Animation import Animation
from classes.Collider import Collider
from classes.EntityCollider import EntityCollider
from entities.EntityBase import EntityBase
from entities.Spiny import Spiny


class Lakitu(EntityBase):
    def __init__(self, screen, spriteColl, x, y, level, sound):
        super(Lakitu, self).__init__(x, y, 0)
        self.spriteCollection = spriteColl
        self.animation = Animation(
            [
                self.spriteCollection.get("lakitu").image,
            ]
        )
        if self.animation.image:
            sprite_height = self.animation.image.get_height()
            self.rect.height = sprite_height
            self.rect.y = self.rect.y - (sprite_height - 32)
        self.screen = screen
        self.type = "Mob"
        self.dashboard = level.dashboard
        self.collision = Collider(self, level)
        self.EntityCollider = EntityCollider(self)
        self.levelObj = level
        self.sound = sound
        self.obeyGravity = False
        self.fixedHeight = self.rect.y
        self.eggCooldown = 0
        self.eggInterval = 120

    def update(self, camera):
        if self.alive and self.active:
            self.updateAlive(camera)
            self.checkEntityCollision()

    def updateAlive(self, camera):
        mario = self._findMario()
        if mario:
            target_x = mario.rect.x - 64
            if self.rect.x > target_x:
                self.rect.x -= 1.5
            elif self.rect.x < target_x - 32:
                self.rect.x += 1.5
        self.rect.y = self.fixedHeight
        self.drawLakitu(camera)
        self.animation.update()
        self.eggCooldown -= 1
        if self.eggCooldown <= 0:
            self._throwEgg()

    def drawLakitu(self, camera):
        draw_x = self.rect.x + camera.x
        if draw_x < -100 or draw_x > 800:
            return
        self.screen.blit(
            self.animation.image,
            (self.rect.x + camera.x, self.rect.y),
        )

    def _findMario(self):
        return self.levelObj.player

    def _throwEgg(self):
        spiny = Spiny(
            self.screen,
            self.spriteCollection,
            self.rect.x // 32,
            self.rect.y // 32,
            self.levelObj,
            self.sound,
            isEgg=True
        )
        self.levelObj.entityList.append(spiny)
        self.eggCooldown = self.eggInterval

    def checkEntityCollision(self):
        for ent in self.levelObj.entityList:
            if ent is not self and hasattr(ent, 'type'):
                collisionState = self.EntityCollider.check(ent)
                if collisionState.isColliding:
                    if ent.type == "Mob" and hasattr(ent, 'bouncing') and ent.bouncing:
                        self.alive = False
                        self.sound.play_sfx(self.sound.brick_bump)
