import math

from classes.SurfaceCache import flip_surface

from classes.Animation import Animation
from classes.Collider import Collider
from classes.EntityCollider import EntityCollider
from classes.Maths import Vec2D
from entities.EntityBase import EntityBase


class CheepCheep(EntityBase):
    def __init__(self, screen, spriteColl, x, y, level, sound=None, variant="red"):
        super(CheepCheep, self).__init__(x, y, 0.3)
        self.variant = str(variant).lower()
        if self.variant in {"green", "jumping"}:
            sprite_keys = ["cheep_cheep_green"]
        elif self.variant in {"gray", "grey"}:
            sprite_keys = ["cheep_cheep_gray-1", "cheep_cheep_gray-2"]
        else:
            sprite_keys = ["cheep_cheep_red", "cheep_cheep_red-2"]
        frames = [
            sprite.image
            for key in sprite_keys
            if (sprite := spriteColl.get(key)) and sprite.image
        ]
        if not frames:
            fallback = spriteColl.get("cheep_cheep_red")
            if fallback and fallback.image:
                frames = [fallback.image]
        self.spriteCollection = spriteColl
        self.animation = Animation(frames, deltaTime=8)
        if self.animation.image:
            sprite_height = self.animation.image.get_height()
            self.rect.height = sprite_height
            self.rect.y = self.rect.y - (sprite_height - 32)
        self.screen = screen
        self.type = "Mob"
        self.dashboard = level.dashboard
        self.collision = Collider(self, level)
        self.EntityCollider = EntityCollider(self)
        self.levelObj = level
        self.sound = sound
        self.waterLevel = y * 32
        self.baseY = self.rect.y
        self.phase = 0
        self.vel.x = -2.0
        self.jumping_variant = self.variant in {"green", "jumping"}
        self.inWater = not self.jumping_variant
        self.jump_timer = 0

    def update(self, camera):
        if self.alive:
            self.updateCheepCheep(camera)
            self.checkEntityCollision()
        else:
            self.onDead(camera)

    def updateCheepCheep(self, camera):
        mario = self._findMario()
        if self.inWater:
            self.phase += 0.05
            self.rect.y = self.baseY + math.sin(self.phase) * 20
            self.rect.x += self.vel.x
            if mario and abs(mario.rect.x - self.rect.x) < 96:
                self.inWater = False
                self.vel.y = -4.0
                self.vel.x = -3.0 if mario.rect.x > self.rect.x else 3.0
        elif self.jumping_variant:
            self.jump_timer += 1
            if mario and self.jump_timer >= 70 and self.onGround:
                self.vel.y = -5.0
                self.vel.x = -2.0 if mario.rect.centerx > self.rect.centerx else 2.0
                self.onGround = False
                self.jump_timer = 0
            self.applyGravity()
            self.rect.y += self.vel.y
            self.collision.checkY()
            self.rect.x += self.vel.x
            self.collision.checkX()
        else:
            self.applyGravity()
            self.rect.x += self.vel.x
            if self.rect.y > self.baseY + 100:
                self.inWater = True
                self.vel.y = 0
                self.vel.x = -2.0
        self.drawCheepCheep(camera)
        self.animation.update()

    def drawCheepCheep(self, camera):
        draw_x = self.rect.x + camera.x
        if draw_x < -100 or draw_x > 800:
            return
        if self.vel.x < 0:
            self.screen.blit(
                self.animation.image,
                (self.rect.x + camera.x, self.rect.y),
            )
        else:
            self.screen.blit(
                flip_surface(self.animation.image, True, False),
                (self.rect.x + camera.x, self.rect.y),
            )

    def _findMario(self):
        return self.levelObj.player

    def onDead(self, camera):
        if self.timer == 0:
            self.setPointsTextStartPosition(self.rect.x + 3, self.rect.y)
        if self.timer < self.timeAfterDeath:
            self.movePointsTextUpAndDraw(camera)
        else:
            self.alive = None
        self.timer += 0.1

    def setPointsTextStartPosition(self, x, y):
        self.textPos = Vec2D(x, y)

    def movePointsTextUpAndDraw(self, camera):
        self.textPos.y += -0.5
        self.dashboard.drawText("100", self.textPos.x + camera.x, self.textPos.y, 8)

    def checkEntityCollision(self):
        for ent in self.levelObj.entityList:
            if ent is not self and hasattr(ent, 'type'):
                collisionState = self.EntityCollider.check(ent)
                if collisionState.isColliding:
                    if ent.type == "Mob" and hasattr(ent, 'bouncing') and ent.bouncing:
                        self.alive = False
                        self.sound.play_sfx(self.sound.brick_bump)
