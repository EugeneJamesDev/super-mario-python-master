from classes.SurfaceCache import flip_surface

from classes.Animation import Animation
from classes.Collider import Collider
from classes.EntityCollider import EntityCollider
from entities.EntityBase import EntityBase
from traits.leftrightwalk import LeftRightWalkTrait


class Koopa(EntityBase):
    def __init__(self, screen, spriteColl, x, y, level, sound, variant="green"):
        super(Koopa, self).__init__(x, y, 1.25)
        self.spriteCollection = spriteColl
        self.variant = str(variant).lower()
        self.is_red = self.variant in {"red", "winged_red", "red_winged"}
        body = spriteColl.get("koopa_red") if self.is_red else spriteColl.get("koopa-1")
        body2 = spriteColl.get("koopa_red-2") if self.is_red else spriteColl.get("koopa-2")
        if self.is_red and (body2 is None or body2.image is None):
            body2 = body
        self.animation = Animation(
            [
                body.image,
                body2.image,
            ]
        )
        # Koopa sprite is 16x24, scaled to 32x48 pixels
        # Adjust rect to match sprite height and position feet on ground
        # EntityBase sets rect at (x*32, y*32) with height 32
        # For Koopa to stand on block at row y, bottom should be at (y+1)*32
        # So top should be at (y+1)*32 - sprite_height = y*32 - (sprite_height - 32)
        if self.animation.image:
            sprite_height = self.animation.image.get_height()
            self.rect.height = sprite_height
            # Adjust y position: move up by (sprite_height - 32) so bottom aligns with block
            self.rect.y = self.rect.y - (sprite_height - 32)
        else:
            # Fallback if sprite not loaded: sprite is 48px tall
            self.rect.height = 48  # 24 * 2
            self.rect.y = self.rect.y - 16  # Move up 16px so bottom aligns

        self.screen = screen
        # Red Koopas turn at platform edges; green Koopas walk off them.
        self.leftrightTrait = LeftRightWalkTrait(self, level, turn_at_ledges=self.is_red)
        self.timer = 0
        self.timeAfterDeath = 35
        self.type = "Mob"
        self.dashboard = level.dashboard
        self.collision = Collider(self, level)
        self.EntityCollider = EntityCollider(self)
        self.levelObj = level
        self.sound = sound

    def _shell_sprite(self):
        key = "koopa_shell_red" if self.is_red else "koopa_shell_green"
        sprite = self.spriteCollection.get(key)
        if sprite and sprite.image:
            return sprite
        return self.spriteCollection.get("koopa-hiding")

    def update(self, camera):
        if self.alive and self.active:
            self.updateAlive(camera)
            self.checkEntityCollision()
        elif self.alive and not self.active and not self.bouncing:
            self.sleepingInShell(camera)
            self.checkEntityCollision()
        elif self.bouncing:
            self.shellBouncing(camera)
            self.checkEntityCollision()

    def drawKoopa(self, camera):
        if self.leftrightTrait.direction == -1:
            self.screen.blit(
                self.animation.image, (self.rect.x + camera.x, self.rect.y)
            )
        else:
            self.screen.blit(
                flip_surface(self.animation.image, True, False),
                (self.rect.x + camera.x, self.rect.y),
            )

    def shellBouncing(self, camera):
        # NES: Shell speed = 0.1875 blocks/f → 6.0 px/frame
        BLOCK_SIZE = 32  # pixels per block
        self.leftrightTrait.speed = 0.1875 * BLOCK_SIZE
        self.applyGravity()
        shell_sprite = self._shell_sprite()
        if shell_sprite and shell_sprite.image:
            # Shell sprite is smaller (16x15, scaled to 32x30)
            # Adjust rect height for shell and position bottom on ground
            shell_height = shell_sprite.image.get_height()
            old_bottom = self.rect.bottom
            self.rect.height = shell_height
            self.rect.bottom = old_bottom  # Keep bottom aligned
            self.animation.image = shell_sprite.image
        self.drawKoopa(camera)
        self.leftrightTrait.update()

    def sleepingInShell(self, camera):
        if self.timer < self.timeAfterDeath:
            shell_sprite = self._shell_sprite()
            if shell_sprite and shell_sprite.image:
                # Shell sprite is smaller, adjust rect
                shell_height = shell_sprite.image.get_height()
                old_bottom = self.rect.bottom
                self.rect.height = shell_height
                self.rect.bottom = old_bottom  # Keep bottom aligned
                self.screen.blit(
                    shell_sprite.image,
                    (self.rect.x + camera.x, self.rect.y),
                )
        else:
            # Respawn as full Koopa
            self.alive = True
            self.active = True
            self.bouncing = False
            self.timer = 0
            # Restore full Koopa rect height
            if self.animation.image:
                sprite_height = self.animation.image.get_height()
                old_bottom = self.rect.bottom
                self.rect.height = sprite_height
                self.rect.bottom = old_bottom
        self.timer += 0.1

    def updateAlive(self, camera):
        self.applyGravity()
        self.drawKoopa(camera)
        self.animation.update()
        self.leftrightTrait.update()

    def checkEntityCollision(self):
        for ent in self.levelObj.entityList:
            if ent is not self:
                collisionState = self.EntityCollider.check(ent)
                if collisionState.isColliding:
                    if ent.type == "Mob":
                        self._onCollisionWithMob(ent, collisionState)

    def _onCollisionWithMob(self, mob, collisionState):
        # If this shell is bouncing, kill the other mob
        if collisionState.isColliding and self.bouncing:
            mob.alive = False
            self.sound.play_sfx(self.sound.brick_bump)
        # If the other mob is bouncing, kill this koopa
        elif collisionState.isColliding and mob.bouncing:
            self.alive = False
            self.sound.play_sfx(self.sound.brick_bump)
