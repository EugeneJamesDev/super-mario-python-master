from classes.Animation import Animation
from classes.Collider import Collider
from classes.EntityCollider import EntityCollider
from entities.EntityBase import EntityBase


class Podoboo(EntityBase):
    def __init__(self, screen, spriteColl, x, y, level, sound=None):
        super(Podoboo, self).__init__(x, y, 0.5)
        self.spriteCollection = spriteColl
        self.animation = Animation(
            [
                self.spriteCollection.get("podoboo").image,
            ]
        )
        if self.animation.image:
            sprite_height = self.animation.image.get_height()
            self.rect.height = sprite_height
            self.rect.y = self.rect.y - (sprite_height - 32)
        self.screen = screen
        self.type = "Hazard"
        self.collision = Collider(self, level)
        self.EntityCollider = EntityCollider(self)
        self.levelObj = level
        self.sound = sound
        self.lavaY = self.rect.y
        self.obeyGravity = False
        self.jumping = False
        self.jumpCooldown = 0
        self.jumpInterval = 90
        self.jumpVelocity = -6.0

    def update(self, camera):
        if not self.alive:
            return
        self.updatePodoboo(camera)

    def updatePodoboo(self, camera):
        draw_x = self.rect.x + camera.x
        if draw_x < -100 or draw_x > 800:
            return
        if not self.jumping:
            self.rect.y = self.lavaY
            self.jumpCooldown -= 1
            if self.jumpCooldown <= 0:
                self.jumping = True
                self.jumpVelocity = -6.0
                self.jumpCooldown = self.jumpInterval
        else:
            self.rect.y += self.jumpVelocity
            self.jumpVelocity += self.gravity
            if self.rect.y >= self.lavaY:
                self.rect.y = self.lavaY
                self.jumping = False
        self.drawPodoboo(camera)
        self.animation.update()

    def drawPodoboo(self, camera):
        self.screen.blit(
            self.animation.image,
            (self.rect.x + camera.x, self.rect.y),
        )
