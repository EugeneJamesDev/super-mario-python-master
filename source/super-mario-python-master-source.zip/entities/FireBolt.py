from classes.SurfaceCache import flip_surface, scale_surface
from classes.Animation import Animation
from classes.Collider import Collider
from entities.EntityBase import EntityBase
from entities.FireBurst import FireBurst
from entities.Mushroom import RedMushroom
from entities.OneUpMushroom import OneUpMushroom


class FireBolt(EntityBase):
    def __init__(self, screen, spriteColl, x, y, direction=-1, level=None, owner=None):
        super(FireBolt, self).__init__(0, 0, 0)
        # Both shooters provide world pixels so a bolt starts at the muzzle.
        self.rect.topleft = (x, y)
        
        self.spriteCollection = spriteColl
        self.animation = Animation(
            [
                self.spriteCollection.get("firebolt_1").image,
                self.spriteCollection.get("firebolt_2").image,
            ],
            self.spriteCollection.get("firebolt_1").image,
            self.spriteCollection.get("firebolt_1").image,
        )
        self.screen = screen
        self.direction = direction  # -1 for left, 1 for right
        self.speed = 4.0  # Pixels per frame
        self.type = "Hazard"
        self.levelObj = level
        self.owner = owner  # Track who shot this fire (Mario, Bowser, etc.)
        if level:
            self.collision = Collider(self, level)
        # Fire bolts sprite is 32x16, but should be displayed as 2x1 blocks (64x32 pixels)
        # Set rect to correct size: 2 blocks wide, 1 block tall
        self.rect.width = 64
        self.rect.height = 32
        self.lifetime = 300  # Frames before disappearing

    def update(self, camera):
        # Check alive status first - if dead, don't do anything
        if self.alive is None or self.alive is False:
            return
        
        self.lifetime -= 1
        if self.lifetime <= 0:
            self._expire()
            return
        
        # Move horizontally
        self.rect.x += self.speed * self.direction
        
        # Check collisions with level tiles
        if self.levelObj:
            # Set velocity for collision detection (checkX uses vel.x to detect direction)
            self.vel.x = self.speed * self.direction
            
            # Store position before collision check
            pos_before_check = self.rect.x
            
            # Check if we hit something (this may adjust our position)
            self.collision.checkX()
            self.collision.checkY()
            
            # If collision adjusted our position or stopped velocity, we hit something
            if self.rect.x != pos_before_check or self.vel.x == 0 or self._hit_enemy():
                self._expire()
                return
            
        # Animate
        self.animation.update()
        
        # Draw - scale sprite from 32x16 to 64x32 (2x1 blocks) and mirror if going left
        scaled_image = scale_surface(self.animation.image, (64, 32))
        if self.direction == -1:  # Going left - mirror/flip horizontally
            scaled_image = flip_surface(scaled_image, True, False)
        self.screen.blit(
            scaled_image,
            (self.rect.x + camera.x, self.rect.y)
        )
    
    def _hit_enemy(self):
        if self.owner is None or self.owner is not self.levelObj.player:
            return False
        for target in self.levelObj.entityList:
            if target.type != "Mob" or not target.alive or isinstance(target, (RedMushroom, OneUpMushroom)):
                continue
            if self.rect.colliderect(target.rect):
                if not getattr(target, "fireResistant", False):
                    self.owner.killEntity(target)
                return True
        return False

    def _expire(self):
        """Remove the bolt and leave an impact burst."""
        self.alive = None
        self.active = False
        if not self.levelObj:
            return
        
        burst = FireBurst(
            self.screen,
            self.spriteCollection,
            self.rect.x + self.rect.width // 2,
            self.rect.y + self.rect.height // 2,
            "down",
            lifetime=20
        )
        self.levelObj.entityList.append(burst)
