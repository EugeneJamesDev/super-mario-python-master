from copy import copy
from entities.EntityBase import EntityBase
from classes.Animation import Animation


class FireBurst(EntityBase):
    """Fire burst effect entity for visual enhancement."""
    
    def __init__(self, screen, spriteCollection, x, y, direction="down", lifetime=20):
        # x, y are pixel coordinates
        super(FireBurst, self).__init__(x // 32, y // 32, 0)  # No gravity
        self.rect.x = x
        self.rect.y = y
        self.screen = screen
        self.spriteCollection = spriteCollection
        self.direction = direction
        self.lifetime = lifetime
        self.timer = 0
        self.type = "Effect"
        
        # Get fire burst animation based on direction
        if direction == "down":
            burst_sprite = self.spriteCollection.get("fire_burst_down")
        else:
            burst_sprite = self.spriteCollection.get("fire_burst_small")
        
        if burst_sprite and burst_sprite.animation:
            self.animation = copy(burst_sprite.animation)
        else:
            # Fallback: create empty animation
            self.animation = Animation([])
    
    def update(self, camera):
        if self.timer >= self.lifetime:
            self.alive = None
            return
        
        if self.animation:
            self.animation.update()
            if self.animation.image:
                # Frames intentionally pulse between native 16px and 32px
                # art. Keep the effect's visual center fixed as the frame
                # changes instead of letting the top-left anchor make it jump.
                frame = self.animation.image
                x = self.rect.x + (32 - frame.get_width()) // 2
                y = self.rect.y + (32 - frame.get_height()) // 2
                self.screen.blit(
                    frame,
                    (x + camera.x, y)
                )
        
        self.timer += 1

