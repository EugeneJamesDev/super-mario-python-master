from copy import copy

from entities.EntityBase import EntityBase
from entities.Item import Item


class CoinBox(EntityBase):
    def __init__(self, screen, spriteCollection, x, y, sound, dashboard, level=None, gravity=0):
        super(CoinBox, self).__init__(x, y, gravity)
        self.screen = screen
        self.spriteCollection = spriteCollection
        self.level = level
        self.animation = self._load_question_animation(spriteCollection, level)
        self.type = "Block"
        self.triggered = False
        self.time = 0
        BLOCK_SIZE = 32
        self.maxTime = 8
        self.sound = sound
        self.dashboard = dashboard
        self.vel = (0.5 / 8) * BLOCK_SIZE
        self.item = Item(spriteCollection, screen, self.rect.x, self.rect.y)

    @staticmethod
    def _load_question_animation(spriteCollection, level):
        question_name = "CoinBox"
        if level and hasattr(level, "get_theme_sprite_name"):
            question_name = level.get_theme_sprite_name("question")
        question_sprite = spriteCollection.get(question_name)
        if question_sprite and question_sprite.animation:
            return copy(question_sprite.animation)
        fallback = spriteCollection.get("CoinBox")
        if fallback and fallback.animation:
            return copy(fallback.animation)
        return None

    def bump(self, _mario):
        if self.triggered:
            return
        self.triggered = True
        self.dashboard.coins += 1
        self.sound.play_sfx(self.sound.bump)

    def update(self, cam):
        if self.alive and not self.triggered:
            if self.animation:
                self.animation.update()
        else:
            empty_sprite = None
            if self.level and hasattr(self.level, "get_theme_sprite"):
                empty_sprite = self.level.get_theme_sprite("empty")
            if empty_sprite is None:
                empty_sprite = self.spriteCollection.get("empty")
            if empty_sprite and empty_sprite.image and self.animation:
                self.animation.image = empty_sprite.image
            if self.item:
                self.item.spawnCoin(cam, self.sound, self.dashboard)
            if self.time < self.maxTime:
                self.time += 1
                self.rect.y -= self.vel
            else:
                if self.time < self.maxTime * 2:
                    self.time += 1
                    self.rect.y += self.vel
        if self.animation and self.animation.image is not None:
            try:
                self.screen.blit(self.animation.image, (self.rect.x + cam.x, self.rect.y - 1))
            except (AttributeError, TypeError):
                pass
