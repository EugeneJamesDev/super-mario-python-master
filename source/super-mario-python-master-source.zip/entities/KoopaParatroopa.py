"""Winged Koopa variants used by Infinity mode.

Paratroopas share the shell, palette, collision, and defeated-shell behavior of
Koopa.  A top stomp removes their wings; the resulting turtle then behaves as a
normal Koopa and can be stomped into a shell on the next hit.
"""

from classes.Animation import Animation
from entities.Koopa import Koopa


class KoopaParatroopa(Koopa):
    """A red traveling or green in-place hopping SMB1 Paratroopa."""

    def __init__(self, screen, spriteColl, x, y, level, sound, variant="green"):
        palette = "red" if str(variant).lower().startswith("red") else "green"
        super().__init__(screen, spriteColl, x, y, level, sound, variant=palette)
        self.is_paratroopa = True
        self.winged = True
        self.paratroopa_variant = palette
        self.hop_cooldown = 6
        self.hop_velocity = -9.0
        self._ground_animation = self.animation
        self._set_winged_animation()
        # Green SMB1 Paratroopas hop vertically in place. Red ones travel
        # across the course and reverse at ledges like red Koopas.
        if palette == "green":
            self.vel.x = 0

    def _set_winged_animation(self):
        """Use authored animation frames if available, with the registered
        static cutout as a safe fallback until more frames are extracted.
        """
        frame_prefix = f"koopa_paratroopa_{self.paratroopa_variant}"
        frames = []
        for key in (f"{frame_prefix}-1", f"{frame_prefix}-2"):
            sprite = self.spriteCollection.get(key)
            if sprite is not None and sprite.image is not None:
                frames.append(sprite.image)
        if not frames:
            sprite = self.spriteCollection.get(frame_prefix)
            if sprite is not None and sprite.image is not None:
                frames.append(sprite.image)
        if frames:
            self.animation = Animation(frames, deltaTime=8)
            self._fit_body_rect()

    def _fit_body_rect(self):
        if not self.animation.image:
            return
        bottom = self.rect.bottom
        self.rect.width = self.animation.image.get_width()
        self.rect.height = self.animation.image.get_height()
        self.rect.bottom = bottom

    def lose_wings(self):
        """Drop the winged state and resume the normal Koopa lifecycle.

        Returns True only on the transition frame so stomp code can award
        points and bounce exactly once.
        """
        if not self.winged:
            return False
        self.winged = False
        self.hop_cooldown = 0
        # Restore the parent's original palette-matched walking frames.
        self.animation = self._ground_animation
        self._fit_body_rect()
        return True

    def updateAlive(self, camera):
        if not self.winged:
            return super().updateAlive(camera)

        self._update_winged_motion()
        self.drawKoopa(camera)
        self.animation.update()

    def _update_winged_motion(self):
        if self.paratroopa_variant == "red":
            # Red Paratroopas make forward hops. LeftRightWalkTrait handles
            # both platform collision and turning at supported ledges.
            self._begin_hop_if_ready()
            self.leftrightTrait.update()
            return

        # Green Paratroopas jump vertically in place.
        self.vel.x = 0
        self._begin_hop_if_ready()
        self.applyGravity()
        self.rect.y += self.vel.y
        self.collision.checkY()
        self.collision.checkX()

    def _begin_hop_if_ready(self):
        if self.onGround:
            if self.hop_cooldown > 0:
                self.hop_cooldown -= 1
                # Keep gravity active so tile collision continues to mark the
                # enemy grounded throughout the short pre-hop pause.
                self.applyGravity()
            else:
                self.vel.y = self.hop_velocity
                self.onGround = False
                # The pause at the ground gives a readable, repeatable hop.
                self.hop_cooldown = 7
        else:
            self.applyGravity()


Paratroopa = KoopaParatroopa
