import pygame

from classes.Animation import Animation
from classes.Camera import Camera
from classes.Collider import Collider
from classes.EntityCollider import EntityCollider
from classes.Input import Input
from classes.Maths import Vec2D
from entities.EntityBase import EntityBase
from entities.FireBolt import FireBolt
from entities.Mushroom import RedMushroom
from entities.OneUpMushroom import OneUpMushroom
from entities.Koopa import Koopa
from entities.BuzzyBeetle import BuzzyBeetle
from traits.bounce import bounceTrait
from traits.go import GoTrait
from traits.jump import JumpTrait
from classes.Pause import Pause


def _fallback_key(base_name):
    if base_name.endswith("_big"):
        return "mario_big"
    return "mario"


def _animation_frame(sprite_collection, base_name, suffix):
    key = f"{base_name}_{suffix}"
    sprite = sprite_collection.get(key)
    if sprite is None and base_name != _fallback_key(base_name):
        fallback = f"{_fallback_key(base_name)}_{suffix}"
        sprite = sprite_collection.get(fallback)
    if sprite is None:
        raise KeyError(f"Missing sprite for {key}")
    # Handle sprites with animations (get current animation frame)
    if sprite.animation is not None:
        return sprite.animation.image
    # Handle static sprites
    return sprite.image


def _build_animation_for(character, sprite_collection, big=False):
    base_name = f"{character}_big" if big else character
    try:
        return Animation(
            [
                _animation_frame(sprite_collection, base_name, "run1"),
                _animation_frame(sprite_collection, base_name, "run2"),
                _animation_frame(sprite_collection, base_name, "run3"),
            ],
            _animation_frame(sprite_collection, base_name, "idle"),
            _animation_frame(sprite_collection, base_name, "jump"),
        )
    except KeyError:
        fallback = "mario"
        base_name = f"{fallback}_big" if big else fallback
        return Animation(
            [
                _animation_frame(sprite_collection, base_name, "run1"),
                _animation_frame(sprite_collection, base_name, "run2"),
                _animation_frame(sprite_collection, base_name, "run3"),
            ],
            _animation_frame(sprite_collection, base_name, "idle"),
            _animation_frame(sprite_collection, base_name, "jump"),
        )


class Mario(EntityBase):
    DEFAULT_GRAVITY = 0.3
    TERMINAL_VELOCITY = 6.5

    def __init__(self, x, y, level, screen, dashboard, sound, gravity=None, character="mario"):
        if gravity is None:
            gravity = self.DEFAULT_GRAVITY
        super(Mario, self).__init__(x, y, gravity)
        self.camera = Camera(Vec2D(), self)
        self.sound = sound
        self.input = Input(self, joystick=Input.first_joystick())
        self.inAir = False
        self.inJump = False
        self.inWater = False
        self.climbing_vine = None
        self.climb_input_y = 0
        self.powerUpState = 0
        self.invincibilityFrames = 0
        self.character = character.lower()
        # Reuse the level's loaded assets instead of loading a second full copy
        # at module import time. Keeping one collection also keeps animations
        # and rendering on the same sprite definitions.
        self.spriteCollection = level.sprites.spriteCollection
        self.animations = {
            "small": _build_animation_for(
                self.character, self.spriteCollection, big=False
            ),
            "big": _build_animation_for(
                self.character, self.spriteCollection, big=True
            ),
        }
        self.animations["swim_small"] = self._make_swim_animation("small")
        self.animations["swim_big"] = self._make_swim_animation("big")
        self.traits = {
            "jumpTrait": JumpTrait(self),
            "goTrait": GoTrait(self.animations["small"], screen, self.camera, self),
            "bounceTrait": bounceTrait(self),
        }

        self.levelObj = level
        level.player = self
        self.collision = Collider(self, level)
        self.screen = screen
        self.EntityCollider = EntityCollider(self)
        self.dashboard = dashboard
        self.restart = False
        self.dying = False
        self.isMario = True
        self.pause = False
        self.pauseObj = Pause(screen, self, dashboard, joystick=self.input.joystick)
        self.terminal_velocity = self.TERMINAL_VELOCITY

        # Fire shooting
        self.fireCooldown = 0
        self.fireInterval = 30  # Frames between fire shots (0.5 seconds at 60fps)
        self.fireballCount = 5  # Start with 5 fireballs
        self.maxFireballs = 5  # Maximum fireballs

        # Jetpack (soft-lock escape) - available to both Mario and Luigi
        # Uses FireBolt sprite as a vertical jet under character, triggered by 'S'
        # Jetpack lifts exactly 3 blocks (96 pixels) maximum
        self.jetpack_active = False
        self.jetpack_timer = 0
        self.jetpack_start_y = None  # Track starting Y position to limit lift to 3 blocks
        BLOCK_SIZE = 32  # pixels per block
        MAX_JETPACK_LIFT = 3 * BLOCK_SIZE  # 3 blocks = 96 pixels
        # Calculate upward velocity needed to lift 3 blocks
        # Using physics: v² = 2 * g * h, where h = 96 pixels, g = 0.3 px/frame²
        # v = sqrt(2 * 0.3 * 96) ≈ 7.59 pixels/frame
        self.jetpack_impulse_vel = -(2 * self.DEFAULT_GRAVITY * MAX_JETPACK_LIFT) ** 0.5
        # Rate limit: 4 bursts per 10 seconds (600 frames at 60 FPS)
        # Track frame numbers when jetpack was used
        self.jetpack_use_times = []  # List of frame numbers when jetpack was activated
        self.jetpack_window_frames = int(10 * 60)  # 10 seconds = 600 frames
        self.jetpack_max_uses = 4  # Maximum uses per window
        self._frame_counter = 0  # Frame counter for rate limiting
        self.MAX_JETPACK_LIFT = MAX_JETPACK_LIFT  # Store for use in update
        self.swim_timer = 0
        fire_sprite = self.spriteCollection.get("firebolt_1")
        self.jetpack_flame_image = (
            pygame.transform.rotate(fire_sprite.image, 90)
            if fire_sprite is not None and fire_sprite.image is not None
            else None
        )

    def _make_swim_animation(self, size):
        sprite = self.spriteCollection[f"{self.character}_swim_{size}"]
        source_animation = sprite.animation
        frames = source_animation.images
        return Animation(
            frames,
            idleSprite=frames[0],
            airSprite=frames[0],
            deltaTime=source_animation.deltaTime,
        )

    def update(self):
        if self.dying:
            self._update_death()
            return
        self._sync_water_physics()
        if self.swim_timer > 0:
            self.swim_timer -= 1
        form = "big" if self.powerUpState else "small"
        self.traits["goTrait"].animation = (
            self.animations[f"swim_{form}"] if self.inWater else self.animations[form]
        )
        if self.invincibilityFrames > 0:
            self.invincibilityFrames -= 1
        if self.climbing_vine is not None:
            self.traits["goTrait"].direction = 0
            self.inAir = False
        self.updateTraits()
        self.moveMario()
        if self.dying or self.restart:
            return
        self.camera.move()
        self.applyGravity()
        self.checkEntityCollision()
        self._update_scoreboard()
        if self.dying or self.restart:
            return
        self.input.checkForInput()

        # Update fire cooldown
        if self.fireCooldown > 0:
            self.fireCooldown -= 1

        # Clean up old jetpack use times (older than 10 seconds)
        # Increment frame counter each update
        self._frame_counter += 1

        # Remove timestamps older than the window
        current_frame = self._frame_counter
        self.jetpack_use_times = [t for t in self.jetpack_use_times if (current_frame - t) < self.jetpack_window_frames]

        # Update jetpack timer (visual effect / state)
        if self.jetpack_active:
            # Limit lift to exactly 3 blocks (96 pixels)
            if self.jetpack_start_y is not None:
                current_lift = self.jetpack_start_y - self.rect.y
                if current_lift >= self.MAX_JETPACK_LIFT:
                    # Reached max lift, stop jetpack and set velocity to 0
                    self.jetpack_active = False
                    self.vel.y = 0
                    self.jetpack_start_y = None
                elif self.jetpack_timer > 0:
                    self.jetpack_timer -= 1
                    # Draw jetpack flame under character using FireBolt sprite rotated 90 degrees
                    if self.jetpack_flame_image is not None:
                        flame = self.jetpack_flame_image
                        img_w, img_h = flame.get_size()
                        draw_x = int(self.rect.centerx - img_w / 2 + self.camera.x)
                        # Position fire below character's feet (top of rotated sprite at bottom of character)
                        draw_y = int(self.rect.bottom + self.camera.y)
                        self.screen.blit(flame, (draw_x, draw_y))
                else:
                    self.jetpack_active = False
                    self.jetpack_start_y = None
            else:
                self.jetpack_active = False

    def _sync_water_physics(self):
        """Use SMB1's swimming gravity tables, scaled to this game's 2x pixels."""
        was_underwater = getattr(self, "inWater", False)
        self.inWater = self.levelObj.is_underwater_at(self.rect)
        if self.inWater:
            # SMB1 water profile: jump gravity $0D and fall gravity $0A,
            # with an initial $FE speed and $80 movement fraction. The game
            # renders NES pixels at 2x, so convert the fixed-point values here.
            self.gravity = (0x0D if self.vel.y < 0 else 0x0A) / 256 * 2
            self.terminal_velocity = 8.0  # NES shared downward cap: 4 px/frame
            self.vel.y = max(-6.0, min(self.terminal_velocity, self.vel.y))
        else:
            self.gravity = self.DEFAULT_GRAVITY
            self.terminal_velocity = self.TERMINAL_VELOCITY
            self.swim_timer = 0
            if was_underwater and self.vel.y > 0:
                self.vel.y = min(self.vel.y, 1.5)

    def moveMario(self):
        if self.climbing_vine is not None:
            vine = self.climbing_vine
            if vine.alive is False or not vine.grown:
                self.detach_vine()
            else:
                self.vel.x = 0
                if self.climb_input_y:
                    self.vel.y = self.climb_input_y * vine.CLIMB_SPEED
                    self.rect.y += self.vel.y
                    self.rect.y = max(vine.top_y - 8, self.rect.y)
                    self.collision.checkY()
                    if self.vel.y == 0:
                        self.climb_input_y = 0
                else:
                    self.vel.y = 0
                self.rect.centerx = vine.rect.centerx
                self.onGround = False
                self.inAir = False
                return
        self.rect.y += self.vel.y
        hit = self.collision.checkY()
        # Check the exact tile hit from below before resolving horizontal motion.
        if hit is not None and hit.block is not None:
            hit.block.bump(self)
        self.rect.x += self.vel.x
        self.collision.checkX()

    def try_attach_vine(self):
        """Grab the nearest grown vine while pressing up."""
        if self.climbing_vine is not None:
            return True
        for vine in self.levelObj.entityList:
            if getattr(vine, "type", None) != "ClimbableVine" or not vine.grown:
                continue
            if abs(self.rect.centerx - vine.rect.centerx) > 22:
                continue
            if self.rect.bottom < vine.top_y - 12 or self.rect.top > vine.base_y + 32:
                continue
            self.climbing_vine = vine
            self.rect.centerx = vine.rect.centerx
            self.vel.x = self.vel.y = 0
            self.onGround = False
            self.inAir = False
            self.inJump = False
            self.traits["jumpTrait"].reset()
            self.traits["goTrait"].direction = 0
            return True
        return False

    def detach_vine(self, jump=False):
        if self.climbing_vine is None:
            return False
        self.climbing_vine = None
        self.climb_input_y = 0
        self.vel.x = 0
        self.vel.y = 0
        if jump:
            self.onGround = True
            self.traits["jumpTrait"]._start_jump()
        return True

    def applyGravity(self):
        """Apply free-fall gravity only when the jump profile is inactive.

        JumpTrait already applies the SMB1 rising-jump gravity and variable
        jump-hold impulse. Applying EntityBase gravity on top of that each
        frame shortened every land jump well below the configured apex.
        Swimming has its own gravity profile and leaves ``jump_active`` false.
        """
        if self.climbing_vine is not None:
            self.vel.y = 0
            return
        jump_trait = self.traits.get("jumpTrait") if self.traits else None
        if jump_trait is not None and jump_trait.jump_active and not getattr(self, "inWater", False):
            return
        super().applyGravity()

    def checkEntityCollision(self):
        # Optimize collision checking with distance-based culling
        # Only check entities within reasonable distance
        mario_x = self.rect.centerx
        mario_y = self.rect.centery
        collision_range_sq = 10000  # 100 pixels squared (avoid sqrt calculation)

        # Collecting an item removes it from the live list. Check the next
        # overlapping entity even when the previous one was removed.
        for ent in self.levelObj.entityList[:]:
            entity_type = getattr(ent, "type", None)
            if entity_type not in {"Item", "Mob", "Platform", "Hazard"}:
                continue
            # Skip if entity doesn't have a valid rect
            if not hasattr(ent, 'rect') or ent.rect is None:
                continue

            # Skip if entity is already dead/inactive
            if not ent.alive:
                continue
            # A tucked-in shell is inactive but still has a collision response.
            if not ent.active and ent.type != "Mob":
                continue

            # EntityCollider.check uses this same rectangle overlap predicate.
            # Skip non-hazards early; animated hazards keep their custom bounds.
            if entity_type != "Hazard" and not ent.rect.colliderect(self.rect):
                continue
            if entity_type == "Hazard":
                # Skip collision if this is Mario's own fire - NEVER collide with own fire
                if hasattr(ent, "owner") and ent.owner is self:
                    continue  # Never collide with own fire

                collision_method = getattr(ent, "collides_with", None)
                if collision_method:
                    # Rotating hazards can extend well beyond 100 pixels from
                    # their center. Use their broad-phase bounds, then let the
                    # hazard check its actual moving hitboxes.
                    if not ent.rect.colliderect(self.rect):
                        continue
                    collided = collision_method(self.rect)
                else:
                    ent_x = ent.rect.centerx
                    ent_y = ent.rect.centery
                    dx = mario_x - ent_x
                    dy = mario_y - ent_y
                    if dx * dx + dy * dy > collision_range_sq:
                        continue
                    collided = self.EntityCollider.check(ent).isColliding
                if collided:
                    self._onCollisionWithHazard(ent)
                    if self.dying or self.restart:
                        return
                continue
            collisionState = self.EntityCollider.check(ent)
            if collisionState.isColliding:
                if entity_type == "Item":
                    self._onCollisionWithItem(ent)
                elif entity_type == "Mob":
                    self._onCollisionWithMob(ent, collisionState)
                    if self.dying or self.restart:
                        return
                elif entity_type == "Platform":
                    self._onCollisionWithPlatform(ent, collisionState)

    def _onCollisionWithItem(self, item):
        self.levelObj.entityList.remove(item)
        # Check what kind of item this is by its rect dimensions or sprite name
        item_name = getattr(item, 'item_name', None) or getattr(item, 'item_type', None)
        if item_name == 'star':
            self.dashboard.points += 1000
            self.invincibilityFrames = 600  # 10 seconds of invincibility
            self.sound.play_sfx(self.sound.powerup)
        elif item_name == 'fire_flower':
            self.dashboard.points += 500
            if self.powerUpState == 0:
                self.powerup(1)
            # Give fireball shooting ability
            if hasattr(self, 'fireballCount'):
                self.fireballCount = min(self.maxFireballs, self.fireballCount + 2)
            self.sound.play_sfx(self.sound.powerup)
        elif item_name == 'oneup':
            self.dashboard.points += 1000
            self.sound.play_sfx(self.sound.powerup)
        else:
            self.dashboard.points += 100
            self.dashboard.coins += 1
            self.sound.play_sfx(self.sound.coin)

    def _onCollisionWithMob(self, mob, collisionState):
        if getattr(mob, "cannotStomp", False):
            self._take_damage()
        elif getattr(mob, "is_paratroopa", False) and getattr(mob, "winged", False):
            if collisionState.isTop and mob.alive:
                self.sound.play_sfx(self.sound.stomp)
                self.rect.bottom = mob.rect.top
                self.bounce()
                mob.lose_wings()
                self.dashboard.points += 400
            elif collisionState.isColliding and mob.alive:
                self._take_damage()
        elif isinstance(mob, OneUpMushroom) and mob.alive:
            # 1UP Mushroom: give extra life instead of powerup
            self.dashboard.points += 1000
            self.killEntity(mob)
            self.sound.play_sfx(self.sound.powerup)
        elif isinstance(mob, RedMushroom) and mob.alive:
            self.powerup(1)
            # Restore fireballs when getting mushroom (up to max)
            if hasattr(self, 'fireballCount'):
                self.fireballCount = min(self.maxFireballs, self.fireballCount + 1)
            self.killEntity(mob)
            self.sound.play_sfx(self.sound.powerup)
        elif not mob.active and not mob.bouncing:
            # Start the shell outside Mario's hitbox to avoid immediately
            # colliding with the moving shell again on the next frame.
            mob.bouncing = True
            if mob.rect.centerx < self.rect.centerx:
                mob.leftrightTrait.direction = -1
                mob.rect.right = self.rect.left
            else:
                mob.leftrightTrait.direction = 1
                mob.rect.left = self.rect.right
            mob.vel.x = mob.leftrightTrait.direction
            if collisionState.isTop:
                self.bounce()
            self.sound.play_sfx(self.sound.kick)
        elif collisionState.isTop:
            self.sound.play_sfx(self.sound.stomp)
            self.rect.bottom = mob.rect.top
            self.bounce()
            self.killEntity(mob)
        elif collisionState.isColliding and mob.alive:
            self._take_damage()

    def bounce(self):
        self.traits["bounceTrait"].jump = True

    def killEntity(self, ent):
        if not isinstance(ent, (Koopa, BuzzyBeetle)):
            ent.alive = False
        else:
            ent.timer = 0
            ent.leftrightTrait.speed = 1
            ent.alive = True
            ent.active = False
            ent.bouncing = False
        self.dashboard.points += 100

    def gameOver(self):
        if self.dying or self.restart:
            return
        self.dying = True
        self._death_background = self.screen.copy()
        self._death_overlay = pygame.Surface(self.screen.get_size())
        self._death_overlay.set_colorkey("white")
        self._death_overlay.set_alpha(128)
        self._death_frame = 0
        self.sound.music_channel.stop()
        self.sound.music_channel.play(self.sound.death)

    def _update_death(self):
        # Advance the iris one frame at a time so browser events and audio
        # continue to run during the transition.
        self._pump_death_events()
        self._death_frame += 1
        radius = max(20, 500 - 20 * self._death_frame)
        self._death_overlay.fill("black")
        pygame.draw.circle(
            self._death_overlay, "white",
            (self.rect.centerx + int(self.camera.x), self.rect.centery),
            radius,
        )
        self.screen.blit(self._death_background, (0, 0))
        self.screen.blit(self._death_overlay, (0, 0))
        if self._death_frame >= 24 and not self.sound.music_channel.get_busy():
            self.restart = True

    @staticmethod
    def _pump_death_events():
        if pygame.event.get(pygame.QUIT):
            pygame.quit()
            raise SystemExit

    def getPos(self):
        return self.camera.x + self.rect.x, self.rect.y

    def powerup(self, powerupID):
        if self.powerUpState == 0:
            if powerupID == 1:
                self.powerUpState = 1
                self.traits["goTrait"].updateAnimation(self.animations["big"])
                self.rect = pygame.Rect(self.rect.x, self.rect.y-32, 32, 64)
                self.invincibilityFrames = 20

    def _onCollisionWithPlatform(self, platform, collisionState):
        if not collisionState.isTop:
            return
        carry = platform.carry_offset()
        self.rect.bottom = platform.rect.top
        self.vel.y = min(0, platform.velocity.y)
        self.rect.x += int(round(carry.x))
        self.onGround = True
        self.inAir = False

    def _onCollisionWithHazard(self, hazard):
        if self.invincibilityFrames:
            return
        self._take_damage()

    def _take_damage(self):
        if self.invincibilityFrames or self._game_over_active or self.restart:
            return
        if self.powerUpState == 0:
            self.gameOver()
            return
        self.powerUpState = 0
        self.traits["goTrait"].updateAnimation(self.animations["small"])
        x, y = self.rect.x, self.rect.y
        self.rect = pygame.Rect(x, y + 32, 32, 32)
        self.invincibilityFrames = 60
        self.sound.play_sfx(self.sound.pipe)

    def _update_scoreboard(self):
        if getattr(self.levelObj, "endless", False):
            current_column = int(self.getPosIndexAsFloat().x)
            if current_column > self.levelObj.distanceRewarded:
                delta = current_column - self.levelObj.distanceRewarded
                self.levelObj.distanceRewarded = current_column
                self.dashboard.points += delta * 10
        self.dashboard.update_high_score(self.dashboard.points)

    def try_jetpack(self):
        """Activate jetpack: lifts exactly 3 blocks (96 pixels) maximum. Rate limited to 4 bursts per 10 seconds. Available to both Mario and Luigi."""
        # Don't activate while in restart state
        if self.restart:
            return
        # Don't stack multiple jetpacks at once
        if self.jetpack_active:
            return

        # Check rate limit: allow max 4 uses per 10 second window
        current_frame = self._frame_counter
        # Count uses in the last 10 seconds
        recent_uses = [t for t in self.jetpack_use_times if (current_frame - t) < self.jetpack_window_frames]
        if len(recent_uses) >= self.jetpack_max_uses:
            return  # Already used 4 times in the last 10 seconds

        # Start jetpack and record use time
        self.jetpack_active = True
        self.jetpack_timer = 60  # Visual effect duration (1 second)
        self.jetpack_start_y = self.rect.y  # Track starting position
        self.jetpack_use_times.append(current_frame)

        # Apply upward impulse to escape soft-locks (exactly 3 blocks max)
        # Reset vertical velocity before impulse so it feels snappy
        self.vel.y = self.jetpack_impulse_vel

        # Optional: play a fireball or powerup sound if available
        if hasattr(self.sound, "powerup"):
            try:
                self.sound.play_sfx(self.sound.powerup)
            except Exception:
                pass

    def shootFire(self):
        """Shoot a fire bolt if cooldown is ready and fireballs available"""
        if self.powerUpState == 0:
            return

        if self.fireCooldown <= 0 and self.fireballCount > 0 and self.levelObj:
            # Shoot fire in the direction Mario is facing (use heading, which tracks last facing direction)
            fire_direction = self.traits["goTrait"].heading
            # If heading is 0 (shouldn't happen, but safety check), default to right
            if fire_direction == 0:
                fire_direction = 1

            # Spawn fire bolt from Mario's position
            # Fire should start at Mario's center, slightly forward and away from Mario
            # Make sure it doesn't spawn overlapping with Mario's rect
            if fire_direction == -1:  # Facing left
                fire_x = self.rect.x - 48  # Start further ahead when facing left to avoid overlap
                fire_y = self.rect.y + 8  # Slightly below top, aligned with Mario's center
            else:  # Facing right
                fire_x = self.rect.x + 48  # Start further ahead when facing right to avoid overlap
                fire_y = self.rect.y + 8  # Slightly below top, aligned with Mario's center

            firebolt = FireBolt(
                self.screen,
                self.spriteCollection,
                fire_x,
                fire_y,
                fire_direction,
                self.levelObj,
                owner=self  # Mark this fire as owned by Mario
            )

            # Add to level's entity list
            self.levelObj.entityList.append(firebolt)

            # Decrease fireball count and reset cooldown
            self.fireballCount -= 1
            self.fireCooldown = self.fireInterval
