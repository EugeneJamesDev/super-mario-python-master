from classes.SurfaceCache import flip_surface

from classes.Animation import Animation
from classes.Collider import Collider
from classes.EntityCollider import EntityCollider
from classes.Maths import Vec2D
from entities.EntityBase import EntityBase
from traits.leftrightwalk import LeftRightWalkTrait


class HammerBro(EntityBase):
    def __init__(self, screen, spriteColl, x, y, level, sound, variant="normal"):
        super(HammerBro, self).__init__(x, y, 1.25)
        self.spriteCollection = spriteColl
        self.variant = str(variant).lower()
        frame_keys = (
            ("hammer_bro_underground-1", "hammer_bro_underground-2")
            if self.variant in {"underground", "castle"}
            else ("hammer_bro-1", "hammer_bro-2")
        )
        frames = [
            sprite.image
            for key in frame_keys
            if (sprite := self.spriteCollection.get(key)) and sprite.image
        ]
        if not frames:
            frames = [
                sprite.image
                for key in ("hammer_bro-1", "hammer_bro-2")
                if (sprite := self.spriteCollection.get(key)) and sprite.image
            ]
        self.animation = Animation(
            frames,
            deltaTime=8,
        )
        if self.animation.image:
            sprite_height = self.animation.image.get_height()
            self.rect.height = sprite_height
            self.rect.y = self.rect.y - (sprite_height - 32)
        self.screen = screen
        self.leftrightTrait = LeftRightWalkTrait(self, level)
        self.type = "Mob"
        self.dashboard = level.dashboard
        self.collision = Collider(self, level)
        self.EntityCollider = EntityCollider(self)
        self.levelObj = level
        self.sound = sound
        self.throwCooldown = 0
        self.throwInterval = 90

    def update(self, camera):
        if self.alive:
            self.updateAlive(camera)
            self.checkEntityCollision()
        else:
            self.onDead(camera)

    def updateAlive(self, camera):
        self.applyGravity()
        self.drawHammerBro(camera)
        self.animation.update()
        self.leftrightTrait.update()
        self.throwCooldown -= 1
        if self.throwCooldown <= 0:
            self._throwHammer()

    def drawHammerBro(self, camera):
        draw_x = self.rect.x + camera.x
        if draw_x < -100 or draw_x > 800:
            return
        if self.leftrightTrait.direction == -1:
            self.screen.blit(
                self.animation.image,
                (self.rect.x + camera.x, self.rect.y),
            )
        else:
            self.screen.blit(
                flip_surface(self.animation.image, True, False),
                (self.rect.x + camera.x, self.rect.y),
            )

    def _throwHammer(self):
        hammer = HammerProjectile(
            self.screen,
            self.spriteCollection,
            self.rect.x // 32,
            self.rect.y // 32,
            self.leftrightTrait.direction,
            self.levelObj,
        )
        self.levelObj.entityList.append(hammer)
        self.throwCooldown = self.throwInterval

    def onDead(self, camera):
        if self.timer == 0:
            self.setPointsTextStartPosition(self.rect.x + 3, self.rect.y)
        if self.timer < self.timeAfterDeath:
            self.movePointsTextUpAndDraw(camera)
        else:
            self.alive = None
        self.timer += 0.1

    def setPointsTextStartPosition(self, x, y):
        self.textPos = Vec2D(x, y)

    def movePointsTextUpAndDraw(self, camera):
        self.textPos.y += -0.5
        self.dashboard.drawText("100", self.textPos.x + camera.x, self.textPos.y, 8)

    def checkEntityCollision(self):
        for ent in self.levelObj.entityList:
            if ent is not self and hasattr(ent, 'type'):
                collisionState = self.EntityCollider.check(ent)
                if collisionState.isColliding:
                    if ent.type == "Mob" and hasattr(ent, 'bouncing') and ent.bouncing:
                        self.alive = False
                        self.sound.play_sfx(self.sound.brick_bump)


class HammerProjectile(EntityBase):
    def __init__(self, screen, spriteColl, x, y, direction, level):
        super(HammerProjectile, self).__init__(x, y, 0.5)
        self.screen = screen
        self.spriteCollection = spriteColl
        hammer_frames = [
            spriteColl.get(f"hammer_projectile_{frame}")
            for frame in range(1, 5)
        ]
        hammer_images = [sprite.image for sprite in hammer_frames if sprite and sprite.image]
        self.animation = Animation(hammer_images, deltaTime=4) if hammer_images else None
        self.vel.x = 3.0 * direction
        self.vel.y = -4.0
        self.type = "Hazard"
        self.levelObj = level
        self.collision = Collider(self, level)
        self.EntityCollider = EntityCollider(self)
        self.lifetime = 120
        self.rect.width = 16
        self.rect.height = 16

    def update(self, camera):
        if self.alive is None or self.alive is False:
            return
        self.lifetime -= 1
        if self.lifetime <= 0:
            self.alive = None
            return
        self.applyGravity()
        self.rect.x += self.vel.x
        self.rect.y += self.vel.y
        draw_x = self.rect.x + camera.x
        if draw_x < -100 or draw_x > 800:
            self.alive = None
            return
        if self.animation and self.animation.image:
            # Keep the original 16×16 hitbox while drawing the native hammer
            # at 2× scale, centered so the four rotations do not jump around.
            self.animation.update()
            hammer = self.animation.image
            self.screen.blit(hammer, (draw_x - (hammer.get_width() - self.rect.width) // 2,
                                      self.rect.y - (hammer.get_height() - self.rect.height) // 2))
