import random

import pygame

from entities.EntityBase import EntityBase


class PiranhaPlant(EntityBase):
    """SMB1 pipe plant with hidden, rising, exposed, and retreating phases."""

    HIDDEN, RISING, EXPOSED, RETREATING = range(4)

    def __init__(
        self,
        screen,
        x,
        y,
        emergence=56,
        spriteCollection=None,
        level=None,
        variant="green",
    ):
        super().__init__(x, y, gravity=0)
        self.screen = screen
        self.type = "Hazard"
        self.levelObj = level
        self.variant = str(variant).lower()
        self.spriteCollection = spriteCollection
        self.image = self._load_sprite(spriteCollection, self.variant)
        self.pipe_center_x = x * 32 + 32
        self.pipe_top_px = y * 32
        # At offset zero the sprite sits immediately below the pipe opening.
        self.base_y = self.pipe_top_px + self.image.get_height()
        self.rect = self.image.get_rect(midbottom=(self.pipe_center_x, self.base_y))
        self.plant_bottom = self.base_y
        self.max_extension = max(1, min(int(emergence), self.image.get_height()))
        self.rise_speed = max(0.5, self.max_extension / 30.0)
        self.phase = self.HIDDEN
        self.offset = 0.0
        self.phase_timer = self._randint(45, 90)
        self.close_distance = 64
        self._sync_visible_hitbox()

    @classmethod
    def _load_sprite(cls, sprite_collection, variant):
        if sprite_collection:
            keys = (f"piranha_plant_{variant}", "piranha_plant")
            for key in keys:
                sprite = sprite_collection.get(key)
                if sprite and sprite.image:
                    return sprite.image
        surface = pygame.Surface((32, 48), pygame.SRCALPHA)
        # Palette-faithful fallback in the original SMB green plant colors.
        pygame.draw.rect(surface, (0, 168, 0), (8, 8, 16, 32))
        pygame.draw.rect(surface, (252, 152, 56), (4, 0, 24, 16))
        return surface

    def _randint(self, low, high):
        rng = getattr(self.levelObj, "randomizer", None)
        return rng.randint(low, high) if rng else random.randint(low, high)

    def _find_player(self):
        if not self.levelObj:
            return None
        return self.levelObj.player

    def _player_is_close(self):
        player = self._find_player()
        return bool(
            player
            and abs(player.rect.centerx - self.pipe_center_x) < self.close_distance
        )

    def _advance_cycle(self):
        # SMB1 plants wait inside their pipe whenever Mario is nearby.
        if self._player_is_close():
            return
        if self.phase == self.HIDDEN:
            self.phase_timer -= 1
            if self.phase_timer <= 0:
                self.phase = self.RISING
        elif self.phase == self.RISING:
            self.offset = min(self.max_extension, self.offset + self.rise_speed)
            if self.offset >= self.max_extension:
                self.phase = self.EXPOSED
                self.phase_timer = 45
        elif self.phase == self.EXPOSED:
            self.phase_timer -= 1
            if self.phase_timer <= 0:
                self.phase = self.RETREATING
        else:
            self.offset = max(0.0, self.offset - self.rise_speed)
            if self.offset <= 0:
                self.phase = self.HIDDEN
                self.phase_timer = self._randint(45, 90)
        self.plant_bottom = round(self.base_y - self.offset)
        self._sync_visible_hitbox()

    def _sync_visible_hitbox(self):
        """Only the exposed part above the pipe lip can hurt Mario."""
        visible_top = self.plant_bottom - self.image.get_height()
        visible_bottom = min(self.plant_bottom, self.pipe_top_px)
        if visible_bottom <= visible_top:
            self.rect = pygame.Rect(self.pipe_center_x - self.image.get_width() // 2,
                                    self.pipe_top_px, self.image.get_width(), 0)
            return
        self.rect = pygame.Rect(
            self.pipe_center_x - self.image.get_width() // 2,
            visible_top,
            self.image.get_width(),
            visible_bottom - visible_top,
        )

    def update(self, camera):
        # Keep the plant's full visual bounds separate from its live hitbox.
        self._advance_cycle()
        top = self.plant_bottom - self.image.get_height()
        if top >= self.pipe_top_px:
            return
        self.screen.blit(
            self.image,
            (self.pipe_center_x - self.image.get_width() // 2 + camera.x, top),
        )

    def collides_with(self, other_rect):
        return self.rect.height > 0 and self.rect.colliderect(other_rect)
