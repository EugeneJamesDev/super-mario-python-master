# Super Mario in Python

Project setup, code and asset layout, gameplay audits, and source credits.
The audit sections record findings from their original passes. Run the current
checks for up-to-date counts and runtime results.

## Table of contents

- [Setup and controls](#setup-and-controls)
  - [Run](#run)
  - [Browser build and GitHub Pages](#browser-build-and-github-pages)
  - [Controls](#controls)
  - [Project layout](#project-layout)
  - [Development checks](#development-checks)
  - [Visual sprite library](#visual-sprite-library)
  - [Windows build](#windows-build)
  - [Moving platforms in custom levels](#moving-platforms-in-custom-levels)
  - [Tileset notes](#tileset-notes)
- [Development and maintenance](#development-and-maintenance)
  - [Check workflow](#check-workflow)
  - [Tool organization](#tool-organization)
  - [Assets and generated files](#assets-and-generated-files)
  - [Follow-up refactoring](#follow-up-refactoring)
  - [Removed demo](#removed-demo)
- [Sprite and image asset layout](#sprite-and-image-asset-layout)
- [Infinity mode and game-wide audit](#infinity-mode-and-game-wide-audit)
  - [Verified in this pass](#verified-in-this-pass)
  - [Remaining gaps and risks](#remaining-gaps-and-risks)
  - [Reproduction commands](#reproduction-commands)
  - [SMB1 sprite-backed Infinity features added](#smb1-sprite-backed-infinity-features-added)
- [Infinity mode section recipes from SMB1](#infinity-mode-section-recipes-from-smb1)
- [SMB1 level, sprite, and gameplay coverage](#smb1-level-sprite-and-gameplay-coverage)
- [SMB1 source sprite and object inventory](#smb1-source-sprite-and-object-inventory)
- [SMB Maker atlas coverage](#smb-maker-atlas-coverage)
- [Super Mario Wiki SMB1 asset-category audit](#super-mario-wiki-smb1-asset-category-audit)
- [Retained demo sprite sheets](#retained-demo-sprite-sheets)
- [SMB1 reference sheets](#smb1-reference-sheets)

## Setup and controls

A Pygame platformer inspired by Meth-Meth-Method's
[Super Mario game](https://github.com/meth-meth-method/super-mario/).
The level picker offers procedural **Infinity** mode and **World1-1 through World8-4**.

### Run

From the project root, create an environment and install the dependencies:

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r config/requirements.txt
python main.py
```

On Windows, activate with `.venv\Scripts\activate` instead. The pinned dependencies
have been validated on Python 3.13. You can also launch the game from another
directory by passing the full path to `main.py`.

### Browser build and GitHub Pages

The browser build uses the same game loop, maps, and artwork as the desktop
version. Pygbag packages the game for its WebAssembly runtime. The first load
fetches that runtime, and clicking the game canvas enables audio and keyboard
focus. Settings and high scores in the browser are session-local.

From the project root:

```sh
python -m pip install -r config/requirements-web.txt
python tools/build_web.py
python -m http.server 8000 --directory build/web
```

Open [the local game](http://localhost:8000/). To publish on GitHub Pages, set
**Settings → Pages → Build and deployment → Source** to **GitHub Actions**. The
`Deploy browser game` workflow builds on pushes to `main` and can also be run
manually from the Actions tab. Its deployment step reports the live URL.

### Controls

- Left / Right or H / L: move
- Space or K: jump
- Left Shift: boost
- Up / Down: climb vines
- A: fire (when powered up)
- S: jetpack ability
- Escape or F5: pause
- Tab in the level picker: switch Mario / Luigi
- Enter in the level picker: start the selected level

The game uses a 640×480 logical surface in a resizable window. Controller input
is also supported. See [Input.py](../classes/Input.py) for the mappings.

### Project layout

| Path | Purpose |
| --- | --- |
| `main.py` | Game launcher |
| `classes/` | Level loading and generation, collision, rendering, input, menus, HUD, and sound |
| `entities/` | Player, enemies, interactive blocks, items, and hazards |
| `traits/` | Shared movement and jumping behaviors |
| `levels/` | Authored stages, Infinity patterns, and custom courses |
| `sprites/` | Sprite and animation manifests |
| `img/` and `sfx/` | Image sheets, reference art, and game audio |
| `config/` | Pinned game and development dependencies |
| `data/` | Local settings and high scores, created as needed |
| `tools/` | Editor, Windows packager, checks, screen captures, and asset tools |
| `test_frames/` | Local logs, captures, and generated asset reports |
| `docs/` | Setup, maintenance, and asset documentation |

Run `python tools/mapmaker.py` to open the editor or
`python tools/capture_frames.py` to capture Infinity frames headlessly.
See [Sprite and image asset layout](#sprite-and-image-asset-layout) for sprite sheet and manifest dependencies.

### Development checks

```sh
python -m pip install -r config/requirements-dev.txt
python tools/run_checks.py
```

This runs static analysis, the asset audit, and every `tools/check_*.py` and
`tools/test_*.py` script in isolated headless processes. It exits nonzero if any
check fails. Logs and rendered test artifacts go into ignored `test_frames/`.
The runner works from any directory when invoked by its absolute path.

See [Development and maintenance](#development-and-maintenance) for tool groups and maintenance notes.

### Visual sprite library

```sh
python tools/build_sprite_library.py
```

Open `test_frames/asset_reports/sprite_library.html` in a browser for a searchable
catalog. Rebuild after changing assets or manifests.

### Windows build

On Windows, install `py2exe` and `setuptools`, then run:

```sh
python tools/compile.py py2exe
```

The packaging script includes sprite manifests, their source images, levels,
sounds, and menu graphics. Local settings are saved when changed.
The file manifest is checked locally; building and running the executable
requires separate validation on Windows.

### Moving platforms in custom levels

A `MovingPlatform` entry accepts `[x, y, size, axis, travel_tiles]`:

- `x`, `y`: starting tile coordinates
- `size`: `"small"`, `"medium"`, or `"large"`
- `axis`: `"horizontal"` or `"vertical"`
- `travel_tiles`: distance from the origin before reversing

### Tileset notes

The SMB1 Maker sheet at `img/sheets/maker_smb1_tileset.png` uses 16×16 cells
separated by a 1px gutter.
Known landmarks include the music note block at A5, the star at E3, and the key
coin at A17. Existing manifests are the source of truth for crop coordinates.

## Development and maintenance

### Check workflow

Install `config/requirements-dev.txt`, then run `python tools/run_checks.py` before and
after gameplay or asset changes. Each script runs in a separate process with dummy
SDL audio/video drivers and a 180-second timeout. Use `--timeout SECONDS` to adjust
that limit. The runner continues after failures and returns a failing exit code.
Inspect `test_frames/check_logs/` for full output, including warnings.

Static analysis covers the active game, editor, capture helper, and tools. Headless checks
cover sprite loading and crops, entity states, procedural hazards, underwater
rules, platform motion, render trails, culling, dashboard caching, and resizing.
They do not replace interactive keyboard/controller and audio testing.

### Tool organization

Keep command-line utilities in `tools/` and retain the naming conventions below:

- `check_*.py`, `test_*.py`: automated regression checks; discovered by the runner
- `audit_*.py`: asset, transparency, and day/night reports; only `audit_assets.py`
  is included in the standard suite
- `capture_*.py`, `paginate_*.py`: screenshots and contact sheets
- `import_*.py`, `extract_*.py`, `download_*.py`: asset/reference preparation;
  run deliberately, since they may write source assets or access the network
- `build_sprite_library.py`, `export_sprite_gallery_data.py`,
  `generate_*_canvas.py`: generated visual catalogs and reports
- `mapmaker.py`: interactive level editor
- `compile.py`: Windows executable packaging

New checks should use assertions or a nonzero exit code on failure and avoid
changing saved settings, scores, or source assets. Use deterministic seeds;
when checking a specific biome's behavior, explicitly select that biome so the
check does not depend on a random sample happening to include it.

### Assets and generated files

Sprite manifests reference assets under `img/`. `tools/compile.py` preserves
their relative paths in the Windows build.

`test_frames/` contains reproducible local outputs and is ignored by Git.
Asset galleries, audits, and generated canvases are in `test_frames/asset_reports/`.
Run `tools/extract_maker_tileset.py` or
`tools/extract_smb1_reference_sprite_components.py` to regenerate their ignored
reference cutout folders.
The ignored `data/` directory holds `settings.json` and `highscore.json`.
For older checkouts, the game reads a legacy root save when its counterpart in
`data/` is absent. All writes go to `data/`.

### Follow-up refactoring

`classes/Level.py` combines authored-level loading, procedural generation,
entity spawning, and rendering. `tools/mapmaker.py` is also large. Split these in focused
changes with behavior-specific checks, rather than mixing broad structural moves
with gameplay fixes.

### Removed demo

The old standalone demo, its import scripts, and unused `DemoMario.json` /
`DemoLuigi.json` catalogs have been removed. The four source sheets still used by
the game now live under `img/sheets/`. `levels/demo_patterns.json` is retained:
Infinity mode loads those extracted formations at runtime. Asset provenance is
recorded in [Retained demo sprite sheets](#retained-demo-sprite-sheets).

Generated captures and reports are not shipped. Paths in historical audit notes
refer to outputs you can regenerate with the corresponding capture tools.

## Sprite and image asset layout

Gameplay art is grouped under `img/` by how the project uses it. `sprites/*.json`
are the runtime catalog: they define source sheets, crop rectangles, animation
frames, scaling, and collision/redraw flags. Keep the original pixel art intact;
make new crops in the cutout/source folders and bind them from a manifest.

### Directories

| Directory | Contents | Runtime role |
| --- | --- | --- |
| `img/sheets/` | Runtime sprite sheets, including the Maker SMB1 tileset, HUD font, and four sheets retained from the removed demo | Source sheets read by sprite manifests and the HUD |
| `img/characters/` | Character-specific loose artwork and palette variants | Princess and Bowser sprite manifests |
| `img/enemies/` | Loose enemy sprite sheets and reference animations | Enemy sprite manifests and source/reference art |
| `img/objects/` | Blocks, power-ups, platforms, flagpole, and fortress object art | Object/tile manifests and gameplay entities |
| `img/effects/` | Fireballs, fire bursts, and other short-lived effects | Effect sprite manifests |
| `img/scenery/` | Background fills, sky and fortress scenery | Background and scenery manifests |
| `img/references/` | Title screen sheet | Menu and pause graphics |
| `img/smb1_source/` | Unmodified SMB1 source sheets, level maps, and swimming references | Source/reference archive |
| `img/smb1_source/reference_cutouts/` | Locally generated crops from original reference sheets | Asset inspection |
| `img/smb1_cutouts/` | Transparent, named cuts used by the runtime | Runtime scenery and selected object/enemy variants |
| `img/wiki_assets/` | Individual images from the SMB1 wiki | Manifest sources and reference images used by regression checks |

### Runtime manifest groups

- `Mario.json`, `Luigi.json`, `SwimSprites.json`, and `Princess.json`: player and NPC poses.
- `Goomba.json`, `Koopa.json`, `NewEnemies.json`, `Bowser.json`, `BowserRedEyes.json`, `FireBolt.json`, `FireBarSprites.json`, and `FireEffects.json`: enemy and effect art.
- `NewItems.json`, `ItemAnimations.json`, `SMB1ObjectVariants.json`, `MushroomVariants.json`, and `FlowerVariants.json`: collectibles and object variants.
- `BackgroundSprites.json`, `NewTiles.json`, `SMB1Scenery.json`, and `SceneryExtras.json`: terrain, biome scenery, and decorations.
- `Animations.json`: shared block and object animation states.

### Integrity checks

Run `python3 tools/audit_assets.py` after adding or relocating a source sheet. It
checks every manifest sheet path, each crop rectangle against source dimensions,
and whether critical registered gameplay sprites load. Update this catalog when
a new directory or manifest family is introduced. Do not put generated test
frames in the runtime asset directories; keep them under `test_frames/`.

## Infinity mode and game-wide audit

Audit date: 2026-11-11

This pass reviewed procedural section generation and biome transitions, route geometry, player movement/collision inputs, moving-platform and hazard state rendering, sprite registration/crop bounds, and long-run entity retention. It preserves the original SMB pixel-art palette and uses the existing original-game sheets where suitable.

### Verified in this pass

- The expanded matrix (`seeds=20261111..20261154`, 1,200 columns each) now covers all eight biomes and all 56 directed transitions between distinct biomes. It generated 3,728 tagged screenshots, including in-water Mario swim poses; there were no capture errors, unsafe stand positions, route warnings, or water/palette frontier mismatches. The largest checked base-ground gap was three tiles. The visual audit also requires ice enemies and fortress Bill Blasters, Podoboos, and lava art to appear in captured frames. Review the overview under `test_frames/infinity_matrix/biome_overview.png` and the detailed `test_frames/infinity_matrix/audit.json`.
- The route screen is a geometry filter using the measured Mario jump profile; it does not simulate enemies, overhead block collisions, water-room routing, or every frame of a playable run. The generated screenshot contact sheet is `test_frames/infinity_sections/contact_sheet.png`; machine-readable findings are in `test_frames/infinity_sections/audit.json`.
- A direct `Mario.update` integration gives a tap jump an apex of 4.3306 tiles, 58 airborne frames, and 7.25 tiles of run distance. Holding jump for 12 frames gives 6.1875 tiles, 73 frames, and 9.125 tiles of run distance. `Mario` no longer receives gravity twice during an active jump. Opposing left/right controls cancel rather than choosing one direction by key priority.
- Water stroke input uses a 32-frame cooldown and does not retrigger continuously while held. The broader underwater movement remains provisional pending level-room routes and a frame-by-frame reference comparison; see the swimming section in [SMB1 level, sprite, and gameplay coverage](#smb1-level-sprite-and-gameplay-coverage).
- Asset audit: 107 source sheets present, 359 crop bounds valid, zero missing sheets or invalid crops, and 305 named sprites loaded. Critical gameplay sprite keys resolve. The complete source-sheet inventory and in-game roles are documented in [SMB1 source sprite and object inventory](#smb1-source-sprite-and-object-inventory).
- Sprite-state capture rendered 17 manifest animations / 67 manifest frames, 36 moving-entity state views, and 52 runtime enemy sprite states. Fifteen constructor-driven animation checks passed with no missing keys or failures. These checks verify art/state availability and composition, not behavior fidelity for every enemy.
- Moving-platform coverage includes large, medium, and small sizes, both movement axes, and start/mid/end positions. The original mushroom lift cutout is registered and uses cap-only collision (48×16) under its 48×48 art. Fire Bar orientations and Piranha Plant hidden/rising/exposed/retreating states are included in the visual sheet.
- The original four Hammer projectile rotations are extracted and rendered at 2× centered scale while preserving the 16×16 projectile hitbox. FireBurst frames are centered in a stable 32×32 drawing area without resizing their original pixel art.
- Endless-only stale-entity culling was stress-checked for 5,000 generated columns: 867 old entities were pruned, entity count peaked at 70, and a canonical-stage sentinel was retained. This avoids changing authored stage entity lifetime.
- The expanded generation pass fixed an unreachable underwater biome, player physics following the generation frontier instead of Mario's column, nondeterministic Fire Bar angles, rejected moving-platform spawns, and route warnings caused by mushroom stems. The dormant fortress feature path is now selectable: it generates short lava gaps, Podoboos, and correctly placed Bill Blasters. A frontier bound had prevented every Bill Blaster from spawning; the placement check now validates the actual one-column, two-row sprite footprint. Ice now receives its snow-palette scenery, coins, item blocks, and ground enemy pool instead of being mostly empty. Red/green Koopa and underground Piranha variants also enter the endless spawn pool.
- A seeded fortress runtime check confirms lava art, five Bill Blasters, four Podoboos, Bill Blaster firing, Bullet Bill movement, and Podoboo rising behavior. The test lives in [check_infinity_fortress_assets.py](../tools/check_infinity_fortress_assets.py).
- Underwater generation now uses the original bright NES water blue, a one-tile seabed, 16×48 coral and 16×46 underwater-plant cutouts (displayed 32×96 and 32×92), smaller coral, green reef pillars/ledges/arches, Cheep-Cheeps, Bloopers, and coins. It omits surface waterlines, land scenery, power-up blocks, land enemies, and moving platforms. Multi-column land features and queued features are trimmed at water transitions. The dedicated [underwater rule check](../tools/check_infinity_underwater_rules.py) passed across 44 seeds, 1,200 gameplay columns per seed plus 16 lookahead columns, with zero violations; it observed 201 tall plants and 221 tall coral overlays.
- Infinity decoration draws now query nearby 512-pixel buckets. In a synthetic 20,000-decoration scene, only 20 visible decorations were drawn (0.1%). HUD glyph scaling uses a cache; the repeated text-render check needed zero additional scale transforms and preserved pixels. This improves frame cost with distance, while terrain and decoration records still accumulate in memory.
- The main menu, settings, and course picker were visually reviewed at 640×480. The UI keeps the NES palette, bitmap font, and pixel borders; the Infinity description is centered, picker labels fit their cards, and the settings player hint no longer crowds its row. The warning state also replaces the footer line instead of overlapping it. [capture_menu_ui.py](../tools/capture_menu_ui.py) writes previews to `test_frames/menu_ui`.
- The display uses a fixed 640×480 logical canvas in a resizable, 4:3 scaled window. A headless resize check passed. Physical drag-resize behavior still needs a GUI run on macOS.

### Remaining gaps and risks

- Generated ground columns and per-column overlays are still retained for the full run. Entity culling bounds stale entities, but total world memory is not bounded; a rolling terrain buffer needs a coordinated world-offset/camera change.
- Seven of the 38 seeded views cross biome boundaries and visibly switch palette at a column edge. This is currently retained to keep hard SMB palette colors; it has no route warning, but can look abrupt. Review the `MIX` views on the contact sheet.
- Route feasibility is checked against base-ground gaps/rises and safe stand cells only. Overhead blocks, enemies, moving platforms, hazards, and actual player control traces are not included in the route solver.
- Remaining enemy art gaps include a distinct normal Hammer Bro pose, verified Lakitu throwing poses, and additional poses for Podoboo. Gray underwater Cheep-Cheep and Blooper now use two verified animated poses; underground Hammer Bros use the verified dark-palette two-frame variant.
- Generated sections currently have no goal condition by design. The Infinity objective is distance survived; canonical SMB1 map completion remains a separate mode.
- The 32 canonical SMB1 stages remain not verified 1:1. See the stage-by-stage findings in [SMB1 level, sprite, and gameplay coverage](#smb1-level-sprite-and-gameplay-coverage).

### Reproduction commands

From the repository root:

```sh
python3 -m compileall -q classes entities traits tools main.py
python3 tools/audit_assets.py
python3 tools/check_infinity_underwater_rules.py
python3 tools/test_sprite_states.py
python3 tools/check_infinity_entity_culling.py
python3 tools/capture_infinity_sections.py --seed 20261011
python3 tools/capture_infinity_matrix.py --seeds 44 --columns 1200 --first-seed 20261111
python3 tools/check_infinity_fortress_assets.py
python3 tools/capture_frames.py
python3 tools/paginate_infinity_matrix.py
python3 tools/capture_menu_ui.py
python3 tools/test_resizable_display.py
python3 tools/check_decoration_culling.py
python3 tools/check_dashboard_glyph_cache.py
```

All listed checks completed successfully on the audit date. Pygame emitted its upstream `pkg_resources` deprecation notice and libpng emitted an embedded-profile warning for source art; neither caused a check failure. The headless resize check cannot verify dragging a macOS window.


### SMB1 sprite-backed Infinity features added

- Red and green Paratroopas now use two exact 16×24 source frames each; the endless land-enemy pool can spawn them after the safe intro, and Mario's first top stomp removes wings before normal Koopa shell behavior resumes.
- Vine blocks now grow the authentic 16×16 tip/stem cuts into climbable vines. Up/down climbs, horizontal movement releases, and jump releases with a jump. The generated block remains a normal SMB1 question block. Bonus-room transitions are still out of scope until Infinity gains a room/vertical-camera model.
- Springboards use a clean transparent crop of the original idle sprite, a top-plate landing detector, a short compression delay, and a tall launch. No alternate pixels were invented; the source has only one pose.
- Fortress lava pits can rarely receive an optional bridge-and-axe span. Touching the axe collapses the bridge behind Mario and keeps the endless run going.
- Focused checks: `tools/check_paratroopa_states.py`, `tools/check_infinity_vine.py`, `tools/check_springboard_runtime.py`, and `tools/check_fortress_bridge_axe.py`. Vine behavior check uses in-memory stand-in images; the runtime cutouts are separately checked by `tools/audit_assets.py`.

## Infinity mode section recipes from SMB1

The 32 NES stage diagrams in `img/smb1_source/levels/` were reviewed together
in the contact sheet. The reference page lists World 1-1 through 8-4, alongside
the two FDS-only stages. See [The Spriters Resource SMB1 page](https://www.spriters-resource.com/nes/supermariobros/).

Infinity uses short motifs from those layouts rather than copying a full map:
the route stays endless, but each stretch has a recognizable SMB1 rhythm.
The expanded 17-recipe library is in `levels/infinity_world_motifs.json`; its
source-stage tags cover all 32 diagrams. `Level._infinity_reference_segments`
selects recipes for the active biome and routes them through the classic-feature
placement path. Those recipes are favored over the much larger legacy pattern
library so they show up regularly.

### Motifs seen across the maps

| Reference family | Repeating level-design cues | Infinity adaptation |
| --- | --- | --- |
| Overworld (1-1, 2-1, 3-1, 5-1, 8-1) | Pipes, low brick/question formations, coin arcs, enemies after a landmark | Pipe with plant, short brick row with a single reward, then an enemy lane |
| Underground (1-2, 4-2) | Low ceilings and block shelves, stairs, compact enemy lanes, coins marking the route | Ceiling/shelf row, supported coin line, then Goombas or a Buzzy Beetle |
| Underwater (2-2, 7-2) | Open swim corridors, separated obstacle clusters, coins and aquatic enemies | Clear coin path and Cheep-Cheep/Blooper groups at swim height; no land enemies or power-up blocks |
| Athletic/platform (1-3, 3-3, 4-3, 5-3, 6-3, 7-3) | Mushroom lifts, changing elevation, gaps, coins placed over safe landing routes | Existing mushroom-cap feature plus compact elevated block/coin approaches |
| Canyon/bridge courses (2-3, 5-3, 7-3) | Long exposed spans, hazards in the air lane, sparse supports | A coin arc and compact obstacle approach; actual pits remain controlled by the route generator |
| Castle (1-4 through 8-4) | Repeated hard-block lanes, fire hazards, brief safe spaces between threats | A short hard-block approach and coin cue; firebars remain biome-authored hazards |
| Late-game courses (8-1 through 8-4) | Longer sequences and denser combinations of familiar elements | Mix known recipes over time while preserving safe landing and rest columns |

These are style and pacing references, not a claim that any endless recipe
recreates a canonical stage 1:1. Exact original stage remakes remain a separate
level-picker task.

### Placement constraints

- A scheduled recipe must fit inside the current biome span. A section cannot
  change its terrain, palette, physics, or enemy rules halfway through.
- Water recipes keep the center of the swim lane open, put aquatic enemies
  above the seabed, and use coins rather than free power-up blocks.
- Routes are formed by the normal endless ground generator; recipe blocks and
  enemies cannot be used to justify an otherwise impossible pit or rise.
- Castle recipes supply visual rhythm only. Firebar and fortress routines own
  their active hazards so animated hazards are not duplicated by the recipe.

### Capture

Seed `20261111` generated 38 section views under
`test_frames/infinity_reference_sections/`. The route audit reported no
impossible ground gaps, missing landing zones, or unreachable ground rises.

A broader matrix run used seeds `20261111` through `20261122`, 1,200 columns
per seed, and captured 1,001 views across all eight biomes. It found zero
capture errors, unsafe stands, required-asset gaps, water/palette frontier
mismatches, or route warnings. The largest observed ground gap was three
tiles. It covered 40 of 56 directed biome transitions, so this is broad
regression evidence, not full transition-pair coverage. See
`test_frames/infinity_reference_matrix_full/biome_overview.png` and
`audit.json` for the captures and machine-readable counts.

## SMB1 level, sprite, and gameplay coverage

Audit date: 2026-11-11  
Reference: [Super Mario Bros. (NES) on The Spriters Resource](https://www.spriters-resource.com/nes/supermariobros/)

This checklist compares the 32 NES stages and the sprite/object families shown by the reference with the current project. The downloaded original-game sheets are in `img/smb1_source/`; earlier scenery cutouts and their manifest are in `img/smb1_cutouts/` and `sprites/SMB1Scenery.json`. The game-level diagrams are references, not level data that can be imported as playable maps without reconstructing collision and entity placement. The level picker now displays each stage's source diagram as a thumbnail and labels the playable layout `LAYOUT NOT VERIFIED 1:1` until its geometry and placements have been checked.

### Every NES stage

The source page lists all 32 NES stages below (it also lists two FDS-only stages, World -1 and World -3). The level picker now shows four courses per world. All stages have loadable JSON, but **none is currently verified 1:1**: `World1-1` through `World1-4` are the earlier authored project maps; the other 28 are structural variants derived from those four families. Each JSON's route width now matches its reference PNG's 16-pixel grid width, and each stores a `reference_map` pointer. That aligns overall scale only; it does not make the terrain or item/enemy placements accurate. The variants are playable placeholders, not remakes. Every stage still needs its reference geometry, object/enemy positions, and room routes checked. The picker labels this status. The `map_section_*` and endless pattern files are custom content.

| World | Stage references | Local authored level | Work needed |
| --- | --- | --- | --- |
| 1 | [1-1](https://www.spriters-resource.com/nes/supermariobros/asset/20592/), [1-2](https://www.spriters-resource.com/nes/supermariobros/asset/20594/), [1-3](https://www.spriters-resource.com/nes/supermariobros/asset/20595/), [1-4](https://www.spriters-resource.com/nes/supermariobros/asset/20597/) | 4/4 authored; 0/4 verified | Check terrain, every placement, collision and route against each reference; 1-4 also needs its complete castle loop. |
| 2 | [2-1](https://www.spriters-resource.com/nes/supermariobros/asset/20599/), [2-2](https://www.spriters-resource.com/nes/supermariobros/asset/20600/), [2-3](https://www.spriters-resource.com/nes/supermariobros/asset/20602/), [2-4](https://www.spriters-resource.com/nes/supermariobros/asset/20604/) | 4/4 data; 0/4 verified | Replace variants with reference-matched layouts; 2-2 has underwater physics/enemies but needs accurate route data. |
| 3 | [3-1](https://www.spriters-resource.com/nes/supermariobros/asset/20606/), [3-2](https://www.spriters-resource.com/nes/supermariobros/asset/20608/), [3-3](https://www.spriters-resource.com/nes/supermariobros/asset/20609/), [3-4](https://www.spriters-resource.com/nes/supermariobros/asset/20611/) | 4/4 data; 0/4 verified | Replace structural variants with reference-matched layouts, including the lift/platform and castle set pieces. |
| 4 | [4-1](https://www.spriters-resource.com/nes/supermariobros/asset/20613/), [4-2](https://www.spriters-resource.com/nes/supermariobros/asset/20615/), [4-3](https://www.spriters-resource.com/nes/supermariobros/asset/20619/), [4-4](https://www.spriters-resource.com/nes/supermariobros/asset/20620/) | 4/4 data; 0/4 verified | Replace structural variants with reference-matched layouts; 4-2 needs its underground/warp/bonus route. |
| 5 | [5-1](https://www.spriters-resource.com/nes/supermariobros/asset/20622/), [5-2](https://www.spriters-resource.com/nes/supermariobros/asset/20624/), [5-3](https://www.spriters-resource.com/nes/supermariobros/asset/20626/), [5-4](https://www.spriters-resource.com/nes/supermariobros/asset/20628/) | 4/4 data; 0/4 verified | Replace structural variants with reference-matched layouts and their enemy/block placements. |
| 6 | [6-1](https://www.spriters-resource.com/nes/supermariobros/asset/20629/), [6-2](https://www.spriters-resource.com/nes/supermariobros/asset/20630/), [6-3](https://www.spriters-resource.com/nes/supermariobros/asset/20632/), [6-4](https://www.spriters-resource.com/nes/supermariobros/asset/20633/) | 4/4 data; 0/4 verified | Replace structural variants with reference-matched layouts, including Lakitu/Spiny and castle routes where shown. |
| 7 | [7-1](https://www.spriters-resource.com/nes/supermariobros/asset/20634/), [7-2](https://www.spriters-resource.com/nes/supermariobros/asset/20635/), [7-3](https://www.spriters-resource.com/nes/supermariobros/asset/20636/), [7-4](https://www.spriters-resource.com/nes/supermariobros/asset/20637/) | 4/4 data; 0/4 verified | Replace structural variants with reference-matched layouts; 7-2 needs swimming and 7-4 needs castle maze progression. |
| 8 | [8-1](https://www.spriters-resource.com/nes/supermariobros/asset/20638/), [8-2](https://www.spriters-resource.com/nes/supermariobros/asset/20639/), [8-3](https://www.spriters-resource.com/nes/supermariobros/asset/20640/), [8-4](https://www.spriters-resource.com/nes/supermariobros/asset/20641/) | 4/4 data; 0/4 verified | Replace structural variants with reference-matched layouts; 8-4 needs multi-section castle/water route and boss completion. |

All 32 reference diagrams are in `img/smb1_source/levels/` with a contact sheet and manifest. Their pixel dimensions and artwork provide a visual basis, but they are not imported tilemaps. A level only counts as 1:1 after terrain, block/enemy/coin/pipe locations, palettes, collision, secrets, and transitions are checked against its diagram. Water diagrams can include separate areas stitched vertically; they need explicit room/pipe transitions rather than treating every piece as one flat continuous room.

### Worlds 1–2 verification pass

Reference-diagram review: 2026-10-08. All eight JSON widths equal the diagram width divided by 16 pixels per tile. That confirms horizontal scale only. I compared the diagrams with stage metadata and placed-object data; none passes full layout, collision, and route verification yet.

| Stage | Diagram | Findings from comparison | Result |
| --- | --- | --- | --- |
| World 1-1 | 211 × 30 tiles | The main overworld has authored blocks, pipes, coins, enemies and goal scenery. The reference also shows the lower bonus-room area; the runtime has no pipe entry or room transition, so that route is not playable. | Not 1:1 |
| World 1-2 | 192 × 45 tiles | The data paints the whole stage as underground. The reference diagram includes vertically arranged room/entrance sections, while the runtime stage is one flat room and pipes are scenery. `CoinBox` and `RandomBox` also occupy the same tile (8,9), so the loader keeps the coin box and drops the item box. | Not 1:1 |
| World 1-3 | 164 × 15 tiles | The course has authored platform and enemy data, but the reference's mushroom-platform shapes and individual placements have not been matched against collision geometry and original platform art. | Not verified |
| World 1-4 | 160 × 15 tiles | Bowser and Princess entries exist, but the castle route, firebar positions, bridge/axe interaction and completion flow are not verified against the diagram. | Not verified |
| World 2-1 | 213 × 45 tiles | Marked as a World 1-1 family reconstruction; its block/enemy counts repeat World 1-1. The diagram's room/bonus route is not represented as a playable transition. | Not 1:1 |
| World 2-2 | 192 × 30 tiles | The water interval is set to columns 16–157, matching the diagram's broad horizontal water section. Individual enemy, obstacle and pipe positions and room transitions are still unverified. `CoinBox` and `RandomBox` overlap at tile (11,9), so only the coin box loads. | Not verified |
| World 2-3 | 237 × 15 tiles | Marked as a World 1-3 family reconstruction. The reference shows suspended bridge spans and open gaps, but the level still has a continuous ground layer. | Not 1:1 |
| World 2-4 | 160 × 15 tiles | Marked as a World 1-4 family reconstruction. Castle maze geometry, hazard placements and bridge/axe completion are not verified against this stage's diagram. | Not verified |

**Count: 8/8 diagram widths match, 0/8 stages verified 1:1.** Worlds 1–2 should remain marked unverified in the level picker until room transitions, geometry, collision and object/enemy placements are reconstructed and checked. The World 2-3 continuous-floor finding is a known implementation gap, not an inferred 1:1 match.

The verification pass also found two loader issues. If an authored stage omitted any one of the older entity arrays (for example, `CoinBox`), the old grouped `try` block aborted loading all later arrays. `Level.loadEntities` now reads those arrays independently. This restored the authored Goombas and Koopas in Worlds 1-3 and 2-3. Also, canonical pipes no longer spawn random Piranha Plants on each load; a plant now needs an explicit pipe flag or a `PiranhaPlant` entity entry. These fixes make loading more deterministic but do not certify the maps. The four 30- or 45-tile-high references (World 1-1, 1-2, 2-1 and 2-2) include content below the runtime's 15-row grid; row-15 map entries are silently discarded, so those lower sections are not playable rooms.

### Infinity mode visual and route pass

`tools/capture_infinity_sections.py` creates 38 reproducible 20-column views from a seeded Infinity run and records a route audit. Run it from the repository root with `python tools/capture_infinity_sections.py --seed 20261011`. The screenshots and report are under `test_frames/infinity_sections/`.

Seed `20261011` covers all six current biomes. An actual `Mario.update` integration measured a 1-frame tap jump at 4.33 tiles high / 7.25 tiles horizontally and a 12-frame held run jump at 6.19 tiles high / 9.125 tiles horizontally. Across the 38 views, the largest generated ground gap was two tiles; no gap, landing-space, or ground-rise warning was found, and all 38 sections had a safe Mario stand point. This is a geometry screening pass against the project's current jump parameters, not a complete frame-by-frame play simulation through enemies and overhead block collisions.

Seven views cross a biome boundary. The contact sheet labels these `MIX`; the current generator changes palettes at a column boundary, which creates a sharp vertical seam in the screenshot. This is a visual transition issue, not a jump-route failure. Review `contact_sheet.png` for all 38 views and `audit.json` for their sampled columns and gap data.

Endless entity cleanup now removes entities more than two screens behind the camera, while canonical stages keep their full authored entity lists. Run `python tools/check_infinity_entity_culling.py` for a 5,000-column seeded check. This bounds stale entity memory; generated tile columns and their overlays still accumulate for the duration of an endless run. A rolling tile buffer needs a separate world-offset change.

### Swimming fidelity pass

- The small and big swimming animations are cut from the animated GIFs linked on the Mario & Luigi source sheet and preserved under `img/smb1_source/swimming/`. Luigi frames use the Luigi palette from that sheet.
- Water gravity uses the original `$0D` rising and `$0A` falling fixed-point values, initial `$FE` Y speed with `$80` fraction, and the shared four-pixel/frame downward cap, converted to the project's 2x display scale.
- Swimming strokes use the source's 32-frame jump/swim timer. Horizontal speed uses the source `$18` walk and `$28` B-run limits, scaled to the project.
- `World2-2` and `World7-2` currently have provisional horizontal water regions from the downloaded diagrams. Exact pipe-room transitions and a frame-by-frame emulator comparison remain open, so swimming is closer to the original but is not yet certified 1:1.

### Sprite and object inventory

“In code” means the sprite is in a loaded manifest or there is an entity class. “Working” means it can be placed through level data and has its expected core SMB behavior. A sheet/cutout alone is not counted as functional.

| SMB1 family | Current project coverage | Status / missing work |
| --- | --- | --- |
| Mario, small/big, running, jump, brake, death; Luigi | `Mario.json`, `Luigi.json`; demo animation sheets also load | Partial: fire, swimming, climbing, flagpole grab, pipe entry, growth/shrink and power-down states need a verified SMB1 behavior pass. |
| Goomba | `Goomba.json`, `entities/Goomba.py`, level loader | Present; verify exact collision/defeat edge cases. |
| Green/red Koopas, shells, and Paratroopas | `Koopa.json`, `SMB1ObjectVariants.json`, `ParatroopaFrames.json`, `entities/Koopa.py`, `entities/KoopaParatroopa.py` | Red/green Paratroopa GIFs now provide two native frames each; Infinity spawns hopping/flying variants, and a first stomp removes wings before a later stomp creates a shell. See the focused headless state check. |
| Buzzy Beetle and shell | `NewEnemies.json`, `entities/BuzzyBeetle.py`, level loader | Present in code; check original behavior and material-specific fire immunity. |
| Piranha Plant | `NewEnemies.json`, `entities/PiranhaPlant.py`, pipe placement | Hidden/rising/exposed/retreating cycle, deterministic timing, nearby-player pause, selectable underground artwork, and exposed-only hazard hitbox are implemented. Needs in-game visual verification. |
| Lakitu and Spiny / egg | `NewEnemies.json`, entity classes, level loader | Partial: spawned and move, but movement, egg arc, stomp rules and sprite poses need verification. |
| Cheep-Cheep (red/gray swimmers and green jumper) | `NewEnemies.json`, `SMB1WikiFrames.json`, `CheepCheep` class | Red and gray underwater swimmers animate from verified two-frame sets; the green jumper remains a separate level-data variant. Swimming physics and jumper landing still need in-game tuning. |
| Blooper | `SMB1WikiFrames.json`, `Blooper` class, level loader | Two distinct verified 16×24 poses now animate at runtime; movement/collision still need in-game verification against SMB1 underwater behavior. |
| Bullet Bill and Bill Blaster | Images, classes, level loader | Partial: blaster fires; direction/trigger/collision timing need reference verification. |
| Hammer Bro and hammer | Hammer Bro class and four extracted hammer rotations are loaded; underground sections use the verified two-frame dark-palette variant | Normal Hammer Bro still needs a distinct authentic second pose; throw arcs/timing need in-game verification. |
| Bowser | Sprite manifests, class, and now `Bowser` level-JSON placement | Partial: can be placed with `{"x":…, "y":…, "variant":"green"}`; boss defeat/end sequence and axe/bridge interaction are still missing. |
| Podoboo / firebar | Sprites, entities, level loader | Partial: hazards exist; placement and collision need verification. |
| Mushroom, Fire Flower, Super Star, 1-Up, coin | Images and item classes/animations | Partial: core pickup paths exist; verify power-up availability, invincibility duration, score/lives, and item block content tables. |
| Brick, ? block, used block, hard block, hidden block | Tile images and brick/question entities | Partial: bricks and question blocks have functionality; hidden-block discovery, correct used-block states and castle/underground palette variants need verification. |
| Pipes and warp pipes | Pipe tiles and level object support | Partial: decorative/solid pipes work; entering a pipe and changing room/world is missing. |
| Ground, sky, water, lava, coral | Ground variants and `NewTiles.json` | Underwater stages now support a surface row, deep-blue submerged background, and Mario swim gravity/speed/input. Add explicit waterline metadata per reconstructed map; lava collision/damage still needs work. |
| Clouds, hills, trees, bushes, fences | Original-palette scenery cutouts plus older scenery | Partial: clouds/hills now use palette-matched cutouts; original tree/forest and castle background variants should be cut and integrated. |
| Mushroom platforms and lifts | Moving-platform class has authentic 48×48 mushroom art with cap-only 48×16 collision; generic lift sizes retain custom bar art | Mushroom and horizontal/vertical movement states are captured; canonical stage placement and exact movement timing remain unverified. |
| Flagpole, flag, castle, fireworks, score/time bonus | Goal pole/fortress art exists | Missing functional flagpole grab/slide, goal-state scoring, castle entry, fireworks, time bonus and stage transition. |
| Bowser bridge and axe | `SMB1ObjectVariants.json` loads bridge tile and axe | Sprites are registered; falling-bridge interaction and boss defeat connection are still missing. |
| Princess / Toad | Princess sprite/class and now `Princess` level-JSON placement; Toad not loaded | Partial: Princess can be placed with `{"x":…, "y":…, "as_npc":true}` but isn't wired to castle-stage completion; Toad sprite/NPC dialogue/end sequence absent. |
| Vines, springboards, hidden bonus areas | `Vine`, `Springboard`, question-block payload and Infinity spawn hooks | Vine tip/segment cuts and climbing are wired; springboard art is alpha-cleaned and launches from a timed compression. Hidden bonus rooms and pipe/room transitions remain absent because the endless map has no room-state or vertical-camera support. |
| HUD, title/intermission screens, timer, score, world map | Existing dashboard/menu assets and code | Partial: project UI exists but needs audit against SMB1 counters, lives, time expiry and transitions. |

### Current inventory checks

- `classes/Sprites.py` loads 280 named sprites from the current manifest set (SDL dummy-driver inventory on 2026-11-11).
- Original source sheets and all 32 stage diagrams are downloaded under `img/smb1_source/`.
- Enemy and item constructors now use `(x, y)` level coordinates consistently; several previously transposed enemies were spawning far from their authored locations.
- Existing `sprites/SMB1Scenery.json` registers 42 palette-specific cloud/hill cutouts. These are used by the level renderer; source files and credit are documented in [SMB1 reference sheets](#smb1-reference-sheets).
- Level object loading supports blocks, coins, Goombas, Koopas, Piranha Plants, Fire Bars, Moving Platforms, Buzzy Beetles, Lakitu, Spiny, Cheep-Cheep, Blooper, Hammer Bro, Bullet Bills, Bill Blasters, Podoboo, 1-Up mushrooms, Bowser and Princess. A class or sprite not listed in that loader is not yet generally placeable from level JSON.
- The project contains extra experimental/custom assets and mechanics (colored mushrooms, jetpack, moving platforms, custom biomes). They are not part of canonical SMB1 and should be kept separate from the “authentic SMB1” checklist.

### Next implementation order

1. Replace the 28 structural variants with reference-matched maps, starting with the 2-2 and 7-2 water layouts; underwater movement and a split surface/water background now exist.
2. Complete the castle loop: load Bowser, add axe/bridge entities, trigger the bridge drop, and resolve each castle's exit (Toad or Princess) into stage progression.
3. Continue auditing source variants (especially a distinct normal Hammer Bro pose, Lakitu/Spiny throwing poses, and separable Mario vine-climb frames); red/green Paratroopas, animated gray underwater Cheep-Cheep, Blooper poses, underground Hammer Bro poses, vine tip/segment, springboard, SMB mushroom lift art, and hammer projectile are now registered.
4. Add level-data handlers and behavior for warp pipes/bonus rooms, hidden blocks, flagpole scoring, fireworks, timer expiry and level transitions.
5. Revisit each of the 32 stage references and mark a stage complete only after layout, enemy/object placements, palette, collision and end condition all match.

## SMB1 source sprite and object inventory

This catalog uses the NES Super Mario Bros. collection on [The Spriters
Resource](https://www.spriters-resource.com/nes/supermariobros/) as its source
index. The page currently lists 43 assets: one Mario/Luigi sheet, one
enemy/boss sheet, 34 stage maps, three background sheets, and four
miscellaneous sheets. Stage maps are references for composition and placement;
the source PNGs are kept unchanged under `img/smb1_source/`.

### Source assets present in the workspace

| Source group | Local reference | Source asset | Use in the game / current project status |
| --- | --- | --- | --- |
| Mario & Luigi | `img/smb1_source/mario_luigi_sheet.png` | [50365](https://www.spriters-resource.com/nes/supermariobros/asset/50365/) | Small/big characters, walking, climbing, growth/shrink, and swimming reference. Runtime Mario and Luigi manifests are in `sprites/Mario.json`, `sprites/Luigi.json`, and `sprites/SwimSprites.json`. |
| Enemies & Bosses | `img/smb1_source/enemies_sheet.png` | [52570](https://www.spriters-resource.com/nes/supermariobros/asset/52570/) | Enemy palettes, animation poses, Bowser, projectiles, and variants. Runtime entities live under `entities/`; sprite bindings are primarily in `sprites/NewEnemies.json`, `sprites/Goomba.json`, `sprites/Koopa.json`, `sprites/Bowser.json`, and `sprites/BowserRedEyes.json`. |
| Item and Brick Blocks | `img/smb1_source/item_blocks_sheet.png` | [65962](https://www.spriters-resource.com/nes/supermariobros/asset/65962/) | Question blocks and brick/block states. Runtime block behavior is in `entities/` and `sprites/Animations.json`. |
| Items, Objects and NPCs | `img/smb1_source/items_objects_sheet.png` | [52569](https://www.spriters-resource.com/nes/supermariobros/asset/52569/) | Coin, power-ups, flag, spring, Princess/Toad, and other world objects. Runtime item manifests include `sprites/NewItems.json`, `sprites/ItemAnimations.json`, `sprites/SMB1ObjectVariants.json`, and `sprites/Princess.json`. |
| Tileset | `img/smb1_source/tileset_sheet.png` | [52571](https://www.spriters-resource.com/nes/supermariobros/asset/52571/) | Ground, pipes, water, scenery, blocks, palette references, and assembled structures. Runtime tile bindings are in `sprites/BackgroundSprites.json`, `sprites/NewTiles.json`, and `sprites/SMB1Scenery.json`. |
| Vine Top | `img/smb1_source/nesmaps_vine_top.png` | [NESMaps SMB1 sprites](https://nesmaps.com/maps/SuperMarioBrothers/sprites/SuperMarioBrothersSprites.html) | Exact 14×95 beanstalk source, cut without scaling into native 16×16 `smb1_vine_tip` and `smb1_vine_segment` tiles by `tools/extract_smb1_vine.py`; runtime art is in `sprites/SMB1Scenery.json`. |
| Background: mountains | `img/smb1_source/background_mountains.png` | [164123](https://www.spriters-resource.com/nes/supermariobros/asset/164123/) | Hills and clouds in six palette rows; transparent cutouts are generated by `tools/extract_smb1_scenery.py` into `img/smb1_cutouts/`. |
| Background: trees | `img/smb1_source/background_trees.png` | [164124](https://www.spriters-resource.com/nes/supermariobros/asset/164124/) | Six palette rows of round/oval/tall trees and fences are cut out by `tools/extract_smb1_tree_scenery.py` into `img/smb1_cutouts/`; the tall underwater plant is used in endless water scenes. |
| Background: clouds | Available from source | [164125](https://www.spriters-resource.com/nes/supermariobros/asset/164125/) | Additional cloud/background reference. The active procedural cloud shapes currently use the mountain-sheet cutouts. |
| Title Screen, HUD and Miscellaneous | Not present as a named source-sheet PNG | [56929](https://www.spriters-resource.com/nes/supermariobros/asset/56929/) | Reference for title/HUD/miscellaneous elements. The current HUD is implemented by `classes/Dashboard.py`; this collection has not been downloaded into `img/smb1_source/`. |
| World 1-1 reference | `img/smb1_source/levels/World1-1.png` | [20592](https://www.spriters-resource.com/nes/supermariobros/asset/20592/) | Tile placement and course-composition reference. |
| World 1-1 through World 8-4 | `img/smb1_source/levels/World*.png` (32 maps) | [Stages index](https://www.spriters-resource.com/nes/supermariobros/) | Reference for the 32 original game maps. Matching playable maps are represented by `levels/World*.json`; picker entries are authored in `classes/Menu.py`. |
| World -1 / World -3 (FDS) | Not present | [Stages index](https://www.spriters-resource.com/nes/supermariobros/) | Famicom Disk System bonus/glitch-stage references, outside the 32-stage NES campaign. |

### Sprite and object behavior roster

| Family / source frames | In-game role | Runtime implementation / usage |
| --- | --- | --- |
| Mario and Luigi: small/big idle, walk, jump, break, death; swim strokes; grow/shrink; climb | Player movement, water movement, power-up transitions, damage, death, and flagpole/pipe transitions | `entities/Mario.py`, `sprites/Mario.json`, `sprites/Luigi.json`, `sprites/SwimSprites.json`; swimming uses two alternating strokes for small/big forms. |
| Goomba: normal, underground, castle; walk and flattened | Walks toward player; stomp flattens; contact damages Mario | `entities/Goomba.py`, `sprites/Goomba.json`; biome palette selection is handled by `classes/Level.py`. |
| Koopa Troopa: green/red; normal, underground/castle; walking, shell, shell-with-legs; Paratroopa | Walks or flies; stomped into shell; shell is kicked and can defeat enemies | `entities/Koopa.py`, `sprites/Koopa.json`, `sprites/SMB1ObjectVariants.json`. The SMB1 red/green Paratroopa GIF references are now split into two native 16×24 transparent frames each in `img/smb1_cutouts/` and registered by `sprites/ParatroopaFrames.json`; Infinity spawning and flight/de-wing behavior are implemented by `entities/KoopaParatroopa.py` and `classes/Level.py`. |
| Buzzy Beetle: normal, underground, castle; walk and shell | Walks; stomped into shell; fire-resistant enemy | `entities/BuzzyBeetle.py`, `sprites/NewEnemies.json`. |
| Hammer Bro and hammer | Throws projectile arcs while jumping/standing; touch/hammer can hurt player | `entities/HammerBro.py`, `entities/HammerProjectile.py` if present, `sprites/NewEnemies.json`. |
| Lakitu, Spiny, Spiny egg | Lakitu hovers and throws eggs; egg becomes Spiny; Spiny is a non-stompable ground enemy | `entities/Lakitu.py`, `entities/Spiny.py`, `sprites/NewEnemies.json`. |
| Cheep-Cheep: red and gray; swimming/flying pose | Swims in water; can also leap over water in selected above-water courses | `entities/CheepCheep.py`, `sprites/NewEnemies.json`. |
| Blooper | Tracks/swims toward Mario underwater | `entities/Blooper.py`, `sprites/NewEnemies.json`. |
| Piranha Plant: overworld and underground/castle palette | Rises from pipes, pauses, retreats; pipe proximity should suppress its appearance | `entities/PiranhaPlant.py`, `sprites/NewEnemies.json`; pipe placement is handled in `classes/Level.py`. |
| Bullet Bill and Bill Blaster | Blaster launches a horizontal projectile; collision hurts Mario | `entities/BillBlaster.py`, `entities/BulletBill.py`, `sprites/NewEnemies.json`. |
| Podoboo / Lava Bubble | Leaps from lava and falls back | `entities/Podoboo.py`, `sprites/NewEnemies.json`. |
| Bowser, Bowser fireball, bridge, axe | Final-area boss/projectile; axe removes bridge and drops Bowser | `entities/Bowser.py`, `entities/FireBolt.py`, stage objects, `sprites/Bowser.json`, `sprites/SMB1ObjectVariants.json`. |
| Mushroom, Fire Flower, Super Star, 1-Up | Grow, grant fire power, temporary invulnerability, or extra life | `entities/Mushroom.py`, `entities/FireFlowerCollectible.py`, `entities/SuperStar.py`, `entities/OneUpMushroom.py`, `sprites/NewItems.json`; in classic SMB, power-ups emerge from blocks rather than being randomly suspended in air. |
| Coin and coin trails | Adds score/coin count; 100 coins grant a life in SMB | `entities/Coin.py`; coin blocks and bricks are entities/blocks in `classes/Level.py`. |
| Question block, brick, hard block, empty block | Question blocks dispense configured contents; bricks break or dispense coins/items; hard blocks are solid | `entities/RandomBox.py`, `entities/BrickBlock.py`, `entities/CoinBox.py`, `entities/CoinBrick.py`; biome tile art uses `sprites/NewTiles.json`. |
| Pipe and warp pipe | Solid pipe geometry; selected pipes contain Piranha Plants or transport Mario to another area | `classes/Level.py` and `entities/PiranhaPlant.py`. |
| Flagpole, castle, fireworks, cloud/mountain/tree backgrounds | Level goal and scenery; fireworks depend on timer/coin-count conditions | `sprites/SceneryExtras.json`, `sprites/SMB1Scenery.json`, `classes/Level.py`, `classes/Menu.py`. |
| Underwater coral / sea plants | Decorative, non-solid scenery rooted at the seabed; should not float in the middle of a room | Small standalone coral is in `sprites/NewTiles.json`. The tall coral is `img/smb1_cutouts/smb1_underwater_coral_tall.png` (`16×48` source pixels, displayed `32×96`) and exposed as `coral_tall`. Original tree-sheet plants are `smb1_underwater_tree_round`, `smb1_underwater_tree_oval`, and `smb1_underwater_tree_tall` (`14×30`, `14×30`, and `16×46` source pixels). The endless underwater generator now selects the tall plant and coral, rooted to the seabed, alongside the small coral. Extraction is reproducible with `tools/extract_smb1_underwater_coral.py` and `tools/extract_smb1_tree_scenery.py`. |
| Mushroom platforms, hills, trees, clouds, fences | Decorative platform structures or background scenery; platforms block/hold Mario, scenery is non-solid | `classes/Level.py`, `sprites/SMB1Scenery.json`, `sprites/BackgroundSprites.json`. Six palette variants of clouds/hills are extracted into `img/smb1_cutouts/`. |
| Fire Bar / fireballs | Rotating hazard with fixed angular motion and projectile collision | `entities/FireBar.py`, `entities/FireBolt.py`, `entities/FireBurst.py`, `sprites/FireBarSprites.json`, `sprites/FireEffects.json`. |
| Springboard | Compresses on contact and launches player upward | The authentic 16×31 idle cutout in `img/smb1_cutouts/smb1_springboard.png` is bound in `sprites/SMB1ObjectVariants.json`. The source only provides an idle pose; `entities/Springboard.py` implements a timed compression and launch without inventing replacement pixels, and Infinity spawns it rarely in supported land biomes. |
| Fireworks | End-of-level celebration under timer/coin conditions | A source image exists in `img/wiki_assets/SMB_Sprite_Firework.png`, but no runtime sprite manifest or effect currently uses it. |

### Cutout notes

- `img/smb1_source/` keeps the downloaded reference sheets unchanged.
- `img/smb1_cutouts/` contains 75 individually named source cutouts: 42 palette-specific cloud/hill pieces, nine earlier character/object cutouts, and 24 palette-specific tree/fence pieces. It also contains an atlas and preview. The scenery extractors remove their exact matte colors while preserving source pixels and transparency; they do not rescale.
- Running `python tools/extract_smb1_reference_sprite_components.py` recreates `img/smb1_source/reference_cutouts/` with 900 unique transparent reference crops from five original sheets, covering 1,107 source records; 207 exact duplicates map back to the shared crop. `catalog.json` records source rectangles, dimensions, family/role/state notes, matte colors, hashes, and duplicate mappings. These crops remain outside runtime manifests to avoid replacing or duplicating current game art.
- `tools/extract_smb1_reference_sprite_components.py` reproduces the component and tile cutouts. A catalog-driven integrity pass verified every named file, dimensions, hashes, and nonempty alpha with zero issues.
- The 34 stage references listed on the site include 32 regular stages plus two FDS entries. The workspace has all 32 regular stage images and no local FDS maps.
- Some downloadable sprite collections are composite labeled sheets, not clean transparent production sprite sheets. Keep those originals as references; export individual crops only where the crop bounds and matte colors are verified. Avoid replacing correct per-biome color variants with a crop from a different palette.
- All downloaded original sheet sources and their uploader credit are recorded in [SMB1 reference sheets](#smb1-reference-sheets).

### Remaining uncropped source regions

The original sheets remain unchanged. The character, enemy, object, item-block, and tileset sheets now have reference crops; these are exact matte-keyed connected components or occupied 16×16 source cells, not all guaranteed to correspond one-to-one with a complete animation frame. Existing runtime sprites often use already isolated art from other sources. The source-region inventory is intentionally explicit so coverage is not overstated.

| Source sheet | Uncropped source bounds | What is still not individually cut from this sheet | Current coverage note |
| --- | --- | --- | --- |
| `mario_luigi_sheet.png` (584×469) | 124 unique transparent crops / 156 source-component records in `reference_cutouts/mario_luigi/`. The assembled tilemap `(136,218)-(264,304)` and text/code panel `(264,218)-(584,320)` remain uncropped. | A few merged/explanatory elements around the central diagrams are not individual player poses. Exact source bounds and duplicate mappings are in `catalog.json`. | Crops cover small/big player poses, fire-powered palettes, transitions and palette-preview poses. Runtime movement remains bound to the project's existing manifests; the reference archive avoids changing runtime art. |
| `enemies_sheet.png` (436×530) | 131 unique files / 133 source-component records in `reference_cutouts/enemies/`; crop details in `catalog.json`. Uncropped: tilemap panel `(298,0)-(436,104)` and palette/credit panel `(0,415)-(436,530)`. | Remaining joined/ambiguous visual components and source text/table regions. The extracted component files are not all known to be complete full animation frames. | Families include ground-enemy palette cells, green-enemy poses, castle palette frames, and red-enemy palette frames. Runtime enemy behavior and art mostly exist through other sprite sources; the reference cutouts preserve this sheet’s distinct palette art for future review. |
| `item_blocks_sheet.png` (448×256) | 70 unique files / 120 occupied-cell records from gridded regions, in `reference_cutouts/item_block_tiles/`. Uncropped loose/ambiguous top `(0,0)-(448,112)`, captions/gutters, and non-grid areas are itemized in `catalog.json`. | Loose upper debris/decoration fragments and caption/blank regions; those cannot be confidently reconstructed as complete block states from this sheet alone. | Individual source cells are 16×16 and preserved without resizing. They show question, brick, hard-block, and castle palette tiles; runtime behavior continues to use existing game classes/art. |
| `items_objects_sheet.png` (592×572) | 78 unique files / 186 component records from left panel `(0,0)-(306,470)`, in `reference_cutouts/items_objects/`. Right demonstration/palette panel `(306,0)-(592,572)` remains uncut. | The right-side diagrams combine object examples, block palettes, score glyphs, and captions, so they are not safe to split into independent gameplay sprites. Some left-panel separated components may be parts of frames rather than complete objects. | Crop family/role tags separate overworld, underground, castle, underwater, and end-of-castle art. Common power-ups, coins, flagpole, and Princess already have runtime art. The springboard has an alpha-cleaned idle sprite and timed compression/launch behavior. |
| `tileset_sheet.png` (680×776) | 497 unique transparent 16×16 crops / 512 source-cell records in `reference_cutouts/tileset_tiles/` across seven clearly gridded palette regions. Exact region bounds and roles are in `catalog.json`. | Palette charts/notes `(296,176)-(680,596)`, variant reference `(0,432)-(296,596)`, assembled mixed-size structures `(0,596)-(680,776)`, labels, and gutters remain as source references. The separate tall underwater coral cut `(312,640)-(328,688)` is retained in `img/smb1_cutouts/`. | Grid cutouts cover ground/stone, sky/water, coin/block, and biome scenery tiles. They remain reference assets; existing runtime manifests are unchanged. The tall coral cut is already integrated into the procedural underwater scenery. |
| `background_trees.png` (768×1660) | Tree/fence crops are covered in 24 files; cloud regions repeat the cloud silhouettes already extracted from the mountain sheet. | Non-distinct repeated clouds and the explanatory/palette legend. | All six themes now have round tree, oval tree, tall tree, and fence-run crops. The underwater tall plant is selected in the procedural generator and rooted at seabed height. |
| `background_clouds.png` (768×1129) | Cloud placements at x≈56–104, 152–184, 296–344, 456–488, 568–600, and 616–648 in each of four palette rows; legends below the cloud rows. | No unique cloud silhouette remains after comparing with the named cloud cutouts; the sheet contains repeated copies/placements. | Existing small/medium/wide cuts from `background_mountains.png` cover the distinct silhouette classes. |
| `background_mountains.png` (768×1660) | No remaining gameplay-scenery source regions from the 6×7 cloud/hill crop grid used by `tools/extract_smb1_scenery.py`; legend remains. | Palette notes and color-key legend only. | 42 hill/cloud variants are individually named in the scenery manifest. |


### Additional SMB1 movement and obstacle art

The [Super Mario Wiki SMB1 asset-category audit](#super-mario-wiki-smb1-asset-category-audit)
compares all 178 category listings by family and records the source-page status
for every entry. The Search service returned 98 pages; 80 page requests failed
with cache misses and remain explicitly unverified. Verified Blooper, gray
Cheep-Cheep, underground Hammer Bro, and axe GIF frames are preserved as
native-size transparent cuts and wired to the matching runtime animations or
palette. Climbing character poses and other GIF-only states will be added only
after their frame identity and palette are verified.

## SMB Maker atlas coverage

The source atlas is a 1369×3160 indexed image. The cutout tool writes
coordinate-preserving 16×16 crops and paged contact sheets to the ignored
`img/maker_tileset_cutouts/` directory. Run `python tools/extract_maker_tileset.py`
to generate them. The resulting `catalog.json` links each image to its source
coordinate, inferred theme region, and day/night band. The current atlas-cell
pass yields 6,381 unique occupied cells. This is an inspection archive, not a
runtime sprite manifest: the source includes labels, grid layout, animation
frames, repeated palette art, and pieces of larger constructions.

### Existing game support

The game already handles question/coin blocks, breakable bricks, hard blocks,
pipes, moving platforms, firebars, vines, ice clusters, underwater movement,
scenery overlays, trees, bushes, and fences. Existing sprite definitions and
entity behavior remain the reliable runtime source for those features.

The atlas visibly includes additional ON/OFF blocks, conveyor-like surfaces,
track pieces, slope pieces, and theme-specific terrain. The source art alone is
not enough to add these as working objects. ON/OFF blocks need a shared switch
state and collision updates; conveyors need player/enemy surface motion; tracks
need path-following entities; slopes need a new collision surface model. A 16×16
cell cut may be only one segment of these larger structures.

### Integration rule

Promote a crop only after checking it against the original atlas and neighboring
cells. Use current static tile or scenery hooks for complete non-interactive
art. Keep theme and day/night variants explicit. Add a gameplay entity and level
format only when the associated behavior is implemented. Do not load the full
cutout archive in `classes/Sprites.py`: it contains thousands of cells and would
inflate startup and memory for atlas fragments that gameplay cannot use.

## Super Mario Wiki SMB1 asset-category audit

Audit date: 2026-11-12. Source: [Category:Super Mario Bros. assets](https://www.mariowiki.com/Category:Super_Mario_Bros._assets), which currently lists 178 files. Every individual file-page URL was requested via the Search service. The service returned content for 98 pages and cache-miss errors for 80; see the per-file checklist below. Individual descriptions, provenance, dimensions, animation details, and quality flags are assessed where returned; blocked pages are explicitly left unverified.

The project's exact-game reference sheets from [The Spriters Resource SMB1 page](https://www.spriters-resource.com/nes/supermariobros/) remain the canonical pixel source when they provide an unambiguous NES frame. The Wiki files are used to fill documented small animation and palette gaps, without resizing/recoloring.

### Added, native-size frames

| Family | Runtime keys | New cutouts | Source and notes |
| --- | --- | --- | --- |
| Blooper | `blooper-1`, `blooper-2` | `img/smb1_cutouts/smb1_blooper_pose_1.png`, `_2.png` | [Source GIF](https://www.mariowiki.com/File:SMB_Blooper_Sprite.gif), 16×24. Three-frame GIF contains two unique images; duplicate frame omitted. Existing `blooper` static key remains. |
| Gray Cheep-Cheep | `cheep_cheep_gray-1`, `cheep_cheep_gray-2` | `img/smb1_cutouts/smb1_cheep_cheep_gray_1.png`, `_2.png` | [Source GIF](https://www.mariowiki.com/File:GreyCheepCheep.gif), 16×16. Adds the authentic gray underwater swimmer variant missing from the runtime set (which had red swimmer and green jumper art). |
| Underground Hammer Bro | `hammer_bro_underground-1`, `hammer_bro_underground-2` | `img/smb1_cutouts/smb1_hammer_bro_underground_1.png`, `_2.png` | [Source GIF](https://www.mariowiki.com/File:SMB_Hammer_Bro_Underground.gif), 16×24. Dark/cyan palette variant; it does not solve the missing distinct normal Hammer Bro animation pose. |
| Red/green Paratroopa | `koopa_paratroopa_red-1/-2`, `koopa_paratroopa_green-1/-2` | Existing cutouts in `img/smb1_cutouts/` | [Red](https://www.mariowiki.com/File:SMB_Red_Koopa_Paratroopa_Sprite.gif) and [green](https://www.mariowiki.com/File:SMB_Green_Koopa_Paratroopa_Sprite.gif) source GIFs. Added in the preceding asset pass and registered in `sprites/ParatroopaFrames.json`; static compatibility keys remain. |
| Vine | `smb1_vine_tip`, `smb1_vine_segment` | Existing cutouts in `img/smb1_cutouts/` | Exact source from [NESMaps SMB sprite reference](https://nesmaps.com/maps/SuperMarioBrothers/sprites/SuperMarioBrothersSprites.html), integrated by parent. |
| Springboard | Existing static key | Existing alpha-cleaned cutout | [Source page](https://www.mariowiki.com/File:SMB_Trampoline_Sprite.png) supplies one 16×31 full-height pose only; no authentic compressed/extended frames were present in this category. |

New Wiki GIF frames are registered in `sprites/SMB1WikiFrames.json`; original source links are in [SMB1 reference sheets](#smb1-reference-sheets).

### Category coverage by family

This is a family-level pass over all 178 category entries, not a claim that every image has had its individual file page inspected. Equivalent authentic art may come from the local Spriters Resource/NESMaps source sheets rather than a duplicate Wiki file.

| Category content | Coverage in this repository | Gaps / caveats |
| --- | --- | --- |
| Mario/Luigi poses, power states, swimming, death, invincibility, growth | Runtime Mario/Luigi and swimming manifests contain the core NES art and swimming frame strips. Several Wiki entries are duplicate individual poses or alternate Classic NES recolors. | No clean, separable SMB1 vine-climb Mario/Luigi pose was found in the category. `Firemarioclimb.gif` is a 20×52 Mario-plus-vine composite, not a native standalone character frame. Vine climbing currently must animate from existing character poses unless a verified original frame is sourced. |
| Goomba, Koopas/shells, Paratroopas, Buzzy Beetle, Spiny/egg, Lakitu, Hammer Bro, Cheep-Cheep, Blooper, Piranha Plant, Podoboo | Static core sprites and most behaviors/art already exist in local manifests/entities. Paratroopa, Blooper, gray Cheep-Cheep, and underground Hammer Bro frames are registered and used by their matching runtime entities. | Normal Hammer Bro still needs an authentic second pose; Wiki throwing GIF is explicitly flagged inaccurate. Lakitu throwing composite GIF is explicitly flagged inaccurate. |
| Blocks, coins, power-ups, pipes, ground and water tiles | Core block/item/tile artwork is represented by local manifests and the original source sheets. Wiki category contains several environment-specific duplicates (castle/underground/underwater variants) and alternate-size coin/explosion assets. | This pass did not compare every individual pixel crop in these duplicate files against every local crop. Room transitions, hidden-room behavior, and all palette-specific placements remain gameplay work, not an art-presence conclusion. |
| Castle, bridge, axe, goal pole/flag, lifts/platforms, firebar, fortress/cannon | Core source art and several objects are represented locally; fortress bridge/axe, firebar, mushroom platform and goal artwork have runtime asset entries. | Large composite castle/scale-lift/fortress images in the category need purpose-specific crop validation before use. Infinity's optional bridge/axe behavior exists; classic goal completion remains separate. |
| Logos, icons, CHR map, game-specific screenshots/reference graphics | Source/reference items in the category are not gameplay sprites; relevant title/menu art is handled separately. | 3DS VC icon, alternate logo variants, CHR map, and screenshot-like composites are not added to the gameplay atlas. |
| SMB3, The Lost Levels, and non-SMB1 duplicates/variants | Identified as outside the target SMB1 NES art set. | `SMB3 Cloud Block tile alt.png`, TLL island variants, and platform/console-specific alternate images are intentionally not used as SMB1 replacements. |

### Reviewed and intentionally skipped animation candidates

- [SMB Hammer Bro Throwing Hammer Sprite.gif](https://www.mariowiki.com/File:SMB_Hammer_Bro_Throwing_Hammer_Sprite.gif), 28×40, 5 frames: the file page marks it poor quality/inaccurate. Its composite dimensions also do not map cleanly to individual 16×24 NES character poses. Kept as raw reference only.
- [SMB Lakitu Throwing Spiny Sprites.gif](https://www.mariowiki.com/File:SMB_Lakitu_Throwing_Spiny_Sprites.gif), 36×45, 6 frames: file page marks it poor quality/inaccurate and it is a multi-sprite composite. Kept as raw reference only.
- [Firemarioclimb.gif](https://www.mariowiki.com/File:Firemarioclimb.gif), 20×52, 16 frames: contains a composite vine and Mario pose sequence with vine pieces shifting/interleaving. No ambiguous segmentation was made; the source page remains available for reference.
- [SMB Trampoline Sprite.png](https://www.mariowiki.com/File:SMB_Trampoline_Sprite.png), 16×31: only a single full-height board image is supplied. No compressed/extended art was fabricated.
- Wiki static gray Cheep-Cheep image is superseded for animation by the two-frame gray GIF above; existing red Cheep-Cheep assets remain for the red swimming variant.

### Remaining asset gaps

1. Authentic small and big Mario/Luigi vine-climb frames (separate from vine art).
2. A verified second normal Hammer Bro animation pose and authentic throw animation (current candidate GIF is inaccurate).
3. Verified Lakitu/Spiny throwing pose states (candidate composite GIF is inaccurate).
4. Authentic compressed and extended springboard poses, if the runtime is expected to show distinct board art rather than transform the single source pose.
5. Additional frame-level comparison of Wiki duplicate/background variants against each local sheet crop; this first pass does not certify pixel identity for all 178 files.

### Scope/source-page note

The category's full 178-file listing was checked for family coverage. All 178 page requests were attempted; 98 pages returned and 80 failed with search-cache misses. The latter cannot be described as individually inspected: only their category listing entries and dimensions were available. Relevant returned-page findings and unverified candidates are documented below. The additions above do not rely on AI-generated artwork.
+
### Individual file-page checklist (178 entries)

I sent an individual page request for each category entry, using category links and direct File URLs. **98 pages returned** through the Search service and **80 returned cache-miss errors**. Page access is recorded below; source-page findings above and below document the actionable reviewed details. The 80 blocked pages are not marked as source-page-reviewed. Their category-list dimensions remain available, but descriptions, histories, and quality flags could not be verified from their file pages.

| Category file | Individual page result |
| --- | --- |
| Bill Blaster Sprite SMB.png | Page returned; source page reachable |
| Bullet Bill Super Mario Bros.png | Page returned; source page reachable |
| Buzzy Beetle SMB.png | Page returned; source page reachable |
| BuzzyBeetleSMBUnderground.gif | Blocked: page fetch returned cache miss |
| ClassicNES SMB Fire Mario Sprite.png | Blocked: page fetch returned cache miss |
| ClassicNES SMB Small Luigi Sprite.png | Page returned; source page reachable |
| ClassicNES SMB Small Mario Sprite.png | Page returned; source page reachable |
| ClassicNES SMB Super Luigi Sprite.png | Blocked: page fetch returned cache miss |
| ClassicNES SMB Super Mario Sprite.png | Page returned; source page reachable |
| Fire Flower SMB.gif | Page returned; source page reachable |
| FireMario Shoot.png | Blocked: page fetch returned cache miss |
| Firemarioclimb.gif | Blocked: page fetch returned cache miss |
| FireRodSMB.gif | Page returned; source page reachable |
| Goomba SMB.png | Page returned; source page reachable |
| GoombaSMBGrey.gif | Blocked: page fetch returned cache miss |
| Green Koopa Troopa SMB.gif | Page returned; source page reachable |
| GreyCheepCheep.gif | Blocked: page fetch returned cache miss |
| Invincible Mario.gif | Page returned; source page reachable |
| KoopaParatroopaGreenDark.gif | Blocked: page fetch returned cache miss |
| LargeFortressSMB.png | Page returned; source page reachable |
| MariotoSuperMario.gif | Page returned; source page reachable |
| Piranha Plant Underwater.png | Blocked: page fetch returned cache miss |
| PiranhaPlant SMB Sprite.gif | Page returned; source page reachable |
| Podoboo Sprite SMB.png | Page returned; source page reachable |
| Small Luigi Walk SMB.gif | Blocked: page fetch returned cache miss |
| SmallFireMarioJump.png | Blocked: page fetch returned cache miss |
| SmallinvincibleMario.gif | Blocked: page fetch returned cache miss |
| SMB 1-up Mushroom Sprite 2.png | Blocked: page fetch returned cache miss |
| SMB 1-up Mushroom Sprite.png | Page returned; source page reachable |
| SMB 2ndCHRMap World36.png | Blocked: page fetch returned cache miss |
| SMB 3DS Virtual Console Icon.png | Page returned; source page reachable |
| SMB Axe.gif | Page returned; source page reachable |
| SMB Background Brick Block.png | Blocked: page fetch returned cache miss |
| SMB Background Underwater Brick Block.png | Page returned; source page reachable |
| SMB Blooper Sprite.gif | Page returned; source page reachable |
| SMB Bowser Breathing Fire Sprite.gif | Page returned; source page reachable |
| SMB Bowser Bridge.png | Page returned; source page reachable |
| SMB Bowser Sprite.png | Page returned; source page reachable |
| SMB Bowser Walking Sprite.gif | Page returned; source page reachable |
| SMB Brick Block Sprite.png | Page returned; source page reachable |
| SMB Bridge.png | Page returned; source page reachable |
| SMB Bullet Bill 6-3.png | Blocked: page fetch returned cache miss |
| SMB Buzzy Beetle Castle Sprite.gif | Blocked: page fetch returned cache miss |
| SMB Buzzy Shell Castle.png | Blocked: page fetch returned cache miss |
| SMB Buzzy Shell Underground.png | Blocked: page fetch returned cache miss |
| SMB Buzzy Shell.png | Blocked: page fetch returned cache miss |
| SMB Castle Brick Block.png | Blocked: page fetch returned cache miss |
| SMB Castle Question Block.png | Page returned; source page reachable |
| SMB Climbable Ball Sprite.png | Blocked: page fetch returned cache miss |
| SMB Coin Heaven Lift.png | Blocked: page fetch returned cache miss |
| SMB CoinCastle.gif | Blocked: page fetch returned cache miss |
| SMB CoinUnderground.gif | Blocked: page fetch returned cache miss |
| SMB CoinUnderwater.gif | Blocked: page fetch returned cache miss |
| SMB Dead Goomba.png | Page returned; source page reachable |
| SMB Fire Mario Ducking.png | Blocked: page fetch returned cache miss |
| SMB Fire Mario Jumping.png | Page returned; source page reachable |
| SMB Fire Mario Sprite.png | Page returned; source page reachable |
| SMB Fire Mario Walking.gif | Page returned; source page reachable |
| SMB fortress flag.png | Page returned; source page reachable |
| SMB Fortress.png | Page returned; source page reachable |
| SMB Goal Pole.png | Page returned; source page reachable |
| SMB Goomba Castle Dead.png | Blocked: page fetch returned cache miss |
| SMB Goomba Sprite.gif | Page returned; source page reachable |
| SMB Goomba Underground Dead.png | Blocked: page fetch returned cache miss |
| SMB Green Horsetail Short.png | Page returned; source page reachable |
| SMB Green Horsetail Tall.png | Page returned; source page reachable |
| SMB Green Koopa Paratroopa Sprite.gif | Page returned; source page reachable |
| SMB Green Koopa Troopa Sprite.png | Page returned; source page reachable |
| SMB Greenshell.png | Blocked: page fetch returned cache miss |
| SMB Ground Castle.png | Page returned; source page reachable |
| SMB Ground Underground.png | Blocked: page fetch returned cache miss |
| SMB Ground Underwater Castle.png | Blocked: page fetch returned cache miss |
| SMB Ground Underwater.png | Blocked: page fetch returned cache miss |
| SMB Ground.png | Page returned; source page reachable |
| SMB Hammer Bro Sprite.png | Page returned; source page reachable |
| SMB Hammer Bro Throwing Hammer Sprite.gif | Page returned; source page reachable |
| SMB Hammer Bro Underground.gif | Blocked: page fetch returned cache miss |
| SMB Hard Block Sprite.png | Page returned; source page reachable |
| SMB In-game Logo.png | Blocked: page fetch returned cache miss |
| SMB Lakitu Sprite.png | Page returned; source page reachable |
| SMB Lakitu Throwing Spiny Sprites.gif | Page returned; source page reachable |
| SMB Luigi Death Sprite.png | Blocked: page fetch returned cache miss |
| SMB Mario walking sprite.png | Page returned; source page reachable |
| SMB Mushroom Platform.png | Page returned; source page reachable |
| SMB Mushroom Retainer Sprite.png | Page returned; source page reachable |
| SMB NES Blue Koopa Troopa Walking.gif | Blocked: page fetch returned cache miss |
| SMB NES Luigi Running.gif | Page returned; source page reachable |
| SMB NES Mario Death Sprite.png | Page returned; source page reachable |
| SMB NES Mario Walking Sprite.gif | Page returned; source page reachable |
| SMB Piranha Plant Underground Sprite.gif | Page returned; source page reachable |
| SMB Piranha Plant Underground Sprite.png | Blocked: page fetch returned cache miss |
| SMB Princess Toadstool Sprite.png | Page returned; source page reachable |
| SMB Qblock.png | Page returned; source page reachable |
| SMB QBlockUW.png | Blocked: page fetch returned cache miss |
| SMB Question Block.gif | Page returned; source page reachable |
| SMB QuestionBlockCastleAnim.gif | Page returned; source page reachable |
| SMB QuestionBlockUndergroundAnim.gif | Page returned; source page reachable |
| SMB QuestionBlockUnderwaterAnim.gif | Blocked: page fetch returned cache miss |
| SMB Red Koopa Paratroopa Sprite.gif | Blocked: page fetch returned cache miss |
| SMB Red Koopa Troopa.gif | Page returned; source page reachable |
| SMB Redshell.png | Blocked: page fetch returned cache miss |
| SMB Scale Lift sprite.png | Blocked: page fetch returned cache miss |
| SMB Small Luigi Jumping.png | Blocked: page fetch returned cache miss |
| SMB Small Luigi Sprite.png | Page returned; source page reachable |
| SMB Small Mario Jumping Sprite.png | Page returned; source page reachable |
| SMB Smallfiremario.png | Blocked: page fetch returned cache miss |
| SMB Smallmario.png | Page returned; source page reachable |
| SMB Spiny Sprite.gif | Page returned; source page reachable |
| SMB Sprite 1UP.png | Blocked: page fetch returned cache miss |
| SMB Sprite Axe.png | Page returned; source page reachable |
| SMB Sprite Blooper.png | Blocked: page fetch returned cache miss |
| SMB Sprite Bowser's Flame.png | Page returned; source page reachable |
| SMB Sprite Cheep Cheep (Gray).png | Page returned; source page reachable |
| SMB Sprite Cheep Cheep (Red).png | Page returned; source page reachable |
| SMB Sprite Coin.png | Page returned; source page reachable |
| SMB Sprite Coral.png | Blocked: page fetch returned cache miss |
| SMB Sprite Fire Bar.png | Blocked: page fetch returned cache miss |
| SMB Sprite Fire Flower.png | Page returned; source page reachable |
| SMB Sprite Firework.gif | Blocked: page fetch returned cache miss |
| SMB Sprite Island (Gray).png | Page returned; source page reachable |
| SMB Sprite Island (Ground).png | Page returned; source page reachable |
| SMB Sprite Koopa Paratroopa (Green).png | Blocked: page fetch returned cache miss |
| SMB Sprite Koopa Paratroopa (Red).png | Page returned; source page reachable |
| SMB Sprite Koopa Troopa (Red).png | Page returned; source page reachable |
| SMB Sprite Lava.png | Blocked: page fetch returned cache miss |
| SMB Sprite Piranha Plant.png | Page returned; source page reachable |
| SMB Sprite Spiny Egg.png | Page returned; source page reachable |
| SMB Sprite Spiny.png | Page returned; source page reachable |
| SMB Sprite Super Star.png | Page returned; source page reachable |
| SMB Super Luigi Ducking.png | Page returned; source page reachable |
| SMB Super Luigi Jumping.png | Page returned; source page reachable |
| SMB Super Luigi Sprite.png | Page returned; source page reachable |
| SMB Super Mario Ducking.png | Page returned; source page reachable |
| SMB Super Mario Jumping.png | Page returned; source page reachable |
| SMB Super Mario Sprite.png | Page returned; source page reachable |
| SMB Supermushroom.png | Page returned; source page reachable |
| SMB Swimming Cheep Cheep Sprite.gif | Blocked: page fetch returned cache miss |
| SMB Trampoline Sprite.png | Blocked: page fetch returned cache miss |
| SMB TurtleCannonCastle.png | Blocked: page fetch returned cache miss |
| SMB TurtleCannonUnderground.png | Blocked: page fetch returned cache miss |
| SMB Underground Blooper.png | Page returned; source page reachable |
| SMB Underground Brick Block.png | Page returned; source page reachable |
| SMB Underground Hard Block.png | Blocked: page fetch returned cache miss |
| SMB Underground Question Block.png | Page returned; source page reachable |
| SMB Water.png | Blocked: page fetch returned cache miss |
| SMB White Horsetail Short.png | Blocked: page fetch returned cache miss |
| SMB White Horsetail Tall.png | Blocked: page fetch returned cache miss |
| SMB-GoombaWalking.gif | Page returned; source page reachable |
| SMB+DH SMB logo.png | Blocked: page fetch returned cache miss |
| SMB+DH+WCTM SMB in-game logo.png | Blocked: page fetch returned cache miss |
| SMB1 Empty Block.png | Page returned; source page reachable |
| SMB1 Sprite Coin.gif | Page returned; source page reachable |
| SMB3 Cloud Block tile alt.png | Blocked: page fetch returned cache miss |
| SMBBlueGoomba.gif | Page returned; source page reachable |
| SMBBowsersFlame.gif | Blocked: page fetch returned cache miss |
| SMBBuzzyBeetle.gif | Blocked: page fetch returned cache miss |
| SMBCastle.png | Page returned; source page reachable |
| SMBCoin.gif | Page returned; source page reachable |
| SMBFireBall.gif | Page returned; source page reachable |
| SMBFireBarLong.png | Blocked: page fetch returned cache miss |
| SMBFireBarWithoutBlock.png | Blocked: page fetch returned cache miss |
| SMBMarioGrowing.png | Page returned; source page reachable |
| SMBPlatform.png | Blocked: page fetch returned cache miss |
| SMBSuperLuigiSwimming.gif | Blocked: page fetch returned cache miss |
| SMBSuperMarioSwimming.gif | Page returned; source page reachable |
| SMBWarpPipeForked.png | Blocked: page fetch returned cache miss |
| SpinysEggs.gif | Blocked: page fetch returned cache miss |
| Starman.gif | Blocked: page fetch returned cache miss |
| TLL Sprite Island (Gray).png | Blocked: page fetch returned cache miss |
| TLL Sprite Island (Snowy).png | Blocked: page fetch returned cache miss |
| TLL Sprite Island (World 9).png | Blocked: page fetch returned cache miss |
| VineTop.png | Blocked: page fetch returned cache miss |
| Warp Pipe Gray SMB.png | Blocked: page fetch returned cache miss |
| Warp Pipe Orange SMB.png | Page returned; source page reachable |
| Warp Pipe SMB.png | Page returned; source page reachable |
| Warp Pipe Snow SMB.png | Blocked: page fetch returned cache miss |
| Warp Pipe Water SMB.png | Blocked: page fetch returned cache miss |
| Wnderwaterbrick.png | Blocked: page fetch returned cache miss |

### Additional verified page findings

- [SMB Axe.gif](https://www.mariowiki.com/File:SMB_Axe.gif) is 16×16, looped, five frames over 0.9 s, sourced to Super Mario Bros. Exact alpha-preserving frames are in `img/smb1_cutouts/smb1_axe_cycle_1.png` through `_5.png` and registered as `axe-1` through `axe-5` in `sprites/SMB1WikiFrames.json`. Frame durations are 150, 150, 150, 150, and 300 ms. Infinity's fortress axe now uses these as one replacing animation sequence, not five persistent sprites.
- [FireRodSMB.gif](https://www.mariowiki.com/File:FireRodSMB.gif) is an 88×88, 77-frame/3.8 s Fire Bar composite sourced to Super Mario Bros. Its composite is not a direct replacement for the runtime's piece-based rotating bar; treat as reference/possible timing evidence only.
- [SMB Bowser Breathing Fire Sprite.gif](https://www.mariowiki.com/File:SMB_Bowser_Breathing_Fire_Sprite.gif) is 69×42, 6 frames, and explicitly marked poor quality: inaccurate. Do not adopt it as runtime art.
- [SMB Background Underwater Brick Block.png](https://www.mariowiki.com/File:SMB_Background_Underwater_Brick_Block.png) has a file-history image-quality: needs transparency tag. Do not replace a clean local crop with it without alpha verification.
- [SMB Dead Goomba.png](https://www.mariowiki.com/File:SMB_Dead_Goomba.png) is a 16×8 squished-Goomba crop sourced to The Spriters Resource. The game already has a goomba-flat runtime key, so this is not a confirmed missing art item.
- [Green Koopa Troopa SMB.gif](https://www.mariowiki.com/File:Green_Koopa_Troopa_SMB.gif) is a 16×24 two-frame/0.3 s GIF sourced from screenshots, not a direct rip. Prefer existing exact NES reference-sheet cutouts unless visual comparison proves this is cleaner.
- [MariotoSuperMario.gif](https://www.mariowiki.com/File:MariotoSuperMario.gif) is 16×32, 10 frames/1.2 s and describes the small-to-super growth transition; [SMBMarioGrowing.png](https://www.mariowiki.com/File:SMBMarioGrowing.png) is 16×24 and says cropped/made transparent. These are potentially useful only if the current runtime lacks the exact growth transition; inspect pixels against the local original sheet before adopting.

The category page confirms all 178 entries belong to this asset category. A cache miss prevents confirming an individual page description/provenance/animation note for the blocked entries. No other art was downloaded or registered during this extended page audit.

## Retained demo sprite sheets

`mario_bros.png`, `item_objects.png`, `tile_set.png`, and `smb_enemies_sheet.png`
were relocated unchanged from the former
`PythonSuperMario DEMO/resources/graphics/` directory. Active sprite manifests
still use these images; the standalone demo code and unused resources were removed.

The bundled demo README identified its source as
[marblexu/PythonSuperMario](https://github.com/marblexu/PythonSuperMario), based on
[justinmeister/Mario-Level-1](https://github.com/justinmeister/Mario-Level-1).
This records the existing provenance; it does not assert new licensing rights.

## SMB1 reference sheets

These original-game reference sheets were downloaded from the Super Mario Bros. (NES) pages on The Spriters Resource on 2026-10-08. The source PNG sheets are kept unchanged under `img/smb1_source/`; generated cutouts are in `img/smb1_cutouts/`.

| Source sheet | Spriters Resource page |
| --- | --- |
| Mario & Luigi | https://www.spriters-resource.com/nes/supermariobros/asset/50365/ |
| Swimming (Small/Big) animated source frames | https://www.spriters-resource.com/nes/supermariobros/asset/50365/ |
| Enemies & Bosses | https://www.spriters-resource.com/nes/supermariobros/asset/52570/ |
| Item and Brick Blocks | https://www.spriters-resource.com/nes/supermariobros/asset/65962/ |
| Items, Objects and NPCs | https://www.spriters-resource.com/nes/supermariobros/asset/52569/ |
| Tileset | https://www.spriters-resource.com/nes/supermariobros/asset/52571/ |
| Background 1 (Mountains) | https://www.spriters-resource.com/nes/supermariobros/asset/164123/ |
| Background 2 (Trees) | https://www.spriters-resource.com/nes/supermariobros/asset/164124/ |
| Background 3 (Clouds) | https://www.spriters-resource.com/nes/supermariobros/asset/164125/ |
| World 1-1 reference image | https://www.spriters-resource.com/nes/supermariobros/asset/20592/ |

The sheets are credited on their source pages to Superjustinbros. SMB artwork and characters are Nintendo's intellectual property; the included sheets are for this project's private development and visual reference.

The transparent PNG frame strips in `img/smb1_source/swimming/` were cut from the swimming GIFs linked from the Mario & Luigi sheet. Luigi's strips use the Luigi palette from the same sheet.

### Additional SMB1 frame references

The two-frame red and green Koopa Paratroopa animations are preserved as
transparent 16×24 PNGs in `img/smb1_cutouts/`. They were exported without
resizing from these source GIFs:

- [Red SMB Paratroopa GIF](https://www.mariowiki.com/File:SMB_Red_Koopa_Paratroopa_Sprite.gif)
- [Green SMB Paratroopa GIF](https://www.mariowiki.com/File:SMB_Green_Koopa_Paratroopa_Sprite.gif)

Runtime keys are registered in
`sprites/ParatroopaFrames.json`; this supplements the existing static
Paratroopa entries and does not replace them.

The single full-height SMB1 springboard pose is cut into
`img/smb1_cutouts/smb1_springboard.png` from [the original reference image](https://www.mariowiki.com/File:SMB_Trampoline_Sprite.png).
The opaque red matte was keyed to alpha. The source provides only the idle pose, so compressed and extended
states must be drawn from the same native pixels at runtime or sourced
separately.


### Additional SMB1 Vine source

The 14×95 Vine Top sprite is preserved unchanged as `img/smb1_source/nesmaps_vine_top.png` from
[NESMaps' Super Mario Bros. sprite reference](https://nesmaps.com/maps/SuperMarioBrothers/sprites/SuperMarioBrothersSprites.html).
`tools/extract_smb1_vine.py` makes centered 16×16 alpha-preserving tip and stem
crops in `img/smb1_cutouts/`; source pixels are not rescaled or recolored.

### Super Mario Wiki animation references

Transparent PNG frames are exact native-size exports under `img/smb1_cutouts/`;
the new keys are registered in `sprites/SMB1WikiFrames.json`.

| Runtime keys | Source file page | Treatment |
| --- | --- | --- |
| `blooper-1`, `blooper-2` | [SMB Blooper Sprite.gif](https://www.mariowiki.com/File:SMB_Blooper_Sprite.gif) | Two unique 16×24 frames; the GIF's third frame duplicates its first. |
| `cheep_cheep_gray-1`, `cheep_cheep_gray-2` | [GreyCheepCheep.gif](https://www.mariowiki.com/File:GreyCheepCheep.gif) | Two 16×16 gray underwater-swimmer frames. |
| `hammer_bro_underground-1`, `hammer_bro_underground-2` | [SMB Hammer Bro Underground.gif](https://www.mariowiki.com/File:SMB_Hammer_Bro_Underground.gif) | Two 16×24 dark-palette frames. This is a palette/environment variant, not the missing normal throwing pose. |
| `axe-1` through `axe-5` | [SMB Axe.gif](https://www.mariowiki.com/File:SMB_Axe.gif) | Five 16×16 alpha-preserving frames; source durations are 150, 150, 150, 150, and 300 ms (0.9 s total). |

Reviewed but intentionally not registered as gameplay frames: [SMB Hammer Bro
Throwing Hammer Sprite.gif](https://www.mariowiki.com/File:SMB_Hammer_Bro_Throwing_Hammer_Sprite.gif)
and [SMB Lakitu Throwing Spiny
Sprites.gif](https://www.mariowiki.com/File:SMB_Lakitu_Throwing_Spiny_Sprites.gif)
are both labeled inaccurate/poor-quality on their source pages. [Firemarioclimb.gif](https://www.mariowiki.com/File:Firemarioclimb.gif)
is a 20×52 composite with vine art interleaved across its 16 frames, so it is
not used as a standalone Mario climb frame. All preserved category GIFs are
review references; their file pages should be checked individually before
using any unlisted variant.
