import os
import json
from pathlib import Path
import sys

import pygame


def make_mock_sound():
    class MockSound:
        def play_sfx(self, *a, **kw):
            pass
        def __getattr__(self, name):
            return None
    return MockSound()


def _capture_sky_color(biome):
    if biome in {"underground", "fortress", "firebar"}:
        return (0, 0, 0)
    return (92, 148, 252)


def _ground_surface_y(level, column):
    """Return the top of the solid ground stack in a column, or None for a pit."""
    if not level.level or not 0 <= column < len(level.level[0]):
        return None
    row = len(level.level) - 1
    if not _is_base_ground_tile(level, level.level[row][column]):
        return None
    while row > 0 and _is_base_ground_tile(level, level.level[row - 1][column]):
        row -= 1
    return row * 32


def _is_base_ground_tile(level, tile):
    """Exclude attached mushroom stems and elevated structures from floor data."""
    if tile is None or tile.rect is None or tile.sprite is None:
        return False
    return tile.sprite in {
        level.sprites.spriteCollection.get("ground"),
        level.sprites.spriteCollection.get("ground_underground"),
        level.sprites.spriteCollection.get("ground_underwater"),
        level.sprites.spriteCollection.get("castle_brick"),
    }


def _safe_stand(level, focus_column, biome, mario_height=32, radius=10):
    """Find nearby ground where Mario's full collision box has clear headroom."""
    width = len(level.level[0]) if level.level else 0
    for distance in range(radius + 1):
        offsets = (0,) if distance == 0 else (-distance, distance)
        for offset in offsets:
            column = focus_column + offset
            if not 0 <= column < width or level.columnBiomes[column] != biome:
                continue
            floor_y = _ground_surface_y(level, column)
            if floor_y is None:
                continue
            player_rect = pygame.Rect(column * 32, floor_y - mario_height, 32, mario_height)
            if any(
                tile.rect is not None and player_rect.colliderect(tile.rect)
                for row in level.level
                for tile in (row[column],)
            ):
                continue
            blocked_by_entity = False
            for entity in level.entityList:
                if type(entity).__name__ == "FireBar":
                    entity._advance_rotation()
                    collision_rects = entity.hitboxes
                else:
                    rect = getattr(entity, "rect", None)
                    collision_rects = (rect,) if rect is not None else ()
                if any(player_rect.colliderect(rect) for rect in collision_rects):
                    blocked_by_entity = True
                    break
            if blocked_by_entity:
                continue
            return column, floor_y
    return None


def main():
    os.environ["SDL_VIDEODRIVER"] = "dummy"
    pygame.init()
    SCREEN_W, SCREEN_H = 640, 480
    screen = pygame.display.set_mode((SCREEN_W, SCREEN_H))

    from classes.Dashboard import Dashboard
    from classes.Level import Level
    from classes.Camera import Camera
    from classes.Maths import Vec2D

    sound = make_mock_sound()
    dashboard = Dashboard("img/sheets/font.png", 8, screen)
    level = Level(screen, sound, dashboard)

    SEED = 123
    TOTAL_COLS = 9000
    FRAMES_PER_BIOME = 10
    BIOMES = (
        "normal", "canyon", "ice", "underground", "firebar",
        "fortress", "mushroom", "underwater",
    )
    out_dir = "test_frames"
    os.makedirs(out_dir, exist_ok=True)

    level.load_endless(seed=SEED, initial_columns=0)
    # This preview advances the world explicitly. Disable the live camera's
    # extra generation buffer so each image reflects the recorded column.
    level.endlessBuffer = 0
    for _ in range(TOTAL_COLS):
        level._append_column()

    candidates = {biome: [] for biome in BIOMES}
    for col in range(16, TOTAL_COLS - 16, 8):
        biome = level.columnBiomes[col]
        if biome in candidates and all(
            level.columnBiomes[index] == biome
            for index in range(col - 15, col + 16)
        ):
            candidates[biome].append(col)

    target_cols = []
    missing = []
    for biome in BIOMES:
        choices = candidates[biome]
        if len(choices) < FRAMES_PER_BIOME:
            missing.append(f"{biome} ({len(choices)}/10)")
            continue
        if biome == "firebar":
            hazard_columns = sorted({
                int(entity.center.x // 32)
                for entity in level.entityList
                if type(entity).__name__ == "FireBar"
                and 0 <= int(entity.center.x // 32) < len(level.columnBiomes)
                and level.columnBiomes[int(entity.center.x // 32)] == biome
                and all(
                    level.columnBiomes[index] == biome
                    for index in range(
                        max(0, int(entity.center.x // 32) - 15),
                        min(len(level.columnBiomes), int(entity.center.x // 32) + 16),
                    )
                )
            })
            if hazard_columns:
                hazard_samples = [
                    hazard_columns[
                        round(i * (len(hazard_columns) - 1) / (min(len(hazard_columns), FRAMES_PER_BIOME) - 1))
                    ]
                    for i in range(min(len(hazard_columns), FRAMES_PER_BIOME))
                ] if len(hazard_columns) > 1 else hazard_columns
                if len(hazard_samples) < FRAMES_PER_BIOME:
                    fill = [column for column in choices if column not in hazard_samples]
                    needed = FRAMES_PER_BIOME - len(hazard_samples)
                    hazard_samples.extend(
                        fill[round(i * (len(fill) - 1) / max(needed - 1, 1))]
                        for i in range(needed)
                    )
                target_cols.extend((biome, column) for column in hazard_samples)
                continue
        for i in range(FRAMES_PER_BIOME):
            sample = round(i * (len(choices) - 1) / (FRAMES_PER_BIOME - 1))
            target_cols.append((biome, choices[sample]))
    if missing:
        raise RuntimeError("Not enough biome samples: " + ", ".join(missing))

    frames_meta = []
    for biome, col in target_cols:
        stand = _safe_stand(level, col, biome)
        if stand is None:
            raise RuntimeError(f"No clear ground near {biome} sample at column {col}")
        player_column, player_floor_y = stand
        # The final generation frontier has its own biome; render using the
        # biome belonging to this saved sample instead.
        level.activeBiome = biome
        # Coin animation begins edge-on; snapshots should show its widest
        # frame so asset and placement errors are visible during review.
        for entity in level.entityList:
            animation = getattr(entity, "animation", None)
            images = getattr(animation, "images", ())
            if type(entity).__name__ == "Coin" and images:
                animation.index = max(
                    range(len(images)),
                    key=lambda index: images[index].get_bounding_rect().width,
                )
                animation.image = images[animation.index]
                animation.timer = 0
        # Camera keeps the safe standing point at tile 8 (pixel 256).
        # Camera.pos.x is the negative scroll offset in tile units.
        # Tile index i draws at pixel (i + camera.pos.x) * 32.
        cam_pos_x = 8 - player_column
        # Need a mock entity so Camera.__init__ doesn't crash
        class MockCamEntity:
            rect = pygame.Rect(player_column * 32, 0, 32, 32)
            def getPosIndexAsFloat(self):
                return type("V", (), {"x": float(player_column)})()
        camera = Camera(Vec2D(cam_pos_x, 0), MockCamEntity())
        camera.x = camera.pos.x * 32
        camera.y = 0

        screen.fill(_capture_sky_color(biome))

        try:
            level.drawLevel(camera)
        except Exception as e:
            print(f"  [warn] drawLevel crashed at col {col}: {e}")
            import traceback
            traceback.print_exc()
            continue

        # Place the canonical SMB1 idle frame above the collision-tested floor.
        mario_sprite = level.sprites.spriteCollection.get("mario_idle")
        if mario_sprite and mario_sprite.image:
            screen.blit(
                mario_sprite.image,
                (8 * 32, player_floor_y - mario_sprite.image.get_height()),
            )

        # Collect entity class names visible on screen
        visible = set()
        cam_pixel_x = camera.x  # negative scroll offset
        for ent in level.entityList:
            if not hasattr(ent, "alive") or ent.alive is None:
                continue
            r = getattr(ent, "rect", None)
            if r is not None and hasattr(r, "x") and r.x is not None:
                if r.right + cam_pixel_x >= 0 and r.left + cam_pixel_x <= SCREEN_W:
                    visible.add(type(ent).__name__)

        fname = f"frame_{len(frames_meta):02d}_col{col}_{biome}.png"
        path = os.path.join(out_dir, fname)
        pygame.image.save(screen, path)

        meta = {
            "file": fname,
            "column": col,
            "player_column": player_column,
            "player_floor_y": player_floor_y,
            "biome": biome,
            "tier": level._get_difficulty_tier(),
            "entity_types": sorted(visible, key=str),
            "entity_count": len(level.entityList),
            "ground_height": level.groundHeight,
            "surface_row": level._surface_row(),
        }
        frames_meta.append(meta)
        print(f"  [{len(frames_meta)}/{len(target_cols)}] {fname}  biome={biome}  col={col}")

    meta_path = os.path.join(out_dir, "frames_meta.json")
    with open(meta_path, "w") as f:
        json.dump(frames_meta, f, indent=2)
    print(f"\nDone: {len(frames_meta)} frames (10 per biome) -> {out_dir}/")
    print(f"Metadata: {meta_path}")


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    sys.path.insert(0, str(root))
    os.chdir(root)
    main()
