"""Cut out the tall coral scenery from the SMB1 Spriters Resource tilesheet.

The source is preserved unchanged. This crop uses source pixel coordinates and
removes the exact palette blue used as the sheet's display matte; no resizing
or resampling is performed.
"""

from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "img" / "smb1_source" / "tileset_sheet.png"
OUTPUT = ROOT / "img" / "smb1_cutouts" / "smb1_underwater_coral_tall.png"
BOUNDS = (312, 640, 328, 688)
MATTE_COLORS = {(66, 66, 255), (68, 66, 255), (66, 66, 253), (68, 66, 253)}


def main():
    sheet = Image.open(SOURCE).convert("RGBA")
    crop = sheet.crop(BOUNDS)
    pixels = crop.load()
    for y in range(crop.height):
        for x in range(crop.width):
            red, green, blue, alpha = pixels[x, y]
            if (red, green, blue) in MATTE_COLORS:
                pixels[x, y] = (red, green, blue, 0)
            else:
                pixels[x, y] = (red, green, blue, alpha)
    if crop.size != (16, 48) or crop.getchannel("A").getbbox() is None:
        raise RuntimeError("Unexpected tall coral crop or empty output")
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    crop.save(OUTPUT, optimize=False)
    print(f"Wrote {OUTPUT.relative_to(ROOT)} ({crop.width}x{crop.height})")


if __name__ == "__main__":
    main()
