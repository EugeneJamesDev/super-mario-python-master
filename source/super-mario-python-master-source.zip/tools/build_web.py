"""Package the Pygame game as a static GitHub Pages site."""

import argparse
import importlib.util
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.compile import collect_data_files


def stage_game(destination):
    """Copy runtime code and assets into the Pygbag app directory."""
    destination.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / "main.py", destination / "main.py")
    for directory in ("classes", "entities", "traits"):
        target = destination / directory
        target.mkdir(exist_ok=True)
        for source in (ROOT / directory).glob("*.py"):
            shutil.copy2(source, target / source.name)
    for directory, sources in collect_data_files():
        target = destination / directory
        target.mkdir(parents=True, exist_ok=True)
        for source in sources:
            shutil.copy2(source, target)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=ROOT / "build/web")
    args = parser.parse_args()
    if importlib.util.find_spec("pygbag") is None:
        parser.error("Install config/requirements-web.txt before building.")
    with TemporaryDirectory(prefix="platformer-web-") as temporary:
        game = Path(temporary) / "game"
        stage_game(game)
        subprocess.run(
            [
                sys.executable, "-m", "pygbag", "--build", "--no_opt",
                "--width", "640", "--height", "480",
                "--title", "Super Mario in Python", str(game),
            ],
            cwd=game.parent,
            check=True,
        )
        site = game / "build/web"
        archive = any(path.name.endswith((".apk", ".tar.gz", ".zip")) for path in site.glob("*"))
        if not (site / "index.html").is_file() or not archive:
            raise RuntimeError("Pygbag did not generate a playable site and game archive")
        shutil.copytree(site, args.output, dirs_exist_ok=True)
    print(f"Browser build: {args.output.resolve()}")


if __name__ == "__main__":
    main()
