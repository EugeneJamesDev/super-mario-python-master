"""Capture rotating firebar frames and check for stale pixels."""

import os
from pathlib import Path
import sys

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pygame


def main():
    pygame.init()
    screen = pygame.display.set_mode((640, 480))

    from classes.Camera import Camera
    from classes.Level import Level
    from classes.Maths import Vec2D
    from classes.Tile import Tile
    from entities.FireBar import FireBar

    class SilentSound:
        def play_sfx(self, *args, **kwargs):
            pass

    class StillPlayer:
        levelObj = None

        def getPosIndexAsFloat(self):
            return Vec2D(8, 8)

    level = Level(screen, SilentSound(), None)
    sky = level.get_theme_sprite("sky")
    level.level = [
        [
            Tile(None, None) if 5 <= x <= 13 and 3 <= y <= 11 else Tile(sky, None)
            for x in range(22)
        ]
        for y in range(15)
    ]
    level.levelLength = 22
    player = StillPlayer()
    camera = Camera(Vec2D(0, 0), player)
    bar = FireBar(screen, 9, 7, segments=6, spriteCollection=level.sprites.spriteCollection)
    bar.burst_interval = 10_000
    level.entityList = [bar]

    output_dir = Path("test_frames/render_redraw")
    output_dir.mkdir(parents=True, exist_ok=True)
    captures = []
    sample_frames = {1, 8, 16, 24, 32, 40, 48, 56}

    for frame_number in range(1, 57):
        level.drawLevel(camera)
        actual = screen.copy()
        if frame_number in sample_frames:
            captures.append(actual)

        # Render the same frame without the moving hazard. Any difference
        # outside the firebar's current sprite rectangles is a stale trail.
        level.entityList = []
        level.drawLevel(camera)
        background = screen.copy()
        level.entityList = [bar]

        allowed = pygame.Surface((640, 480), pygame.SRCALPHA)
        for rect in bar.hitboxes:
            allowed.fill((255, 255, 255, 255), rect.move(camera.x, 0))
        center_rect = bar.center_image.get_rect(center=bar.center)
        allowed.fill((255, 255, 255, 255), center_rect.move(camera.x, 0))

        actual_rgb = pygame.surfarray.array3d(actual)
        background_rgb = pygame.surfarray.array3d(background)
        allowed_mask = pygame.surfarray.array_alpha(allowed) > 0
        changed = (actual_rgb != background_rgb).any(axis=2)
        stale = changed & ~allowed_mask
        stale_pixels = int(stale.sum())
        if stale_pixels:
            pygame.image.save(actual, output_dir / f"failure_frame_{frame_number:03d}.png")
            raise AssertionError(
                f"Frame {frame_number} has {stale_pixels} pixels outside current firebar bounds"
            )

    columns = 4
    rows = (len(captures) + columns - 1) // columns
    sheet = pygame.Surface((columns * 320, rows * 240))
    for index, capture in enumerate(captures):
        thumb = pygame.transform.scale(capture, (320, 240))
        sheet.blit(thumb, ((index % columns) * 320, (index // columns) * 240))
    pygame.image.save(sheet, output_dir / "firebar_rotation_contact.png")
    pygame.quit()
    print(f"PASS: 56 rotating frames have no stale pixels; captured {len(captures)} samples")
    print(output_dir / "firebar_rotation_contact.png")


if __name__ == "__main__":
    main()
