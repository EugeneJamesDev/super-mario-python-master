"""Run static analysis and the headless regression suite from any directory."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--timeout", type=int, default=180, help="Seconds allowed per check")
    args = parser.parse_args()
    if args.timeout <= 0:
        parser.error("--timeout must be positive")
    env = dict(os.environ, SDL_VIDEODRIVER="dummy", SDL_AUDIODRIVER="dummy", PYGAME_HIDE_SUPPORT_PROMPT="1")
    commands = [("static analysis", ["-m", "pyflakes", "main.py", "classes", "entities", "traits", "tools"])]
    scripts = [ROOT / "tools/audit_assets.py", *sorted((ROOT / "tools").glob("check_*.py")), *sorted((ROOT / "tools").glob("test_*.py"))]
    commands.extend((script.stem, [str(script)]) for script in scripts)
    log_dir = ROOT / "test_frames/check_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    failures = []
    for name, command in commands:
        started = time.monotonic()
        print(f"Running {name}...", flush=True)
        try:
            result = subprocess.run([sys.executable, *command], cwd=ROOT, env=env, capture_output=True, text=True, timeout=args.timeout)
            output = result.stdout + result.stderr
            passed = result.returncode == 0
        except subprocess.TimeoutExpired as error:
            output = f"Timed out after {args.timeout}s\n"
            for stream in (error.stdout, error.stderr):
                if stream:
                    output += stream.decode(errors="replace") if isinstance(stream, bytes) else stream
            passed = False
        (log_dir / f"{name.replace(' ', '_')}.log").write_text(output)
        print(f"{'PASS' if passed else 'FAIL'}: {name} ({time.monotonic() - started:.1f}s)", flush=True)
        if not passed:
            failures.append(name)
            print(output[-6000:], flush=True)
    print(f"\n{len(commands) - len(failures)}/{len(commands)} checks passed. Logs: {log_dir}")
    return int(bool(failures))


if __name__ == "__main__":
    raise SystemExit(main())
