"""Audit sprite JSON manifests and hardcoded asset paths.

Usage:
    python tools/audit_assets.py
"""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

SPRITE_JSON_FILES = sorted(path.relative_to(REPO_ROOT).as_posix() for path in (REPO_ROOT / "sprites").glob("*.json"))

HARDCODED_LOAD_PATTERN = re.compile(
    r'pygame\.image\.load\(\s*["\']([^"\']+)["\']'
)

ENTITY_FILES = [
    "main.py",
    *sorted(path.relative_to(REPO_ROOT).as_posix()
            for folder in ("classes", "entities")
            for path in (REPO_ROOT / folder).glob("*.py")),
]

CRITICAL_SPRITES = {
    "sky",
    "ground",
    "bricks",
    "hardBlock",
    "empty",
    "pipeL",
    "pipeR",
    "CoinBox",
    "coin",
    "mushroom",
    "goomba-1",
    "koopa-1",
    "mario_idle",
}


def collect_sheet_paths(json_path: Path) -> set[str]:
    paths: set[str] = set()
    try:
        data = json.loads(json_path.read_text())
    except (OSError, json.JSONDecodeError):
        return paths

    default = data.get("spriteSheetURL")
    if default:
        paths.add(default)

    for sprite in data.get("sprites", []):
        sheet = sprite.get("spriteSheetURL")
        if sheet:
            paths.add(sheet)
        for image in sprite.get("images", []):
            image_sheet = image.get("spriteSheetURL")
            if image_sheet:
                paths.add(image_sheet)
    return paths


def audit_json_sheets() -> tuple[list[str], list[str]]:
    missing_sheets: list[str] = []
    present_sheets: list[str] = []
    seen: set[str] = set()

    for rel_path in SPRITE_JSON_FILES:
        json_path = REPO_ROOT / rel_path
        for sheet in sorted(collect_sheet_paths(json_path)):
            if sheet in seen:
                continue
            seen.add(sheet)
            full_path = REPO_ROOT / sheet.lstrip("./")
            if full_path.exists():
                present_sheets.append(sheet)
            else:
                missing_sheets.append(sheet)
    return missing_sheets, present_sheets


def _crop_definitions(json_path: Path):
    """Yield each source crop using the same pixel/tile rules as Sprites."""
    data = json.loads(json_path.read_text())
    sprite_type = data.get("type")
    default_size = data.get("size", (16, 16))

    for sprite in data.get("sprites", []):
        name = sprite.get("name", "<unnamed>")
        if sprite_type == "animation":
            for index, frame in enumerate(sprite.get("images", [])):
                width = frame.get("xsize", sprite.get("xsize", default_size[0]))
                height = frame.get("ysize", sprite.get("ysize", default_size[1]))
                ignore_tile_size = frame.get(
                    "ignoreTileSize", sprite.get("ignoreTileSize", False)
                )
                if "xsize" in frame or "ysize" in frame:
                    ignore_tile_size = True
                x, y = frame.get("x", 0), frame.get("y", 0)
                if not ignore_tile_size:
                    x, y = x * width, y * height
                sheet = frame.get("spriteSheetURL") or sprite.get(
                    "spriteSheetURL", data.get("spriteSheetURL")
                )
                yield f"{name} frame {index + 1}", sheet, x, y, width, height
        else:
            width = sprite.get("xsize", sprite.get("tileWidth", default_size[0]))
            height = sprite.get("ysize", sprite.get("tileHeight", default_size[1]))
            if sprite_type == "background":
                ignore_tile_size = sprite.get("ignoreTileSize", False)
                if "xsize" in sprite or "ysize" in sprite:
                    ignore_tile_size = True
            else:
                # Character/item manifests use source-pixel coordinates.
                ignore_tile_size = True
            x, y = sprite.get("x", 0), sprite.get("y", 0)
            if not ignore_tile_size:
                x, y = x * width, y * height
            sheet = sprite.get("spriteSheetURL", data.get("spriteSheetURL"))
            yield name, sheet, x, y, width, height


def audit_sprite_crops() -> tuple[int, list[str]]:
    from PIL import Image

    checked = 0
    invalid: list[str] = []
    for rel_path in SPRITE_JSON_FILES:
        manifest = REPO_ROOT / rel_path
        try:
            definitions = _crop_definitions(manifest)
            for name, sheet_rel, x, y, width, height in definitions:
                if not sheet_rel:
                    invalid.append(f"{rel_path}: {name}: no source sheet")
                    continue
                sheet_path = REPO_ROOT / sheet_rel.lstrip("./")
                try:
                    with Image.open(sheet_path) as sheet:
                        sheet_width, sheet_height = sheet.size
                except OSError as exc:
                    invalid.append(f"{rel_path}: {name}: cannot read {sheet_rel}: {exc}")
                    continue
                checked += 1
                if x < 0 or y < 0 or width <= 0 or height <= 0 or x + width > sheet_width or y + height > sheet_height:
                    invalid.append(
                        f"{rel_path}: {name}: crop ({x}, {y}, {width}, {height}) "
                        f"outside {sheet_rel} ({sheet_width}x{sheet_height})"
                    )
        except (OSError, json.JSONDecodeError, TypeError, IndexError) as exc:
            invalid.append(f"{rel_path}: cannot audit manifest: {exc}")
    return checked, invalid


def audit_hardcoded_loads() -> list[tuple[str, str, bool]]:
    results: list[tuple[str, str, bool]] = []
    for rel_path in ENTITY_FILES:
        file_path = REPO_ROOT / rel_path
        if not file_path.exists():
            continue
        text = file_path.read_text()
        for match in HARDCODED_LOAD_PATTERN.finditer(text):
            asset_path = match.group(1)
            exists = (REPO_ROOT / asset_path.lstrip("./")).exists()
            results.append((rel_path, asset_path, exists))
    return results


def audit_sprite_collection() -> tuple[list[str], list[str]]:
    import os

    os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
    import pygame

    pygame.init()
    from classes.Sprites import Sprites

    sprites = Sprites()
    loaded: list[str] = []
    missing: list[str] = []

    for name, sprite in sorted(sprites.spriteCollection.items()):
        has_image = sprite.image is not None
        has_animation = sprite.animation is not None and bool(sprite.animation.images)
        if has_image or has_animation:
            loaded.append(name)
        else:
            missing.append(name)

    critical_missing = sorted(name for name in CRITICAL_SPRITES if name in missing or name not in loaded)
    return loaded, critical_missing


def main() -> int:
    print("=== Sprite sheet paths ===")
    missing_sheets, present_sheets = audit_json_sheets()
    print(f"Present sheets: {len(present_sheets)}")
    print(f"Missing sheets: {len(missing_sheets)}")
    for sheet in missing_sheets:
        print(f"  MISSING: {sheet}")

    print("\n=== Sprite crop bounds ===")
    crop_count, invalid_crops = audit_sprite_crops()
    print(f"Crops checked: {crop_count}")
    print(f"Invalid crops: {len(invalid_crops)}")
    for crop in invalid_crops:
        print(f"  INVALID: {crop}")

    print("\n=== Hardcoded pygame.image.load paths ===")
    hardcoded = audit_hardcoded_loads()
    for file_path, asset_path, exists in hardcoded:
        status = "OK" if exists else "MISSING"
        print(f"  [{status}] {file_path}: {asset_path}")

    print("\n=== Loaded sprite collection ===")
    try:
        loaded, critical_missing = audit_sprite_collection()
        print(f"Loaded sprites: {len(loaded)}")
        if critical_missing:
            print("Critical missing sprites:")
            for name in critical_missing:
                print(f"  MISSING: {name}")
        else:
            print("All critical gameplay sprites loaded.")
    except Exception as exc:
        print(f"Could not load sprite collection: {exc}")
        return 1

    return 1 if critical_missing or missing_sheets or invalid_crops or any(not exists for _, _, exists in hardcoded) else 0


if __name__ == "__main__":
    raise SystemExit(main())
