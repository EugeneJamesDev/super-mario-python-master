"""Build the openable, self-contained sprite library HTML page.

Run from any directory with:
    python3 tools/build_sprite_library.py

Then open test_frames/asset_reports/sprite_library.html. Rebuild after changing sprite
manifests or source images so the embedded previews stay current.
"""

from __future__ import annotations

import json
from pathlib import Path

from export_sprite_gallery_data import main as export_gallery_data


REPO_ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = REPO_ROOT / "test_frames/asset_reports/sprite_gallery_data.json"
OUTPUT_PATH = REPO_ROOT / "test_frames/asset_reports/sprite_library.html"

PAGE = r"""<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SMB Sprite Library</title>
  <style>
    :root {
      color-scheme: dark;
      --sky: #172335;
      --panel: #24344b;
      --panel-raised: #304765;
      --red: #c92b23;
      --yellow: #ffd34f;
      --text: #fff7df;
      --muted: #c5d0dc;
      --border: #526984;
    }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      background: var(--sky);
      color: var(--text);
      font: 15px/1.45 ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
    }
    header {
      padding: 20px clamp(16px, 4vw, 48px) 16px;
      background: var(--red);
      border-bottom: 5px solid #8e1f1c;
      box-shadow: 0 5px 0 #111b29;
    }
    .header-line { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; }
    .mushroom-mark {
      width: 42px; height: 36px; position: relative; flex: 0 0 42px;
      background: #f3f0e9; border: 3px solid #76231f; border-radius: 22px 22px 8px 8px;
      image-rendering: pixelated;
    }
    .mushroom-mark::before, .mushroom-mark::after {
      content: ""; position: absolute; width: 8px; height: 8px; top: 8px;
      background: #c92b23; box-shadow: 0 0 0 2px #8e1f1c;
    }
    .mushroom-mark::before { left: 7px; }
    .mushroom-mark::after { right: 7px; }
    h1 { margin: 0; color: white; font-size: clamp(20px, 3vw, 30px); letter-spacing: .04em; text-shadow: 2px 2px #72201c; }
    .subtitle { margin: 6px 0 0 56px; color: #ffe7c1; font-size: 12px; }
    main { max-width: 1500px; margin: 0 auto; padding: 20px clamp(12px, 3vw, 36px) 48px; }
    .toolbar {
      position: sticky; top: 0; z-index: 5; padding: 12px; margin: 0 0 16px;
      display: grid; grid-template-columns: minmax(220px, 1fr) minmax(170px, 240px) auto;
      gap: 10px; background: #1c2a3c; border: 2px solid var(--border); border-radius: 8px;
    }
    input, select, button {
      min-height: 42px; border: 2px solid var(--border); border-radius: 5px;
      background: #0f1a28; color: var(--text); padding: 8px 11px; font: inherit;
    }
    input:focus, select:focus, button:focus { outline: 3px solid var(--yellow); outline-offset: 1px; }
    button { cursor: pointer; background: var(--panel-raised); font-weight: bold; }
    button:hover { border-color: var(--yellow); }
    .summary { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; margin-bottom: 15px; }
    .badge { padding: 5px 9px; border: 1px solid var(--border); border-radius: 99px; background: var(--panel); color: var(--muted); font-size: 12px; }
    #resultCount { color: var(--yellow); font-weight: bold; }
    #library { display: grid; grid-template-columns: repeat(auto-fill, minmax(235px, 1fr)); gap: 13px; align-items: start; }
    .card { min-width: 0; overflow: hidden; background: var(--panel); border: 2px solid var(--border); border-radius: 7px; box-shadow: 0 3px 0 #101a27; }
    .card-head { min-height: 56px; padding: 9px 10px; display: flex; justify-content: space-between; align-items: flex-start; gap: 7px; background: #2b3f58; border-bottom: 1px solid var(--border); }
    .name { min-width: 0; overflow-wrap: anywhere; font-weight: bold; }
    .count { flex: 0 0 auto; color: #182638; background: var(--yellow); border-radius: 4px; padding: 2px 5px; font-size: 10px; font-weight: bold; }
    .category { color: var(--yellow); text-transform: uppercase; font-size: 10px; letter-spacing: .08em; margin-bottom: 7px; }
    .frames { display: flex; gap: 8px; overflow-x: auto; padding: 10px; scrollbar-color: #8299b1 #1a293b; }
    .frame { flex: 0 0 auto; width: 102px; text-align: center; }
    .checker {
      width: 96px; height: 96px; margin: 0 auto 5px; display: flex; align-items: center; justify-content: center;
      border: 1px solid #6e85a0; border-radius: 4px;
      background-color: #d7d7d7;
      background-image: linear-gradient(45deg,#b9b9b9 25%,transparent 25%),linear-gradient(-45deg,#b9b9b9 25%,transparent 25%),linear-gradient(45deg,transparent 75%,#b9b9b9 75%),linear-gradient(-45deg,transparent 75%,#b9b9b9 75%);
      background-size: 16px 16px; background-position: 0 0,0 8px,8px -8px,-8px 0;
    }
    .checker img { max-width: 88px; max-height: 88px; width: auto; height: auto; object-fit: contain; image-rendering: pixelated; }
    .frame-label { color: var(--text); font-size: 11px; }
    .dimensions { color: var(--muted); font-size: 10px; }
    .source { padding: 7px 10px 9px; border-top: 1px solid #405875; color: var(--muted); font-size: 10px; overflow-wrap: anywhere; }
    .empty { padding: 32px; grid-column: 1 / -1; text-align: center; border: 2px dashed var(--border); border-radius: 8px; color: var(--muted); }
    footer { margin-top: 22px; padding: 13px; border-top: 1px solid var(--border); color: var(--muted); font-size: 11px; }
    code { color: var(--yellow); }
    @media (max-width: 640px) {
      .toolbar { grid-template-columns: 1fr; position: static; }
      .subtitle { margin-left: 0; }
      #library { grid-template-columns: repeat(auto-fill, minmax(205px, 1fr)); }
    }
  </style>
</head>
<body>
  <header>
    <div class="header-line"><span class="mushroom-mark" aria-hidden="true"></span><h1>SUPER MARIO SPRITE LIBRARY</h1></div>
    <p class="subtitle">Visual reference for the sprites currently loaded by this game project.</p>
  </header>
  <main>
    <section class="toolbar" aria-label="Library filters">
      <input id="search" type="search" placeholder="Search sprites… (mario, vine, fire bar)" aria-label="Search sprites">
      <select id="category" aria-label="Filter by category"><option value="">All categories</option></select>
      <button id="clear" type="button">Clear filters</button>
    </section>
    <div class="summary" id="summary"></div>
    <section id="library" aria-live="polite"></section>
    <footer>
      This page is a visual library, not the game. It shows the loaded sprite keys and animation frames from the current manifests.<br>
      To refresh it after adding or changing assets, run <code>python3 tools/build_sprite_library.py</code> from the project folder, then reload this file.
    </footer>
  </main>
  <script>
    const DATA = __LIBRARY_DATA__;
    const search = document.querySelector('#search');
    const category = document.querySelector('#category');
    const library = document.querySelector('#library');
    const summary = document.querySelector('#summary');
    const categories = [...new Set(DATA.entries.map(entry => entry.category))].sort();
    for (const name of categories) {
      const option = document.createElement('option'); option.value = name; option.textContent = name; category.append(option);
    }
    const esc = value => String(value).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
    function render() {
      const query = search.value.trim().toLowerCase();
      const selected = category.value;
      const entries = DATA.entries.filter(entry => {
        const searchable = `${entry.name} ${entry.category} ${entry.sourceFile}`.toLowerCase();
        return (!query || searchable.includes(query)) && (!selected || entry.category === selected);
      });
      summary.innerHTML = `<span id="resultCount">${entries.length} shown</span><span class="badge">${DATA.loadedCount} loaded sprite keys</span><span class="badge">${DATA.sourceFiles.length} manifests</span><span class="badge">Updated ${esc(DATA.generatedAt)}</span>`;
      if (!entries.length) { library.innerHTML = '<div class="empty">No sprites match those filters.</div>'; return; }
      library.innerHTML = entries.map(entry => `
        <article class="card">
          <div class="card-head"><span class="name">${esc(entry.name)}</span><span class="count">${entry.animated ? `${entry.frameCount} FRAMES` : 'STATIC'}</span></div>
          <div class="frames">${entry.frames.map(frame => `
            <div class="frame">
              <div class="checker"><img src="${frame.dataUrl}" alt="${esc(entry.name)} ${esc(frame.label)}" loading="lazy"></div>
              <div class="frame-label">${esc(frame.label)}</div>
              <div class="dimensions">${frame.width} × ${frame.height} px</div>
            </div>`).join('')}
          </div>
          <div class="source"><span class="category">${esc(entry.category)}</span><br>${esc(entry.sourceFile || 'No manifest source recorded')}</div>
        </article>`).join('');
    }
    search.addEventListener('input', render);
    category.addEventListener('change', render);
    document.querySelector('#clear').addEventListener('click', () => { search.value = ''; category.value = ''; render(); });
    render();
  </script>
</body>
</html>
"""


def main() -> None:
    # The exporter reads the live runtime manifests and writes current images
    # into the JSON payload, so the final HTML works when opened as file://.
    export_gallery_data()
    data = json.loads(DATA_PATH.read_text(encoding="utf-8"))
    json_blob = json.dumps(data, separators=(",", ":"))
    # Avoid a sprite name/source accidentally ending the inline script element.
    json_blob = json_blob.replace("<", "\\u003c")
    OUTPUT_PATH.write_text(
        PAGE.replace("__LIBRARY_DATA__", json_blob), encoding="utf-8"
    )
    print(f"Built {OUTPUT_PATH} ({OUTPUT_PATH.stat().st_size // 1024} KB)")
    print(f"Includes {data['loadedCount']} loaded sprites from {len(data['sourceFiles'])} manifests")


if __name__ == "__main__":
    main()
