"""Export the current loaded game sprites for the visual sprite library.

Usage:
    python tools/export_sprite_gallery_data.py
"""

from __future__ import annotations

import base64
import io
import json
import os
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")

import pygame

from classes.Sprites import Sprites

OUTPUT_PATH = REPO_ROOT / "test_frames/asset_reports/sprite_gallery_data.json"

CATEGORY_HINTS = (
    (("demo",), "Demo"),
    (("mario",), "Mario"),
    (("luigi",), "Luigi"),
    (("bowser",), "Boss"),
    (("princess", "toadstool", "retainer"), "NPC"),
    (("goomba", "koopa", "buzzy", "lakitu", "spiny", "hammer_bro",
      "cheep", "blooper", "bullet_bill", "bill_blaster", "podoboo",
      "piranha", "paratroopa"), "Enemies"),
    (("fire_flower", "flower-item", "mushroom", "oneup", "1up", "coin",
      "star", "starman", "item"), "Items"),
    (("firebar", "fire_bar", "firebolt", "fire_bolt", "fireball", "fire",
      "burst", "explosion", "spark"), "Effects"),
    (("platform", "lift", "springboard"), "Platforms"),
    (("tree", "cloud", "hill", "bush", "fence", "goal", "fortress",
      "castle", "mountain", "coral", "scenery"), "Scenery"),
    (("pipe", "ground", "sky", "brick", "hard", "block", "empty", "water",
      "lava", "ice", "tile", "vine", "bridge", "axe"), "Tiles"),
    (("font", "logo", "title", "cursor", "menu"), "UI"),
)


def categorize(name: str) -> str:
    lowered = name.lower()
    for hints, category in CATEGORY_HINTS:
        if any(hint in lowered for hint in hints):
            return category
    return "Other"


def manifest_sources() -> dict[str, str]:
    """Map loaded keys to the manifest that currently defines them."""
    sources: dict[str, str] = {}
    for manifest_name in Sprites.SPRITE_MANIFESTS:
        manifest_path = REPO_ROOT / "sprites" / manifest_name
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        for sprite in manifest.get("sprites", []):
            name = sprite.get("name")
            if name:
                sources[name] = manifest_name
    return sources


def surface_to_data_url(surface: pygame.Surface) -> str:
    buffer = io.BytesIO()
    # Blit onto an alpha surface so SDL color keys become transparent pixels
    # in the exported PNG; saving the source surface directly retains them as
    # opaque black in some pygame versions.
    preview = pygame.Surface(surface.get_size(), pygame.SRCALPHA)
    preview.blit(surface, (0, 0))
    pygame.image.save(preview, buffer, "PNG")
    encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
    return f"data:image/png;base64,{encoded}"


def export_sprite(name: str, sprite, source_file: str = "") -> dict | None:
    frames: list[dict] = []
    if sprite.image is not None:
        frames.append(
            {
                "label": "static",
                "width": sprite.image.get_width(),
                "height": sprite.image.get_height(),
                "dataUrl": surface_to_data_url(sprite.image),
            }
        )
    elif sprite.animation is not None and sprite.animation.images:
        for index, image in enumerate(sprite.animation.images):
            if image is None:
                continue
            frames.append(
                {
                    "label": f"frame {index + 1}",
                    "width": image.get_width(),
                    "height": image.get_height(),
                    "dataUrl": surface_to_data_url(image),
                }
            )
    if not frames:
        return None
    return {
        "name": name,
        "category": categorize(name),
        "animated": len(frames) > 1,
        "frameCount": len(frames),
        "sourceFile": source_file,
        "frames": frames,
    }


def main() -> None:
    pygame.init()
    collection = Sprites().spriteCollection
    sources = manifest_sources()
    entries = []
    missing = []
    for name in sorted(collection):
        exported = export_sprite(name, collection[name], sources.get(name, ""))
        if exported:
            entries.append(exported)
        else:
            missing.append(name)

    payload = {
        "generatedAt": __import__("datetime").datetime.now().isoformat(timespec="seconds"),
        "totalDefined": len(collection),
        "loadedCount": len(entries),
        "missingCount": len(missing),
        "missingNames": missing,
        "sourceFiles": list(Sprites.SPRITE_MANIFESTS),
        "entries": entries,
    }
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_text(json.dumps(payload), encoding="utf-8")
    pygame.quit()
    print(f"Exported {len(entries)} sprites to {OUTPUT_PATH}")
    print(f"Missing: {len(missing)}")


if __name__ == "__main__":
    main()
