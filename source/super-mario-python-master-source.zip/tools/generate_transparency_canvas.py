#!/usr/bin/env python3
"""Generate transparency classification canvas from audit output."""

from __future__ import annotations

import json
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
AUDIT_PATH = REPO_ROOT / "test_frames/asset_reports/transparency_audit.json"
CANVAS_PATH = AUDIT_PATH.with_name("transparency-audit.canvas.tsx")

CANVAS_SOURCE = '''import { useMemo, useState } from "react";
import {
  Card,
  CardBody,
  CardHeader,
  Grid,
  H1,
  H2,
  H3,
  Pill,
  Row,
  Select,
  Stack,
  Stat,
  Text,
  TextInput,
  useHostTheme,
} from "cursor/canvas";

type AuditEntry = {
  name: string;
  jsonFile: string;
  sheetPath: string;
  mode: "alpha" | "black_key" | "opaque";
  modeLabel: string;
  configuredColorKey: string;
  recommendedColorKey: string | null;
  status: string;
  previewDataUrl: string;
  width: number;
  height: number;
};

type AuditData = {
  generatedAt: string;
  summary: Record<string, number>;
  entries: AuditEntry[];
};

const AUDIT_DATA: AuditData = __AUDIT_JSON__;

const MODE_ORDER = ["alpha", "black_key", "opaque"] as const;

const MODE_COLORS: Record<string, "green" | "yellow" | "blue"> = {
  alpha: "green",
  black_key: "yellow",
  opaque: "blue",
};

function EntryCard({ entry }: { entry: AuditEntry }) {
  const theme = useHostTheme();
  return (
    <Card>
      <CardBody>
        <Stack gap={8}>
          <Row justify="between" align="center">
            <Text weight="semibold">{entry.name}</Text>
            <Pill color={MODE_COLORS[entry.mode]}>{entry.modeLabel}</Pill>
          </Row>
          <div
            style={{
              width: Math.max(entry.width, 64),
              height: Math.max(entry.height, 64),
              imageRendering: "pixelated",
              border: `1px solid ${theme.border}`,
              borderRadius: 4,
              overflow: "hidden",
            }}
          >
            <img
              src={entry.previewDataUrl}
              alt={entry.name}
              width={Math.max(entry.width, 64)}
              height={Math.max(entry.height, 64)}
              style={{ imageRendering: "pixelated" }}
            />
          </div>
          <Text size="sm" color="secondary">
            JSON: {entry.jsonFile}
          </Text>
          <Text size="sm" color="secondary">
            Config: {entry.configuredColorKey} → {entry.recommendedColorKey ?? "none"}
          </Text>
          <Text size="sm" color="secondary">
            {entry.status === "ok" || entry.status === "fixed" ? "Synced" : "Needs review"} ({entry.status})
          </Text>
        </Stack>
      </CardBody>
    </Card>
  );
}

export default function TransparencyAuditCanvas() {
  const [query, setQuery] = useState("");
  const [modeFilter, setModeFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return AUDIT_DATA.entries.filter((entry) => {
      if (modeFilter !== "all" && entry.mode !== modeFilter) return false;
      if (statusFilter !== "all" && entry.status !== statusFilter) return false;
      if (!q) return true;
      return (
        entry.name.toLowerCase().includes(q) ||
        entry.jsonFile.toLowerCase().includes(q) ||
        entry.sheetPath.toLowerCase().includes(q)
      );
    });
  }, [query, modeFilter, statusFilter]);

  const grouped = useMemo(() => {
    const buckets: Record<string, AuditEntry[]> = {
      alpha: [],
      black_key: [],
      opaque: [],
    };
    for (const entry of filtered) buckets[entry.mode].push(entry);
    return buckets;
  }, [filtered]);

  return (
    <Stack gap={24} padding={24}>
      <Stack gap={8}>
        <H1>Sprite Transparency Classification</H1>
        <Text color="secondary">
          Checkerboard previews show how each asset handles transparency. Alpha sprites use PNG transparency; black-key sprites knock out opaque black; opaque tiles are solid.
        </Text>
        <Text size="sm" color="secondary">Generated {AUDIT_DATA.generatedAt}</Text>
      </Stack>

      <Grid columns={4} gap={12}>
        <Stat label="Alpha transparent" value={String(AUDIT_DATA.summary.alpha ?? 0)} />
        <Stat label="Black colorkey" value={String(AUDIT_DATA.summary.black_key ?? 0)} />
        <Stat label="Opaque tiles" value={String(AUDIT_DATA.summary.opaque ?? 0)} />
        <Stat label="Synced" value={String((AUDIT_DATA.summary.ok ?? 0) + (AUDIT_DATA.summary.fixed ?? 0))} />
      </Grid>

      <Card>
        <CardHeader>
          <H2>Legend</H2>
        </CardHeader>
        <CardBody>
          <Stack gap={8}>
            <Row gap={8} wrap>
              <Pill color="green">Alpha transparent</Pill>
              <Text size="sm">PNG alpha channel — no colorKey</Text>
            </Row>
            <Row gap={8} wrap>
              <Pill color="yellow">Black colorkey</Pill>
              <Text size="sm">Opaque black backdrop — colorKey [0,0,0]</Text>
            </Row>
            <Row gap={8} wrap>
              <Pill color="blue">Opaque tile</Pill>
              <Text size="sm">Solid ground/sky/block — no transparency</Text>
            </Row>
          </Stack>
        </CardBody>
      </Card>

      <Row gap={12} wrap align="end">
        <Stack gap={4}>
          <Text size="sm" weight="semibold">Search</Text>
          <TextInput value={query} onChange={setQuery} placeholder="sprite name or sheet" />
        </Stack>
        <Stack gap={4}>
          <Text size="sm" weight="semibold">Mode</Text>
          <Select value={modeFilter} onChange={setModeFilter} options={[
            { value: "all", label: "All modes" },
            { value: "alpha", label: "Alpha transparent" },
            { value: "black_key", label: "Black colorkey" },
            { value: "opaque", label: "Opaque tile" },
          ]} />
        </Stack>
        <Stack gap={4}>
          <Text size="sm" weight="semibold">Status</Text>
          <Select value={statusFilter} onChange={setStatusFilter} options={[
            { value: "all", label: "All" },
            { value: "ok", label: "OK" },
            { value: "fixed", label: "Fixed" },
            { value: "mismatch", label: "Mismatch" },
          ]} />
        </Stack>
      </Row>

      {MODE_ORDER.map((mode) => {
        const items = grouped[mode];
        if (items.length === 0) return null;
        return (
          <Stack gap={12} key={mode}>
            <H3>{MODE_LABELS[mode]} ({items.length})</H3>
            <Grid columns={3} gap={12}>
              {items.map((entry) => (
                <EntryCard key={`${entry.jsonFile}-${entry.name}`} entry={entry} />
              ))}
            </Grid>
          </Stack>
        );
      })}
    </Stack>
  );
}

const MODE_LABELS: Record<string, string> = {
  alpha: "Alpha Transparent",
  black_key: "Black Colorkey",
  opaque: "Opaque Tiles",
};
'''


def main():
    audit = json.loads(AUDIT_PATH.read_text())
    payload = json.dumps(audit, separators=(",", ":"))
    source = CANVAS_SOURCE.replace("__AUDIT_JSON__", payload)
    CANVAS_PATH.write_text(source)
    print(f"Wrote {CANVAS_PATH}")


if __name__ == "__main__":
    main()
