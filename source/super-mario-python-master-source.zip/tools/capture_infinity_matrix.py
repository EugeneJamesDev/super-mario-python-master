"""Capture a multi-seed Infinity biome/feature matrix for visual review.

Run from repository root:
    python3 tools/capture_infinity_matrix.py --seeds 12 --columns 1200

Writes one labeled screenshot for each biome plus each observed in-view entity
type, and a contact sheet / JSON coverage report under test_frames/infinity_matrix.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import traceback
from collections import Counter, defaultdict
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.capture_frames import _capture_sky_color, _safe_stand, make_mock_sound
from tools.capture_infinity_sections import _analyze_route, _verified_jump_profiles

WIDTH, HEIGHT = 640, 480
VIEW_TILES = 20
BIOMES = (
    "normal", "canyon", "ice", "underground", "firebar", "fortress",
    "mushroom", "underwater",
)
ROUTE_LOOKAHEAD_COLUMNS = 16


def _visible_entity_types(level, left, right):
    found = set()
    for entity in level.entityList:
        rect = getattr(entity, "rect", None)
        if rect is not None and rect.right > left * 32 and rect.left < right * 32:
            found.add(type(entity).__name__)
    return found


def _entity_feature_tags(entity):
    tags = {type(entity).__name__}
    variant = getattr(entity, "variant", None)
    if variant:
        tags.add(f"{type(entity).__name__}:{variant}")
    size = getattr(entity, "size", None)
    axis = getattr(entity, "axis", None)
    if size:
        tags.add(f"{type(entity).__name__}:{size}:{axis or 'static'}")
    segments = getattr(entity, "segments", None)
    if segments:
        tags.add(f"{type(entity).__name__}:{segments}_segments")
    return tags


def _visible_tile_features(level, left, right):
    sprite_names = {
        id(sprite): name
        for name, sprite in level.sprites.spriteCollection.items()
    }
    interesting = ("mushroomcap", "mushroomstem", "ice", "lava", "water", "pipe", "firebar")
    found = set()
    for row in level.level:
        for col in range(max(0, left), min(right, len(row))):
            tile = row[col]
            if tile is None or tile.sprite is None:
                continue
            name = sprite_names.get(id(tile.sprite))
            if name and any(token in name.lower() for token in interesting):
                found.add(f"tile:{name}")
    for overlay in level.overlaySprites:
        sprite = overlay.get("sprite")
        name = sprite_names.get(id(sprite), "")
        world_x = overlay["x"] if overlay.get("pixel") else overlay["x"] * 32
        width = overlay.get("width", sprite.image.get_width() if sprite and sprite.image else 0)
        if (
            name
            and world_x < right * 32
            and world_x + width > left * 32
            and any(token in name.lower() for token in interesting)
        ):
            found.add(f"overlay:{name}")
    return found


def _draw_sample(screen, level, camera_cls, vec_cls, seed, biome, center, tags, output_dir):
    stand = _safe_stand(level, center, biome, radius=12)
    player_column, floor_y = stand if stand is not None else (center, 14 * 32)
    level.activeBiome = biome

    class CameraTarget:
        rect = pygame.Rect(player_column * 32, 0, 32, 32)

        def getPosIndexAsFloat(self):
            return vec_cls(float(player_column), 0)

    camera = camera_cls(vec_cls(8 - player_column, 0), CameraTarget())
    camera.x = camera.pos.x * 32
    camera.y = 0
    screen.fill(_capture_sky_color(biome))

    # Drawing a screenshot should not update every simulated entity in a long
    # generated history. Keep only nearby instances for this one render pass.
    saved_entities = level.entityList
    left, right = center - 10, center + 10
    level.entityList = [
        entity for entity in saved_entities
        if getattr(entity, "rect", None) is not None
        and entity.rect.right > (left - 4) * 32
        and entity.rect.left < (right + 4) * 32
    ]
    try:
        level.drawLevel(camera)
    finally:
        level.entityList = saved_entities

    if biome == "underwater":
        # Use the actual SMB1 swimming frame and place Mario in open water so
        # underwater captures show the intended pose rather than a floor idle.
        mario = level.sprites.spriteCollection.get("mario_swim_small")
        mario_image = (
            mario.animation.image
            if mario and mario.animation is not None
            else mario.image if mario else None
        )
        if mario_image:
            candidate_rows = (208, 176, 240, 144, 272, 112, 304)
            swim_row = candidate_rows[0]
            for candidate_y in candidate_rows:
                mario_rect = pygame.Rect(
                    8 * 32, candidate_y, mario_image.get_width(), mario_image.get_height()
                )
                if all(
                    not mario_rect.colliderect(
                        entity.rect.move(round(camera.pos.x * 32), 0)
                    )
                    for entity in level.entityList
                    if getattr(entity, "rect", None) is not None
                ):
                    swim_row = candidate_y
                    break
            screen.blit(mario_image, (8 * 32, swim_row))
    else:
        mario = level.sprites.spriteCollection.get("mario_idle")
        if stand is not None and mario and mario.image:
            screen.blit(mario.image, (8 * 32, floor_y - mario.image.get_height()))

    labels = "+".join(sorted(tags)) or "base"
    # Tags such as Koopa:green include characters Windows forbids in filenames.
    safe_labels = re.sub(r"[^A-Za-z0-9_-]+", "-", labels)[:48]
    filename = f"seed_{seed}_{biome}_{center}_{safe_labels}.png"
    path = output_dir / filename
    pygame.image.save(screen, path)
    return filename, stand is not None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", type=int, default=12)
    parser.add_argument("--columns", type=int, default=1200)
    parser.add_argument("--first-seed", type=int, default=20261111)
    parser.add_argument("--output", type=Path, default=ROOT / "test_frames/infinity_matrix")
    args = parser.parse_args()
    args.output = args.output.resolve()
    os.chdir(ROOT)

    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    from classes.Camera import Camera
    from classes.Dashboard import Dashboard
    from classes.Level import Level
    from classes.Maths import Vec2D

    out = args.output
    out.mkdir(parents=True, exist_ok=True)

    sprite = Dashboard("img/sheets/font.png", 8, screen)
    records = []
    biome_coverage = Counter()
    feature_coverage = defaultdict(Counter)
    transition_coverage = Counter()
    errors = []
    water_frontier_mismatches = []
    palette_frontier_mismatches = []
    route_warnings = []
    route_max_gap_tiles = {}
    sample_budget = defaultdict(lambda: 2)  # Base look + one feature view per biome.

    for seed in range(args.first_seed, args.first_seed + args.seeds):
        level = Level(screen, make_mock_sound(), sprite)
        level.load_endless(seed=seed, initial_columns=0)
        level.endlessBuffer = 0
        for _ in range(args.columns + ROUTE_LOOKAHEAD_COLUMNS):
            level._append_column()

        transition_coverage.update(
            (previous, current)
            for previous, current in zip(level.columnBiomes, level.columnBiomes[1:])
            if previous != current
        )

        route = _analyze_route(
            level, _verified_jump_profiles()["max_hold"], (0, args.columns)
        )
        route_max_gap_tiles[str(seed)] = route["max_ground_gap_tiles"]
        if not route["continuous_endless_route"]:
            route_warnings.append({"seed": seed, "route": route})

        # Count all generated biomes and entity classes before selecting shots.
        for biome in level.columnBiomes[:args.columns]:
            biome_coverage[biome] += 1
        for entity in level.entityList:
            col = int(getattr(entity, "rect", pygame.Rect(0, 0, 0, 0)).centerx // 32)
            if 0 <= col < args.columns:
                for tag in _entity_feature_tags(entity):
                    feature_coverage[level.columnBiomes[col]][tag] += 1

        # Simulate the generator frontier disagreeing with the player's
        # location. This catches early water-physics or palette switches while
        # the camera is still in the preceding biome.
        frontier_biome = level.activeBiome
        for col, biome in enumerate(level.columnBiomes[:args.columns]):
            level.activeBiome = "normal" if biome == "underwater" else "underwater"
            rect = pygame.Rect(col * 32, 100, 32, 32)
            if level.is_underwater_at(rect) != (biome == "underwater"):
                water_frontier_mismatches.append({"seed": seed, "column": col, "biome": biome})
            expected_sky = level.sprites.spriteCollection.get(level._biome_sprite("sky", biome))
            if level.get_theme_sprite("sky", column=col) is not expected_sky:
                palette_frontier_mismatches.append({"seed": seed, "column": col, "biome": biome})
        level.activeBiome = frontier_biome

        candidates = []
        for center in range(10, args.columns - 10, 4):
            biome = level.columnBiomes[center]
            if biome not in BIOMES:
                continue
            if not all(level.columnBiomes[x] == biome for x in range(center - 10, center + 10)):
                continue
            types = set()
            for entity in level.entityList:
                rect = getattr(entity, "rect", None)
                if rect is not None and rect.right > (center - 10) * 32 and rect.left < (center + 10) * 32:
                    types.update(_entity_feature_tags(entity))
            types.update(_visible_tile_features(level, center - 10, center + 10))
            candidates.append((center, biome, types))

        selected = set()
        # Guarantee a baseline view per biome found, then one view exposing
        # every different in-view entity class in that biome/seed.
        for biome in BIOMES:
            windows = [row for row in candidates if row[1] == biome]
            if not windows:
                continue
            biome_coverage[biome] += 0
            base = windows[len(windows) // 2]
            selected.add((base[0], biome, frozenset()))
            by_type = {}
            for center, _, types in windows:
                for name in types:
                    by_type.setdefault(name, (center, biome, frozenset({name})))
            # Spread selections across this biome run while keeping every
            # distinct visible entity family represented in the output.
            selected.update(by_type.values())

        # Save every palette/terrain boundary too. These are intentionally
        # distinct from homogeneous biome samples so abrupt seams remain visible.
        for col in range(1, args.columns - 1):
            previous, current = level.columnBiomes[col - 1], level.columnBiomes[col]
            if previous == current:
                continue
            center = min(max(col, 10), args.columns - 11)
            selected.add((center, level.columnBiomes[center], frozenset({f"transition:{previous}-to-{current}"})))

        for center, biome, tags in sorted(selected, key=lambda row: (row[1], row[0], sorted(row[2]))):
            try:
                filename, safe = _draw_sample(screen, level, Camera, Vec2D, seed, biome, center, tags, out)
                records.append({
                    "seed": seed, "biome": biome, "center_column": center,
                    "focus_entity": sorted(tags), "safe_mario_stand": safe,
                    "visible_entities": sorted(_visible_entity_types(level, center - 10, center + 10)),
                    "visible_tile_features": sorted(_visible_tile_features(level, center - 10, center + 10)),
                    "image": filename,
                })
                sample_budget[biome] -= 1
            except Exception as exc:
                traceback.print_exc()
                errors.append({"seed": seed, "biome": biome, "center_column": center, "error": repr(exc)})

    # Do not let a palette pass silently pass when one of the registered
    # biome-defining assets has no reachable generated use.
    required_features = {
        "ice": {"Goomba", "Koopa", "BuzzyBeetle"},
        "fortress": {"BillBlaster", "Podoboo", "overlay:lava"},
    }
    visible_asset_features = defaultdict(set)
    for record in records:
        biome = record["biome"]
        visible_asset_features[biome].update(record["visible_entities"])
        visible_asset_features[biome].update(record["visible_tile_features"])
    missing_asset_features = []
    for biome, expected in required_features.items():
        observed = visible_asset_features.get(biome, set())
        for name in sorted(expected - observed):
            missing_asset_features.append({"biome": biome, "feature": name})
    if missing_asset_features:
        errors.append({"missing_asset_features": missing_asset_features})
    expected_transitions = {
        (previous, current)
        for previous in BIOMES
        for current in BIOMES
        if previous != current
    }
    missing_transitions = sorted(expected_transitions - set(transition_coverage))

    # Contact sheet: make one compact overview of every selected frame.
    thumb_w, thumb_h, label_h, cols = 160, 120, 24, 5
    rows = (len(records) + cols - 1) // cols
    sheet = pygame.Surface((cols * thumb_w, rows * (thumb_h + label_h)))
    sheet.fill((20, 24, 32))
    font = pygame.font.SysFont("Arial", 11)
    for i, record in enumerate(records):
        x, y = (i % cols) * thumb_w, (i // cols) * (thumb_h + label_h)
        frame = pygame.image.load(str(out / record["image"]))
        sheet.blit(pygame.transform.scale(frame, (thumb_w, thumb_h)), (x, y))
        label = f'{record["seed"]} {record["biome"]} x{record["center_column"]}'
        if record["focus_entity"]:
            label += " " + ",".join(record["focus_entity"])
        color = (255, 100, 100) if not record["safe_mario_stand"] else (235, 235, 235)
        sheet.blit(font.render(label[:28], True, color), (x + 2, y + thumb_h + 4))
    pygame.image.save(sheet, out / "contact_sheet.png")

    base_records = [record for record in records if not record["focus_entity"]]
    overview_cols = 7
    overview_rows = (len(base_records) + overview_cols - 1) // overview_cols
    overview = pygame.Surface((overview_cols * thumb_w, overview_rows * (thumb_h + label_h)))
    overview.fill((20, 24, 32))
    for i, record in enumerate(base_records):
        x, y = (i % overview_cols) * thumb_w, (i // overview_cols) * (thumb_h + label_h)
        frame = pygame.image.load(str(out / record["image"]))
        overview.blit(pygame.transform.scale(frame, (thumb_w, thumb_h)), (x, y))
        label = f'{record["seed"]} {record["biome"]}'
        overview.blit(font.render(label, True, (235, 235, 235)), (x + 2, y + thumb_h + 4))
    pygame.image.save(overview, out / "biome_overview.png")

    report = {
        "first_seed": args.first_seed,
        "seed_count": args.seeds,
        "columns_per_seed": args.columns,
        "route_lookahead_columns": ROUTE_LOOKAHEAD_COLUMNS,
        "biome_columns_generated": dict(sorted(biome_coverage.items())),
        "entity_counts_by_biome": {biome: dict(sorted(counts.items())) for biome, counts in feature_coverage.items()},
        "biomes_missing": [biome for biome in BIOMES if not biome_coverage[biome]],
        "missing_asset_features": missing_asset_features,
        "biome_transition_counts": {
            f"{previous}->{current}": count
            for (previous, current), count in sorted(transition_coverage.items())
        },
        "missing_biome_transitions": [f"{previous}->{current}" for previous, current in missing_transitions],
        "visible_asset_features_by_biome": {
            biome: sorted(features)
            for biome, features in sorted(visible_asset_features.items())
        },
        "frames": records,
        "frame_count": len(records),
        "unsafe_mario_stands": [record["image"] for record in records if not record["safe_mario_stand"]],
        "capture_errors": errors,
        "water_frontier_mismatches": water_frontier_mismatches,
        "palette_frontier_mismatches": palette_frontier_mismatches,
        "route_warnings": route_warnings,
        "largest_ground_gap_by_seed": route_max_gap_tiles,
        "contact_sheet": "contact_sheet.png",
        "biome_overview": "biome_overview.png",
    }
    (out / "audit.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"Seeds: {args.first_seed}..{args.first_seed + args.seeds - 1}; columns/seed: {args.columns}")
    print(f"Biomes seen: {', '.join(b for b in BIOMES if biome_coverage[b])}")
    print(f"Directed biome transitions: {len(transition_coverage)}/{len(expected_transitions)}; missing: {len(missing_transitions)}")
    print(f"Missing required biome assets: {len(missing_asset_features)}")
    print(f"Frames: {len(records)}; unsafe stands: {len(report['unsafe_mario_stands'])}; capture errors: {len(errors)}")
    print(f"Frontier state mismatches: water={len(water_frontier_mismatches)}, palette={len(palette_frontier_mismatches)}")
    print(f"Route warnings: {len(route_warnings)}; largest gap: {max(route_max_gap_tiles.values(), default=0)} tiles")
    print(f"Contact sheet: {out / 'contact_sheet.png'}")
    print(f"Biome overview: {out / 'biome_overview.png'}")
    print(f"Audit: {out / 'audit.json'}")
    return 1 if (
        report["biomes_missing"] or missing_transitions or errors or report["unsafe_mario_stands"]
        or water_frontier_mismatches or palette_frontier_mismatches
        or route_warnings
    ) else 0


if __name__ == "__main__":
    raise SystemExit(main())
