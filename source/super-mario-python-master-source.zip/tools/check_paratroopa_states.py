"""Headless motion/state check for Infinity Koopa Paratroopa variants."""

from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.capture_frames import make_mock_sound
from classes.Level import Level
from entities.KoopaParatroopa import KoopaParatroopa


class MockCamera:
    x = 0


def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    level = Level(screen, make_mock_sound(), None)
    level.load_endless(seed=20261112, initial_columns=32)
    level.entityList = []
    sprites = level.sprites.spriteCollection
    surface_row = level._surface_row()
    camera = MockCamera()

    green = KoopaParatroopa(
        screen, sprites, 12, surface_row - 1, level, level.sound, variant="green"
    )
    level.entityList.append(green)
    start_y = green.rect.y
    greatest_y = start_y
    least_y = start_y
    for _ in range(90):
        green.update(camera)
        greatest_y = max(greatest_y, green.rect.y)
        least_y = min(least_y, green.rect.y)
    assert greatest_y - least_y >= 16, "Green Paratroopa never hopped"
    assert abs(green.rect.centerx - 12 * 32 - 16) <= 1, "Green Paratroopa drifted horizontally"
    assert green.lose_wings(), "First stomp did not remove the wings"
    assert not green.winged and green.is_paratroopa
    assert not green.lose_wings(), "Wing removal transition fired twice"
    prior_y = green.rect.y
    green.update(camera)
    assert green.rect.y >= prior_y, "Wingless Koopa did not resume gravity"

    red = KoopaParatroopa(
        screen, sprites, 20, surface_row - 1, level, level.sound, variant="red"
    )
    level.entityList = [red]
    start_x = red.rect.x
    for _ in range(24):
        red.update(camera)
    assert red.rect.x != start_x, "Red Paratroopa did not travel horizontally"
    assert red.winged, "Red Paratroopa unexpectedly lost its wings"

    print(
        "PASS: green variant hops in place, red variant travels, "
        "wing loss is one-shot, and wingless Koopa resumes ground motion"
    )
    pygame.quit()


if __name__ == "__main__":
    main()
