#!/usr/bin/env python3
"""Report which biomes and sprite keys are daytime vs nighttime."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

DAYTIME_BIOMES = {"normal", "canyon", "ice", "firebar", "mushroom"}
DARK_BIOMES = {"underground", "fortress"}
DISABLED_BIOMES = {"underwater"}

THEME_MAP = {
    "normal": {
        "sky": "sky",
        "ground": "ground",
        "bricks": "bricks",
        "hardBlock": "hardBlock",
        "empty": "empty",
        "question": "CoinBox",
    },
    "fortress": {
        "sky": "sky_fortress",
        "ground": "castle_brick",
        "bricks": "castle_brick",
        "hardBlock": "castle_brick",
        "empty": "empty_block",
        "question": "castle_question",
    },
    "underground": {
        "sky": "sky_underground",
        "ground": "ground_underground",
        "bricks": "bricks_underground",
        "hardBlock": "hardBlock_underground",
        "empty": "empty_block",
        "question": "blue_CoinBox",
    },
    "underwater": {
        "sky": "sky",
        "ground": "ground_underwater",
        "bricks": "blue_bricks",
        "hardBlock": "blue_hardBlock",
        "empty": "empty_block",
        "question": "blue_CoinBox",
    },
    "ice": {
        "sky": "sky",
        "ground": "iceBlock",
        "bricks": "bricks",
        "hardBlock": "hardBlock",
        "empty": "empty",
        "question": "CoinBox",
    },
    "firebar": {
        "sky": "sky",
        "ground": "ground",
        "bricks": "bricks",
        "hardBlock": "hardBlock",
        "empty": "empty",
        "question": "CoinBox",
    },
    "canyon": {
        "sky": "sky",
        "ground": "ground",
        "bricks": "bricks",
        "hardBlock": "hardBlock",
        "empty": "empty",
        "question": "CoinBox",
    },
    "mushroom": {
        "sky": "sky",
        "ground": "ground",
        "bricks": "bricks",
        "hardBlock": "hardBlock",
        "empty": "empty",
        "question": "CoinBox",
    },
}

DAYTIME_ONLY_DECOR = [
    "tree_small_top",
    "tree_trunk",
    "tree_big_top",
    "tree_big_bottom",
    "decorative_flower_normal",
    "decorative_flower_red",
    "decorative_flower_blue",
    "decorative_flower_white",
    "circle_bush",
    "bush",
    "cloud",
]

NIGHT_SKY_KEYS = {"sky_underground", "sky_fortress"}
DAY_SKY_KEYS = {"sky"}


def load_sprite_names():
    names = set()
    for path in (ROOT / "sprites").glob("*.json"):
        try:
            data = json.loads(path.read_text())
        except json.JSONDecodeError:
            continue
        for sprite in data.get("sprites", []):
            if sprite.get("name"):
                names.add(sprite["name"])
    return names


def main():
    defined = load_sprite_names()
    print("=== Biome lighting ===")
    for biome in sorted(THEME_MAP):
        lighting = (
            "DAY"
            if biome in DAYTIME_BIOMES
            else "NIGHT"
            if biome in DARK_BIOMES
            else "DISABLED"
            if biome in DISABLED_BIOMES
            else "UNKNOWN"
        )
        active = "active" if biome not in DISABLED_BIOMES else "disabled in infinity"
        print(f"  {biome:12} {lighting:8} ({active})")
        theme = THEME_MAP[biome]
        for slot, key in theme.items():
            status = "OK" if key in defined else "MISSING"
            sky_note = ""
            if slot == "sky":
                if key in NIGHT_SKY_KEYS:
                    sky_note = " [night sky]"
                elif key in DAY_SKY_KEYS:
                    sky_note = " [day sky]"
            print(f"    {slot:10} -> {key:22} {status}{sky_note}")

    print("\n=== Daytime-only decorations ===")
    for name in DAYTIME_ONLY_DECOR:
        print(f"  {name:28} {'OK' if name in defined else 'MISSING'}")

    print("\n=== Removed / disabled ===")
    print("  tree_short, tree_tall (broken horsetail PNGs)")
    print("  underwater biome rotation + water overlay")


if __name__ == "__main__":
    main()
