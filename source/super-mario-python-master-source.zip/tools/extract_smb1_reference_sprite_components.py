"""Extract source-faithful reference sprites from composite SMB1 sheets.

This writes to ``img/smb1_source/reference_cutouts`` only; it does not add or
replace runtime assets. Crops are unscaled and every catalog record retains
its exact source rectangle. Composite regions that cannot be safely separated
are called out in the inventory document instead of being guessed.
"""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
SOURCE_DIR = ROOT / "img" / "smb1_source"
OUTPUT_DIR = SOURCE_DIR / "reference_cutouts"
CATALOG_PATH = OUTPUT_DIR / "catalog.json"

# The composite reference sheets use a navy sheet background and three blue
# checker/matte colors. These are the only pixels made transparent.
MATTE = {
    (0, 41, 140),
    (136, 134, 255),
    (146, 144, 255),
    (108, 106, 255),
}


def connected_components(image: Image.Image):
    """Return 4-connected opaque/non-matte components and exact bounds."""
    image = image.convert("RGBA")
    width, height = image.size
    pixels = image.load()
    seen = bytearray(width * height)
    for y in range(height):
        for x in range(width):
            start = y * width + x
            if seen[start]:
                continue
            px = pixels[x, y]
            if px[3] == 0 or px[:3] in MATTE:
                continue

            stack = [(x, y)]
            seen[start] = 1
            left = right = x
            top = bottom = y
            area = 0
            while stack:
                cx, cy = stack.pop()
                area += 1
                left, right = min(left, cx), max(right, cx)
                top, bottom = min(top, cy), max(bottom, cy)
                for nx, ny in (
                    (cx - 1, cy),
                    (cx + 1, cy),
                    (cx, cy - 1),
                    (cx, cy + 1),
                ):
                    if not (0 <= nx < width and 0 <= ny < height):
                        continue
                    index = ny * width + nx
                    if seen[index]:
                        continue
                    q = pixels[nx, ny]
                    if q[3] and q[:3] not in MATTE:
                        seen[index] = 1
                        stack.append((nx, ny))
            yield area, (left, top, right + 1, bottom + 1)


def remove_matte(image: Image.Image):
    image = image.convert("RGBA")
    pixels = image.load()
    for y in range(image.height):
        for x in range(image.width):
            r, g, b, a = pixels[x, y]
            if (r, g, b) in MATTE:
                pixels[x, y] = (r, g, b, 0)
    return image


def enemy_group(y: int):
    if y < 104:
        return (
            "ground_enemy_palette",
            "Ground enemy sprite/palette cell; enemies walk, collide with Mario, and may be stomped or shelled depending on species.",
        )
    if y < 172:
        return (
            "green_enemy_palette",
            "Green-enemy palette/state cell from the original sheet; exact species/state should be checked against its neighboring labeled frames.",
        )
    if y < 270:
        return (
            "green_enemy_animation",
            "Green-enemy animation pose or related character part; source grouping preserves palette/state variants.",
        )
    if y < 307:
        return (
            "castle_enemy_animation",
            "Castle enemy palette/pose; palette changes appearance while retaining the enemy behavior.",
        )
    if y < 415:
        return (
            "red_enemy_palette",
            "Red-enemy palette/state cell; includes alternate poses and projectiles in the all-environments group.",
        )
    return ("palette_reference", "Palette-code legend, not an independent gameplay sprite.")


def object_group(x: int, y: int):
    if x < 306 and y < 108:
        return (
            "overworld_object",
            "Overworld item/object frame: coins, power-ups, block contents, fire effects, or flag/score pieces; visual state only.",
        )
    if x < 306 and y < 220:
        return (
            "underground_object",
            "Underground object or item frame; this palette is used for underground maps and object contents.",
        )
    if x < 306 and y < 330:
        return (
            "castle_object",
            "Castle object or item frame; this palette is used for fortress maps and block contents.",
        )
    if x < 306 and y < 440:
        return (
            "underwater_object",
            "Underwater object/item frame; use only where the original underwater course supports the object.",
        )
    if x < 306 and y < 470:
        return (
            "end_of_castle_character",
            "End-of-castle Princess/Toad character art; used by the rescue message scene.",
        )
    return (
        "object_palette_or_example",
        "Object/block palette example, score glyph, or demonstration tile; reference art rather than a separately verified runtime frame.",
    )


def player_group(x: int, y: int):
    character = "mario" if x < 292 else "luigi"
    if y < 32:
        return (
            f"{character}_small_player",
            "Small-form walking/standing frame; controls, acceleration, and collision come from the player entity.",
        )
    if y < 72:
        return (
            f"{character}_big_player",
            "Big-form walking/jump/standing frame; this is a visual state for the same player movement and collision rules.",
        )
    if y < 112:
        return (
            f"{character}_growth_fire_effect",
            "Growth/shrink transition or fireball visual frame; animation does not independently define power-up behavior.",
        )
    if y < 168:
        return (
            f"{character}_fire_player",
            "Fire-form player pose or projectile frame; fire power permits shooting fireballs in the game.",
        )
    if y < 218:
        return (
            f"{character}_fire_transition_swim_reference",
            "Fire-form transition/projectile or swimming pose from the source sheet; use only for the matching player state.",
        )
    return (
        f"{character}_palette_preview",
        "Palette-demonstration character pose; documents color changes for biome palettes rather than a separate gameplay state.",
    )


def save_unique_components(source_name, output_folder, min_area, max_size, classify, accept):
    source_path = SOURCE_DIR / source_name
    sheet = Image.open(source_path).convert("RGBA")
    output = OUTPUT_DIR / output_folder
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    hashes = {}
    for area, bounds in connected_components(sheet):
        left, top, right, bottom = bounds
        width, height = right - left, bottom - top
        if area < min_area or width > max_size[0] or height > max_size[1]:
            continue
        family, role = classify(left, top)
        if not accept(bounds, area, family):
            continue
        crop = remove_matte(sheet.crop(bounds))
        if crop.getchannel("A").getbbox() is None:
            continue
        digest = hashlib.sha256(crop.tobytes()).hexdigest()
        if digest in hashes:
            rows.append(
                {
                    "source_bounds": list(bounds),
                    "size": [width, height],
                    "family": family,
                    "role": role,
                    "duplicate_of": hashes[digest],
                    "sha256": digest,
                }
            )
            continue
        name = f"{family}_{len(hashes) + 1:03d}.png"
        crop.save(output / name, optimize=False)
        hashes[digest] = name
        rows.append(
            {
                "name": name,
                "source_bounds": list(bounds),
                "size": [width, height],
                "family": family,
                "state": "separated source component; a distinct pose/palette cell where the sheet is unambiguous",
                "role": role,
                "matte_colors_removed": [list(color) for color in sorted(MATTE)],
                "sha256": digest,
            }
        )
    return rows


def extract_item_block_cells():
    source_name = "item_blocks_sheet.png"
    sheet = Image.open(SOURCE_DIR / source_name).convert("RGBA")
    output = OUTPUT_DIR / "item_block_tiles"
    output.mkdir(parents=True, exist_ok=True)
    rows = []
    hashes = {}
    for y in range(112, sheet.height, 16):
        for x in range(0, sheet.width, 16):
            in_palette_grid = (
                y < 176 and x in range(80, 160, 16)
                or y < 176 and x in range(176, 256, 16)
                or y < 176 and x in range(272, 352, 16)
                or y < 176 and x in range(368, 448, 16)
                or y >= 192 and x in range(272, 352, 16)
                or y >= 192 and x in range(368, 448, 16)
            )
            if not in_palette_grid:
                continue
            bounds = (x, y, min(x + 16, sheet.width), min(y + 16, sheet.height))
            crop = sheet.crop(bounds).convert("RGBA")
            if crop.getchannel("A").getbbox() is None:
                continue
            digest = hashlib.sha256(crop.tobytes()).hexdigest()
            region = "question_brick_palette_tiles" if y < 176 else "castle_block_palette_tiles"
            role = (
                "Question/brick/hard block tile or block-destruction fragment; cell is a 16×16 visual tile and does not define a full block object's behavior."
            )
            if digest in hashes:
                rows.append(
                    {
                        "source_bounds": list(bounds),
                        "size": [16, 16],
                        "family": region,
                        "role": role,
                        "duplicate_of": hashes[digest],
                        "sha256": digest,
                    }
                )
                continue
            name = f"{region}_{len(hashes) + 1:03d}.png"
            crop.save(output / name, optimize=False)
            hashes[digest] = name
            rows.append(
                {
                    "name": name,
                    "source_bounds": list(bounds),
                    "size": [16, 16],
                    "family": region,
                    "state": "unique 16×16 occupied sheet cell",
                    "role": role,
                    "sha256": digest,
                }
            )
    return rows


def extract_tileset_grid_cells():
    """Crop clearly gridded 16x16 palette tiles from the main tile table."""
    source_name = "tileset_sheet.png"
    sheet = Image.open(SOURCE_DIR / source_name).convert("RGBA")
    output = OUTPUT_DIR / "tileset_tiles"
    output.mkdir(parents=True, exist_ok=True)
    regions = [
        ("ground_stone_overworld_underground", (0, 32, 296, 80), "Solid terrain and stone tile palette cells.", None),
        ("ground_stone_castle_underwater", (0, 104, 296, 160), "Solid terrain and stone tile palette cells.", None),
        ("water_sky_tiles", (296, 16, 680, 56), "Water, sky, cloud, and associated background tiles.", None),
        ("coin_block_tiles", (296, 80, 680, 160), "Coin, question-block, and related animated tile frames.", None),
        ("scenery_overworld_underground", (0, 208, 296, 272), "Pipe/scenery tiles in overworld and underground palettes.", None),
        ("scenery_castle_underwater", (0, 288, 296, 336), "Pipe/scenery tiles in castle and underwater palettes.", None),
        ("scenery_mushrooms_snow", (0, 368, 296, 432), "Pipe/scenery tiles in mushrooms and snow palettes.", None),
    ]
    records = []
    hashes = {}
    for family, (left, top, right, bottom), role, _theme in regions:
        for y in range(top, bottom, 16):
            for x in range(left, right, 16):
                bounds = (x, y, min(x + 16, sheet.width), min(y + 16, sheet.height))
                crop = remove_matte(sheet.crop(bounds))
                if crop.getchannel("A").getbbox() is None:
                    continue
                digest = hashlib.sha256(crop.tobytes()).hexdigest()
                if digest in hashes:
                    records.append(
                        {
                            "source_bounds": list(bounds),
                            "size": [16, 16],
                            "family": family,
                            "role": role,
                            "duplicate_of": hashes[digest],
                            "sha256": digest,
                        }
                    )
                    continue
                name = f"{family}_{len(hashes) + 1:03d}.png"
                crop.save(output / name, optimize=False)
                hashes[digest] = name
                records.append(
                    {
                        "name": name,
                        "source_bounds": list(bounds),
                        "size": [16, 16],
                        "family": family,
                        "state": "unique 16×16 palette tile from the source grid",
                        "role": role,
                        "matte_colors_removed": [list(color) for color in sorted(MATTE)],
                        "sha256": digest,
                    }
                )
    return records, regions


def main():
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    for generated_folder in ("enemies", "items_objects", "item_block_tiles", "mario_luigi", "tileset_tiles"):
        path = OUTPUT_DIR / generated_folder
        if path.exists():
            shutil.rmtree(path)
    catalog = {
        "source": "Super Mario Bros. (NES), The Spriters Resource source sheets",
        "source_index": "https://www.spriters-resource.com/nes/supermariobros/",
        "purpose": "Reference-only pixel-exact crops. These are not registered as runtime game sprites to avoid duplicating current art.",
        "sheets": {},
    }

    enemies = save_unique_components(
        "enemies_sheet.png",
        "enemies",
        min_area=100,
        max_size=(48, 48),
        classify=lambda x, y: enemy_group(y),
        accept=lambda bounds, area, family: bounds[1] < 415
        and not (bounds[0] >= 298 and bounds[1] < 104),
    )
    catalog["sheets"]["enemies_sheet.png"] = {
        "description": "Separated enemy frames and palette variants. The lower palette-code chart and explanatory text are not exported as gameplay sprite crops.",
        "cutouts": enemies,
        "uncropped_regions": [
            {"bounds": [304, 0, 436, 104], "reason": "tilemap composite and labels"},
            {"bounds": [0, 415, 436, 530], "reason": "palette charts, sheet credit, and palette notes"},
        ],
    }

    objects = save_unique_components(
        "items_objects_sheet.png",
        "items_objects",
        min_area=90,
        max_size=(64, 64),
        classify=object_group,
        accept=lambda bounds, area, family: bounds[2] <= 306 and bounds[1] < 470,
    )
    catalog["sheets"]["items_objects_sheet.png"] = {
        "description": "Separated item/object/NPC frames and palette cells; exact sheet matte colors are transparent. Some right-side diagram components are classified as examples, not runtime sprites.",
        "cutouts": objects,
        "uncropped_regions": [
            {"bounds": [306, 0, 592, 572], "reason": "labeled behavior and palette demonstration panels; components are not safe to identify as independent game sprites"},
        ],
    }

    player = save_unique_components(
        "mario_luigi_sheet.png",
        "mario_luigi",
        min_area=100,
        max_size=(48, 48),
        classify=player_group,
        accept=lambda bounds, area, family: bounds[1] < 218 or bounds[1] >= 320,
    )
    catalog["sheets"]["mario_luigi_sheet.png"] = {
        "description": "Separated Mario/Luigi animation components and palette-preview poses, with the labeled middle tilemap/text region left intact as a source reference.",
        "cutouts": player,
        "uncropped_regions": [
            {"bounds": [136, 218, 264, 304], "reason": "assembled tilemap/explanation panel, not a set of independent character frames"},
            {"bounds": [264, 218, 584, 320], "reason": "text and palette-code reference panel"},
        ],
    }

    blocks = extract_item_block_cells()
    catalog["sheets"]["item_blocks_sheet.png"] = {
        "description": "Occupied 16×16 cells from the clearly gridded block palette regions, deduplicated by exact RGBA pixel content. This keeps individual block tiles without upscaling.",
        "cutouts": blocks,
        "uncropped_regions": [
            {"bounds": [0, 0, 448, 112], "reason": "loose decorative/debris art and ambiguous fragments are not safely separable as complete block sprites"},
            {"bounds": [0, 112, 80, 176], "reason": "section labels and palette captions"},
            {"bounds": [256, 112, 272, 176], "reason": "blank gutter"},
            {"bounds": [352, 112, 368, 176], "reason": "blank gutter"},
            {"bounds": [0, 176, 448, 192], "reason": "blank row"},
            {"bounds": [0, 192, 272, 256], "reason": "empty/label region without isolated block cells"},
            {"bounds": [352, 192, 368, 256], "reason": "blank gutter"},
        ],
    }
    tileset, tileset_regions = extract_tileset_grid_cells()
    catalog["sheets"]["tileset_sheet.png"] = {
        "description": "Pixel-exact 16×16 tile crops from clearly gridded ground, sky/water, coin/block, and six-biome scenery palettes. Assembled examples and explanatory tables remain as full source references.",
        "cutouts": tileset,
        "source_regions_cropped": [
            {"family": family, "bounds": list(bounds), "role": role}
            for family, bounds, role, _theme in tileset_regions
        ],
        "uncropped_regions": [
            {"bounds": [0, 0, 296, 32], "reason": "sheet title and palette labels"},
            {"bounds": [0, 80, 296, 104], "reason": "beta-tile label and gutters"},
            {"bounds": [296, 0, 680, 16], "reason": "section heading"},
            {"bounds": [296, 56, 680, 80], "reason": "section labels/gutters"},
            {"bounds": [296, 160, 680, 176], "reason": "block-exclusive caption/gutter"},
            {"bounds": [296, 176, 680, 596], "reason": "palette notes, color-code charts, and example tilemaps"},
            {"bounds": [0, 432, 296, 596], "reason": "palette-code/variant reference panels"},
            {"bounds": [0, 596, 680, 776], "reason": "assembled structures with mixed-size objects; individual tile cells cannot be separated into complete objects confidently"},
        ],
    }
    catalog["matte_colors"] = [list(color) for color in sorted(MATTE)]
    CATALOG_PATH.write_text(json.dumps(catalog, indent=2) + "\n", encoding="utf-8")
    print(f"Enemy sheet: {len(enemies)} crop records")
    print(f"Items/objects sheet: {len(objects)} crop records")
    print(f"Item/block sheet: {len(blocks)} cell records")
    print(f"Tileset sheet: {len(tileset)} tile records")
    print(f"Catalog: {CATALOG_PATH.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
