"""Check dashboard text reuses scaled pixel glyphs between frames."""

from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import pygame

from classes.Dashboard import Dashboard


def main():
    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    dashboard = Dashboard("./img/sheets/font.png", 8, screen)

    screen.fill((0, 0, 0))
    dashboard.drawText("MARIO 012345", 20, 20, 15)
    expected = pygame.image.tostring(screen, "RGBA")
    warm_cache_size = len(dashboard._glyphScaleCache)

    scale_calls = 0
    original_scale = pygame.transform.scale

    def count_scale_calls(*args, **kwargs):
        nonlocal scale_calls
        scale_calls += 1
        return original_scale(*args, **kwargs)

    pygame.transform.scale = count_scale_calls
    try:
        screen.fill((0, 0, 0))
        dashboard.drawText("MARIO 012345", 20, 20, 15)
    finally:
        pygame.transform.scale = original_scale

    actual = pygame.image.tostring(screen, "RGBA")
    if actual != expected:
        raise AssertionError("Cached text rendering changed the pixels")
    if scale_calls != 0:
        raise AssertionError(f"Expected zero repeat transforms, got {scale_calls}")

    print(f"unique_cached_glyphs={warm_cache_size}")
    print(f"repeat_scale_calls={scale_calls}")
    print("cached_render_pixels_match=True")
    pygame.quit()


if __name__ == "__main__":
    main()
