"""Exercise active fortress-biome hazards and their registered SMB1 art."""

from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.capture_frames import make_mock_sound
from classes.Level import Level
from entities.BillBlaster import BillBlaster
from entities.BulletBill import BulletBill
from entities.Podoboo import Podoboo


class MockCamera:
    def __init__(self, x=0):
        self.x = x


class MockMario:
    isMario = True

    def __init__(self, rect):
        self.rect = rect


def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    level = Level(screen, make_mock_sound(), None)
    level.load_endless(seed=20261112, initial_columns=0)
    level.endlessBuffer = 0
    # Exercise fortress generation independently of random biome selection.
    level._select_next_biome = lambda: "fortress"
    for _ in range(1216):
        level._append_column()

    fortress_columns = {
        index for index, biome in enumerate(level.columnBiomes) if biome == "fortress"
    }
    assert fortress_columns, "Seed did not generate a fortress biome"
    blasters = [
        entity for entity in level.entityList
        if isinstance(entity, BillBlaster)
        and entity.rect.centerx // 32 in fortress_columns
    ]
    podoboos = [
        entity for entity in level.entityList
        if isinstance(entity, Podoboo)
        and entity.rect.centerx // 32 in fortress_columns
    ]
    assert blasters, "Fortress biome generated no Bill Blaster"
    assert podoboos, "Fortress biome generated no Podoboo"
    assert any(
        overlay["sprite"] is level.sprites.spriteCollection.get("lava")
        for overlay in level.overlaySprites
    ), "Fortress biome generated no lava art"

    blaster = blasters[0]
    mario = MockMario(pygame.Rect(blaster.rect.x + 128, blaster.rect.y, 32, 32))
    level.player = mario
    blaster.spawnTimer = 0
    blaster.update(MockCamera())
    bullets = [entity for entity in level.entityList if isinstance(entity, BulletBill)]
    assert bullets, "Bill Blaster did not emit a Bullet Bill near Mario"
    bullet = bullets[0]
    prior_x = bullet.rect.x
    bullet.update(MockCamera())
    assert bullet.rect.x < prior_x, "Bullet Bill did not travel toward Mario"

    podoboo = podoboos[0]
    camera = MockCamera(-podoboo.rect.x + 100)
    podoboo.update(camera)
    podoboo.update(camera)
    assert podoboo.rect.y < podoboo.lavaY, "Podoboo did not rise from its lava surface"

    print(
        f"PASS: fortress columns={len(fortress_columns)}, "
        f"BillBlasters={len(blasters)}, Podoboos={len(podoboos)}, "
        f"BulletBills fired={len(bullets)}"
    )
    pygame.quit()


if __name__ == "__main__":
    main()
