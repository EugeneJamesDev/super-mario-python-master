"""Verify that distant Infinity decorations do not enter each frame's draw pass."""

from __future__ import annotations

import os
import sys
from pathlib import Path
from types import SimpleNamespace

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import pygame

from tools.capture_frames import make_mock_sound
from classes.Level import Level
from classes.Sprite import Sprite


def main():
    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    from classes.Dashboard import Dashboard

    level = Level(screen, make_mock_sound(), Dashboard("./img/sheets/font.png", 8, screen))
    level.load_endless(seed=17, initial_columns=0)
    decoration = Sprite(pygame.Surface((16, 16), pygame.SRCALPHA), False)
    count = 20_000
    for world_x in range(count):
        level._register_overlay(decoration, world_x * 32, 32, pixel=True)

    camera = SimpleNamespace(pos=SimpleNamespace(x=-(10_000 * 32) / 32))
    touched = 0
    original_overlay_image = level._overlay_image

    def count_image_reads(sprite):
        nonlocal touched
        touched += 1
        return original_overlay_image(sprite)

    level._overlay_image = count_image_reads
    level._draw_overlays(camera)

    expected_visible = sum(
        10_000 * 32 - 16 < world_x * 32 < 10_000 * 32 + screen.get_width()
        for world_x in range(count)
    )
    if touched != expected_visible:
        raise AssertionError(f"Expected {expected_visible} visible decorations, drew {touched}")
    if touched >= count // 10:
        raise AssertionError(f"Visible draw pass was not culled: {touched}/{count}")

    print(f"registered={count}")
    print(f"visible_draw_calls={touched}")
    print(f"skipped={count - touched}")
    print(f"visible_ratio={touched / count:.4%}")
    pygame.quit()


if __name__ == "__main__":
    main()
