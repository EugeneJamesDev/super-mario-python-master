"""Headless check for an optional Infinity fortress bridge/axe set piece."""

from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from classes.EntityCollider import EntityCollider
from entities.FortressBridge import FortressBridge


class Sprite:
    def __init__(self, image):
        self.image = image


class Sprites:
    def __init__(self):
        bridge = pygame.image.load(
            str(ROOT / "img/wiki_assets/SMB_Bowser_Bridge.png")
        ).convert()
        bridge.set_colorkey(bridge.get_at((0, 0)))
        axe = pygame.image.load(str(ROOT / "img/wiki_assets/SMB_Axe.png")).convert()
        axe.set_colorkey(axe.get_at((0, 0)))
        self.items = {
            "bridge_tile": Sprite(pygame.transform.scale(bridge, (32, 32))),
            "axe": Sprite(pygame.transform.scale(axe, (32, 32))),
        }
        for index in range(1, 6):
            frame = pygame.image.load(
                str(ROOT / f"img/smb1_cutouts/smb1_axe_cycle_{index}.png")
            ).convert_alpha()
            self.items[f"axe-{index}"] = Sprite(
                pygame.transform.scale(frame, (32, 32))
            )

    def get(self, key):
        return self.items.get(key)


class MarioStub:
    isMario = True

    def __init__(self, rect, vy):
        self.rect = rect
        self.vel = pygame.Vector2(0, vy)


class LevelStub:
    def __init__(self):
        self.entityList = []


class CameraStub:
    x = 0


def main():
    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    level = LevelStub()
    bridge = FortressBridge(screen, Sprites(), 4, 8, 6, level)
    # The ordinary player collider requires a one-pixel overlap while resolving
    # a falling top contact; this mirrors the actual post-movement check.
    mario = MarioStub(pygame.Rect(5 * 32, bridge.rect.top - 44, 32, 45), 4)
    level.player = mario
    level.entityList = [bridge]

    # The bridge exposes one continuous top surface for normal platform landing.
    state = EntityCollider(mario).check(bridge)
    assert state.isColliding and state.isTop, "Bridge top was not recognized as a landing surface"
    assert bridge.type == "Platform" and bridge.rect.size == (6 * 32, 32)

    # The axe cycles through one current image with the source GIF's timing.
    assert len(bridge.axe_frames) == 5
    frame_indices = {bridge.axe_frame_index}
    for _ in range(sum(bridge.axe_frame_durations)):
        bridge.update(CameraStub())
        frame_indices.add(bridge.axe_frame_index)
    assert frame_indices == set(range(5)), "Axe animation did not visit each frame"
    assert bridge.axe_frame_index == 0, "Axe animation did not loop back to its first frame"

    # Touching the axe disables support immediately; the world does not end.
    mario.rect.center = bridge.axe_rect.center
    bridge.update(CameraStub())
    assert bridge.axe_triggered and bridge.alive is False
    assert not hasattr(bridge, "ending")

    # The tile art falls from the axe end across the span, then cleans up.
    initial_offsets = list(bridge.segment_fall)
    for _ in range(bridge.COLLAPSE_FRAMES):
        bridge.update(CameraStub())
    assert any(after > before for before, after in zip(initial_offsets, bridge.segment_fall))
    assert bridge.alive is None, "Collapsed bridge did not clean itself up"

    pygame.quit()
    print("PASS: bridge supports top landing; axe collapses it and run continues")


if __name__ == "__main__":
    main()
