from copy import deepcopy

import pygame
import json
import os
from pathlib import Path
import sys

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from classes.Sprites import Sprites
from classes.Level import Level
from classes.Dashboard import Dashboard
from classes.Sound import Sound
from classes.Camera import Camera
from classes.Paths import PROJECT_ROOT
from entities.Mario import Mario

# Window setup
GAME_PAGE_WIDTH = 640
GAME_PAGE_HEIGHT = 480
SIDEBAR_WIDTH = 300  # Wider sidebar for better UI
BUILD_WIDTH = GAME_PAGE_WIDTH * 2  # Exactly 2 game pages wide
BUILD_HEIGHT = GAME_PAGE_HEIGHT  # One game page tall
WINDOW_WIDTH = SIDEBAR_WIDTH + BUILD_WIDTH  # 1580 total
WINDOW_HEIGHT = BUILD_HEIGHT + 120  # Extra space for info
BLOCK_SIZE = 32  # 32x32 pixel blocks

# Build space dimensions (in blocks)
BUILD_WIDTH_BLOCKS = BUILD_WIDTH // BLOCK_SIZE  # 40 blocks
BUILD_HEIGHT_BLOCKS = BUILD_HEIGHT // BLOCK_SIZE  # 15 blocks

# Colors - Adobe-like modern palette
SKY_BLUE = (107, 140, 255)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (128, 128, 128)
LIGHT_GRAY = (240, 240, 240)
DARK_GRAY = (45, 45, 45)
GREEN = (76, 175, 80)  # Material Green
RED = (244, 67, 54)  # Material Red
BLUE = (33, 150, 243)  # Material Blue
YELLOW = (255, 193, 7)  # Material Amber
ORANGE = (255, 152, 0)  # Material Orange
CYAN = (0, 188, 212)  # Material Cyan
DARK_BLUE = (25, 118, 210)  # Material Blue Dark
SIDEBAR_BG = (38, 38, 38)  # Dark sidebar
PANEL_BG = (50, 50, 50)  # Panel background
ACCENT = (0, 150, 255)  # Accent color
HOVER = (60, 60, 60)  # Hover state
SELECTED = (0, 120, 215)  # Selected state

# Entity sizes in blocks (width, height)
ENTITY_SIZES = {
    "goomba": (1, 1),
    "koopa": (1, 2),
    "bowser": (1, 2),
    "piranha": (1, 2),
    "coin": (1, 1),
    "coinbox": (1, 1),
    "coinbrick": (1, 1),
    "randombox": (1, 1),
    "brickblock": (1, 1),
    "hardblock": (1, 1),
    "firebar": (1, 1),
    "movingplatform": (1, 1),
    "redmushroom": (1, 1),
    "mushroom": (1, 1),
    "star": (1, 1),
    "fireflower": (1, 1),
    "flower": (1, 1),
}

class UIComponent:
    """Base class for UI components"""
    def __init__(self, rect, parent=None):
        self.rect = rect
        self.parent = parent
        self.visible = True
        self.enabled = True
    
    def handle_event(self, event):
        """Handle events - override in subclasses"""
        return False
    
    def draw(self, surface):
        """Draw component - override in subclasses"""
        pass

class Button(UIComponent):
    """Button UI component"""
    def __init__(self, rect, text, color, callback, parent=None):
        super().__init__(rect, parent)
        self.text = text
        self.color = color
        self.callback = callback
        self.hover = False
        self.pressed = False
    
    def handle_event(self, event):
        if not self.enabled or not self.visible:
            return False
        
        if event.type == pygame.MOUSEMOTION:
            self.hover = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.pressed = True
                return True
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self.pressed and self.rect.collidepoint(event.pos):
                self.pressed = False
                if self.callback:
                    self.callback()
                return True
            self.pressed = False
        
        return False
    
    def draw(self, surface):
        if not self.visible:
            return
        
        # Adobe-like button styling with subtle shadows
        bg_color = self.color
        border_color = tuple(max(0, c - 40) for c in self.color)
        
        if self.pressed:
            bg_color = tuple(max(0, c - 25) for c in self.color)
            # Pressed state - darker
            pygame.draw.rect(surface, tuple(max(0, c - 15) for c in bg_color), 
                           (self.rect.x + 1, self.rect.y + 1, self.rect.width, self.rect.height))
        elif self.hover:
            bg_color = tuple(min(255, c + 15) for c in self.color)
        
        # Main button
        pygame.draw.rect(surface, bg_color, self.rect)
        # Subtle border
        pygame.draw.rect(surface, border_color, self.rect, 1)
        # Top highlight
        if not self.pressed:
            pygame.draw.line(surface, tuple(min(255, c + 30) for c in bg_color),
                           (self.rect.left + 1, self.rect.top + 1),
                           (self.rect.right - 1, self.rect.top + 1), 1)
        
        # Button text with better font
        font = pygame.font.Font(None, 20)
        text_surf = font.render(self.text, True, WHITE)
        text_rect = text_surf.get_rect(center=self.rect.center)
        # Text shadow for readability
        shadow_surf = font.render(self.text, True, (0, 0, 0))
        surface.blit(shadow_surf, (text_rect.x + 1, text_rect.y + 1))
        surface.blit(text_surf, text_rect)

class SpritePalette(UIComponent):
    """Sprite palette component"""
    def __init__(self, rect, sprites, categories, on_select, parent=None):
        super().__init__(rect, parent)
        self.sprites = sprites
        self.categories = categories
        self.on_select = on_select
        self.scroll_offset = 0
        self.selected_sprite = None
        self.sprite_size = 52
        self.start_y = 0
        self.max_scroll = 0
        self._calculate_max_scroll()
    
    def handle_event(self, event):
        if not self.enabled or not self.visible:
            return False
        
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if hasattr(event, 'pos'):
                mouse_x, mouse_y = event.pos
                if self.rect.collidepoint(mouse_x, mouse_y):
                    # Convert to local coordinates
                    local_y = mouse_y - self.rect.y
                    self._handle_click(mouse_x, local_y)
                    return True
        
        if event.type == pygame.MOUSEWHEEL:
            # MOUSEWHEEL events don't have pos, use mouse position from pygame
            mouse_pos = pygame.mouse.get_pos()
            mouse_x, mouse_y = mouse_pos
            # Allow scrolling if mouse is in palette or in sidebar area
            if self.rect.collidepoint(mouse_x, mouse_y) or mouse_x < SIDEBAR_WIDTH:
                scroll_amount = event.y * 30
                self.scroll_offset = max(0, min(self.max_scroll, self.scroll_offset - scroll_amount))
                return True
        
        return False
    
    def _calculate_max_scroll(self):
        """Calculate maximum scroll offset based on content height"""
        total_height = self.start_y
        for category, sprites in self.categories.items():
            if sprites:
                total_height += 28  # Category header
                total_height += len(sprites) * self.sprite_size
        
        # Max scroll is content height minus visible height
        self.max_scroll = max(0, total_height - self.rect.height)
    
    def _handle_click(self, x, y):
        """Handle click on sprite palette"""
        current_y = self.start_y - self.scroll_offset
        
        for category, sprites in self.categories.items():
            if sprites:
                current_y += 28  # Category header
                for sprite_name in sprites:
                    if current_y <= y < current_y + self.sprite_size:
                        self.selected_sprite = sprite_name
                        if self.on_select:
                            self.on_select(sprite_name)
                        return
                    current_y += self.sprite_size
    
    def draw(self, surface):
        if not self.visible:
            return
        
        # Draw on a sub-surface
        palette_surface = surface.subsurface(self.rect)
        palette_surface.fill(PANEL_BG)
        
        # Draw scrollbar if content exceeds visible area
        if self.max_scroll > 0:
            scrollbar_width = 10
            scrollbar_x = self.rect.width - scrollbar_width - 2
            scrollbar_height = self.rect.height - 4
            scrollbar_y = 2
            
            # Scrollbar track
            pygame.draw.rect(palette_surface, (60, 60, 60), 
                           (scrollbar_x, scrollbar_y, scrollbar_width, scrollbar_height))
            pygame.draw.rect(palette_surface, (100, 100, 100), 
                           (scrollbar_x, scrollbar_y, scrollbar_width, scrollbar_height), 1)
            
            # Scrollbar thumb - proportional to visible content
            content_height = self.max_scroll + self.rect.height
            thumb_height = max(30, int(self.rect.height * (self.rect.height / content_height)))
            if self.max_scroll > 0:
                thumb_y = scrollbar_y + int((self.scroll_offset / self.max_scroll) * (scrollbar_height - thumb_height))
            else:
                thumb_y = scrollbar_y
            
            # Clamp thumb position
            thumb_y = max(scrollbar_y, min(thumb_y, scrollbar_y + scrollbar_height - thumb_height))
            
            pygame.draw.rect(palette_surface, (180, 180, 180), 
                           (scrollbar_x + 1, thumb_y, scrollbar_width - 2, thumb_height))
            pygame.draw.rect(palette_surface, WHITE, 
                           (scrollbar_x + 1, thumb_y, scrollbar_width - 2, thumb_height), 1)
        
        y_offset = self.start_y - self.scroll_offset
        
        for category, sprites in self.categories.items():
            if sprites:
                # Category header with Adobe-like styling
                if y_offset > -30 and y_offset < self.rect.height:
                    cat_bg = pygame.Rect(0, y_offset, self.rect.width, 28)
                    pygame.draw.rect(palette_surface, (42, 42, 42), cat_bg)
                    pygame.draw.line(palette_surface, (30, 30, 30), (0, y_offset), (self.rect.width, y_offset), 1)
                    pygame.draw.line(palette_surface, (60, 60, 60), (0, y_offset + 27), (self.rect.width, y_offset + 27), 1)
                    
                    cat_font = pygame.font.Font(None, 16)
                    cat_text = cat_font.render(category.upper(), True, ACCENT)
                    palette_surface.blit(cat_text, (10, y_offset + 7))
                y_offset += 28
                
                for sprite_name in sprites:
                    if y_offset + self.sprite_size > 0 and y_offset < self.rect.height:
                        # Sprite item background with Adobe-like styling
                        sprite_bg = pygame.Rect(2, y_offset + 1, self.rect.width - 4, self.sprite_size - 2)
                        if self.selected_sprite == sprite_name:
                            pygame.draw.rect(palette_surface, SELECTED, sprite_bg)
                            pygame.draw.rect(palette_surface, ACCENT, sprite_bg, 2)
                        else:
                            pygame.draw.rect(palette_surface, (45, 45, 45), sprite_bg)
                            # Subtle hover effect border
                            pygame.draw.rect(palette_surface, (35, 35, 35), sprite_bg, 1)
                        
                        # Sprite preview would go here
                        # For now, just show name
                        name_font = pygame.font.Font(None, 13)
                        name_text = name_font.render(sprite_name[:24], True, WHITE)
                        palette_surface.blit(name_text, (8, y_offset + 18))
                    
                    y_offset += self.sprite_size

class MapMaker:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption("Super Mario Map Maker")
        self.clock = pygame.time.Clock()
        
        # Create a game-sized surface for play mode
        self.game_surface = pygame.Surface((GAME_PAGE_WIDTH, GAME_PAGE_HEIGHT))
        
        # Initialize game components
        self.dashboard = Dashboard("./img/sheets/font.png", 8, self.game_surface)
        self.sound = Sound()
        self.sprites = Sprites()
        
        # Dynamic build width (starts at 2 game pages, can be extended)
        self.build_width_blocks = BUILD_WIDTH_BLOCKS  # 40 blocks = 2 game pages
        
        # Create a minimal level for rendering
        self.level = Level(self.game_surface, self.sound, self.dashboard)
        self.level.level = [[None for _ in range(self.build_width_blocks)] for _ in range(BUILD_HEIGHT_BLOCKS)]
        self.level.levelLength = self.build_width_blocks
        
        # Initialize sky background
        sky_sprite = self.sprites.spriteCollection.get("sky")
        if sky_sprite and sky_sprite.image:
            for y in range(BUILD_HEIGHT_BLOCKS):
                for x in range(self.build_width_blocks):
                    from classes.Tile import Tile
                    self.level.level[y][x] = Tile(sky_sprite, None)
        
        # Map data
        self.map_data = {
            "id": 1,
            "length": self.build_width_blocks,
            "level": {
                "objects": {
                    "bush": [],
                    "cloud": [],
                    "pipe": [],
                    "ground": [],
                    "sky": [],
                    "scenery": []
                },
                "layers": {
                    "sky": {
                        "x": [0, self.build_width_blocks],
                        "y": [0, BUILD_HEIGHT_BLOCKS]
                    },
                    "ground": {
                        "x": [0, self.build_width_blocks],
                        "y": [BUILD_HEIGHT_BLOCKS - 2, BUILD_HEIGHT_BLOCKS]
                    }
                },
                "entities": {}
            }
        }
        
        # Editor state
        self.selected_sprite = None
        self.selected_tube_height = 3  # Default tube height
        self.placing_piranha_on_pipe = False  # Special mode for placing piranha on pipe
        self.dragging = False
        self.drag_start_pos = None
        self.last_placed_pos = None
        self.is_playing = False
        from classes.Maths import Vec2D
        self.camera = Camera(Vec2D(0, 0), None)
        self.camera.x = 0
        self.camera.pos.x = 0
        
        # Build area scrolling
        self.build_scroll_x = 0  # Horizontal scroll offset for build area (in pixels)
        self.scroll_speed = 20  # Pixels per scroll step
        self.max_scroll_x = 0  # Will be calculated based on build width
        
        # Load all available sprites
        self.available_sprites = self._load_all_sprites()
        self.sprite_categories = self._categorize_sprites()
        
        # Entity placement tracking
        self.placed_entities = {
            "objects": {},
            "entities": {}
        }
        
        # UI Components
        self.ui_components = []
        self._setup_ui()
        
        # Mario for testing
        self.mario = None
        self.play_level = None
        
        # Font for labels
        self.label_font = pygame.font.Font(None, 14)
        self.small_font = pygame.font.Font(None, 12)
    
    def _setup_ui(self):
        """Setup modular UI components"""
        # Buttons
        button_width = 130
        button_height = 38
        button_spacing = 8
        start_y = 12
        
        play_btn = Button(
            pygame.Rect(10, start_y, button_width, button_height),
            "Play" if not self.is_playing else "Pause",
            GREEN if self.is_playing else (100, 100, 100),
            self._toggle_play
        )
        self.ui_components.append(play_btn)
        self.play_button = play_btn
        
        save_btn = Button(
            pygame.Rect(10, start_y + button_height + button_spacing, button_width, button_height),
            "Save",
            BLUE,
            self._save_map
        )
        self.ui_components.append(save_btn)
        self.save_button = save_btn
        
        clear_btn = Button(
            pygame.Rect(10, start_y + (button_height + button_spacing) * 2, button_width, button_height),
            "Clear",
            RED,
            self._clear_map
        )
        self.ui_components.append(clear_btn)
        self.clear_button = clear_btn
        
        extend_btn = Button(
            pygame.Rect(10, start_y + (button_height + button_spacing) * 3, button_width, button_height),
            "Add Page (+20 blocks)",
            ORANGE,
            self._extend_build_space
        )
        self.ui_components.append(extend_btn)
        self.extend_button = extend_btn
        
        # Tube preset buttons
        tube_button_width = 50
        tube_button_height = 28
        tube_start_y = start_y + (button_height + button_spacing) * 4 + 10
        tube_label_font = pygame.font.Font(None, 14)
        
        # Label for tube buttons
        self.tube_buttons = []
        total_tube_width = 5 * tube_button_width + 4 * 4  # 5 buttons + 4 gaps
        tube_start_x = (SIDEBAR_WIDTH - total_tube_width) // 2  # Center the buttons
        for i, height in enumerate([2, 3, 4, 5, 6]):
            btn_x = tube_start_x + (i * (tube_button_width + 4))
            tube_btn = Button(
                pygame.Rect(btn_x, tube_start_y, tube_button_width, tube_button_height),
                f"{height}",
                CYAN if height == 3 else DARK_BLUE,
                lambda h=height: self._select_tube_height(h)
            )
            self.ui_components.append(tube_btn)
            self.tube_buttons.append((tube_btn, height))
        
        # Add label above tube buttons
        label_text = tube_label_font.render("Tube Height:", True, WHITE)
        label_y = tube_start_y - 18
        self.tube_label_surface = label_text
        self.tube_label_y = label_y
        
        # Piranha on pipe button
        piranha_btn = Button(
            pygame.Rect(10, tube_start_y + tube_button_height + 10, button_width, tube_button_height),
            "Piranha Spawner",
            GREEN,
            self._toggle_piranha_mode
        )
        self.ui_components.append(piranha_btn)
        self.piranha_button = piranha_btn
        
        # Sprite palette
        palette_y = tube_start_y + tube_button_height * 2 + 35
        palette_height = WINDOW_HEIGHT - palette_y - 140
        palette = SpritePalette(
            pygame.Rect(10, palette_y, SIDEBAR_WIDTH - 20, palette_height),
            self.available_sprites,
            self.sprite_categories,
            self._on_sprite_selected
        )
        palette.start_y = 0
        palette._calculate_max_scroll()  # Calculate initial max scroll
        self.ui_components.append(palette)
        self.sprite_palette = palette
    
    def _on_sprite_selected(self, sprite_name):
        """Callback when sprite is selected"""
        self.selected_sprite = sprite_name
        self.sprite_palette.selected_sprite = sprite_name
        # Disable piranha mode when selecting a sprite
        self.placing_piranha_on_pipe = False
    
    def _select_tube_height(self, height):
        """Select a preset tube height"""
        self.selected_tube_height = height
        self.selected_sprite = "pipe"  # Set pipe as selected
        self.placing_piranha_on_pipe = False
        # Update button colors
        for btn, btn_height in self.tube_buttons:
            if btn_height == height:
                btn.color = CYAN
            else:
                btn.color = DARK_BLUE
    
    def _toggle_piranha_mode(self):
        """Toggle piranha plant spawner mode"""
        self.placing_piranha_on_pipe = not self.placing_piranha_on_pipe
        if self.placing_piranha_on_pipe:
            self.selected_sprite = None
            self.piranha_button.color = RED
            self.piranha_button.text = "Cancel Piranha"
        else:
            self.piranha_button.color = GREEN
            self.piranha_button.text = "Piranha Spawner"
    
    def _load_all_sprites(self):
        """Load all sprites from the sprite collection"""
        sprites = {}
        sprite_collection = self.sprites.spriteCollection
        
        for sprite_name in sprite_collection.keys():
            sprite = sprite_collection.get(sprite_name)
            if sprite:
                sprites[sprite_name] = sprite
        
        return sprites
    
    def _categorize_sprites(self):
        """Categorize sprites for better organization"""
        categories = {
            "Blocks": [],
            "Enemies": [],
            "Items": [],
            "Background": [],
            "Scenery": [],
            "Other": []
        }
        
        enemy_first_frames = {
            "goomba": "goomba-1",
            "koopa": "koopa-1",
            "bowser_green": "bowser_green_1",
            "bowser_redeyes": "bowser_redeyes_1",
            "piranha": None,
        }
        
        found_enemies = set()
        for sprite_name in self.available_sprites.keys():
            name_lower = sprite_name.lower()
            if "piranha" in name_lower and "piranha" not in found_enemies:
                enemy_first_frames["piranha"] = sprite_name
                found_enemies.add("piranha")
            elif "goomba-1" in name_lower and "goomba" not in found_enemies:
                found_enemies.add("goomba")
            elif "koopa-1" in name_lower and "koopa" not in found_enemies:
                found_enemies.add("koopa")
            elif "bowser_green_1" in name_lower and "bowser_green" not in found_enemies:
                found_enemies.add("bowser_green")
            elif "bowser_redeyes_1" in name_lower and "bowser_redeyes" not in found_enemies:
                found_enemies.add("bowser_redeyes")
        
        block_keywords = ["brick", "block", "hard", "ground", "pipe", "empty", "coin"]
        enemy_keywords = ["goomba", "koopa", "piranha", "bowser", "fire"]
        item_keywords = ["coin", "mushroom", "flower", "star", "item", "powerup"]
        bg_keywords = ["sky", "cloud", "bush"]
        scenery_keywords = ["scenery", "fortress", "pole", "horsetail", "tree", "fence", "mushroom"]
        
        for sprite_name, sprite in self.available_sprites.items():
            name_lower = sprite_name.lower()
            
            # Filter out Mario and Luigi
            if "mario" in name_lower or "luigi" in name_lower:
                continue
            
            categorized = False
            
            if name_lower in {"coin", "fire_flower_item", "super_star", "mushroom"}:
                categories["Items"].append(sprite_name)
                categorized = True
            elif any(kw in name_lower for kw in block_keywords):
                categories["Blocks"].append(sprite_name)
                categorized = True
            elif any(kw in name_lower for kw in enemy_keywords):
                is_first_frame = False
                for enemy_type, first_frame in enemy_first_frames.items():
                    if first_frame and sprite_name == first_frame:
                        is_first_frame = True
                        break
                    if enemy_type == "goomba" and sprite_name == "goomba-1":
                        is_first_frame = True
                        break
                    elif enemy_type == "koopa" and sprite_name == "koopa-1":
                        is_first_frame = True
                        break
                    elif enemy_type == "bowser_green" and sprite_name == "bowser_green_1":
                        is_first_frame = True
                        break
                    elif enemy_type == "bowser_redeyes" and sprite_name == "bowser_redeyes_1":
                        is_first_frame = True
                        break
                    elif enemy_type == "piranha" and first_frame and sprite_name == first_frame:
                        is_first_frame = True
                        break
                
                if is_first_frame:
                    categories["Enemies"].append(sprite_name)
                categorized = True
            elif any(kw in name_lower for kw in item_keywords) and "coinbox" not in name_lower:
                categories["Items"].append(sprite_name)
                categorized = True
            elif any(kw in name_lower for kw in bg_keywords):
                categories["Background"].append(sprite_name)
                categorized = True
            elif any(kw in name_lower for kw in scenery_keywords):
                categories["Scenery"].append(sprite_name)
                categorized = True
            
            if not categorized:
                categories["Other"].append(sprite_name)
        
        return categories
    
    def _get_sprite_preview(self, sprite_name):
        """Get a preview image for a sprite"""
        sprite = self.available_sprites.get(sprite_name)
        if not sprite:
            return None
        
        if sprite.image:
            return sprite.image
        elif sprite.animation and sprite.animation.images:
            return sprite.animation.images[0]
        return None
    
    def _get_entity_size(self, sprite_name):
        """Get the size of an entity spawner"""
        base_name = sprite_name.lower()
        if "-1" in base_name:
            base_name = base_name.split("-1")[0]
        elif "_1" in base_name:
            base_name = base_name.rsplit("_1", 1)[0]
        
        for entity_key, size in ENTITY_SIZES.items():
            if entity_key in base_name:
                return size
        return (1, 1)
    
    def _get_entity_label(self, sprite_name):
        """Get a label for an entity"""
        base_name = sprite_name.lower()
        if "-1" in base_name:
            base_name = base_name.split("-1")[0]
        elif "_1" in base_name:
            base_name = base_name.rsplit("_1", 1)[0]
        
        if "goomba" in base_name:
            return "Goomba"
        elif "koopa" in base_name:
            return "Koopa"
        elif "bowser" in base_name:
            if "redeyes" in sprite_name.lower():
                return "Bowser (Red)"
            return "Bowser"
        elif "piranha" in base_name:
            return "Piranha"
        elif "coinbox" in base_name:
            return "CoinBox"
        elif "coinbrick" in base_name:
            return "CoinBrick"
        elif "randombox" in base_name:
            return "RandomBox"
        elif "brickblock" in base_name:
            return "BrickBlock"
        elif "hardblock" in base_name:
            return "HardBlock"
        elif "firebar" in base_name:
            return "FireBar"
        elif "movingplatform" in base_name:
            return "Platform"
        elif "coin" in base_name:
            return "Coin"
        elif "redmushroom" in base_name or "mushroom" in base_name:
            return "Red Mushroom"
        elif "star" in base_name:
            return "Star"
        elif "fireflower" in base_name or "flower" in base_name:
            return "Fire Flower"
        return sprite_name
    
    def _snap_to_grid(self, x, y):
        """Snap coordinates to grid (accounting for scroll offset)"""
        grid_x = (x - SIDEBAR_WIDTH + self.build_scroll_x) // BLOCK_SIZE
        grid_y = y // BLOCK_SIZE
        return grid_x, grid_y
    
    def _is_in_build_area(self, x, y):
        """Check if coordinates are in build area"""
        return SIDEBAR_WIDTH <= x < SIDEBAR_WIDTH + self.build_width_blocks * BLOCK_SIZE and 0 <= y < BUILD_HEIGHT
    
    def _place_sprite(self, sprite_name, grid_x, grid_y, force=False):
        """Place a sprite at grid coordinates"""
        if not (0 <= grid_x < self.build_width_blocks and 0 <= grid_y < BUILD_HEIGHT_BLOCKS):
            return False
        
        if not force and self.last_placed_pos == (grid_x, grid_y):
            return False
        
        # Handle pipe placement first (before sprite lookup, since "pipe" is not a sprite)
        sprite_lower = sprite_name.lower() if sprite_name else ""
        if "pipe" in sprite_lower or (self.selected_sprite == "pipe" and not self.placing_piranha_on_pipe):
            # Place a pipe using the selected tube height
            return self._place_pipe(grid_x, grid_y, force)
        
        sprite = self.available_sprites.get(sprite_name)
        if not sprite:
            return False
        
        if any(kw in sprite_lower for kw in ["sky", "ground", "brick", "hardblock", "empty", 
                                              "mushroomcap", "mushroomstem", "fence", "dirt", 
                                              "iceblock", "tree", "circle_bush", "key_coin"]):
            from classes.Tile import Tile
            self.level.level[grid_y][grid_x] = Tile(sprite, sprite.colliding if hasattr(sprite, 'colliding') else False)
            self.last_placed_pos = (grid_x, grid_y)
            return True
        
        elif any(kw in sprite_lower for kw in ["bush", "cloud"]):
            key = "bush" if "bush" in sprite_lower else "cloud"
            if key not in self.placed_entities["objects"]:
                self.placed_entities["objects"][key] = []
            entry = [grid_x, grid_y]
            if entry not in self.placed_entities["objects"][key]:
                self.placed_entities["objects"][key].append(entry)
                self.last_placed_pos = (grid_x, grid_y)
                return True
        
        elif any(kw in sprite_lower for kw in ["fortress", "pole", "horsetail", "scenery"]):
            if "scenery" not in self.placed_entities["objects"]:
                self.placed_entities["objects"]["scenery"] = []
            entry = [sprite_name, grid_x]
            if entry not in self.placed_entities["objects"]["scenery"]:
                self.placed_entities["objects"]["scenery"].append(entry)
                from classes.Tile import Tile
                self.level.level[grid_y][grid_x] = Tile(sprite, sprite.colliding if hasattr(sprite, 'colliding') else False)
                self.last_placed_pos = (grid_x, grid_y)
                return True
        
        elif any(kw in sprite_lower for kw in ["goomba", "koopa", "coin", "coinbox", "coinbrick", 
                                                "randombox", "brickblock", "hardblock", "firebar",
                                                "movingplatform", "piranha", "bowser", "mushroom",
                                                "star", "flower", "redmushroom", "fireflower"]):
            return self._place_entity(sprite_name, grid_x, grid_y, force)
        
        else:
            from classes.Tile import Tile
            self.level.level[grid_y][grid_x] = Tile(sprite, sprite.colliding if hasattr(sprite, 'colliding') else False)
            self.last_placed_pos = (grid_x, grid_y)
            return True
    
    def _place_pipe(self, grid_x, grid_y, force=False):
        """Place a pipe at grid coordinates with the selected height"""
        # Check if we can place a pipe (needs 2 blocks wide)
        if not (0 <= grid_x < self.build_width_blocks - 1 and 0 <= grid_y < BUILD_HEIGHT_BLOCKS):
            return False
        
        if not force and self.last_placed_pos == (grid_x, grid_y):
            return False
        
        # Remove any existing pipe at this location first
        if "pipe" in self.placed_entities["objects"]:
            pipes_to_remove = []
            for entry in self.placed_entities["objects"]["pipe"]:
                if len(entry) >= 2 and entry[0] == grid_x and entry[1] == grid_y:
                    pipes_to_remove.append(entry)
            for pipe_entry in pipes_to_remove:
                if pipe_entry in self.placed_entities["objects"]["pipe"]:
                    self.placed_entities["objects"]["pipe"].remove(pipe_entry)
        
        # Use the level's addPipeSprite method to actually place the pipe tiles
        height = self.selected_tube_height
        success = self.level.addPipeSprite(grid_x, grid_y, height, plant=False)
        
        if success:
            # Add to placed entities for saving
            if "pipe" not in self.placed_entities["objects"]:
                self.placed_entities["objects"]["pipe"] = []
            entry = [grid_x, grid_y, height]
            if entry not in self.placed_entities["objects"]["pipe"]:
                self.placed_entities["objects"]["pipe"].append(entry)
            self.last_placed_pos = (grid_x, grid_y)
            return True
        
        return False
    
    def _place_piranha_on_pipe(self, grid_x, grid_y):
        """Place a piranha plant spawner on top of a pipe"""
        # Check if there's a pipe at this location or one block below
        pipe_found = False
        pipe_x = grid_x
        pipe_y = grid_y
        
        # Check current position
        if "pipe" in self.placed_entities["objects"]:
            for entry in self.placed_entities["objects"]["pipe"]:
                if len(entry) >= 2:
                    px, py = entry[0], entry[1]
                    # Check if clicking on the top of the pipe (pipe is 2 blocks wide)
                    if (px == grid_x or px + 1 == grid_x) and py == grid_y:
                        pipe_found = True
                        pipe_x, pipe_y = px, py
                        break
                    # Also check one block below (in case clicking on the pipe body)
                    elif (px == grid_x or px + 1 == grid_x) and py == grid_y - 1:
                        pipe_found = True
                        pipe_x, pipe_y = px, py
                        break
        
        if not pipe_found:
            return False
        
        # Place piranha plant entity at the pipe top
        return self._place_entity("piranha", pipe_x, pipe_y, force=True)
    
    def _place_entity(self, sprite_name, grid_x, grid_y, force=False):
        """Place an entity spawner at grid coordinates"""
        sprite_lower = sprite_name.lower()
        
        entity_map = {
            "goomba-1": "Goomba",
            "goomba": "Goomba",
            "koopa-1": "Koopa",
            "koopa": "Koopa",
            "coin": "coin",
            "coinbox": "CoinBox",
            "coinbrick": "coinBrick",
            "randombox": "RandomBox",
            "brickblock": "BrickBlock",
            "hardblock": "HardBlock",
            "firebar": "FireBar",
            "movingplatform": "MovingPlatform",
            "piranha": "PiranhaPlant",
            "bowser_green_1": "Bowser",
            "bowser_redeyes_1": "Bowser",
            "bowser": "Bowser",
            "redmushroom": "RedMushroom",
            "mushroom": "RedMushroom",
            "star": "Star",
            "fireflower": "FireFlower",
            "flower": "FireFlower",
        }
        
        entity_type = None
        if sprite_lower in entity_map:
            entity_type = entity_map[sprite_lower]
        else:
            for key, etype in entity_map.items():
                if key in sprite_lower:
                    entity_type = etype
                    break
        
        if not entity_type:
            return False
        
        base_name = sprite_name
        if "-1" in sprite_name:
            base_name = sprite_name.split("-1")[0]
        elif "_1" in sprite_name:
            base_name = sprite_name.rsplit("_1", 1)[0]
        
        size_w, size_h = self._get_entity_size(base_name)
        label = self._get_entity_label(base_name)
        
        if entity_type not in self.placed_entities["entities"]:
            self.placed_entities["entities"][entity_type] = []
        
        for existing in self.placed_entities["entities"][entity_type]:
            if isinstance(existing, tuple) and len(existing) >= 2:
                ex, ey = existing[0], existing[1]
                if len(existing) >= 4:
                    esize_w, esize_h = existing[2], existing[3]
                else:
                    esize_w, esize_h = 1, 1
                if (ex <= grid_x < ex + esize_w and ey <= grid_y < ey + esize_h):
                    if not force:
                        return False
                if (grid_x <= ex < grid_x + size_w and grid_y <= ey < grid_y + size_h):
                    if not force:
                        return False
        
        spawner_data = (grid_x, grid_y, size_w, size_h, label, sprite_lower)
        self.placed_entities["entities"][entity_type].append(spawner_data)
        self.last_placed_pos = (grid_x, grid_y)
        return True
    
    def _remove_at_position(self, grid_x, grid_y):
        """Remove sprite/entity at grid position"""
        removed = False
        sky_sprite = self.sprites.spriteCollection.get("sky")
        from classes.Tile import Tile
        
        # Handle pipe removal (pipes are 2 blocks wide and multiple blocks tall)
        if "pipe" in self.placed_entities["objects"]:
            pipes_to_remove = []
            for entry in self.placed_entities["objects"]["pipe"]:
                if len(entry) >= 3:
                    px, py, pheight = entry[0], entry[1], entry[2]
                    end_row = self.level.pipe_end_row(py, pheight)
                    clicked_tile = self.level.level[grid_y][grid_x]
                    if (
                        px <= grid_x < px + 2
                        and py <= grid_y < end_row
                        and clicked_tile is not None
                        and clicked_tile.sprite in self.level.pipeSprites
                    ):
                        pipes_to_remove.append(entry)
                        # Remove all pipe tiles
                        for y in range(py, end_row):
                            for x in [px, px + 1]:
                                if 0 <= y < len(self.level.level) and 0 <= x < len(self.level.level[y]):
                                    tile = self.level.level[y][x]
                                    if sky_sprite and tile is not None and tile.sprite in self.level.pipeSprites:
                                        self.level.level[y][x] = Tile(sky_sprite, None)
                        removed = True
            
            # Remove from placed entities
            for pipe_entry in pipes_to_remove:
                if pipe_entry in self.placed_entities["objects"]["pipe"]:
                    self.placed_entities["objects"]["pipe"].remove(pipe_entry)
                plants = self.placed_entities["entities"].get("PiranhaPlant", [])
                plants[:] = [plant for plant in plants if tuple(plant[:2]) != tuple(pipe_entry[:2])]
            if pipes_to_remove:
                self.level._rebuild_pipe_foreground()
        
        # Handle regular tile removal
        if 0 <= grid_y < len(self.level.level) and 0 <= grid_x < len(self.level.level[grid_y]):
            if sky_sprite:
                self.level.level[grid_y][grid_x] = Tile(sky_sprite, None)
                removed = True
        
        # Handle other objects (bush, cloud, scenery)
        for obj_type, positions in list(self.placed_entities["objects"].items()):
            if obj_type == "pipe":  # Already handled above
                continue
            original_len = len(self.placed_entities["objects"][obj_type])
            self.placed_entities["objects"][obj_type] = [
                pos for pos in positions 
                if not (isinstance(pos, list) and len(pos) >= 2 and pos[0] == grid_x and pos[1] == grid_y)
            ]
            if len(self.placed_entities["objects"][obj_type]) < original_len:
                removed = True
        
        for entity_type, entities in list(self.placed_entities["entities"].items()):
            new_entities = []
            for entity_data in entities:
                if isinstance(entity_data, tuple) and len(entity_data) >= 2:
                    ex, ey = entity_data[0], entity_data[1]
                    if len(entity_data) >= 4:
                        size_w, size_h = entity_data[2], entity_data[3]
                    else:
                        size_w, size_h = 1, 1
                    if not (ex <= grid_x < ex + size_w and ey <= grid_y < ey + size_h):
                        new_entities.append(entity_data)
                    else:
                        removed = True
                elif isinstance(entity_data, list) and len(entity_data) >= 2:
                    ex, ey = entity_data[0], entity_data[1]
                    if ex != grid_x or ey != grid_y:
                        new_entities.append(entity_data)
                    else:
                        removed = True
                elif isinstance(entity_data, dict):
                    ex = entity_data.get("x", 0)
                    ey = entity_data.get("y", 0)
                    if ex != grid_x or ey != grid_y:
                        new_entities.append(entity_data)
                    else:
                        removed = True
                else:
                    new_entities.append(entity_data)
            self.placed_entities["entities"][entity_type] = new_entities
        
        return removed
    
    def _map_snapshot(self):
        """Create the level data used by both JSON exports and play mode."""
        data = deepcopy(self.map_data)
        level = data["level"]
        level["objects"].update(self.placed_entities["objects"])
        for entity_type, entries in self.placed_entities["entities"].items():
            serialized = []
            for entry in entries:
                if isinstance(entry, tuple):
                    record = {"x": entry[0], "y": entry[1]}
                    if entity_type == "Bowser" and entry[5] == "bowser_redeyes_1":
                        record["variant"] = "redeyes"
                    serialized.append(record)
                else:
                    serialized.append(entry)
            level["entities"][entity_type] = serialized

        # Pipes load from object entries. Painted terrain and scenery retain
        # their exact cells through the tile list.
        names = {sprite: name for name, sprite in self.available_sprites.items()}
        level["tiles"] = [
            [x, y, names[tile.sprite]]
            for y, row in enumerate(self.level.level)
            for x, tile in enumerate(row)
            if tile is not None and tile.sprite in names and names[tile.sprite] != "sky"
        ]
        level["objects"]["scenery"] = []
        return data

    def _save_map(self):
        """Save the current map to a JSON file."""
        try:
            data = self._map_snapshot()
            # Ensure levels directory exists
            os.makedirs("./levels", exist_ok=True)
            
            # Find next available filename
            filename = "map_section_1.json"
            filepath = f"./levels/{filename}"
            
            counter = 1
            while os.path.exists(filepath):
                counter += 1
                filename = f"map_section_{counter}.json"
                filepath = f"./levels/{filename}"
            
            # Save the file
            with open(filepath, 'w') as f:
                json.dump(data, f, indent=4)
            
            # Print confirmation
            print(f"✓ Map saved successfully to: {filepath}")
            print(f"  - Width: {self.build_width_blocks} blocks")
            print(f"  - Objects: {sum(len(v) for v in self.placed_entities['objects'].values())}")
            print(f"  - Entities: {sum(len(v) for v in data['level']['entities'].values())}")
            
            return filepath
            
        except Exception as e:
            print(f"✗ Error saving map: {e}")
            import traceback
            traceback.print_exc()
            return None
    
    def _toggle_play(self):
        """Toggle play/pause mode - create separate game instance"""
        self.is_playing = not self.is_playing
        
        if self.is_playing:
            play_dashboard = Dashboard("./img/sheets/font.png", 8, self.game_surface)
            self.play_level = Level(self.game_surface, self.sound, play_dashboard)
            self.play_level.load_authored(self._map_snapshot())
            self.mario = Mario(0, 10, self.play_level, self.game_surface, play_dashboard, self.sound)
            self.camera = self.mario.camera

            # Update button text and make it more visible
            self.play_button.text = "EXIT PLAY"
            self.play_button.color = RED
            # Make button bigger and more visible
            self.play_button.rect = pygame.Rect(10, 10, SIDEBAR_WIDTH - 20, 50)
        else:
            if self.mario:
                self.mario = None
            if self.play_level:
                self.play_level = None
            from classes.Maths import Vec2D
            self.camera = Camera(Vec2D(0, 0), None)
            self.camera.x = 0
            self.camera.pos.x = 0
            
            # Update button text and restore size
            self.play_button.text = "Play"
            self.play_button.color = (100, 100, 100)
            # Restore button size
            button_width = 130
            button_height = 38
            start_y = 12
            self.play_button.rect = pygame.Rect(10, start_y, button_width, button_height)
            self.play_button.enabled = True
    
    def _clear_map(self):
        """Clear the entire map"""
        sky_sprite = self.sprites.spriteCollection.get("sky")
        if sky_sprite:
            from classes.Tile import Tile
            for y in range(BUILD_HEIGHT_BLOCKS):
                for x in range(self.build_width_blocks):
                    self.level.level[y][x] = Tile(sky_sprite, None)
        
        self.placed_entities = {
            "objects": {},
            "entities": {}
        }
        
        self.map_data = {
            "id": 1,
            "length": self.build_width_blocks,
            "level": {
                "objects": {
                    "bush": [],
                    "cloud": [],
                    "pipe": [],
                    "ground": [],
                    "sky": [],
                    "scenery": []
                },
                "layers": {
                    "sky": {
                        "x": [0, self.build_width_blocks],
                        "y": [0, BUILD_HEIGHT_BLOCKS]
                    },
                    "ground": {
                        "x": [0, self.build_width_blocks],
                        "y": [BUILD_HEIGHT_BLOCKS - 2, BUILD_HEIGHT_BLOCKS]
                    }
                },
                "entities": {}
            }
        }
    
    def _extend_build_space(self):
        """Extend the build space by one game page (20 blocks = 640 pixels)"""
        # One game page = 640 pixels = 20 blocks
        extension_blocks = GAME_PAGE_WIDTH // BLOCK_SIZE  # 20 blocks
        new_width = self.build_width_blocks + extension_blocks
        
        # Extend the level array
        sky_sprite = self.sprites.spriteCollection.get("sky")
        from classes.Tile import Tile
        
        for y in range(BUILD_HEIGHT_BLOCKS):
            # Extend each row
            for x in range(self.build_width_blocks, new_width):
                if sky_sprite:
                    self.level.level[y].append(Tile(sky_sprite, None))
                else:
                    self.level.level[y].append(None)
        
        # Update width
        self.build_width_blocks = new_width
        self.level.levelLength = new_width
        
        # Don't resize window - keep it at 2 pages visible, use scrolling
        # The window stays at 2 game pages wide, but build space can extend
        
        # Update map data length
        self.map_data["length"] = new_width
        self.map_data["level"]["layers"]["sky"]["x"][1] = new_width
        self.map_data["level"]["layers"]["ground"]["x"][1] = new_width
        
        pages = self.build_width_blocks // 20
        print(f"Build space extended to {self.build_width_blocks} blocks ({pages} game pages)")
    
    def handle_events(self):
        """Handle pygame events"""
        # In play mode, let Mario handle input via his update() method
        # We only check for editor-specific controls here
        if self.is_playing and self.mario:
            # Get all events
            events = list(pygame.event.get())  # Convert to list so we can iterate multiple times
            exit_rect = pygame.Rect(10, 10, SIDEBAR_WIDTH - 20, 50)
            
            # Check for exit controls first
            events_to_post = []
            exit_triggered = False
            
            for event in events:
                if event.type == pygame.QUIT:
                    return False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self._toggle_play()
                        exit_triggered = True
                        # Don't post this event back
                        continue
                elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                    # Check if exit button was clicked (in sidebar area)
                    if event.pos[0] < SIDEBAR_WIDTH and exit_rect.collidepoint(event.pos):
                        self._toggle_play()
                        exit_triggered = True
                        # Don't post this event back
                        continue
                
                # Post other events for Mario to handle
                events_to_post.append(event)
            
            # Post remaining events for Mario
            for event in events_to_post:
                pygame.event.post(event)
            
            # If exit was triggered, return early
            if exit_triggered:
                return True
            
            # Check if Mario died and return to editor
            if self.mario and self.mario.restart:
                self._toggle_play()  # This will exit play mode and return to editor
                return True
            
            return True
        else:
            # Edit mode - handle UI and editor events
            events = pygame.event.get()
            for event in events:
                if event.type == pygame.QUIT:
                    return False
                
                # Let UI components handle events first
                handled = False
                for component in self.ui_components:
                    if component.handle_event(event):
                        handled = True
                        break
                
                if handled:
                    continue
                
                # Editor events
                if event.type == pygame.MOUSEBUTTONDOWN:
                    mouse_x, mouse_y = event.pos
                    
                    if event.button == 1:  # Left click
                        if self._is_in_build_area(mouse_x, mouse_y):
                            grid_x, grid_y = self._snap_to_grid(mouse_x, mouse_y)
                            
                            # Handle piranha plant spawner mode
                            if self.placing_piranha_on_pipe:
                                if self._place_piranha_on_pipe(grid_x, grid_y):
                                    self.dragging = True
                                    self.drag_start_pos = (grid_x, grid_y)
                                    self.last_placed_pos = (grid_x, grid_y)
                            # Handle pipe placement (when tube height is selected)
                            elif self.selected_sprite == "pipe" or (self.selected_tube_height and not self.selected_sprite):
                                if self._place_pipe(grid_x, grid_y, force=True):
                                    self.dragging = True
                                    self.drag_start_pos = (grid_x, grid_y)
                                    self.last_placed_pos = (grid_x, grid_y)
                            elif self.selected_sprite:
                                if self._place_sprite(self.selected_sprite, grid_x, grid_y, force=True):
                                    self.dragging = True
                                    self.drag_start_pos = (grid_x, grid_y)
                                    self.last_placed_pos = (grid_x, grid_y)
                    
                    elif event.button == 3:  # Right click - remove
                        if self._is_in_build_area(mouse_x, mouse_y):
                            grid_x, grid_y = self._snap_to_grid(mouse_x, mouse_y)
                            self._remove_at_position(grid_x, grid_y)
                
                elif event.type == pygame.MOUSEBUTTONUP:
                    if event.button == 1:
                        self.dragging = False
                        self.last_placed_pos = None
                
                elif event.type == pygame.MOUSEMOTION:
                    if event.buttons[0] and self.dragging:
                        mouse_x, mouse_y = event.pos
                        if self._is_in_build_area(mouse_x, mouse_y):
                            grid_x, grid_y = self._snap_to_grid(mouse_x, mouse_y)
                            if (grid_x, grid_y) != self.last_placed_pos:
                                if self.placing_piranha_on_pipe:
                                    self._place_piranha_on_pipe(grid_x, grid_y)
                                elif self.selected_sprite:
                                    if self._place_sprite(self.selected_sprite, grid_x, grid_y):
                                        self.last_placed_pos = (grid_x, grid_y)
                
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.selected_sprite = None
                        self.dragging = False
                        if self.sprite_palette:
                            self.sprite_palette.selected_sprite = None
                    elif event.key == pygame.K_s and pygame.key.get_pressed()[pygame.K_LCTRL]:
                        self._save_map()
                    elif event.key == pygame.K_SPACE:
                        self._toggle_play()
                    # Scroll controls
                    elif event.key == pygame.K_LEFT or event.key == pygame.K_a:
                        self.build_scroll_x = max(0, self.build_scroll_x - self.scroll_speed)
                    elif event.key == pygame.K_RIGHT or event.key == pygame.K_d:
                        visible_width = WINDOW_WIDTH - SIDEBAR_WIDTH
                        total_width = self.build_width_blocks * BLOCK_SIZE
                        max_scroll = max(0, total_width - visible_width)
                        self.build_scroll_x = min(max_scroll, self.build_scroll_x + self.scroll_speed)
                
        
        return True
    
    def draw_ui(self):
        """Draw all UI components"""
        # Adobe-like sidebar with gradient effect
        pygame.draw.rect(self.screen, SIDEBAR_BG, (0, 0, SIDEBAR_WIDTH, WINDOW_HEIGHT))
        # Subtle border
        pygame.draw.line(self.screen, (20, 20, 20), (SIDEBAR_WIDTH - 1, 0), (SIDEBAR_WIDTH - 1, WINDOW_HEIGHT), 1)
        # Top highlight
        pygame.draw.line(self.screen, (60, 60, 60), (0, 0), (SIDEBAR_WIDTH, 0), 1)
        
        # Draw tube label if not in play mode
        if not self.is_playing and hasattr(self, 'tube_label_surface'):
            self.screen.blit(self.tube_label_surface, (10, self.tube_label_y))
        
        # Draw UI components
        if self.is_playing:
            # Draw exit button prominently in play mode
            exit_rect = pygame.Rect(10, 10, SIDEBAR_WIDTH - 20, 50)
            pygame.draw.rect(self.screen, RED, exit_rect)
            pygame.draw.rect(self.screen, WHITE, exit_rect, 3)
            exit_font = pygame.font.Font(None, 28)
            exit_text = exit_font.render("EXIT PLAY MODE", True, WHITE)
            text_rect = exit_text.get_rect(center=exit_rect.center)
            self.screen.blit(exit_text, text_rect)
        else:
            # Draw normal UI components in edit mode
            for component in self.ui_components:
                component.draw(self.screen)
        
        # Draw sprite previews in palette
        if self.sprite_palette:
            self._draw_sprite_previews()
        
        # Instructions with better styling
        if not self.is_playing:
            inst_font = pygame.font.Font(None, 13)
            instructions = [
                "Click sprite to select",
                "Click/Drag to place",
                "Right-click: remove",
                "Space: Play/Pause",
                "Ctrl+S: Save",
                "ESC: Deselect/Exit",
                "←/→ or A/D: Scroll"
            ]
            inst_y = WINDOW_HEIGHT - len(instructions) * 15 - 15
            # Instructions panel background
            inst_panel = pygame.Rect(5, inst_y - 5, SIDEBAR_WIDTH - 10, len(instructions) * 15 + 10)
            pygame.draw.rect(self.screen, PANEL_BG, inst_panel)
            pygame.draw.rect(self.screen, (30, 30, 30), inst_panel, 1)
            
            for i, inst in enumerate(instructions):
                text = inst_font.render(inst, True, LIGHT_GRAY)
                self.screen.blit(text, (12, inst_y + i * 15))
    
    def _draw_sprite_previews(self):
        """Draw sprite previews in the palette"""
        if not self.sprite_palette or not self.sprite_palette.visible:
            return
        
        y_offset = self.sprite_palette.start_y - self.sprite_palette.scroll_offset
        palette_rect = self.sprite_palette.rect
        
        for category, sprites in self.sprite_categories.items():
            if sprites:
                y_offset += 28
                for sprite_name in sprites:
                    if y_offset + self.sprite_palette.sprite_size > 0 and y_offset < palette_rect.height:
                        preview = self._get_sprite_preview(sprite_name)
                        if preview:
                            scaled = pygame.transform.scale(preview, (42, 42))
                            # Draw relative to palette position
                            self.screen.blit(scaled, (palette_rect.x + 6, palette_rect.y + y_offset + 5))
                    y_offset += self.sprite_palette.sprite_size
    
    def draw_build_area(self):
        """Draw the build area"""
        if not self.is_playing:
            # Calculate max scroll based on build width
            visible_width = WINDOW_WIDTH - SIDEBAR_WIDTH
            total_width = self.build_width_blocks * BLOCK_SIZE
            self.max_scroll_x = max(0, total_width - visible_width)
            self.build_scroll_x = max(0, min(self.build_scroll_x, self.max_scroll_x))
            
            # Edit mode: draw tiles directly with scroll offset
            for y in range(BUILD_HEIGHT_BLOCKS):
                for x in range(self.build_width_blocks):
                    if y < len(self.level.level) and x < len(self.level.level[y]):
                        tile = self.level.level[y][x]
                        if tile and tile.sprite:
                            draw_x = SIDEBAR_WIDTH + x * BLOCK_SIZE - self.build_scroll_x
                            draw_y = y * BLOCK_SIZE
                            # Only draw if visible on screen
                            if -BLOCK_SIZE <= draw_x < visible_width + BLOCK_SIZE:
                                if tile.sprite.image:
                                    self.screen.blit(tile.sprite.image, (draw_x, draw_y))
                                elif tile.sprite.animation:
                                    if tile.sprite.animation.image:
                                        self.screen.blit(tile.sprite.animation.image, (draw_x, draw_y))
        else:
            # Play mode: draw game surface at normal size (640x480) at the start of build area
            if self.play_level and self.mario:
                # Draw level to game surface (this draws background, tiles, and entities)
                # Note: Mario is NOT in level.entities, he's separate
                if self.mario.pause:
                    self.mario.pauseObj.update()
                else:
                    if not self.mario.dying:
                        self.play_level.drawLevel(self.mario.camera)
                        self.play_level.dashboard.update()
                    self.mario.update()
                
                # Draw at normal game size, positioned at the start (left side) of build area
                offset_x = SIDEBAR_WIDTH
                self.screen.blit(self.game_surface, (offset_x, 0))
                
                # Draw borders to show the play area
                play_area_rect = pygame.Rect(offset_x - 2, 0, GAME_PAGE_WIDTH + 4, GAME_PAGE_HEIGHT)
                pygame.draw.rect(self.screen, YELLOW, play_area_rect, 3)
                
                # Draw info text
                info_font = pygame.font.Font(None, 20)
                info_text = info_font.render("PLAY MODE - Press ESC or click EXIT to exit", True, YELLOW)
                self.screen.blit(info_text, (offset_x + 10, 10))
        
        # Draw pipes in edit mode (visual indicator with scroll)
        if not self.is_playing and "pipe" in self.placed_entities["objects"]:
            for entry in self.placed_entities["objects"]["pipe"]:
                if len(entry) >= 3:
                    pipe_x, pipe_y, pipe_height = entry[0], entry[1], entry[2]
                    # Draw a visual indicator for pipes (accounting for scroll)
                    draw_x = SIDEBAR_WIDTH + pipe_x * BLOCK_SIZE - self.build_scroll_x
                    draw_y = pipe_y * BLOCK_SIZE
                    visible_width = WINDOW_WIDTH - SIDEBAR_WIDTH
                    if -BLOCK_SIZE * 2 <= draw_x < visible_width + BLOCK_SIZE * 2:
                        pipe_rect = pygame.Rect(
                            draw_x,
                            draw_y,
                            2 * BLOCK_SIZE,
                            pipe_height * BLOCK_SIZE
                        )
                        pipe_surface = pygame.Surface((2 * BLOCK_SIZE, pipe_height * BLOCK_SIZE), pygame.SRCALPHA)
                        pipe_surface.fill((0, 200, 255, 60))
                        self.screen.blit(pipe_surface, pipe_rect.topleft)
                        pygame.draw.rect(self.screen, CYAN, pipe_rect, 1)
        
        # Draw entity spawners in edit mode
        if not self.is_playing:
            visible_width = WINDOW_WIDTH - SIDEBAR_WIDTH
            for entity_type, entities in self.placed_entities["entities"].items():
                for entity_data in entities:
                    if isinstance(entity_data, tuple) and len(entity_data) >= 5:
                        grid_x, grid_y, size_w, size_h, label = entity_data[:5]
                        draw_x = SIDEBAR_WIDTH + grid_x * BLOCK_SIZE - self.build_scroll_x
                        draw_y = grid_y * BLOCK_SIZE
                        # Only draw if visible
                        if -size_w * BLOCK_SIZE <= draw_x < visible_width + size_w * BLOCK_SIZE:
                            spawner_rect = pygame.Rect(
                                draw_x,
                                draw_y,
                                size_w * BLOCK_SIZE,
                                size_h * BLOCK_SIZE
                            )
                            spawner_surface = pygame.Surface((size_w * BLOCK_SIZE, size_h * BLOCK_SIZE), pygame.SRCALPHA)
                            spawner_surface.fill((255, 0, 0, 80))
                            self.screen.blit(spawner_surface, spawner_rect.topleft)
                            pygame.draw.rect(self.screen, RED, spawner_rect, 2)
                            label_text = self.label_font.render(label, True, WHITE)
                            label_bg = pygame.Surface((label_text.get_width() + 4, label_text.get_height() + 2))
                            label_bg.fill(BLACK)
                            label_bg.set_alpha(200)
                            self.screen.blit(label_bg, (spawner_rect.x + 2, spawner_rect.y + 2))
                            self.screen.blit(label_text, (spawner_rect.x + 4, spawner_rect.y + 3))
        
        # Draw grid overlay (with scroll offset)
        if not self.is_playing:
            visible_width = WINDOW_WIDTH - SIDEBAR_WIDTH
            start_x = max(0, self.build_scroll_x // BLOCK_SIZE - 1)
            end_x = min(self.build_width_blocks + 1, (self.build_scroll_x + visible_width) // BLOCK_SIZE + 2)
            
            # Draw vertical grid lines
            for x in range(start_x, end_x):
                draw_x = SIDEBAR_WIDTH + x * BLOCK_SIZE - self.build_scroll_x
                if SIDEBAR_WIDTH <= draw_x < WINDOW_WIDTH:
                    # Every 20 blocks (1 game page), draw a thicker line
                    if x % 20 == 0:
                        pygame.draw.line(self.screen, (100, 100, 100), 
                                       (draw_x, 0),
                                       (draw_x, BUILD_HEIGHT), 2)
                    else:
                        pygame.draw.line(self.screen, (60, 60, 60), 
                                       (draw_x, 0),
                                       (draw_x, BUILD_HEIGHT), 1)
            
            # Draw horizontal grid lines
            for y in range(BUILD_HEIGHT_BLOCKS + 1):
                draw_y = y * BLOCK_SIZE
                # Every 15 blocks (full height), draw a thicker line
                if y % 15 == 0:
                    pygame.draw.line(self.screen, (100, 100, 100),
                                   (SIDEBAR_WIDTH, draw_y),
                                   (WINDOW_WIDTH, draw_y), 2)
                else:
                    pygame.draw.line(self.screen, (60, 60, 60),
                                   (SIDEBAR_WIDTH, draw_y),
                                   (WINDOW_WIDTH, draw_y), 1)
            
            # Draw page markers at the top
            page_font = pygame.font.Font(None, 14)
            for x in range(start_x, end_x, 20):  # Every game page
                if x < self.build_width_blocks:
                    draw_x = SIDEBAR_WIDTH + x * BLOCK_SIZE - self.build_scroll_x
                    if SIDEBAR_WIDTH <= draw_x < WINDOW_WIDTH:
                        page_num = (x // 20) + 1
                        page_text = page_font.render(f"Page {page_num}", True, (150, 150, 150))
                        text_bg = pygame.Surface((page_text.get_width() + 4, page_text.get_height() + 2))
                        text_bg.fill((40, 40, 40))
                        text_bg.set_alpha(200)
                        self.screen.blit(text_bg, (draw_x + 2, 2))
                        self.screen.blit(page_text, (draw_x + 4, 3))
        
        # Draw cursor preview
        if (self.selected_sprite or self.placing_piranha_on_pipe) and not self.is_playing:
            mouse_x, mouse_y = pygame.mouse.get_pos()
            if self._is_in_build_area(mouse_x, mouse_y):
                grid_x, grid_y = self._snap_to_grid(mouse_x, mouse_y)
                preview_draw_x = SIDEBAR_WIDTH + grid_x * BLOCK_SIZE - self.build_scroll_x
                
                # Preview for piranha spawner mode
                if self.placing_piranha_on_pipe:
                    # Check if there's a pipe at this location
                    pipe_found = False
                    if "pipe" in self.placed_entities["objects"]:
                        for entry in self.placed_entities["objects"]["pipe"]:
                            if len(entry) >= 2:
                                px, py = entry[0], entry[1]
                                if (px == grid_x or px + 1 == grid_x) and (py == grid_y or py == grid_y - 1):
                                    pipe_found = True
                                    break
                    
                    preview_rect = pygame.Rect(
                        preview_draw_x,
                        grid_y * BLOCK_SIZE,
                        BLOCK_SIZE,
                        BLOCK_SIZE
                    )
                    if pipe_found:
                        preview_surface = pygame.Surface((BLOCK_SIZE, BLOCK_SIZE), pygame.SRCALPHA)
                        preview_surface.fill((0, 255, 0, 100))
                        self.screen.blit(preview_surface, preview_rect.topleft)
                        pygame.draw.rect(self.screen, GREEN, preview_rect, 2)
                        label_text = self.small_font.render("Piranha", True, WHITE)
                    else:
                        preview_surface = pygame.Surface((BLOCK_SIZE, BLOCK_SIZE), pygame.SRCALPHA)
                        preview_surface.fill((255, 0, 0, 100))
                        self.screen.blit(preview_surface, preview_rect.topleft)
                        pygame.draw.rect(self.screen, RED, preview_rect, 2)
                        label_text = self.small_font.render("No Pipe", True, WHITE)
                    
                    label_bg = pygame.Surface((label_text.get_width() + 4, label_text.get_height() + 2))
                    label_bg.fill(BLACK)
                    label_bg.set_alpha(200)
                    self.screen.blit(label_bg, (preview_rect.x + 2, preview_rect.y + 2))
                    self.screen.blit(label_text, (preview_rect.x + 4, preview_rect.y + 3))
                else:
                    preview = self._get_sprite_preview(self.selected_sprite)
                    
                    sprite_lower = self.selected_sprite.lower()
                    is_entity = any(kw in sprite_lower for kw in ["goomba", "koopa", "bowser", "piranha", "coin", 
                                                                  "coinbox", "coinbrick", "randombox", "brickblock",
                                                                  "hardblock", "firebar", "movingplatform"])
                    # Preview for pipe placement
                    if self.selected_sprite == "pipe":
                        preview_rect = pygame.Rect(
                            preview_draw_x,
                            grid_y * BLOCK_SIZE,
                            2 * BLOCK_SIZE,
                            self.selected_tube_height * BLOCK_SIZE
                        )
                        preview_surface = pygame.Surface((2 * BLOCK_SIZE, self.selected_tube_height * BLOCK_SIZE), pygame.SRCALPHA)
                        preview_surface.fill((0, 255, 255, 100))
                        self.screen.blit(preview_surface, preview_rect.topleft)
                        pygame.draw.rect(self.screen, CYAN, preview_rect, 2)
                        label_text = self.small_font.render(f"Tube {self.selected_tube_height}", True, WHITE)
                        label_bg = pygame.Surface((label_text.get_width() + 4, label_text.get_height() + 2))
                        label_bg.fill(BLACK)
                        label_bg.set_alpha(200)
                        self.screen.blit(label_bg, (preview_rect.x + 2, preview_rect.y + 2))
                        self.screen.blit(label_text, (preview_rect.x + 4, preview_rect.y + 3))
                    elif is_entity:
                        size_w, size_h = self._get_entity_size(self.selected_sprite)
                        label = self._get_entity_label(self.selected_sprite)
                        
                        preview_rect = pygame.Rect(
                            preview_draw_x,
                            grid_y * BLOCK_SIZE,
                            size_w * BLOCK_SIZE,
                            size_h * BLOCK_SIZE
                        )
                        preview_surface = pygame.Surface((size_w * BLOCK_SIZE, size_h * BLOCK_SIZE), pygame.SRCALPHA)
                        preview_surface.fill((0, 255, 0, 100))
                        self.screen.blit(preview_surface, preview_rect.topleft)
                        pygame.draw.rect(self.screen, GREEN, preview_rect, 2)
                        
                        label_text = self.small_font.render(label, True, WHITE)
                        label_bg = pygame.Surface((label_text.get_width() + 4, label_text.get_height() + 2))
                        label_bg.fill(BLACK)
                        label_bg.set_alpha(200)
                        self.screen.blit(label_bg, (preview_rect.x + 2, preview_rect.y + 2))
                        self.screen.blit(label_text, (preview_rect.x + 4, preview_rect.y + 3))
                    elif preview:
                        preview_surface = pygame.Surface((BLOCK_SIZE, BLOCK_SIZE), pygame.SRCALPHA)
                        preview_surface.fill((255, 255, 255, 128))
                        scaled = pygame.transform.scale(preview, (BLOCK_SIZE, BLOCK_SIZE))
                        preview_surface.blit(scaled, (0, 0))
                        self.screen.blit(preview_surface, 
                                        (preview_draw_x, grid_y * BLOCK_SIZE))
    
    def update(self):
        """Update game state"""
        if self.is_playing and self.mario and self.play_level:
            # Mario update (input and movement) is now called in draw_build_area()
            # after drawLevel() so Mario draws on top of everything
            # This method is for non-drawing updates if needed
            pass
        else:
            # Continuous scrolling with held keys in edit mode
            keys = pygame.key.get_pressed()
            if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                self.build_scroll_x = max(0, self.build_scroll_x - self.scroll_speed)
            if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                visible_width = WINDOW_WIDTH - SIDEBAR_WIDTH
                total_width = self.build_width_blocks * BLOCK_SIZE
                max_scroll = max(0, total_width - visible_width)
                self.build_scroll_x = min(max_scroll, self.build_scroll_x + self.scroll_speed)
    
    def draw(self):
        """Draw everything"""
        self.screen.fill(SKY_BLUE)
        
        self.draw_build_area()
        self.draw_ui()
        
        pygame.display.flip()
    
    def run(self):
        """Main game loop"""
        try:
            while self.handle_events():
                self.update()
                self.draw()
                self.clock.tick(60)
        finally:
            pygame.quit()

if __name__ == "__main__":
    os.chdir(PROJECT_ROOT)
    MapMaker().run()
