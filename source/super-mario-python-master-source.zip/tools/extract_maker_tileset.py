"""Extract unique 16x16 cells from the SMB Maker atlas and build a gallery.

The source is a reference atlas, not a pure sprite sheet: gutters, labels and
layout backgrounds are filtered; the exact source coordinates remain in the
catalog so each crop can be checked against context.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "img/sheets/maker_smb1_tileset.png"
OUTPUT = ROOT / "img" / "maker_tileset_cutouts"
CATALOG = OUTPUT / "catalog.json"
BACKGROUND = (147, 187, 236)
GRID_BLUE = (27, 89, 153)
CELL = 16
STEP = 17
X_ORIGIN = 1
Y_ORIGIN = 23
THEMES = ("ground", "underground", "underwater", "desert", "snow", "sky", "forest", "ghost_house", "airship", "castle")


def main() -> None:
    source = Image.open(SOURCE).convert("RGBA")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    unique: dict[str, dict] = {}
    seen: dict[str, str] = {}
    for y in range(Y_ORIGIN, source.height - CELL + 1, STEP):
        row = (y - Y_ORIGIN) // STEP
        band = row // 46
        group = (y - Y_ORIGIN) // (46 * STEP)
        day_night = "day" if group < 2 else "night"
        for panel in range(5):
            for column in range(16):
                panel_inset = X_ORIGIN if panel == 0 else 4
                x = panel * 273 + panel_inset + column * STEP
                if x + CELL > source.width:
                    continue
                theme_index = (band % 2) * 5 + panel
                theme = THEMES[theme_index] if band < 4 and theme_index < len(THEMES) else "rail_and_footer"
                cell = source.crop((x, y, x + CELL, y + CELL))
                pixels = list(cell.getdata())
                occupied = sum(pixel[:3] != BACKGROUND for pixel in pixels)
                if occupied < 16:
                    continue
                digest = hashlib.sha256(cell.tobytes()).hexdigest()[:12]
                if digest in seen:
                    continue
                name = f"{theme}_{day_night}_x{x}_y{y}_{digest}.png"
                # Remove the flat atlas backing and grid blue, preserving sprite pixels.
                rgba = cell.copy()
                rgba.putdata([(r, g, b, 0 if (r, g, b) in (BACKGROUND, GRID_BLUE) else a) for r, g, b, a in pixels])
                rgba.save(OUTPUT / name, optimize=True)
                record = {"file": name, "x": x, "y": y, "width": CELL, "height": CELL,
                          "theme_region": theme, "lighting_region": day_night,
                          "sha256_12": digest, "non_background_pixels": occupied}
                unique[digest] = record
                seen[digest] = name
    records = sorted(unique.values(), key=lambda r: (r["theme_region"], r["lighting_region"], r["y"], r["x"]))
    CATALOG.write_text(json.dumps({"source": SOURCE.relative_to(ROOT).as_posix(), "grid": {"cell": CELL, "step": STEP,
        "origin": [X_ORIGIN, Y_ORIGIN]}, "unique_cells": len(records), "tiles": records}, indent=2) + "\n")
    columns, thumb, label_h, per_page = 8, 64, 18, 256
    for page, start in enumerate(range(0, len(records), per_page), 1):
        chunk = records[start:start + per_page]
        rows = (len(chunk) + columns - 1) // columns
        sheet = Image.new("RGB", (columns * thumb, rows * (thumb + label_h)), (35, 43, 57))
        draw = ImageDraw.Draw(sheet)
        for i, record in enumerate(chunk):
            x, y = i % columns * thumb, i // columns * (thumb + label_h)
            tile = Image.open(OUTPUT / record["file"]).convert("RGBA").resize((thumb, thumb), Image.Resampling.NEAREST)
            sheet.paste(tile, (x, y), tile)
            draw.text((x + 2, y + thumb + 2), f'{record["x"]},{record["y"]}', fill="white")
        sheet.save(OUTPUT / f"index_{page:02d}.png", optimize=True)
    print(f"Extracted {len(records)} unique occupied cells to {OUTPUT}")
    print(f"Catalog: {CATALOG}\nGallery pages: {OUTPUT}/index_*.png")


if __name__ == "__main__":
    main()
