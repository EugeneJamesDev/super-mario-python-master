"""Cut the named SMB1 VineTop source into native-size runtime tiles."""

from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "img/smb1_source/nesmaps_vine_top.png"
DEST = ROOT / "img/smb1_cutouts"


def main() -> None:
    image = Image.open(SOURCE).convert("RGBA")
    if image.size != (14, 95):
        raise ValueError(f"Expected the 14x95 SMB1 VineTop sprite, got {image.size}")

    # The source is a 14-pixel-wide vine with one 16x16 tip tile followed by
    # repeated 16x16 stem/leaf tiles. Center it in the native 16px SMB tile
    # without scaling or changing any opaque source pixels.
    crops = {
        "smb1_vine_tip.png": (0, 0, 14, 16),
        "smb1_vine_segment.png": (0, 17, 14, 33),
    }
    DEST.mkdir(parents=True, exist_ok=True)
    for filename, bounds in crops.items():
        crop = image.crop(bounds)
        tile = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
        tile.alpha_composite(crop, (1, 0))
        tile.save(DEST / filename)


if __name__ == "__main__":
    main()
