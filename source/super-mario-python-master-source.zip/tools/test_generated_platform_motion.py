"""Capture and check a generated medium vertical moving platform at runtime.

Run from the repository root:
    python3 tools/test_generated_platform_motion.py

The tool uses the real Level, MovingPlatform, EntityCollider, and Mario platform
collision method. It writes a standalone audit and also updates the Infinity
matrix report when one is already present.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.capture_frames import make_mock_sound


def main():
    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    from classes.Camera import Camera
    from classes.Dashboard import Dashboard
    from classes.EntityCollider import EntityCollider
    from classes.Level import Level
    from classes.Maths import Vec2D
    from entities.Mario import Mario

    seed = 20261154
    level = Level(screen, make_mock_sound(), Dashboard("img/sheets/font.png", 8, screen))
    level.load_endless(seed=seed, initial_columns=0)
    level.endlessBuffer = 0
    for _ in range(400):
        level._append_column()

    placement = None
    for column in range(20, 360):
        for row in range(4, 9):
            if level._vertical_platform_clearance_ok(column, 2, row, 3):
                placement = (column, row)
                break
        if placement:
            break
    if placement is None:
        raise RuntimeError("Could not find a clear corridor for the test platform")

    column, row = placement
    platform = level.addMovingPlatform(
        column, row, size="medium", axis="vertical", travel_tiles=3
    )
    level.entityList.append(platform)
    phases = [("start", 1)]
    phases.append(("mid", 52))
    phases.append(("end", 0))
    phase_frames = {}
    out_dir = ROOT / "test_frames/infinity_matrix/platform_runtime"
    out_dir.mkdir(parents=True, exist_ok=True)

    for name, ticks in phases:
        if name == "mid":
            for _ in range(ticks):
                platform._advance_motion()
        elif name == "end":
            while platform._path_position < platform.travel_distance:
                platform._advance_motion()
        else:
            platform._advance_motion()

        probe = type("MarioProbe", (), {})()
        probe.rect = pygame.Rect(
            platform.rect.centerx - 16,
            platform.rect.top - 30,
            32,
            32,
        )
        # The probe must catch up to the platform on its downward leg.
        probe.vel = pygame.Vector2(0, 3 + max(0, platform.velocity.y))
        probe.onGround = False
        probe.inAir = True
        collision = EntityCollider(probe).check(platform)
        if not collision.isColliding or not collision.isTop:
            raise AssertionError(f"Mario did not land on platform at {name}")
        Mario._onCollisionWithPlatform(probe, platform, collision)
        if probe.rect.bottom != platform.rect.top or not probe.onGround:
            raise AssertionError(f"Landing resolution failed at {name}")

        center = column + 1

        class CameraTarget:
            rect = pygame.Rect(center * 32, 0, 32, 32)

            def getPosIndexAsFloat(self):
                return Vec2D(float(center), 0)

        camera = Camera(Vec2D(8 - center, 0), CameraTarget())
        camera.x = camera.pos.x * 32
        camera.y = 0
        screen.fill((0, 0, 0) if level.columnBiomes[center] in level.DARK_BIOMES else (92, 148, 252))
        saved = level.entityList
        level.entityList = [entity for entity in saved if entity is not platform]
        try:
            level.drawLevel(camera)
        finally:
            level.entityList = saved
        screen.blit(platform.sprite, (platform.rect.x + camera.x, platform.rect.y))
        mario_sprite = level.sprites.spriteCollection.get("mario_idle")
        if mario_sprite and mario_sprite.image:
            screen.blit(
                mario_sprite.image,
                (platform.rect.centerx - 16 + camera.x, platform.rect.top - mario_sprite.image.get_height()),
            )
        filename = f"medium_vertical_{name}.png"
        pygame.image.save(screen, out_dir / filename)
        phase_frames[name] = {
            "image": filename,
            "path_position_px": round(platform._path_position, 2),
            "platform_rect": list(platform.rect),
            "platform_velocity": [platform.velocity.x, platform.velocity.y],
            "collision_is_top": collision.isTop,
            "mario_bottom_after_collision": probe.rect.bottom,
        }

    result = {
        "seed": seed,
        "biome": level.columnBiomes[column],
        "placement_column": column,
        "placement_row": row,
        "size": "medium",
        "axis": "vertical",
        "travel_tiles": 3,
        "runtime_phases": phase_frames,
        "collision_checks_passed": len(phase_frames),
    }
    (out_dir / "audit.json").write_text(json.dumps(result, indent=2) + "\n")

    print(f"Placement: column {column}, row {row}; biome={level.columnBiomes[column]}")
    print(f"Captured {len(phase_frames)} phases; all top-landing collision checks passed.")
    print(f"Frames: {out_dir}")


if __name__ == "__main__":
    main()
