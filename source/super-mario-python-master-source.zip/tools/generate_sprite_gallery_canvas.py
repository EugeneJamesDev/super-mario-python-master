"""Generate the sprite gallery canvas from exported sprite data.

Usage:
    python tools/export_sprite_gallery_data.py
    python tools/generate_sprite_gallery_canvas.py
"""

from __future__ import annotations

import json
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = REPO_ROOT / "test_frames/asset_reports/sprite_gallery_data.json"
CANVAS_PATH = DATA_PATH.with_name("sprite-gallery.canvas.tsx")

CANVAS_SOURCE = '''import { useMemo, useState } from "react";
import {
  Card,
  CardBody,
  CardHeader,
  Grid,
  H1,
  H2,
  H3,
  Pill,
  Row,
  Select,
  Stack,
  Stat,
  Text,
  TextInput,
  useHostTheme,
} from "cursor/canvas";

type SpriteFrame = {
  label: string;
  width: number;
  height: number;
  dataUrl: string;
};

type SpriteEntry = {
  name: string;
  category: string;
  animated: boolean;
  frameCount: number;
  frames: SpriteFrame[];
};

type GalleryData = {
  generatedAt: string;
  totalDefined: number;
  loadedCount: number;
  missingCount: number;
  missingNames: string[];
  sourceFiles: string[];
  entries: SpriteEntry[];
};

const GALLERY_DATA: GalleryData = __GALLERY_JSON__;

const CATEGORY_ORDER = [
  "Mario",
  "Luigi",
  "Demo",
  "Enemies",
  "Boss",
  "Items",
  "Tiles",
  "Effects",
  "Platforms",
  "Scenery",
  "NPC",
  "Other",
];

function SpriteCard({ entry }: { entry: SpriteEntry }) {
  const theme = useHostTheme();
  return (
    <Card variant="outlined" size="sm">
      <CardHeader
        trailing={
          <Pill size="sm">
            {entry.animated ? `${entry.frameCount} frames` : "static"}
          </Pill>
        }
      >
        {entry.name}
      </CardHeader>
      <CardBody>
        <Stack gap={8}>
          <Text size="small" weight="medium">
            {entry.category}
          </Text>
          <Row gap={8} style={{ flexWrap: "wrap" }}>
            {entry.frames.map((frame) => (
              <Stack key={`${entry.name}-${frame.label}`} gap={4} style={{ alignItems: "center" }}>
                <div
                  style={{
                    background: theme.bg.elevated,
                    border: `1px solid ${theme.stroke.secondary}`,
                    borderRadius: 4,
                    padding: 8,
                    minWidth: 72,
                    minHeight: 72,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <img
                    src={frame.dataUrl}
                    alt={`${entry.name} ${frame.label}`}
                    style={{
                      imageRendering: "pixelated",
                      maxWidth: 96,
                      maxHeight: 96,
                      width: "auto",
                      height: "auto",
                    }}
                  />
                </div>
                <Text size="small">{frame.label}</Text>
                <Text size="small">
                  {frame.width}×{frame.height}
                </Text>
              </Stack>
            ))}
          </Row>
        </Stack>
      </CardBody>
    </Card>
  );
}

export default function SpriteGalleryCanvas() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All");

  const categories = useMemo(() => {
    const unique = new Set(GALLERY_DATA.entries.map((entry) => entry.category));
    return ["All", ...CATEGORY_ORDER.filter((name) => unique.has(name))];
  }, []);

  const filtered = useMemo(() => {
    const lowered = query.trim().toLowerCase();
    return GALLERY_DATA.entries.filter((entry) => {
      const matchesCategory = category === "All" || entry.category === category;
      const matchesQuery = !lowered || entry.name.toLowerCase().includes(lowered);
      return matchesCategory && matchesQuery;
    });
  }, [query, category]);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    for (const entry of GALLERY_DATA.entries) {
      counts[entry.category] = (counts[entry.category] ?? 0) + 1;
    }
    return counts;
  }, []);

  return (
    <Stack gap={16} style={{ padding: 16 }}>
      <Stack gap={6}>
        <H1>Super Mario Python — Sprite Gallery</H1>
        <Text size="small">
          Every sprite currently loaded by the game engine ({GALLERY_DATA.loadedCount} of{" "}
          {GALLERY_DATA.totalDefined} defined keys). Generated {GALLERY_DATA.generatedAt}.
        </Text>
      </Stack>

      <Grid columns={4} gap={12}>
        <Stat label="Loaded sprites" value={String(GALLERY_DATA.loadedCount)} tone="success" />
        <Stat label="Missing sprites" value={String(GALLERY_DATA.missingCount)} tone={GALLERY_DATA.missingCount ? "warning" : "success"} />
        <Stat label="Animated" value={String(GALLERY_DATA.entries.filter((e) => e.animated).length)} />
        <Stat label="Categories" value={String(categories.length - 1)} />
      </Grid>

      <Card>
        <CardBody>
          <Row gap={12} style={{ alignItems: "end", flexWrap: "wrap" }}>
            <Stack gap={4} style={{ minWidth: 220, flex: 1 }}>
              <Text size="small" weight="medium">
                Search sprite name
              </Text>
              <TextInput value={query} onChange={setQuery} placeholder="e.g. mario, koopa, brick" />
            </Stack>
            <Stack gap={4} style={{ minWidth: 180 }}>
              <Text size="small" weight="medium">
                Category
              </Text>
              <Select value={category} onChange={setCategory} options={categories.map((name) => ({ value: name, label: name }))} />
            </Stack>
          </Row>
        </CardBody>
      </Card>

      <Stack gap={8}>
        <H2>
          Showing {filtered.length} sprite{filtered.length === 1 ? "" : "s"}
        </H2>
        <Row gap={8} style={{ flexWrap: "wrap" }}>
          {Object.entries(categoryCounts).map(([name, count]) => (
            <Pill key={name} size="sm">
              {name}: {count}
            </Pill>
          ))}
        </Row>
      </Stack>

      <Grid columns={3} gap={12}>
        {filtered.map((entry) => (
          <SpriteCard key={entry.name} entry={entry} />
        ))}
      </Grid>

      <Stack gap={8}>
        <H3>Sprite JSON sources</H3>
        <Text size="small">{GALLERY_DATA.sourceFiles.join(", ")}</Text>
      </Stack>
    </Stack>
  );
}
'''


def main() -> None:
    if not DATA_PATH.exists():
        raise SystemExit(f"Missing {DATA_PATH}. Run tools/export_sprite_gallery_data.py first.")

    data = json.loads(DATA_PATH.read_text())
    json_blob = json.dumps(data, separators=(",", ":"))
    canvas_source = CANVAS_SOURCE.replace("__GALLERY_JSON__", json_blob)
    CANVAS_PATH.parent.mkdir(parents=True, exist_ok=True)
    CANVAS_PATH.write_text(canvas_source)
    print(f"Wrote {CANVAS_PATH} ({CANVAS_PATH.stat().st_size // 1024} KB)")


if __name__ == "__main__":
    main()
