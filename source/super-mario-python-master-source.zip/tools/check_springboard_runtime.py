"""Headless deterministic checks for springboard landing and launch behavior."""

from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

import pygame

from entities.Springboard import Springboard


class Camera:
    x = 0


class Sprite:
    def __init__(self, image):
        self.image = image


class MarioStub:
    def __init__(self, x, bottom):
        self.isMario = True
        self.rect = pygame.Rect(x, bottom - 32, 32, 32)
        self.vel = pygame.Vector2(0, 0)
        self.onGround = True
        self.inAir = False
        self.inJump = False
        self.traits = {"jumpTrait": JumpStub()}


class JumpStub:
    MAX_HOLD_FRAMES = 12

    def __init__(self):
        self.jump_active = False
        self.jump_button = False
        self.hold_frames = 0


class LevelStub:
    def __init__(self, mario):
        self.player = mario
        self.entityList = []


def make_springboard(mario, ground_row=8):
    image = pygame.Surface((32, 62), pygame.SRCALPHA)
    image.fill((255, 255, 255, 255))
    sprites = {"springboard": Sprite(image)}
    level = LevelStub(mario)
    board = Springboard(pygame.Surface((320, 320)), sprites, 3, ground_row, level)
    level.entityList.append(board)
    return board, level


def check_landing_launches_after_compression():
    # Make the actor land on the plate on the first update.
    top = 8 * 32 - 62
    mario = MarioStub(3 * 32, top)
    board, level = make_springboard(mario)
    board._previous_mario_bottom = board.rect.top - 1
    mario.rect.bottom = board.rect.top
    mario.vel.y = 1
    mario.onGround = True

    for _ in range(board.COMPRESS_FRAMES):
        board.update(Camera())

    assert board.state == "up", "springboard should return to its raised state after launch"
    assert mario.vel.y == board.LAUNCH_VELOCITY, "springboard should give Mario the launch impulse"
    assert not mario.onGround and mario.inAir, "launch must clear grounded state"
    assert not mario.traits["jumpTrait"].jump_active, "spring launch must not stack the normal jump controller"


def check_departed_mario_is_not_launched():
    top = 8 * 32 - 62
    mario = MarioStub(3 * 32, top)
    board, _ = make_springboard(mario)
    board._previous_mario_bottom = board.rect.top - 1
    mario.rect.bottom = board.rect.top
    mario.vel.y = 1
    mario.onGround = True
    board.update(Camera())
    assert board.state == "compressed", "top landing should start compression"

    mario.rect.bottom = board.rect.top - 50
    mario.onGround = False
    mario.vel.y = -2
    for _ in range(board.COMPRESS_FRAMES):
        board.update(Camera())

    assert board.state == "up", "empty springboard should reset after compression"
    assert mario.vel.y == -2, "springboard must not launch a Mario who has left"


def main():
    pygame.init()
    try:
        check_landing_launches_after_compression()
        check_departed_mario_is_not_launched()
    finally:
        pygame.quit()
    print("Springboard landing, compression, launch, and cancellation checks passed.")


if __name__ == "__main__":
    main()
