"""Check SMB1 underwater generation rules across deterministic Infinity seeds."""

from __future__ import annotations

import argparse
import os
import sys
from collections import Counter
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.capture_frames import make_mock_sound
from classes.Dashboard import Dashboard
from classes.Level import Level


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seeds", type=int, default=44)
    parser.add_argument("--columns", type=int, default=1200)
    parser.add_argument("--first-seed", type=int, default=20261111)
    args = parser.parse_args()

    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    allowed_entities = {"Coin", "CheepCheep", "Blooper"}
    forbidden_blocks = {"RandomBox", "CoinBox", "CoinBrick", "BrickBlock"}
    violations = []
    coverage = Counter()
    flora_coverage = Counter()

    for seed in range(args.first_seed, args.first_seed + args.seeds):
        level = Level(screen, make_mock_sound(), Dashboard("img/sheets/font.png", 8, screen))
        level.load_endless(seed=seed, initial_columns=0)
        level.endlessBuffer = 0
        for _ in range(args.columns + 16):
            level._append_column()

        fill = level.sprites.spriteCollection["underwater_fill"].image
        if fill.get_at((0, 0))[:3] != (32, 56, 236):
            violations.append((seed, "underwater palette", fill.get_at((0, 0))))

        for entity in level.entityList:
            column = int(entity.rect.centerx // 32)
            if not (0 <= column < args.columns):
                continue
            if level.columnBiomes[column] != "underwater":
                continue
            kind = type(entity).__name__
            coverage[kind] += 1
            if kind not in allowed_entities:
                violations.append((seed, "non-aquatic entity", kind, column))

        sprite_names = {
            id(sprite): name
            for name, sprite in level.sprites.spriteCollection.items()
        }
        for row in level.level:
            for column, tile in enumerate(row[: args.columns]):
                if level.columnBiomes[column] != "underwater" or tile is None:
                    continue
                name = sprite_names.get(id(tile.sprite), "")
                if any(token in name.lower() for token in ("mushroomcap", "mushroomstem")):
                    violations.append((seed, "land feature in water", name, column))
        for entity in level.entityList:
            if type(entity).__name__ not in forbidden_blocks:
                continue
            column = int(entity.rect.centerx // 32)
            if 0 <= column < len(level.columnBiomes) and level.columnBiomes[column] == "underwater":
                violations.append((seed, "item/brick block in water", type(entity).__name__, column))

        tall_coral_columns = set()
        waterline_columns = set()
        for overlay in level.overlaySprites:
            name = sprite_names.get(id(overlay["sprite"]), "")
            world_x = overlay["x"] if overlay["pixel"] else overlay["x"] * 32
            column = int(world_x // 32)
            if 0 <= column < len(level.columnBiomes) and level.columnBiomes[column] == "underwater":
                if name == "coral_tall":
                    tall_coral_columns.add(column)
                    flora_coverage["coral_tall"] += 1
                if name == "smb1_underwater_tree_tall":
                    flora_coverage["underwater_plant_tall"] += 1
                if name == "water":
                    waterline_columns.add(column)
        if waterline_columns:
            violations.append((seed, "surface waterline in submerged biome", sorted(waterline_columns)[:5]))
        if "underwater" in level.columnBiomes[: args.columns] and not tall_coral_columns:
            violations.append((seed, "no tall SMB coral cutout", None))

    for flora in ("coral_tall", "underwater_plant_tall"):
        if flora_coverage[flora] == 0:
            violations.append(("all seeds", "missing large underwater flora", flora))

    pygame.quit()
    print(f"Seeds: {args.first_seed}..{args.first_seed + args.seeds - 1}; columns per seed: {args.columns}")
    print("Aquatic entities:", dict(coverage))
    print("Large underwater flora:", dict(flora_coverage))
    print("Violations:", len(violations))
    for failure in violations[:40]:
        print(" -", failure)
    return 1 if violations else 0


if __name__ == "__main__":
    raise SystemExit(main())
