"""Headless check that the game keeps its 4:3 logical display when resizable."""

import os

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")

import pygame


LOGICAL_SIZE = (640, 480)


def main():
    pygame.init()
    screen = pygame.display.set_mode(
        LOGICAL_SIZE,
        pygame.RESIZABLE | pygame.SCALED,
    )
    assert screen.get_size() == LOGICAL_SIZE, screen.get_size()
    assert screen.get_flags() & pygame.RESIZABLE

    # A resize event must not mutate the coordinate surface. SDL's scaled
    # renderer handles mapping between the physical window and this surface.
    pygame.event.post(
        pygame.event.Event(pygame.VIDEORESIZE, size=(960, 720), w=960, h=720)
    )
    pygame.event.pump()
    assert pygame.display.get_surface().get_size() == LOGICAL_SIZE

    pygame.display.quit()
    pygame.quit()
    print("Resizable display check passed (640x480 logical, 4:3 scaled renderer).")


if __name__ == "__main__":
    main()
