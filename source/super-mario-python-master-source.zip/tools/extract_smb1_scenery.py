"""Extract clean, pixel-faithful scenery cutouts from the SMB1 reference sheets.

The uploaded sheets show transparent regions as a three-colour blue checker.
Those exact matte colours are made transparent after cropping; sprite pixels
are otherwise preserved without resampling.
"""

from pathlib import Path
import json

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "img" / "smb1_source"
OUTPUT = ROOT / "img" / "smb1_cutouts"
CHECKER_COLORS = {
    (136, 134, 255),
    (146, 144, 255),
    (108, 106, 255),
}

THEMES = {
    "overworld": 0,
    "underground": 248,
    "castle": 496,
    "underwater": 744,
    "mushrooms": 992,
    "snow": 1240,
}
REGIONS = {
    "cloud_small": (136, 56, 168, 80),
    "cloud_medium": (584, 40, 632, 64),
    "cloud_wide": (440, 56, 504, 80),
    "hill_round": (184, 200, 248, 216),
    "hill_slope": (256, 197, 304, 216),
    "hill_low": (376, 200, 408, 216),
    "hill_group": (664, 200, 712, 216),
}
CELL_SIZE = (64, 32)


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    source = Image.open(SOURCE / "background_mountains.png").convert("RGBA")
    atlas = Image.new("RGBA", (CELL_SIZE[0] * len(REGIONS), CELL_SIZE[1] * len(THEMES)))
    manifest_sprites = []

    for theme_row, (theme, y_offset) in enumerate(THEMES.items()):
        for region_col, (kind, base_bounds) in enumerate(REGIONS.items()):
            left, top, right, bottom = base_bounds
            bounds = (left, top + y_offset, right, bottom + y_offset)
            image = source.crop(bounds)
            pixels = image.load()
            for y in range(image.height):
                for x in range(image.width):
                    red, green, blue, _alpha = pixels[x, y]
                    if (red, green, blue) in CHECKER_COLORS:
                        pixels[x, y] = (red, green, blue, 0)

            name = f"smb1_{theme}_{kind}"
            if image.getchannel("A").getbbox() is None:
                raise RuntimeError(f"{name} crop is empty")
            if image.getchannel("A").getextrema()[0] != 0:
                raise RuntimeError(f"{name} crop has no transparent matte pixels")
            if image.width > CELL_SIZE[0] or image.height > CELL_SIZE[1]:
                raise RuntimeError(f"{name} is larger than an atlas cell")

            atlas.alpha_composite(
                image, (region_col * CELL_SIZE[0], theme_row * CELL_SIZE[1])
            )
            manifest_sprites.append(
                {
                    "name": name,
                    "x": region_col * CELL_SIZE[0],
                    "y": theme_row * CELL_SIZE[1],
                    "xsize": image.width,
                    "ysize": image.height,
                    "ignoreTileSize": True,
                    "scalefactor": 2,
                    "collision": False,
                    "redrawBg": True,
                }
            )
            print(f"{name}: {image.width}x{image.height}")

    atlas_path = OUTPUT / "scenery_atlas.png"
    atlas.save(atlas_path, optimize=False)
    manifest = {
        "spriteSheetURL": "./img/smb1_cutouts/scenery_atlas.png",
        "type": "background",
        "sprites": manifest_sprites,
    }
    manifest_path = ROOT / "sprites" / "SMB1Scenery.json"
    atlas_entries = {sprite["name"]: sprite for sprite in manifest_sprites}
    if manifest_path.exists():
        # Keep entries from the tree/fence extractor and other loose sheets.
        previous = json.loads(manifest_path.read_text(encoding="utf-8"))
        manifest_sprites.extend(
            sprite for sprite in previous["sprites"] if sprite["name"] not in atlas_entries
        )
    manifest_path.write_text(json.dumps(manifest, indent=4) + "\n", encoding="utf-8")

    preview = Image.new("RGB", (400, 136 * len(THEMES)), (42, 42, 42))
    draw = ImageDraw.Draw(preview)
    for theme_row, theme in enumerate(THEMES):
        row_y = theme_row * 136
        draw.text((8, row_y + 6), theme.upper(), fill="white")
        for y in range(row_y + 26, row_y + 136, 12):
            for x in range(0, 400, 12):
                shade = 66 if ((x // 12 + (y - row_y) // 12) % 2) else 45
                draw.rectangle((x, y, x + 11, y + 11), fill=(shade, shade, shade))
        cloud, hill = (
            atlas.crop((sprite["x"], sprite["y"],
                        sprite["x"] + sprite["xsize"], sprite["y"] + sprite["ysize"]))
            for sprite in (atlas_entries[f"smb1_{theme}_cloud_wide"],
                           atlas_entries[f"smb1_{theme}_hill_slope"])
        )
        cloud = cloud.resize((cloud.width * 2, cloud.height * 2), Image.Resampling.NEAREST)
        hill = hill.resize((hill.width * 2, hill.height * 2), Image.Resampling.NEAREST)
        preview.paste(cloud, (12, row_y + 38), cloud)
        preview.paste(hill, (204, row_y + 42), hill)
        draw.text((12, row_y + 104), "cloud", fill="white")
        draw.text((204, row_y + 104), "hill", fill="white")
    preview_path = ROOT / "test_frames" / "biome_preview.png"
    preview_path.parent.mkdir(exist_ok=True)
    preview.save(preview_path)
    print(f"Wrote {atlas_path.relative_to(ROOT)} and {manifest_path.relative_to(ROOT)}")
    print(f"Wrote {preview_path.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
