"""Download the original SMB1 stage-map PNG references from The Spriters Resource."""

import json
from pathlib import Path
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "img" / "smb1_source" / "levels"
ASSET_IDS = {
    "World1-1": 20592,
    "World1-2": 20594,
    "World1-3": 20595,
    "World1-4": 20597,
    "World2-1": 20599,
    "World2-2": 20600,
    "World2-3": 20602,
    "World2-4": 20604,
    "World3-1": 20606,
    "World3-2": 20608,
    "World3-3": 20609,
    "World3-4": 20611,
    "World4-1": 20613,
    "World4-2": 20615,
    "World4-3": 20619,
    "World4-4": 20620,
    "World5-1": 20622,
    "World5-2": 20624,
    "World5-3": 20626,
    "World5-4": 20628,
    "World6-1": 20629,
    "World6-2": 20630,
    "World6-3": 20632,
    "World6-4": 20633,
    "World7-1": 20634,
    "World7-2": 20635,
    "World7-3": 20636,
    "World7-4": 20637,
    "World8-1": 20638,
    "World8-2": 20639,
    "World8-3": 20640,
    "World8-4": 20641,
}


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    entries = []
    for name, asset_id in ASSET_IDS.items():
        source = f"https://www.spriters-resource.com/media/assets/19/{asset_id}.png"
        request = Request(source, headers={"User-Agent": "Mozilla/5.0"})
        with urlopen(request, timeout=30) as response:
            content_type = response.headers.get_content_type()
            image_data = response.read()
        if content_type != "image/png" or not image_data.startswith(b"\x89PNG\r\n\x1a\n"):
            raise RuntimeError(f"{name} ({asset_id}) did not return a PNG: {content_type}")
        output_path = OUTPUT / f"{name}.png"
        output_path.write_bytes(image_data)
        entries.append(
            {
                "name": name,
                "asset_id": asset_id,
                "source": f"https://www.spriters-resource.com/nes/supermariobros/asset/{asset_id}/",
                "reference_file": output_path.relative_to(ROOT).as_posix(),
                "bytes": len(image_data),
            }
        )
        print(f"Downloaded {name}: {len(image_data)} bytes")
    (OUTPUT / "manifest.json").write_text(
        json.dumps(entries, indent=2) + "\n", encoding="utf-8"
    )
    print(f"Saved {len(entries)} SMB1 stage maps to {OUTPUT.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
