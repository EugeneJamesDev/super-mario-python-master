"""Capture reproducible endless-mode screens and audit basic route reachability.

Run from the repository root:

    python tools/capture_infinity_sections.py --seed 20261008

The script writes 38 numbered screenshots, a contact sheet, and an audit JSON
under ``test_frames/infinity_sections`` by default.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

from tools.capture_frames import (
    make_mock_sound,
    _safe_stand,
    _capture_sky_color,
    _is_base_ground_tile,
)


SCREEN_SIZE = (640, 480)
SECTION_COUNT = 38
SECTION_STRIDE = 18  # two columns of overlap in each 20-column view
FIRST_CENTER = 8
BIOMES = ("normal", "canyon", "ice", "underground", "firebar", "mushroom")


def _verified_jump_profiles():
    """Measured Mario.update integration with current run speed and gravity.

    The integration includes Mario's collision/landing frame and the base
    gravity terminal-speed cap; a JumpTrait-only trajectory is not equivalent.
    """
    return {
        "tap": {
            "frames": 58,
            "run_distance_tiles": 7.25,
            "apex_tiles": 4.3306,
        },
        "max_hold": {
            "frames": 73,
            "run_distance_tiles": 9.125,
            "apex_tiles": 6.1875,
        },
    }


def _ground_surface_row(level, column):
    """Return the top of a contiguous base-ground column, or None for a pit."""
    if not level.level or not 0 <= column < len(level.level[0]):
        return None
    row = len(level.level) - 1
    if not _is_base_ground_tile(level, level.level[row][column]):
        return None
    while row > 0 and _is_base_ground_tile(level, level.level[row - 1][column]):
        row -= 1
    return row


def _analyze_route(level, jump_profile, view_columns):
    width = len(level.level[0]) if level.level else 0
    grounded = [level._column_has_ground(column) for column in range(width)]
    gaps = []
    start = None
    for column, has_ground in enumerate(grounded + [True]):
        if not has_ground and start is None:
            start = column
        elif has_ground and start is not None:
            gaps.append({"start": start, "end": column - 1, "width": column - start})
            start = None

    ground_rows = [
        _ground_surface_row(level, column) if grounded[column] else None
        for column in range(width)
    ]
    height_steps = []
    prior = None
    for column, row in enumerate(ground_rows):
        if row is None:
            continue
        if prior is not None:
            prev_column, prev_row = prior
            if column == prev_column + 1:
                rise = prev_row - row
                if rise > jump_profile["apex_tiles"]:
                    height_steps.append({"from": prev_column, "to": column, "rise_tiles": rise})
        prior = (column, row)

    # Mario's width and edge launching allow a gap to be crossed with less
    # travel than center-to-center range. Keep one tile of safety margin.
    conservative_gap_limit = max(1, int(jump_profile["run_distance_tiles"]) - 1)
    impossible_gaps = [gap for gap in gaps if gap["width"] > conservative_gap_limit]
    landing_failures = []
    for gap in gaps:
        landing_end = min(width, gap["end"] + 1 + conservative_gap_limit)
        if not any(grounded[gap["end"] + 1 : landing_end]):
            landing_failures.append(gap)

    start_column, end_column = view_columns
    intersects = lambda item: item["start"] < end_column and item["end"] >= start_column
    section_gaps = [gap for gap in gaps if intersects(gap)]
    section_impossible = [gap for gap in impossible_gaps if intersects(gap)]
    section_landings = [gap for gap in landing_failures if intersects(gap)]
    section_rises = [
        step for step in height_steps
        if start_column <= step["from"] < end_column
        or start_column <= step["to"] < end_column
    ]
    return {
        "ground_gap_count": len(section_gaps),
        "max_ground_gap_tiles": max((gap["width"] for gap in section_gaps), default=0),
        "ground_gaps": section_gaps,
        "impossible_gap_candidates": section_impossible,
        "landing_failures": section_landings,
        "unreachable_ground_rises": section_rises,
        "continuous_endless_route": not section_impossible and not section_landings and not section_rises,
    }


def _make_contact_sheet(screen, output_dir, sections):
    columns = 5
    thumb_size = (160, 120)
    label_height = 23
    rows = (len(sections) + columns - 1) // columns
    sheet = pygame.Surface(
        (columns * thumb_size[0], rows * (thumb_size[1] + label_height)),
        pygame.SRCALPHA,
    )
    sheet.fill((20, 24, 32))
    font = pygame.font.SysFont("Arial", 12)
    for index, section in enumerate(sections):
        col = index % columns
        row = index // columns
        x = col * thumb_size[0]
        y = row * (thumb_size[1] + label_height)
        image = pygame.image.load(str(output_dir / section["image"]))
        preview = pygame.transform.scale(image, thumb_size)
        sheet.blit(preview, (x, y))
        warning = section["route_audit"]["impossible_gap_candidates"] or section["route_audit"]["landing_failures"] or section["route_audit"]["unreachable_ground_rises"]
        mixed = section["biome_transition_in_view"]
        color = (255, 128, 128) if warning else ((255, 211, 112) if mixed else (230, 230, 230))
        label = f'{index + 1:02d} {section["biome"].upper()}{" MIX" if mixed else ""} x{section["center_column"]}'
        sheet.blit(font.render(label, True, color), (x + 3, y + thumb_size[1] + 3))
    path = output_dir / "contact_sheet.png"
    pygame.image.save(sheet, path)
    return path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--seed", type=int, default=20261008)
    parser.add_argument("--output", type=Path, default=REPO_ROOT / "test_frames/infinity_sections")
    args = parser.parse_args()
    args.output = args.output.resolve()
    os.chdir(REPO_ROOT)

    pygame.init()
    screen = pygame.display.set_mode(SCREEN_SIZE)
    from classes.Camera import Camera
    from classes.Dashboard import Dashboard
    from classes.Level import Level
    from classes.Maths import Vec2D

    output_dir = args.output
    output_dir.mkdir(parents=True, exist_ok=True)

    dashboard = Dashboard("img/sheets/font.png", 8, screen)
    level = Level(screen, make_mock_sound(), dashboard)
    last_center = FIRST_CENTER + (SECTION_COUNT - 1) * SECTION_STRIDE
    # Keep enough generated ground beyond the final screenshot to confirm a
    # safe landing after a gap at the right edge of the last view.
    columns_to_generate = last_center + 12 + 16
    level.load_endless(seed=args.seed, initial_columns=0)
    level.endlessBuffer = 0
    for _ in range(columns_to_generate):
        level._append_column()

    jump_profiles = _verified_jump_profiles()
    jump_profile = jump_profiles["max_hold"]
    sections = []
    for index in range(SECTION_COUNT):
        center = FIRST_CENTER + index * SECTION_STRIDE
        biome = level.columnBiomes[center]
        stand = _safe_stand(level, center, biome, radius=8)
        screen.fill(_capture_sky_color(biome))
        if stand is None:
            player_column = center
            floor_y = None
        else:
            player_column, floor_y = stand

        class MockCameraEntity:
            rect = pygame.Rect(player_column * 32, 0, 32, 32)

            def getPosIndexAsFloat(self):
                return Vec2D(float(player_column), 0)

        camera = Camera(Vec2D(8 - player_column, 0), MockCameraEntity())
        camera.x = camera.pos.x * 32
        camera.y = 0
        level.drawLevel(camera)
        # drawLevel advances nearby enemies one frame; pick the post-update
        # safe standing point so screenshot samples never place Mario inside
        # an enemy that moved into the original sample position.
        updated_stand = _safe_stand(level, player_column, biome, radius=8)
        if updated_stand is not None:
            player_column, floor_y = updated_stand
            stand = updated_stand
        mario = level.sprites.spriteCollection.get("mario_idle")
        if stand is not None and mario and mario.image:
            mario_screen_x = int(round((player_column + camera.pos.x) * 32))
            screen.blit(mario.image, (mario_screen_x, floor_y - mario.image.get_height()))

        filename = f"section_{index + 1:02d}_col{center:04d}_{biome}.png"
        pygame.image.save(screen, output_dir / filename)
        left = max(0, center - 8)
        right = min(len(level.level[0]), left + 20)
        section_route = _analyze_route(level, jump_profile, (left, right))
        view_biomes = sorted(set(level.columnBiomes[left:right]))
        camera_pixel_x = camera.x
        visible_entities = sorted({
            type(entity).__name__
            for entity in level.entityList
            if getattr(entity, "alive", None) is not None
            and getattr(entity, "rect", None) is not None
            and entity.rect.right + camera_pixel_x >= 0
            and entity.rect.left + camera_pixel_x <= SCREEN_SIZE[0]
        })
        sections.append({
            "section": index + 1,
            "image": filename,
            "center_column": center,
            "view_columns": [left, right],
            "biome": biome,
            "biomes_in_view": view_biomes,
            "biome_transition_in_view": len(view_biomes) > 1,
            "safe_stand": None if stand is None else {"column": player_column, "floor_y_px": floor_y},
            "route_audit": section_route,
            "visible_entity_types": visible_entities,
        })

    contact_path = _make_contact_sheet(screen, output_dir, sections)
    report = {
        "seed": args.seed,
        "section_count": len(sections),
        "section_stride_columns": SECTION_STRIDE,
        "jump_profile": jump_profile,
        "jump_profiles": jump_profiles,
        "biomes_seen": sorted({section["biome"] for section in sections}),
        "sections_without_safe_stand": [section["section"] for section in sections if section["safe_stand"] is None],
        "sections_with_route_warnings": [
            section["section"] for section in sections
            if not section["route_audit"]["continuous_endless_route"]
        ],
        "sections_with_biome_boundaries": [
            section["section"] for section in sections if section["biome_transition_in_view"]
        ],
        "route_audit_scope": "Ground gaps and base-ground rises checked against modeled jump profile; enemies and overhead block collisions require gameplay simulation.",
        "contact_sheet": contact_path.name,
        "sections": sections,
    }
    report_path = output_dir / "audit.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"Generated {len(sections)} sections at {output_dir}")
    print(f"Contact sheet: {contact_path}")
    print(f"Biomes seen: {', '.join(report['biomes_seen'])}")
    print(f"Jump profile: {jump_profile['apex_tiles']:.2f} tiles high, {jump_profile['run_distance_tiles']:.2f} tiles horizontal")
    print(f"Sections with geometry warnings: {report['sections_with_route_warnings']}")
    print(f"Audit: {report_path}")
    pygame.quit()


if __name__ == "__main__":
    main()
