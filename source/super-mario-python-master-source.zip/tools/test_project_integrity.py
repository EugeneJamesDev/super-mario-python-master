"""Regress asset-audit exit status and the Windows packaging asset manifest."""

import contextlib
import io
from pathlib import Path
import runpy
from unittest.mock import patch

import audit_assets

ROOT = Path(__file__).resolve().parents[1]


def main():
    with (
        patch.object(audit_assets, "audit_json_sheets", return_value=([], [])),
        patch.object(audit_assets, "audit_sprite_crops", return_value=(0, [])),
        patch.object(audit_assets, "audit_hardcoded_loads", return_value=[]),
        patch.object(audit_assets, "audit_sprite_collection", return_value=([], ["mario_idle"])),
        contextlib.redirect_stdout(io.StringIO()),
    ):
        assert audit_assets.main() == 1, "Missing critical sprites must fail the audit"

    collect = runpy.run_path(str(ROOT / "tools/compile.py"))["collect_data_files"]
    packaged = set()
    for destination, sources in collect():
        for source in sources:
            path = Path(source)
            assert path.is_file(), source
            packaged.add((Path(destination) / path.name).as_posix())
    for manifest in (ROOT / "sprites").glob("*.json"):
        for sheet in audit_assets.collect_sheet_paths(manifest):
            assert Path(sheet).as_posix() in packaged, f"Unpackaged sprite sheet: {sheet}"
    for asset in ("img/sheets/font.png", "img/sheets/maker_smb1_tileset.png", "img/references/title_screen.png", "sfx/main_theme.ogg", "levels/World1-1.json"):
        assert asset in packaged, f"Unpackaged runtime asset: {asset}"
    assert "settings.json" not in packaged, "Do not distribute personal settings"
    assert not any(name.startswith("data/") for name in packaged)
    assert not any(name.startswith("img/smb1_source/levels/") for name in packaged)
    assert not any(name.startswith("img/maker_tileset_cutouts/") for name in packaged)
    missing = ROOT / "sfx/pipe.ogg"
    is_file = Path.is_file
    with patch.object(Path, "is_file", lambda path: path != missing and is_file(path)):
        try:
            collect()
        except FileNotFoundError as error:
            assert "pipe.ogg" in str(error)
        else:
            raise AssertionError("Packaging accepted a missing runtime sound")
    print("PASS: missing critical sprites fail; runtime assets retain their packaged paths")


if __name__ == "__main__":
    main()
