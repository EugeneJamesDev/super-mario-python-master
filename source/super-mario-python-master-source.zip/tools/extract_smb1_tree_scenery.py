"""Extract authentic SMB1 tree and fence cutouts from the original sheet.

The sprite sheet is a labeled composite with a three-color checker matte.
These crops use fixed source coordinates and no interpolation/resizing.
"""

import json
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "img" / "smb1_source" / "background_trees.png"
OUTPUT = ROOT / "img" / "smb1_cutouts"
MANIFEST = ROOT / "sprites" / "SMB1Scenery.json"
MATTE_COLORS = {
    (136, 134, 255),
    (146, 144, 255),
    (108, 106, 255),
}
THEMES = {
    "overworld": 0,
    "underground": 248,
    "castle": 496,
    "underwater": 744,
    "mushrooms": 992,
    "snow": 1240,
}
# (source x1, source y1, source x2, source y2, descriptive suffix)
REGIONS = (
    (177, 186, 191, 216, "tree_round"),
    (385, 186, 399, 216, "tree_oval"),
    (208, 170, 224, 216, "tree_tall"),
    (224, 200, 288, 216, "fence_run"),
)


def cutout(source, bounds):
    image = source.crop(bounds).convert("RGBA")
    pixels = image.load()
    for y in range(image.height):
        for x in range(image.width):
            r, g, b, a = pixels[x, y]
            if (r, g, b) in MATTE_COLORS:
                pixels[x, y] = (r, g, b, 0)
    if image.getchannel("A").getbbox() is None:
        raise RuntimeError(f"Crop is empty: {bounds}")
    if image.getchannel("A").getextrema()[0] != 0:
        raise RuntimeError(f"No transparent matte found in crop: {bounds}")
    return image


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    source = Image.open(SOURCE).convert("RGBA")
    manifest = json.loads(MANIFEST.read_text(encoding="utf-8"))
    sprites = manifest.setdefault("sprites", [])
    old = {sprite["name"]: sprite for sprite in sprites if sprite.get("name")}
    source_regions = []

    for theme, y_offset in THEMES.items():
        for x1, y1, x2, y2, kind in REGIONS:
            bounds = (x1, y1 + y_offset, x2, y2 + y_offset)
            name = f"smb1_{theme}_{kind}"
            image = cutout(source, bounds)
            image.save(OUTPUT / f"{name}.png", optimize=False)
            row = {
                "name": name,
                "spriteSheetURL": f"./img/smb1_cutouts/{name}.png",
                "x": 0,
                "y": 0,
                "xsize": image.width,
                "ysize": image.height,
                "ignoreTileSize": True,
                "scalefactor": 2,
                "collision": False,
                "redrawBg": True,
                "role": "non-solid SMB1 background scenery",
                "sourceFile": "img/smb1_source/background_trees.png",
                "sourceBounds": list(bounds),
            }
            old[name] = row
            source_regions.append({"name": name, "bounds": list(bounds), "size": list(image.size)})

    # Keep existing order and append newly extracted names only once.
    existing_names = {sprite.get("name") for sprite in sprites}
    for name, sprite in old.items():
        if name not in existing_names:
            sprites.append(sprite)
    MANIFEST.write_text(json.dumps(manifest, indent=4) + "\n", encoding="utf-8")
    print(f"Extracted {len(source_regions)} tree/fence cutouts from {SOURCE.name}.")
    for item in source_regions:
        print(f"{item['name']}: {item['bounds']} -> {item['size'][0]}x{item['size'][1]}")


if __name__ == "__main__":
    main()
