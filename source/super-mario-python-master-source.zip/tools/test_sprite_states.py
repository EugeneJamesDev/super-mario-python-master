"""Load every declared animation frame and render key Infinity sprite states.

Run from the repository root:

    python tools/test_sprite_states.py

Outputs sprite-state PNG sheets and a JSON audit under test_frames/sprite_states.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import pygame


def _label(surface, text, x, y, font):
    surface.blit(font.render(text, True, (255, 255, 255)), (x, y))


def _fit(image, max_size=(96, 64)):
    scale = min(max_size[0] / image.get_width(), max_size[1] / image.get_height(), 1)
    size = (max(1, int(image.get_width() * scale)), max(1, int(image.get_height() * scale)))
    return pygame.transform.scale(image, size)


def audit_animation_frames(sprites):
    records = []
    failures = []
    for name, sprite in sorted(sprites.items()):
        animation = getattr(sprite, "animation", None)
        if animation is None:
            continue
        images = getattr(animation, "images", ())
        record = {"sprite": name, "frame_count": len(images), "dimensions": [], "transparent_frames": 0}
        for index, image in enumerate(images):
            record["dimensions"].append(list(image.get_size()))
            if image.get_width() <= 0 or image.get_height() <= 0 or image.get_bounding_rect().width == 0:
                failures.append(f"{name} frame {index + 1}: empty image")
            if image.get_flags() & pygame.SRCALPHA:
                if image.get_bounding_rect(min_alpha=1).width < image.get_width() or image.get_bounding_rect(min_alpha=1).height < image.get_height():
                    record["transparent_frames"] += 1
        if not images:
            failures.append(f"{name}: animation has no frames")
        records.append(record)
    return records, failures


def check_runtime_constructor_states(screen, sprites):
    """Build moving entities and verify their constructor-selected frames."""
    from types import SimpleNamespace
    from entities.Blooper import Blooper
    from entities.BuzzyBeetle import BuzzyBeetle
    from entities.CheepCheep import CheepCheep
    from entities.FireBolt import FireBolt
    from entities.Goomba import Goomba
    from entities.HammerBro import HammerBro, HammerProjectile
    from entities.Koopa import Koopa
    from entities.Lakitu import Lakitu
    from entities.Podoboo import Podoboo

    class LevelStub:
        levelLength = 80
        endless = True
        player = None
        entityList = []
        randomizer = __import__("random").Random(1)
        dashboard = SimpleNamespace(drawText=lambda *args, **kwargs: None)
        level = [[SimpleNamespace(rect=None) for _ in range(80)] for _ in range(20)]

    level = LevelStub()
    sound = SimpleNamespace()
    checks, failures = [], []

    def check(label, animation, expected_keys):
        actual = list(getattr(animation, "images", ())) if animation else []
        expected = [sprites.get(key).image for key in expected_keys]
        passed = len(actual) == len(expected) and all(a is e for a, e in zip(actual, expected))
        checks.append({"entity_state": label, "expected_sprite_keys": expected_keys, "frame_count": len(actual), "passed": passed})
        if not passed:
            failures.append(f"{label}: constructor animation did not select expected sprite frames")

    try:
        check("Goomba walk/squash", Goomba(screen, sprites, 3, 3, level, sound).animation, ["goomba-1", "goomba-2"])
        for variant in ("green", "red"):
            koopa = Koopa(screen, sprites, 3, 3, level, sound, variant=variant)
            body_key = "koopa_red" if variant == "red" else "koopa-1"
            body2_key = "koopa_red-2" if variant == "red" else "koopa-2"
            check(f"Koopa {variant} walking", koopa.animation, [body_key, body2_key])
            shell = koopa._shell_sprite()
            check(f"Koopa {variant} shell", SimpleNamespace(images=[shell.image]), [f"koopa_shell_{variant}"])
        buzzy = BuzzyBeetle(screen, sprites, 3, 3, level, sound)
        check("Buzzy walk", buzzy.animation, ["buzzy_beetle-1", "buzzy_beetle-2"])
        shell = sprites.get("buzzy_shell")
        check("Buzzy shell", SimpleNamespace(images=[shell.image]), ["buzzy_shell"])
        check("FireBolt", FireBolt(screen, sprites, 96, 96, level=level).animation, ["firebolt_1", "firebolt_2"])
        check("HammerBro", HammerBro(screen, sprites, 3, 3, level, sound).animation, ["hammer_bro-1", "hammer_bro-2"])
        projectile = HammerProjectile(screen, sprites, 3, 3, 1, level)
        check("Hammer projectile rotations", projectile.animation, [f"hammer_projectile_{i}" for i in range(1, 5)])
        for variant, keys in (("red", ["cheep_cheep_red", "cheep_cheep_red-2"]), ("green", ["cheep_cheep_green"])):
            check(f"CheepCheep {variant}", CheepCheep(screen, sprites, 3, 3, level, variant=variant).animation, keys)
        check("Blooper swim", Blooper(screen, sprites, 3, 3, level).animation, ["blooper-1", "blooper-2"])
        check("Podoboo pose", Podoboo(screen, sprites, 3, 3, level).animation, ["podoboo"])
        check("Lakitu pose", Lakitu(screen, sprites, 3, 3, level, sound).animation, ["lakitu"])
    except Exception as error:
        failures.append(f"Runtime entity construction failed: {type(error).__name__}: {error}")
    return checks, failures


def animation_frame_sheet(sprites, out_dir, font):
    entries = []
    for name, sprite in sorted(sprites.items()):
        animation = getattr(sprite, "animation", None)
        if animation:
            for index, frame in enumerate(animation.images):
                entries.append((name, index + 1, frame))
    cell_w, cell_h = 116, 96
    columns = 6
    rows = (len(entries) + columns - 1) // columns
    sheet = pygame.Surface((columns * cell_w, rows * cell_h), pygame.SRCALPHA)
    sheet.fill((25, 35, 55))
    for slot, (name, index, frame) in enumerate(entries):
        x, y = (slot % columns) * cell_w, (slot // columns) * cell_h
        pygame.draw.rect(sheet, (10, 20, 36), (x + 3, y + 3, cell_w - 6, cell_h - 6))
        preview = _fit(frame)
        sheet.blit(preview, (x + (cell_w - preview.get_width()) // 2, y + 6))
        _label(sheet, f"{name} {index}", x + 4, y + cell_h - 18, font)
    path = out_dir / "animation_frames.png"
    pygame.image.save(sheet, path)
    return path, len(entries)


def runtime_state_sheet(screen, sprites, out_dir, font):
    """Render all sprite frames used by moving Infinity enemies.

    Some entities (Podoboo, Blooper, Lakitu) are moved by code while using one
    pose. These are represented as distinct labeled runtime phases so their
    actual art and the absence of alternate poses are visible in the report.
    """
    states = [
        ("Goomba walk 1", "goomba-1", False),
        ("Goomba walk 2", "goomba-2", False),
        ("Goomba squashed", "goomba-flat", False),
        ("Koopa green walk 1", "koopa-1", False),
        ("Koopa green walk 2", "koopa-2", False),
        ("Koopa green shell idle", "koopa_shell_green", False),
        ("Koopa green shell moving", "koopa_shell_green", True),
        ("Koopa red walk 1", "koopa_red", False),
        ("Koopa red walk 2", "koopa_red-2", False),
        ("Koopa red shell idle", "koopa_shell_red", False),
        ("Koopa red shell moving", "koopa_shell_red", True),
        ("Koopa hiding transition", "koopa-hiding-with-legs", False),
        ("Buzzy walk 1", "buzzy_beetle-1", False),
        ("Buzzy walk 2", "buzzy_beetle-2", False),
        ("Buzzy shell idle", "buzzy_shell", False),
        ("Buzzy shell moving", "buzzy_shell", True),
        ("FireBolt frame 1 right", "firebolt_1", False),
        ("FireBolt frame 2 right", "firebolt_2", False),
        ("FireBolt frame 1 left", "firebolt_1", True),
        ("FireBolt frame 2 left", "firebolt_2", True),
        ("HammerBro throw pose 1", "hammer_bro-1", False),
        ("HammerBro throw pose 2", "hammer_bro-2", False),
        ("HammerBro reversed pose", "hammer_bro-1", True),
        ("Hammer projectile rotation 1", "hammer_projectile_1", False),
        ("Hammer projectile rotation 2", "hammer_projectile_2", False),
        ("Hammer projectile rotation 3", "hammer_projectile_3", False),
        ("Hammer projectile rotation 4", "hammer_projectile_4", False),
        ("CheepCheep red swim", "cheep_cheep_red", False),
        ("CheepCheep red swim frame 2", "cheep_cheep_red-2", False),
        ("CheepCheep green swim", "cheep_cheep_green", False),
        ("Blooper swim pose", "blooper", False),
        ("Podoboo rising", "podoboo", False),
        ("Podoboo apex", "podoboo", False),
        ("Podoboo falling", "podoboo", True),
        ("Lakitu hover pose", "lakitu", False),
        ("Spiny egg", "spiny_egg", False),
        ("Spiny walking", "spiny", False),
        ("Bullet Bill flight", "bullet_bill", False),
        ("Bill Blaster", "bill_blaster", False),
        ("SMB1 mushroom platform cutout", "smb1_mushroom_platform", False),
    ]
    for i in range(1, 6):
        states.append((f"Bowser green frame {i}", f"bowser_green_{i}", False))
        states.append((f"Bowser red-eye frame {i}", f"bowser_redeyes_{i}", False))
    states.extend([
        ("Green Paratroopa pose", "koopa_paratroopa_green", False),
        ("Red Paratroopa pose", "koopa_paratroopa_red", False),
    ])

    cell_w, cell_h, columns = 132, 100, 6
    rows = (len(states) + columns - 1) // columns
    sheet = pygame.Surface((columns * cell_w, rows * cell_h), pygame.SRCALPHA)
    sheet.fill((23, 30, 45))
    rendered, absent = [], []
    for slot, (label, key, flip) in enumerate(states):
        x, y = (slot % columns) * cell_w, (slot // columns) * cell_h
        pygame.draw.rect(sheet, (10, 20, 36), (x + 3, y + 3, cell_w - 6, cell_h - 6))
        sprite = sprites.get(key)
        image = getattr(sprite, "image", None) if sprite else None
        if image is None:
            absent.append({"state": label, "sprite_key": key})
        else:
            if flip:
                image = pygame.transform.flip(image, True, False)
            preview = _fit(image, (112, 64))
            phase_y = {"Podoboo rising": 19, "Podoboo apex": 5, "Podoboo falling": 30}.get(label, 5)
            sheet.blit(preview, (x + (cell_w - preview.get_width()) // 2, y + phase_y))
        _label(sheet, label, x + 4, y + cell_h - 20, font)
        rendered.append({"state": label, "sprite_key": key, "flipped": flip, "present": image is not None})

    path = out_dir / "runtime_enemy_states.png"
    pygame.image.save(sheet, path)
    return path, rendered, absent


def fireburst_anchor_sheet(sprites, out_dir, font):
    """Show native-size burst frames within the stable 32px draw box."""
    entries = []
    for key in ("fire_burst_down", "fire_burst_small"):
        sprite = sprites.get(key)
        animation = getattr(sprite, "animation", None)
        if animation:
            entries.extend((key, index + 1, frame) for index, frame in enumerate(animation.images))
    cell_w, cell_h = 120, 88
    columns = 5
    rows = (len(entries) + columns - 1) // columns
    sheet = pygame.Surface((columns * cell_w, rows * cell_h), pygame.SRCALPHA)
    sheet.fill((23, 30, 45))
    for slot, (key, index, frame) in enumerate(entries):
        x, y = (slot % columns) * cell_w, (slot // columns) * cell_h
        box_x, box_y = x + (cell_w - 32) // 2, y + 5
        pygame.draw.rect(sheet, (90, 110, 140), (box_x, box_y, 32, 32), 1)
        sheet.blit(frame, (box_x + (32 - frame.get_width()) // 2, box_y + (32 - frame.get_height()) // 2))
        _label(sheet, f"{key} {index} {frame.get_width()}x{frame.get_height()}", x + 3, y + 59, font)
    path = out_dir / "fireburst_centered_frames.png"
    pygame.image.save(sheet, path)
    return path, len(entries)


def moving_state_sheet(screen, sprites, out_dir, font):
    from entities.FireBar import FireBar
    from entities.MovingPlatform import MovingPlatform
    from entities.PiranhaPlant import PiranhaPlant

    class Camera:
        x = 0

    camera = Camera()
    cells = []

    def capture(label, draw, crop_rect):
        screen.fill((12, 22, 43))
        draw()
        image = screen.subsurface(crop_rect).copy()
        cells.append((label, image))

    # Rotating hazard: inspect representative orientations and the corrected
    # hub crop in addition to verifying the segment asset is present.
    firebar = FireBar(screen, 5, 4, segments=4, spriteCollection=sprites)
    for label, angle in (("FireBar horizontal", 0), ("FireBar diagonal", 0.785398), ("FireBar vertical", 1.570796), ("FireBar reverse", 3.141593)):
        firebar.angle = angle
        capture(label, lambda fb=firebar: (fb._advance_rotation(), fb._draw_segments(camera)), pygame.Rect(96, 64, 160, 160))

    # Platforms exercise stationary, midpoint, endpoint, and return travel on
    # both axes, using all generic sizes and the original SMB mushroom variant.
    for size in ("large", "medium", "small", "mushroom"):
        for axis in ("horizontal", "vertical"):
            platform = MovingPlatform(screen, 4, 5, size=size, axis=axis, travel_tiles=3, spriteCollection=sprites)
            for label, path_pos, direction in (("start", 0, 1), ("mid", 48, 1), ("end", platform.travel_distance, -1)):
                platform._path_position = path_pos
                platform._direction = direction
                if label == "start":
                    platform._direction = -1
                    platform._advance_motion()  # verify lower endpoint reversal
                elif label == "end":
                    platform._path_position = platform.travel_distance - platform.speed
                    platform._direction = 1
                    platform._advance_motion()  # verify upper endpoint reversal
                else:
                    platform._advance_motion()
                crop_x = max(0, min(480, platform.rect.centerx - 80))
                crop_y = max(0, min(384, platform.rect.centery - 48))
                capture(f"Platform {size} {axis} {label}", lambda p=platform: screen.blit(p.sprite, (p.rect.x + camera.x, p.rect.y)), pygame.Rect(crop_x, crop_y, 160, 96))

    class LevelStub:
        player = None
        entityList = []
        randomizer = __import__("random").Random(1)

    level = LevelStub()
    for variant in ("green", "underground"):
        for phase_name, phase, ratio in (
            ("hidden", PiranhaPlant.HIDDEN, 0),
            ("rising", PiranhaPlant.RISING, 0.5),
            ("exposed", PiranhaPlant.EXPOSED, 1),
            ("retreating", PiranhaPlant.RETREATING, 0.5),
        ):
            plant = PiranhaPlant(screen, 5, 8, emergence=48, spriteCollection=sprites, level=level, variant=variant)
            plant.phase = phase
            plant.offset = plant.max_extension * ratio
            plant.plant_bottom = round(plant.base_y - plant.offset)
            plant._sync_visible_hitbox()
            crop_x = max(0, min(480, plant.pipe_center_x - 80))
            crop_y = max(0, min(384, plant.pipe_top_px - 24))
            capture(f"Plant {variant} {phase_name}", lambda p=plant: p.update(camera), pygame.Rect(crop_x, crop_y, 160, 96))

    cell_w, cell_h = 160, 140
    columns = 4
    rows = (len(cells) + columns - 1) // columns
    sheet = pygame.Surface((columns * cell_w, rows * cell_h), pygame.SRCALPHA)
    sheet.fill((23, 30, 45))
    for slot, (label, image) in enumerate(cells):
        x, y = (slot % columns) * cell_w, (slot // columns) * cell_h
        preview = pygame.transform.scale(image, (cell_w, 120))
        sheet.blit(preview, (x, y))
        _label(sheet, label, x + 3, y + 123, font)
    path = out_dir / "moving_entity_states.png"
    pygame.image.save(sheet, path)
    return path, [label for label, _ in cells]


def main():
    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    from classes.Sprites import Sprites

    out_dir = ROOT / "test_frames" / "sprite_states"
    out_dir.mkdir(parents=True, exist_ok=True)
    sprites = Sprites().spriteCollection
    font = pygame.font.SysFont("Arial", 10)
    records, failures = audit_animation_frames(sprites)
    constructor_checks, constructor_failures = check_runtime_constructor_states(screen, sprites)
    failures.extend(constructor_failures)
    animation_path, frame_count = animation_frame_sheet(sprites, out_dir, font)
    state_path, state_labels = moving_state_sheet(screen, sprites, out_dir, font)
    runtime_path, runtime_states, absent_states = runtime_state_sheet(screen, sprites, out_dir, font)
    burst_path, burst_frame_count = fireburst_anchor_sheet(sprites, out_dir, font)
    report = {
        "loaded_sprite_count": len(sprites),
        "manifest_animation_count": len(records),
        "manifest_animation_frame_count": frame_count,
        "animation_records": records,
        "moving_states_rendered": state_labels,
        "animation_frame_sheet": animation_path.name,
        "moving_state_sheet": state_path.name,
        "runtime_enemy_state_sheet": runtime_path.name,
        "runtime_enemy_states": runtime_states,
        "runtime_enemy_state_missing_keys": absent_states,
        "runtime_constructor_state_checks": constructor_checks,
        "fireburst_centered_sheet": burst_path.name,
        "fireburst_centered_frame_count": burst_frame_count,
        "authentic_cutouts": {
            "mushroom_platform": "img/smb1_cutouts/smb1_mushroom_platform.png (img/smb1_source/tileset_sheet.png crop x=344 y=728, 48x48)",
            "hammer_projectile": "img/smb1_cutouts/smb1_hammer_projectile.png (img/smb1_source/enemies_sheet.png four rotation frames)",
        },
        "failures": failures,
        "remaining_authenticity_gaps": [
            "An authentic SMB1 mushroom platform cutout is loaded from the local reference tileset and available as the MovingPlatform mushroom variant.",
            "Green CheepCheep, Blooper, Podoboo, and Lakitu have one available pose each; red CheepCheep has two swim frames.",
            "HammerBro's two manifest animation slots resolve to identical pixels; a distinct second SMB1 pose was not found in the local cutouts.",
            "HammerProjectile keeps its existing 16×16 collision box while the recovered four-frame hammer art is drawn at centered 2× scale.",
        ],
    }
    report_path = out_dir / "audit.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(f"Loaded sprites: {len(sprites)}")
    print(f"Manifest animations: {len(records)} ({frame_count} frames rendered)")
    print(f"Moving entity state screenshots: {len(state_labels)}")
    print(f"Runtime enemy sprite states: {len(runtime_states)}; missing keys: {len(absent_states)}")
    print(f"Constructor-driven state checks: {len(constructor_checks)}; failures: {len(constructor_failures)}")
    print(f"FireBurst native-size centered frames: {burst_frame_count}")
    print(f"Image sheets: {animation_path}, {state_path}")
    print(f"Failures: {failures}")
    print(f"Report: {report_path}")
    pygame.quit()
    return 1 if failures or absent_states else 0


if __name__ == "__main__":
    raise SystemExit(main())
