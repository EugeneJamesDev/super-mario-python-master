"""Build a Windows executable with its nested runtime assets (py2exe)."""

from collections import defaultdict
from importlib import import_module
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if __name__ == "__main__":
    sys.path.insert(0, str(ROOT))

from classes.Menu import Menu
from classes.Sound import Sound
from classes.Sprites import Sprites


def collect_data_files():
    """Preserve asset paths used by sprite manifests and runtime loaders."""
    paths = {
        Path("img/sheets/font.png"),
        Path("img/references/title_screen.png"),
        *(Path(path) for path in Sound.ASSET_FILES.values()),
        *(Path(f"levels/{name}.json") for name in Menu.SMB1_STAGES),
    }
    manifests = {Path("sprites") / name for name in Sprites.SPRITE_MANIFESTS}
    manifests.update(path.relative_to(ROOT) for path in (ROOT / "sprites").glob("*.json"))
    for relative in sorted(manifests):
        manifest = ROOT / relative
        if not manifest.is_file():
            raise FileNotFoundError(f"Missing sprite manifest: {relative}")
        paths.add(relative)
        data = json.loads(manifest.read_text(encoding="utf-8"))
        # Sheets can be declared by a manifest, an individual sprite, or a frame.
        sprites = data.get("sprites", [])
        frames = [frame for sprite in sprites for frame in sprite.get("images", [])]
        for entry in (data, *sprites, *frames):
            if sheet := entry.get("spriteSheetURL"):
                paths.add(Path(sheet))
    paths.update(path.relative_to(ROOT) for path in (ROOT / "levels").glob("*.json"))

    groups = defaultdict(list)
    for relative in sorted(paths):
        path = ROOT / relative
        if not path.is_file():
            raise FileNotFoundError(f"Missing runtime asset: {relative}")
        destination = "" if relative.parent == Path(".") else str(relative.parent)
        groups[destination].append(str(path))
    return sorted(groups.items())


if __name__ == "__main__":
    os.chdir(ROOT)
    from setuptools import setup
    import_module("py2exe")  # Registers the py2exe setup command.

    setup(console=[str(ROOT / "main.py")], data_files=collect_data_files())
