"""Focused long-run check for stale endless-mode entity cleanup."""

from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"

import pygame

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from tools.capture_frames import make_mock_sound
from classes.Dashboard import Dashboard
from classes.Level import Level


def main():
    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    level = Level(screen, make_mock_sound(), Dashboard("img/sheets/font.png", 8, screen))
    level.load_endless(seed=20261111, initial_columns=0)

    peak_entities = 0
    pruned_total = 0
    total_columns = 5000
    for column in range(total_columns):
        level._append_column()
        if column % 10 == 0:
            # Match the game's camera position with an 85-column generation
            # buffer ahead of the player and the player at screen tile 10.
            player_column = max(0, level.generatedColumns - level.endlessBuffer)
            camera_x = -max(0, player_column - 10) * 32
            pruned_total += level._prune_endless_entities_behind_camera(camera_x)
        peak_entities = max(peak_entities, len(level.entityList))

    assert pruned_total > 0, "Long seeded run never pruned stale entities"
    assert len(level.entityList) < 500, (
        f"Entity count grew beyond the expected recent-world window: {len(level.entityList)}"
    )

    # The cleanup policy must leave canonical stage entity lists untouched.
    level.endless = False
    sentinel = type("Sentinel", (), {"rect": pygame.Rect(0, 0, 32, 32)})()
    level.entityList = [sentinel]
    removed = level._prune_endless_entities_behind_camera(-100_000)
    assert removed == 0 and level.entityList == [sentinel]

    print(f"columns={total_columns}")
    print(f"entities_pruned={pruned_total}")
    print(f"peak_entities={peak_entities}")
    print(f"final_entities={len(level.entityList)} (canonical sentinel preserved)")
    pygame.quit()


if __name__ == "__main__":
    main()
