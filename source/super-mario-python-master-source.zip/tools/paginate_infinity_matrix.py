"""Create review-sized contact sheets for a completed Infinity matrix run."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame


def _save_pages(records, frame_dir, output_dir, stem, per_page, columns, thumb_size):
    output_dir.mkdir(parents=True, exist_ok=True)
    page_paths = []
    for page_index, start in enumerate(range(0, len(records), per_page), 1):
        chunk = records[start : start + per_page]
        rows = (len(chunk) + columns - 1) // columns
        label_height = 24
        sheet = pygame.Surface(
            (columns * thumb_size[0], rows * (thumb_size[1] + label_height))
        )
        sheet.fill((20, 24, 32))
        font = pygame.font.SysFont("Arial", 11)
        for index, record in enumerate(chunk):
            x = (index % columns) * thumb_size[0]
            y = (index // columns) * (thumb_size[1] + label_height)
            frame = pygame.image.load(str(frame_dir / record["image"]))
            sheet.blit(pygame.transform.scale(frame, thumb_size), (x, y))
            focus = ",".join(record.get("focus_entity", []))
            label = f'{record["seed"]} {record["biome"]} x{record["center_column"]}'
            if focus:
                label += " " + focus
            color = (255, 110, 110) if not record.get("safe_mario_stand", True) else (235, 235, 235)
            sheet.blit(font.render(label[:30], True, color), (x + 2, y + thumb_size[1] + 4))
        path = output_dir / f"{stem}_{page_index:03d}.png"
        pygame.image.save(sheet, path)
        page_paths.append(path.name)
    return page_paths


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    root = Path(__file__).resolve().parents[1]
    parser.add_argument("--input", type=Path, default=root / "test_frames/infinity_matrix")
    parser.add_argument("--per-page", type=int, default=100)
    args = parser.parse_args()
    if args.per_page <= 0:
        parser.error("--per-page must be positive")
    report_path = args.input / "audit.json"
    report = json.loads(report_path.read_text())
    pygame.init()
    pygame.display.set_mode((1, 1))
    pages_dir = args.input / "pages"
    pages_dir.mkdir(parents=True, exist_ok=True)

    records = report["frames"]
    report["contact_sheet_pages"] = _save_pages(
        records, args.input, pages_dir, "all_frames", args.per_page, 5, (160, 120)
    )
    by_biome = {}
    for biome in sorted({record["biome"] for record in records}):
        subset = [record for record in records if record["biome"] == biome]
        by_biome[biome] = _save_pages(
            subset, args.input, pages_dir / biome, f"{biome}",
            args.per_page, 5, (160, 120),
        )
    report["contact_sheet_page_directory"] = "pages/"
    report["contact_sheet_pages_by_biome"] = by_biome
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    print(f"Frames: {len(records)}")
    print(f"All-frame pages: {len(report['contact_sheet_pages'])}")
    print(f"Biome-group pages: {sum(len(paths) for paths in by_biome.values())}")
    print(f"Directory: {pages_dir}")


if __name__ == "__main__":
    main()
