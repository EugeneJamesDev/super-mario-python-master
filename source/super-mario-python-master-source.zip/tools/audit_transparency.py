#!/usr/bin/env python3
"""Classify sprite assets by transparency mode and sync JSON colorKey config.

Modes:
  alpha       - PNG alpha channel; no colorKey needed
  black_key   - Opaque black backdrop; needs colorKey [0, 0, 0]
  opaque      - Solid tile; no transparency

Usage:
    python tools/audit_transparency.py
    python tools/audit_transparency.py --fix-json
    python tools/generate_transparency_canvas.py
"""

from __future__ import annotations

import argparse
import base64
import io
import json
import os
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")

from PIL import Image, ImageDraw

SPRITE_JSON_FILES = sorted((REPO_ROOT / "sprites").glob("*.json"))
OUTPUT_PATH = REPO_ROOT / "test_frames/asset_reports/transparency_audit.json"

ALPHA_THRESHOLD = 0.05
BLACK_THRESHOLD = 0.12

MODE_LABELS = {
    "alpha": "Alpha transparent",
    "black_key": "Black colorkey",
    "opaque": "Opaque tile",
}

# Full tiles use black pixels as texture detail, not as a backdrop to key out.
OPAQUE_TILE_NAMES = frozenset(
    {
        "sky",
        "sky_underground",
        "sky_fortress",
        "ground",
        "ground_alt",
        "ground_underground",
        "ground_underwater",
        "bricks",
        "bricks_underground",
        "hardBlock",
        "hardBlock_underground",
        "blue_hardBlock",
        "blue_bricks",
        "blue_ground",
        "empty",
        "empty_block",
        "iceBlock",
        "castle_brick",
        "castle_question_tile",
        "dirt_black_top",
        "dirt_black_underground",
        "water",
        "lava",
    }
)


def classify_region(image: Image.Image, sprite_name: str | None = None) -> str:
    if sprite_name in OPAQUE_TILE_NAMES:
        return "opaque"
    rgba = image.convert("RGBA")
    pixels = list(rgba.getdata())
    total = max(1, len(pixels))
    transparent = sum(1 for _, _, _, alpha in pixels if alpha < 128)
    # Color keys are exact RGB values; near-black SMB outlines must not be
    # mistaken for a transparent matte.
    black = sum(1 for r, g, b, alpha in pixels if alpha >= 200 and (r, g, b) == (0, 0, 0))

    if transparent / total >= ALPHA_THRESHOLD:
        return "alpha"
    if black / total >= BLACK_THRESHOLD:
        return "black_key"
    return "opaque"


def config_color_key(sprite: dict) -> str:
    if sprite.get("colorKey") is False:
        return "disabled"
    if "colorKey" not in sprite or sprite.get("colorKey") is None:
        return "none"
    if sprite.get("colorKey") == -1:
        return "corner"
    return "black"


def recommended_color_key(mode: str) -> str | None:
    if mode == "black_key":
        return "black"
    if mode == "opaque":
        return "disabled"
    return None


def load_region(sheet_path: Path, sprite: dict, rect: tuple[int, int, int, int]) -> Image.Image | None:
    if not sheet_path.exists():
        return None
    sheet = Image.open(sheet_path).convert("RGBA")
    x, y, w, h = rect
    return sheet.crop((x, y, x + w, y + h))


def checkerboard(size: tuple[int, int], tile: int = 8) -> Image.Image:
    image = Image.new("RGBA", size, (180, 180, 180, 255))
    draw = ImageDraw.Draw(image)
    light = (220, 220, 220, 255)
    dark = (140, 140, 140, 255)
    for y in range(0, size[1], tile):
        for x in range(0, size[0], tile):
            color = light if ((x // tile) + (y // tile)) % 2 == 0 else dark
            draw.rectangle((x, y, x + tile - 1, y + tile - 1), fill=color)
    return image


def preview_data_url(sprite_image: Image.Image) -> str:
    canvas = checkerboard(sprite_image.size)
    canvas.alpha_composite(sprite_image.convert("RGBA"))
    buffer = io.BytesIO()
    canvas.save(buffer, format="PNG")
    encoded = base64.b64encode(buffer.getvalue()).decode("ascii")
    return f"data:image/png;base64,{encoded}"


def iter_sprite_defs(data: dict, json_path: Path):
    default_sheet = data.get("spriteSheetURL")
    sprite_type = data.get("type")
    default_size = data.get("size", (16, 16))

    for sprite in data.get("sprites", []):
        name = sprite.get("name")
        if not name:
            continue

        if sprite_type == "animation":
            for frame_index, image_data in enumerate(sprite.get("images", [])):
                width = int(image_data.get("xsize", sprite.get("xsize", default_size[0])))
                height = int(image_data.get("ysize", sprite.get("ysize", default_size[1])))
                ignore_tile = image_data.get(
                    "ignoreTileSize", sprite.get("ignoreTileSize", False)
                )
                if "xsize" in image_data or "ysize" in image_data:
                    ignore_tile = True
                x, y = int(image_data.get("x", 0)), int(image_data.get("y", 0))
                if not ignore_tile:
                    x, y = x * width, y * height
                sheet_path = image_data.get("spriteSheetURL") or sprite.get(
                    "spriteSheetURL", default_sheet
                )
                yield (
                    json_path,
                    image_data,
                    sheet_path,
                    f"{name}#{frame_index}",
                    (x, y, width, height),
                    image_data.get("colorKey", sprite.get("colorKey")),
                )
            continue

        width = int(sprite.get("xsize", sprite.get("tileWidth", default_size[0])))
        height = int(sprite.get("ysize", sprite.get("tileHeight", default_size[1])))
        ignore_tile = sprite.get("ignoreTileSize", False)
        if sprite_type != "background" or "xsize" in sprite or "ysize" in sprite:
            ignore_tile = True
        x, y = int(sprite.get("x", 0)), int(sprite.get("y", 0))
        if not ignore_tile:
            x, y = x * width, y * height
        sheet_path = sprite.get("spriteSheetURL", default_sheet)
        yield (
            json_path,
            sprite,
            sheet_path,
            name,
            (x, y, width, height),
            sprite.get("colorKey"),
        )


def audit(fix_json: bool) -> dict:
    entries = []
    summary = {
        "alpha": 0,
        "black_key": 0,
        "opaque": 0,
        "ok": 0,
        "mismatch": 0,
        "fixed": 0,
    }

    json_documents: dict[Path, dict] = {}

    for json_path in SPRITE_JSON_FILES:
        data = json.loads(json_path.read_text())
        json_documents[json_path] = data

        for source_path, sprite, sheet_rel, display_name, rect, configured_value in iter_sprite_defs(data, json_path):
            if not sheet_rel:
                continue
            sheet_path = REPO_ROOT / sheet_rel.lstrip("./")
            region = load_region(sheet_path, sprite, rect)
            if region is None:
                continue

            base_name = display_name.split("#", 1)[0]
            mode = classify_region(region, base_name)
            configured = config_color_key({"colorKey": configured_value})
            recommended = recommended_color_key(mode)
            status = "ok"
            if mode == "alpha" and configured in {"black", "corner"}:
                status = "mismatch"
            elif mode == "black_key" and configured not in {"black", "corner"}:
                status = "mismatch"
            elif mode == "opaque" and configured != "disabled":
                status = "mismatch"

            if fix_json and status == "mismatch":
                if mode == "alpha":
                    # A frame can inherit a key from its parent animation.
                    # Override that inheritance explicitly for alpha art.
                    sprite["colorKey"] = False
                elif recommended is None:
                    sprite.pop("colorKey", None)
                elif recommended == "disabled":
                    sprite["colorKey"] = False
                else:
                    sprite["colorKey"] = [0, 0, 0]
                status = "fixed"

            summary[mode] += 1
            summary[status if status in summary else "ok"] += 1

            entries.append(
                {
                    "name": display_name,
                    "jsonFile": json_path.name,
                    "sheetPath": sheet_rel,
                    "mode": mode,
                    "modeLabel": MODE_LABELS[mode],
                    "configuredColorKey": configured,
                    "recommendedColorKey": recommended,
                    "status": status,
                    "previewDataUrl": preview_data_url(region),
                    "width": region.width,
                    "height": region.height,
                }
            )

    if fix_json:
        for json_path, data in json_documents.items():
            json_path.write_text(json.dumps(data, indent=4) + "\n")

    return {
        "generatedAt": __import__("datetime").datetime.now().isoformat(timespec="seconds"),
        "summary": summary,
        "entries": sorted(entries, key=lambda item: (item["mode"], item["name"])),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--fix-json",
        action="store_true",
        help="Update sprite JSON colorKey fields to match detected transparency mode",
    )
    args = parser.parse_args()

    report = audit(fix_json=args.fix_json)
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_text(json.dumps(report, indent=2))
    summary = report["summary"]
    print("Transparency audit")
    print(f"  alpha:      {summary['alpha']}")
    print(f"  black_key:  {summary['black_key']}")
    print(f"  opaque:     {summary['opaque']}")
    print(f"  ok:         {summary['ok']}")
    print(f"  mismatch:   {summary['mismatch']}")
    if args.fix_json:
        print(f"  fixed:      {summary['fixed']}")
    print(f"Wrote {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
