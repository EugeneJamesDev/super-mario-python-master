"""Render deterministic menu and level-picker review images (no audio required)."""
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")

import pygame

from classes.Dashboard import Dashboard
from classes.Level import Level
from classes.Menu import Menu


class SilentChannel:
    def play(self, *args, **kwargs):
        pass

    def stop(self):
        pass


class SilentSound:
    def __init__(self):
        self.music_channel = SilentChannel()
        self.soundtrack = None
        self.allowSFX = False

    def play_sfx(self, *args, **kwargs):
        pass


def main():
    os.chdir(ROOT)
    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    sound = SilentSound()
    dashboard = Dashboard("./img/sheets/font.png", 8, screen)
    level = Level(screen, sound, dashboard)
    menu = Menu(screen, dashboard, level, sound)

    output = ROOT / "test_frames/menu_ui"
    output.mkdir(parents=True, exist_ok=True)

    menu.drawMenuBackground()
    dashboard.drawText("HI SCORE", 272, 18, 10)
    dashboard.drawText(dashboard.highScoreString(), 276, 32, 12)
    menu.drawMenu()
    pygame.image.save(screen, output / "main_menu.png")

    menu.inSettings = True
    menu.state = 0
    menu.drawMenuBackground()
    menu.drawSettings()
    pygame.image.save(screen, output / "settings.png")

    menu.inSettings = False
    menu.inChoosingLevel = True
    menu.levelNames = menu.loadLevelNames()
    for selection, page, filename in (
        (1, "infinity", "infinity_picker.png"),
        (2, "worlds", "world_picker.png"),
    ):
        menu.currSelectedLevel = selection
        menu.picker_page = page
        menu.drawLevelChooser()
        pygame.image.save(screen, output / filename)

    menu.currSelectedLevel = 2
    menu.picker_page = "worlds"
    menu.levelPickerNotice = "World1-1 has not been rebuilt yet"
    menu.drawLevelChooser()
    pygame.image.save(screen, output / "world_picker_notice.png")

    pygame.quit()
    print(f"Captured menu previews in {output}")


if __name__ == "__main__":
    main()
