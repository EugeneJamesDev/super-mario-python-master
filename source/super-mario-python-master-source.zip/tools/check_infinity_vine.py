"""Headless state check for Infinity vine blocks and climbing controls.

The test injects in-memory stand-ins for the vine images so it can validate
the climb/trigger logic before authentic SMB1 crops are bound. It does not
evaluate the final artwork.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ["SDL_VIDEODRIVER"] = "dummy"
os.environ["SDL_AUDIODRIVER"] = "dummy"

import pygame

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from tools.capture_frames import make_mock_sound
from classes.Dashboard import Dashboard
from classes.Level import Level
from classes.Sprite import Sprite
from entities.Mario import Mario


class MockCamera:
    x = 0


def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((640, 480))
    sound = make_mock_sound()
    dashboard = Dashboard("img/sheets/font.png", 8, screen)
    level = Level(screen, sound, dashboard)
    level.load_endless(seed=20261112, initial_columns=0)
    level.endlessBuffer = 0
    for _ in range(64):
        level._append_column()

    # In-memory stand-ins exercise behavior only. The art extraction agent
    # supplies the authentic cutouts used by the game.
    pixel = pygame.Surface((32, 32), pygame.SRCALPHA)
    pixel.fill((0, 180, 0, 255))
    for key in ("smb1_vine_segment", "smb1_vine_tip", "smb1_vine_block"):
        level.sprites.spriteCollection[key] = Sprite(pixel, False)

    column, block_row = 63, 8
    assert level.addRandomBox(column, block_row, "Vine")
    block = next(
        entity for entity in level.entityList
        if type(entity).__name__ == "RandomBox" and entity.grid_position == (column, block_row)
    )
    mario = Mario(column, block_row + 1, level, screen, dashboard, sound)
    mario.rect.y += 4
    mario.vel.y = -10
    mario.moveMario()
    assert block.triggered, "a jump into the block should release the vine"
    block.update(MockCamera())
    vine = next(entity for entity in level.entityList if type(entity).__name__ == "Vine")
    for _ in range(vine.GROW_EVERY_FRAMES * vine.max_segments):
        vine.update(MockCamera())
    assert vine.grown_segments == vine.max_segments

    mario = Mario(column, 5, level, screen, dashboard, sound)
    assert mario.try_attach_vine()
    start_y = mario.rect.y
    mario.climb_input_y = -1
    mario.moveMario()
    assert mario.rect.y < start_y
    assert mario.detach_vine(jump=True)
    assert mario.vel.y < 0
    print("PASS: vine block trigger, full growth, grab, climb, and jump-off")
    pygame.quit()


if __name__ == "__main__":
    main()
