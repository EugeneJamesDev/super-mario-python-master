import asyncio
import os
import sys
from time import perf_counter

import pygame

from classes.Dashboard import Dashboard
from classes.Level import Level
from classes.Menu import Menu
from classes.Paths import PROJECT_ROOT
from classes.Sound import Sound
from entities.Mario import Mario


WINDOW_SIZE = (640, 480)
FRAME_RATE = 60
IS_BROWSER = sys.platform == "emscripten"


def game_frames(browser=False):
    """Run one game session, returning control to the caller after each frame."""
    pygame.mixer.pre_init(44100, -16, 2, 4096)
    pygame.init()
    flags = 0 if browser else pygame.RESIZABLE | pygame.SCALED
    screen = pygame.display.set_mode(WINDOW_SIZE, flags)
    pygame.display.set_caption("Super Mario in Python")
    dashboard = Dashboard("./img/sheets/font.png", 8, screen)
    sound = Sound()
    level = Level(screen, sound, dashboard)
    menu = Menu(screen, dashboard, level, sound)

    while not menu.start:
        menu.update()
        yield

    mario = Mario(0, 0, level, screen, dashboard, sound, character=menu.selected_character)
    while not mario.restart:
        if mario.pause:
            mario.pauseObj.update()
        else:
            if not mario.dying:
                level.drawLevel(mario.camera)
                dashboard.update()
            mario.update()
        pygame.display.flip()
        yield


def main():
    clock = pygame.time.Clock()
    for _ in game_frames():
        clock.tick(FRAME_RATE)
    return "restart"


async def browser_main():
    # Yield on every display callback. A time gate keeps gameplay at 60 Hz
    # on high-refresh displays without blocking the browser's event loop.
    interval = 1 / FRAME_RATE
    while True:
        frames = game_frames(browser=True)
        next_frame = perf_counter()
        while True:
            now = perf_counter()
            if now >= next_frame:
                try:
                    next(frames)
                except StopIteration:
                    break
                next_frame = max(next_frame + interval, now)
            await asyncio.sleep(0)


if __name__ == "__main__":
    os.chdir(PROJECT_ROOT)
    if IS_BROWSER:
        asyncio.run(browser_main())
    else:
        while main() == "restart":
            pass
